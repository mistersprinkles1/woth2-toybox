"""Read the territory / need-zone GUIDs of each map straight from the installed game.

The game ships its content in Unreal IoStore containers (``*.utoc`` index + ``*.ucas``
data, Oodle-compressed 64 KiB blocks).  Per map, the package
``<Map>_SpawnData_All_GeneratedAnimalSigns`` lists every static animal-sign spawner:
its name table references one ``DA_TerritorySigns_<GUID>`` asset per animal territory,
and each spawner record carries the GUID of the need zone it belongs to
(``01 06 02 03`` + 16 bytes).  The Discovery world subsystem stores discovered
territories and need zones as exactly these GUIDs, so the two sets are all we need.

The English display names (animals, weapons, calibers, optics, weather) come from the
``.locres`` string tables inside the classic ``pakchunk0-Windows.pak`` (Oodle-compressed
entries, read with the same decoder).

``python3 woth2_paks.py`` refreshes ``need_zones.json`` and ``names_en.json`` (the
fallbacks used when the game files cannot be found).
"""
import glob, json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import nrgs
import hostos

CACHE = os.path.join(HERE, "need_zones.json")
NAMES_CACHE = os.path.join(HERE, "names_en.json")
APP_ID = "2543830"
GAME_DIR_NAME = "Way of the Hunter 2"
MAPS = ["Map01", "Map02", "Hub"]

# The animals you can hunt in the game (the encyclopedia's ANIMALS list). Game files also hold animals that are not
# in the game; nothing the Toybox ships or shows may name them, so every table built from the game files is cut
# down to these (released_species).
RELEASED_SPECIES = (
    "AepycerosMelampusMelampus", "AlcesAlcesAndersoni", "AnasPlatyrhynchos", "AnasUndulataUndulata", "AntilocapraAmericana", "BisonBisonAthabascae",
    "CanisLupusOccidentalis", "CervusCanadensisNelsoni", "ConnochaetesTaurinusTaurinus", "CrocodylusNiloticus",
    "CrocutaCrocuta", "DamaliscusPygargusPhillipsi", "EquusZebraZebra", "GuloGuloLuscus", "HippopotamusAmphibiusAmphibius",
    "LagopusLeucura", "LepusAmericanusAmericanus", "MeleagrisGallopavoSilvestris", "MellivoraCapensisCapensis",
    "OdocoileusHemionusHemionus", "OdocoileusVirginianusBorealis", "OvisDalliDalli", "PantheraLeoMelanochaita",
    "PhacochoerusAfricanusSundevallii", "StruthioCamelusAustralis", "SusScrofaScrofa", "SyncerusCafferCaffer",
    "TragelaphusStrepsicerosStrepsiceros", "UrsusArctosHorribilis")
# shorter names some game files use for the same animals (configs, decoys)
RELEASED_SPECIES_SHORT = ("MellivoraCapensis", "StruthioCamelus", "OdocoileusHemionus", "AnasUndulata", "MeleagrisGallopavo")

def released_species(sub):
    """True for an animal that is in the game (a subspecies id, its short form or a longer form of it)."""
    sub = sub or ""
    return sub in RELEASED_SPECIES_SHORT or any(sub.startswith(r) for r in RELEASED_SPECIES)

def released_config(name):
    """True for a DA_AnimalConfig_<Sub>_<M|F>[_...] name (or a bare <Sub>_...) of an animal in the game."""
    s = name[len("DA_AnimalConfig_"):] if name.startswith("DA_AnimalConfig_") else name
    return released_species(s.split("_", 1)[0])
ZONE_MARK = b"\x01\x06\x02\x03"

# ---------------------------------------------------------------- locating the game
def steam_libraries():
    roots = []
    if hostos.WINDOWS:
        for hive, key in (("HKCU", r"Software\\Valve\\Steam"), ("HKLM", r"SOFTWARE\\WOW6432Node\\Valve\\Steam"), ("HKLM", r"SOFTWARE\\Valve\\Steam")):
            for name in ("SteamPath", "InstallPath"):
                v = hostos.reg_value(hive, key, name)
                if v:
                    roots.append(hostos.p(v))
        roots += [os.path.join(os.environ.get("ProgramFiles(x86)") or hostos.p(r"C:\\Program Files (x86)"), "Steam"), hostos.p(r"C:\\Program Files\\Steam")]
    roots += [os.path.expanduser(p) for p in ("~/.local/share/Steam", "~/.steam/steam", "~/.steam/root",
                                              "~/.var/app/com.valvesoftware.Steam/.local/share/Steam")]
    libs = []
    for r in roots:
        if not os.path.isdir(r):
            continue
        libs.append(r)
        vdf = os.path.join(r, "steamapps", "libraryfolders.vdf")
        try:
            libs += [hostos.p(x.replace("\\\\", "\\")) for x in re.findall(r'"path"\s+"([^"]+)"', open(vdf, encoding="utf-8", errors="replace").read())]
        except OSError:
            pass
    out = []
    for l in libs:
        l = os.path.realpath(l.replace("\\\\", "\\"))
        if l not in out:
            out.append(l)
    return out

def game_dir_file():
    """Where the app remembers a game folder the user picked by hand (FIND THE GAME FOLDER)."""
    if hostos.WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, "woth2-toybox", "game_dir.txt")

def _has_paks(d):
    return bool(glob.glob(os.path.join(glob.escape(d), "pakchunk*-Windows.utoc")))

def paks_in(folder):
    """The Paks folder inside a folder the user points at (the game folder, WOTH2, Content, Paks, or a library
    holding it a few levels down), or None."""
    if not folder or not os.path.isdir(folder):
        return None
    for sub in ("", os.path.join("WOTH2", "Content", "Paks"), os.path.join("Content", "Paks"), "Paks",
                os.path.join(GAME_DIR_NAME, "WOTH2", "Content", "Paks"),
                os.path.join("common", GAME_DIR_NAME, "WOTH2", "Content", "Paks"),
                os.path.join("steamapps", "common", GAME_DIR_NAME, "WOTH2", "Content", "Paks")):
        d = os.path.join(folder, sub) if sub else folder
        if _has_paks(d):
            return os.path.normpath(d)
    base = folder.rstrip("/\\").count(os.sep)
    for root, dirs, _files in os.walk(folder):             # anything else: look a few levels down
        if root.count(os.sep) - base >= 5:
            dirs[:] = []
            continue
        dirs[:] = [x for x in dirs if not x.startswith(("$", ".")) and x not in ("Windows", "System Volume Information", "Binaries", "Engine")]
        if os.path.basename(root) == "Paks" and _has_paks(root):
            return root
    return None

def _drive_roots():
    if hostos.WINDOWS:
        if os.path.isdir("/mnt"):                           # the wasm core: drives are mounted at /mnt/<letter>
            return [os.path.join("/mnt", x) for x in sorted(os.listdir("/mnt")) if len(x) == 1]
        return [c + ":\\" for c in "CDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.isdir(c + ":\\")]
    return []

def _install_dirs(sa):
    """Game folders a Steam library's appmanifest names (the folder is not always "Way of the Hunter 2")."""
    out = [os.path.join(sa, "common", GAME_DIR_NAME)]
    try:
        m = re.search(r'"installdir"\s+"([^"]+)"', open(os.path.join(sa, f"appmanifest_{APP_ID}.acf"), encoding="utf-8", errors="replace").read())
        if m:
            out.insert(0, os.path.join(sa, "common", m.group(1)))
    except OSError:
        pass
    return out

_FOUND = []
LOOKED = []                                            # where the last search looked (shown when the game is not found)

def find_paks_dir(save_path=None):
    """Directory holding the game's *.utoc / *.ucas files, or None."""
    if os.environ.get("WOTH2_NOGAME") == "1":         # testing the console-player path: act as if the game is not installed
        return None
    if _FOUND:
        return _FOUND[0]
    try:                                               # a folder the user picked in the app wins
        d = paks_in(hostos.p(open(game_dir_file(), encoding="utf-8").read().strip()))
        if d:
            _FOUND.append(d); return d
    except OSError:
        pass
    cands = []
    if save_path:                                     # save lives in <lib>/steamapps/compatdata/<id>/...
        m = re.search(r"^(.*[/\\]steamapps)[/\\]compatdata[/\\]", os.path.realpath(save_path))
        if m:
            cands.append(m.group(1))
    cands += [os.path.join(l, "steamapps") for l in steam_libraries()]
    games = []
    for sa in cands:
        games += _install_dirs(sa)
    if hostos.WINDOWS:                                 # Steam's uninstall entry, then the usual library spots on every drive
        for hive, key in (("HKLM", r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Steam App " + APP_ID),
                          ("HKLM", r"SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Steam App " + APP_ID)):
            v = hostos.reg_value(hive, key, "InstallLocation")
            if v:
                games.append(hostos.p(v))
        for r in _drive_roots():
            for lib in ("SteamLibrary", "Steam", "Steam Library", "Games", os.path.join("Games", "Steam"), os.path.join("Games", "SteamLibrary"),
                        os.path.join("Program Files (x86)", "Steam"), os.path.join("Program Files", "Steam")):
                games += _install_dirs(os.path.join(r, lib, "steamapps"))
            games.append(os.path.join(r, "Games", GAME_DIR_NAME))
            games.append(os.path.join(r, GAME_DIR_NAME))
    LOOKED[:] = list(dict.fromkeys(hostos.host(sa) for sa in cands if os.path.isdir(sa)))[:6]
    for g in games:
        d = os.path.join(g, "WOTH2", "Content", "Paks")
        if _has_paks(d):
            _FOUND.append(d); return d
    return None

def set_game_dir(folder):
    """Remember a game folder the user picked. Returns the Paks folder found in it, or raises ValueError."""
    d = paks_in(hostos.p(folder))
    if not d:
        import i18n
        raise ValueError(i18n.t("No Way of the Hunter 2 game files in that folder. Pick the folder named \"Way of the Hunter 2\" "
                                "(Steam: right-click the game > Manage > Browse local files shows it)."))
    f = game_dir_file()
    os.makedirs(os.path.dirname(f), exist_ok=True)
    with open(f, "w", encoding="utf-8") as fh:
        fh.write(hostos.host(d))
    del _FOUND[:]
    return d

def game_build(paks_dir):
    """Short fingerprint of the installed game build (names + sizes of its containers): every patch changes it,
    so caches built from the game files can tell they are stale. '' when the game is not found."""
    if not paks_dir:
        return ""
    import hashlib
    h = hashlib.sha1()
    try:                                               # blocks the app appended itself (gamepatch.py) are not a game update
        import gamepatch
        grown = gamepatch.patched_sizes()
    except Exception:
        grown = {}
    for f in sorted(glob.glob(os.path.join(paks_dir, "*.utoc")) + glob.glob(os.path.join(paks_dir, "*.ucas")) + glob.glob(os.path.join(paks_dir, "*.pak"))):
        size = os.path.getsize(f)
        orig, patched = grown.get(os.path.basename(f), (None, None))
        if orig is not None and size == patched:
            size = orig
        h.update(f"{os.path.basename(f).lower()}:{size};".encode())
    return h.hexdigest()[:12]

# ---------------------------------------------------------------- IoStore reader
class _OffLen:
    """The .utoc chunk table: entry i -> (offset, length), two 40-bit big-endian numbers, read when asked."""
    __slots__ = ("b", "p", "n")
    def __init__(self, b, p, n): self.b, self.p, self.n = b, p, n
    def __len__(self): return self.n
    def __getitem__(self, i):
        if i < 0: i += self.n
        if not 0 <= i < self.n: raise IndexError(i)
        q = self.p + 10 * i
        return int.from_bytes(self.b[q:q + 5], "big"), int.from_bytes(self.b[q + 5:q + 10], "big")

class _Blocks:
    """The .utoc compression blocks: entry i -> (offset, compressed size, size, method), read when asked."""
    __slots__ = ("b", "p", "n")
    def __init__(self, b, p, n): self.b, self.p, self.n = b, p, n
    def __len__(self): return self.n
    def __getitem__(self, i):
        if i < 0: i += self.n
        if not 0 <= i < self.n: raise IndexError(i)
        q = self.p + 12 * i; e = self.b[q:q + 12]
        return int.from_bytes(e[:5], "little"), int.from_bytes(e[5:8], "little"), int.from_bytes(e[8:11], "little"), e[11]

class Toc:
    """One .utoc: chunk table, compression blocks and the directory index (file path -> chunk)."""
    def __init__(self, path, ucas=None):
        self.path = path
        self.ucas = ucas or path[:-5] + ".ucas"         # gamepatch reads a pristine .utoc backup against the live .ucas
        b = open(path, "rb").read()
        if b[:16] != b"-==--==--==--==-":
            raise ValueError("not a .utoc file")
        ver, hdr, ecount, cbcount, _cbsize, cmcount, cmlen, self.cbs, dirsz, _pcount = struct.unpack_from("<BxxxIIIIIIIII", b, 16)
        self.flags = b[80]
        phs, _psize, nph = struct.unpack_from("<IQI", b, 84)
        if self.flags & 2:
            raise ValueError("encrypted container")
        if self.flags & 4:
            raise ValueError("signed container not supported")
        p = hdr + 12 * ecount                          # skip chunk ids
        self.ol = _OffLen(b, p, ecount)                 # decoded entry by entry when asked (all up front took ~1.9 s)
        p += 10 * ecount
        if ver >= 4:
            p += 4 * phs
        if ver >= 5:
            p += 4 * nph
        self.blocks = _Blocks(b, p, cbcount)
        p += 12 * cbcount
        self.methods = [None] + [b[p + cmlen * i:p + cmlen * i + cmlen].split(b"\0")[0].decode() for i in range(cmcount)]
        p += cmlen * cmcount
        self.files = {}
        if self.flags & 8 and dirsz:
            self._directory(b[p:p + dirsz])

    def _directory(self, d):
        def fstr(p):
            n, = struct.unpack_from("<i", d, p); p += 4
            if n < 0:
                return d[p:p - 2 * n - 2].decode("utf-16-le"), p - 2 * n
            return d[p:p + n - 1].decode(), p + n
        mount, p = fstr(0)
        n, = struct.unpack_from("<I", d, p); p += 4
        dirs = [struct.unpack_from("<IIII", d, p + 16 * i) for i in range(n)]; p += 16 * n
        n, = struct.unpack_from("<I", d, p); p += 4
        files = [struct.unpack_from("<III", d, p + 12 * i) for i in range(n)]; p += 12 * n
        n, = struct.unpack_from("<I", d, p); p += 4
        strs = []
        for _ in range(n):
            s, p = fstr(p); strs.append(s)
        NONE = 0xFFFFFFFF
        stack = [(0, mount)]
        while stack:
            di, prefix = stack.pop()
            while di != NONE:
                name, child, sib, fe = dirs[di]
                path = prefix + (strs[name] if name != NONE else "") + "/"
                while fe != NONE:
                    fn, nxt, ud = files[fe]
                    self.files[path + strs[fn]] = ud
                    fe = nxt
                if child != NONE:
                    stack.append((child, path))
                di = sib

    def read(self, idx):
        off, ln = self.ol[idx]
        first, last = off // self.cbs, (off + ln - 1) // self.cbs
        out = bytearray()
        with hostos.open_big(self.ucas, "rb") as f:
            for bi in range(first, last + 1):
                bo, cs, us, m = self.blocks[bi]
                f.seek(bo)
                raw = f.read(cs)
                if m == 0:
                    out += raw
                elif self.methods[m].lower() == "oodle":
                    out += nrgs.oodle_decompress(raw, us)
                else:
                    raise ValueError("unsupported compression " + self.methods[m])
        start = off - first * self.cbs
        return bytes(out[start:start + ln])

_toc_cache = {}
def all_tocs(paks_dir):
    """Parsed Toc objects for every pakchunk container (cached per process)."""
    out = []
    for f in sorted(glob.glob(os.path.join(paks_dir, "pakchunk*-Windows.utoc"))):
        if f not in _toc_cache:
            _toc_cache[f] = Toc(f)
        out.append(_toc_cache[f])
    return out

def find_package(paks_dir, basename):
    """-> (Toc, chunk index) of the first package whose file name matches."""
    for t in all_tocs(paks_dir):
        for path, idx in t.files.items():
            if path.endswith("/" + basename):
                return t, idx
    raise FileNotFoundError(basename)

# ---------------------------------------------------------------- zen package names
def package_names(data):
    """Name map of a cooked (zen) package."""
    hasver, = struct.unpack_from("<I", data, 0)
    p = 60
    if hasver:
        p += 16
        n, = struct.unpack_from("<i", data, p); p += 4 + 20 * n
    cnt, _nbytes, _hv = struct.unpack_from("<IIQ", data, p); p += 16
    p += 8 * cnt
    hdrs = [struct.unpack_from(">H", data, p + 2 * i)[0] for i in range(cnt)]; p += 2 * cnt
    names = []
    for h in hdrs:
        ln = h & 0x7FFF
        if h & 0x8000:
            names.append(data[p:p + 2 * ln].decode("utf-16-le")); p += 2 * ln
        else:
            names.append(data[p:p + ln].decode("latin-1")); p += ln
    return names

def guid_from_text(s):
    """UE prints an FGuid as four big-endian u32 hex groups; the save stores the u32s little-endian."""
    return struct.pack("<IIII", *[int(s[i:i + 8], 16) for i in range(0, 32, 8)])

# ---------------------------------------------------------------- the actual data
def map_guids_from_game(paks_dir, mapname):
    """-> (territory GUIDs, need-zone GUIDs) as sorted lists of 16-byte values: only the herds the map shows (released,
    no test or empty mission herds) and their zones - what the Hunter page counts and "discover all" writes. Taken from
    the level data (the zones each territory really lists); the sign packages below are only the fallback (they list
    unused zones and miss some)."""
    try:
        import mapdata
        return mapdata.level_guids(paks_dir, mapname, shown_only=True)
    except Exception:
        pass
    toc, idx = find_package(paks_dir, f"{mapname}_SpawnData_All_GeneratedAnimalSigns.uasset")
    pk = toc.read(idx)
    names = package_names(pk)
    terr = {guid_from_text(s) for s in re.findall(r"DA_TerritorySigns_([0-9A-F]{32})$", "\n".join(names), re.M)}
    zones = {m.group(1) for m in re.finditer(re.escape(ZONE_MARK) + rb"(.{16})", pk, re.S)}
    if not terr or not zones:
        raise ValueError(f"no territories/zones found in {mapname} sign data")
    return sorted(terr), sorted(zones)

def load_cache():
    with open(CACHE) as f:
        j = json.load(f)
    return {m: (sorted(bytes.fromhex(g) for g in v["territories"]), sorted(bytes.fromhex(g) for g in v["zones"])) for m, v in j["maps"].items()}

def all_map_guids(save_path=None, prefer_cache=False):
    """{map: (territories, zones)} from the installed game, else from need_zones.json.
    Returns (data, source)."""
    if not prefer_cache:
        paks = find_paks_dir(save_path)
        if paks:
            try:
                return _game_guids_cached(paks), "game files"
            except Exception as e:                    # fall back to the shipped list
                err = e
        else:
            err = "game files not found"
    try:
        return load_cache(), f"need_zones.json ({err})" if not prefer_cache else "need_zones.json"
    except OSError:
        raise RuntimeError(f"cannot read need-zone data: {err}; and no {CACHE}")

def _user_cache_file(name):
    if hostos.WINDOWS:
        root = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local"), "woth2-toybox")
    else:
        root = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "woth2-save-editor")
    return os.path.join(root, name)

def _game_guids_cached(paks):
    """map_guids_from_game for every map, kept on disk per game build: reading them from the level data of all
    maps took ~2.6 s, and every command needs them. A game patch changes the build, and they are read again."""
    build = game_build(paks)
    path = _user_cache_file("map_guids.json")
    try:
        with open(path) as f:
            j = json.load(f)
        if j.get("game") == build and set(j.get("maps", {})) == set(MAPS):
            return {m: ([bytes.fromhex(g) for g in v["territories"]], [bytes.fromhex(g) for g in v["zones"]]) for m, v in j["maps"].items()}
    except (OSError, ValueError, KeyError, TypeError):
        pass
    data = {m: map_guids_from_game(paks, m) for m in MAPS}
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            f.write(json.dumps({"game": build, "maps": {m: {"territories": [g.hex() for g in t], "zones": [g.hex() for g in z]} for m, (t, z) in data.items()}}))
        os.replace(tmp, path)
    except OSError:
        pass
    return data

def write_cache(data, source):
    j = {"note": "territory / need-zone GUIDs per map, from the game files", "maps":
         {m: {"territories": [g.hex() for g in t], "zones": [g.hex() for g in z]} for m, (t, z) in data.items()}}
    with open(CACHE, "w") as f:
        json.dump(j, f)

# ---------------------------------------------------------------- classic .pak (localization lives here)
PAK_MAGIC = 0x5A6F12E1

def _pstr(b, p):
    """FString as the pak index stores it (may lack the NUL)."""
    n, = struct.unpack_from("<i", b, p); p += 4
    if n < 0:
        return b[p:p - 2 * n].decode("utf-16-le").rstrip("\0"), p - 2 * n
    return b[p:p + n].rstrip(b"\0").decode("utf-8", "replace"), p + n

class Pak:
    """UE pak v11/v12 index reader: ``files`` maps path -> encoded entry offset; ``read(path)`` extracts."""
    def __init__(self, path):
        self.path = path
        self.f = hostos.open_big(path, "rb")
        self.f.seek(0, 2); size = self.f.tell()
        self.f.seek(max(0, size - 256)); tail = self.f.read()
        m = tail.rfind(struct.pack("<I", PAK_MAGIC))
        if m < 0:
            raise ValueError("not a pak file")
        if tail[m - 1]:
            raise ValueError("encrypted pak")
        self.ver, ioff, isize = struct.unpack_from("<IQQ", tail, m + 4)
        mp = m + 4 + 4 + 8 + 8 + 20 + (1 if 9 <= self.ver <= 10 else 0)
        self.methods = [None]
        while mp + 32 <= len(tail):
            self.methods.append(tail[mp:mp + 32].split(b"\0")[0].decode()); mp += 32
        self.f.seek(ioff); idx = self.f.read(isize)
        p = 0
        self.mount, p = _pstr(idx, p)
        p += 4 + 8                                    # entry count, path hash seed
        has, = struct.unpack_from("<i", idx, p); p += 4
        if has:
            p += 8 + 8 + 20
        has, = struct.unpack_from("<i", idx, p); p += 4
        fdi_off, fdi_size = struct.unpack_from("<QQ", idx, p); p += 16 + 20
        n, = struct.unpack_from("<i", idx, p); p += 4
        self.encoded = idx[p:p + n]
        self.f.seek(fdi_off); fdi = self.f.read(fdi_size)
        p = 0
        ndirs, = struct.unpack_from("<i", fdi, p); p += 4
        self.files = {}
        for _ in range(ndirs):
            d, p = _pstr(fdi, p)
            nf, = struct.unpack_from("<i", fdi, p); p += 4
            for _ in range(nf):
                fn, p = _pstr(fdi, p)
                eo, = struct.unpack_from("<i", fdi, p); p += 4
                self.files[d + fn] = eo

    def _entry(self, eo):
        e = self.encoded
        flags, = struct.unpack_from("<I", e, eo); p = eo + 4
        method = (flags >> 23) & 0x3F; nblocks = (flags >> 6) & 0xFFFF; bsbits = flags & 0x3F
        off, = struct.unpack_from("<I" if flags >> 31 & 1 else "<Q", e, p); p += 4 if flags >> 31 & 1 else 8
        unc, = struct.unpack_from("<I" if flags >> 30 & 1 else "<Q", e, p); p += 4 if flags >> 30 & 1 else 8
        blocks, blocksize = [], 0
        if method:
            sz, = struct.unpack_from("<I" if flags >> 29 & 1 else "<Q", e, p); p += 4 if flags >> 29 & 1 else 8
            if bsbits == 0x3F:
                blocksize, = struct.unpack_from("<I", e, p); p += 4
            else:
                blocksize = bsbits << 11
            if nblocks == 1:
                blocks = [sz]
            else:
                blocks = list(struct.unpack_from(f"<{nblocks}I", e, p))
        return off, unc, method, blocks, blocksize

    def read(self, path):
        off, unc, method, blocks, blocksize = self._entry(self.files[path])
        hdr = 8 + 8 + 8 + 4 + 20 + 1 + 4 + (4 + 16 * len(blocks) if method else 0)   # FPakEntry copy before the data
        pos = off + hdr
        if not method:
            self.f.seek(pos); return self.f.read(unc)
        out = bytearray(); remain = unc
        if not blocksize:
            blocksize = unc
        for cs in blocks:
            self.f.seek(pos); raw = self.f.read(cs); pos += cs
            us = min(blocksize, remain); remain -= us
            if self.methods[method].lower() != "oodle":
                raise ValueError("unsupported pak compression " + self.methods[method])
            out += nrgs.oodle_decompress(raw, us)
        return bytes(out)

LOCRES_MAGIC = bytes.fromhex("0E147475674A03FC4A15909DC3377F1B")

def _lstr(b, p):
    n, = struct.unpack_from("<i", b, p); p += 4
    if n < 0:
        return b[p:p - 2 * n - 2].decode("utf-16-le"), p - 2 * n
    return b[p:p + n - 1].decode("utf-8", "replace"), p + n

def parse_locres(b):
    """-> {namespace: {key: text}}"""
    if b[:16] != LOCRES_MAGIC:
        raise ValueError("not a locres file")
    ver = b[16]; p = 17
    arr_off, = struct.unpack_from("<q", b, p); p += 8
    if ver >= 2:
        p += 4
    nns, = struct.unpack_from("<I", b, p); p += 4
    strings = []
    q = arr_off
    n, = struct.unpack_from("<i", b, q); q += 4
    for _ in range(n):
        s, q = _lstr(b, q); strings.append(s)
        if ver >= 3:
            q += 4
    out = {}
    for _ in range(nns):
        if ver >= 2:
            p += 4
        ns, p = _lstr(b, p)
        nk, = struct.unpack_from("<I", b, p); p += 4
        d = out.setdefault(ns, {})
        for _ in range(nk):
            if ver >= 2:
                p += 4
            key, p = _lstr(b, p); p += 4
            idx, = struct.unpack_from("<i", b, p); p += 4
            d[key] = strings[idx]
    return out

NAME_TABLES = ["AnimalsRelease", "ProductsRelease", "UIRelease", "MetagameRelease"]
NAME_KEEP = re.compile(r"^(KEY_ANIMALS_SUBSPECIES_\w+_NAME(_LATIN)?|KEY_GEAR_[\w-]+_NAME|KEY_WEATHERFORECAST_PRESET_\w+|KEY_ENVIRONMENT_\w+_NAME)$")

def released_name_keys():
    """The name keys the Toybox may use: the ones in the shipped names_en.json (released animals, gear, lands and
    weather only). The game's text tables also name things that are not in the game; those never get through."""
    try:
        with open(NAMES_CACHE, encoding="utf-8") as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return None

def names_from_game(paks_dir, every=False):
    """English display-name table {KEY: text}, trimmed to what the editor uses (and to released_name_keys unless
    every=True, which only the names_en.json refresh below uses)."""
    pak = Pak(os.path.join(paks_dir, "pakchunk0-Windows.pak"))
    out = {}
    for t in NAME_TABLES:
        path = next((p for p in pak.files if p.endswith(f"/Localization/{t}/en-US/{t}.locres")), None)
        if not path:
            continue
        for ns, kv in parse_locres(pak.read(path)).items():
            for k, v in kv.items():
                if NAME_KEEP.match(k):
                    out.setdefault(k, v)
    if len(out) < 100:
        raise ValueError("localization tables not found")
    keep = None if every else released_name_keys()
    if keep is not None:
        out = {k: v for k, v in out.items() if k in keep}
    return out

def game_lines(tables, lang, paks_dir=None):
    """{English line: the game's own line in that language} for these text tables (same key in both; lang as the
    app has it, pt_BR -> the game's pt-BR). {} without the game files or that language."""
    paks_dir = paks_dir or find_paks_dir()
    if not paks_dir or not lang:
        return {}
    loc = lang.replace("_", "-")
    pak = Pak(os.path.join(paks_dir, "pakchunk0-Windows.pak"))
    out = {}
    for t in tables:
        en = next((p for p in pak.files if p.endswith(f"/Localization/{t}/en-US/{t}.locres")), None)
        tr = next((p for p in pak.files if p.endswith(f"/Localization/{t}/{loc}/{t}.locres")), None)
        if not en or not tr:
            continue
        a, b = parse_locres(pak.read(en)), parse_locres(pak.read(tr))
        for ns, kv in a.items():
            for k, v in kv.items():
                w = b.get(ns, {}).get(k)
                if v and w:
                    out.setdefault(v, w)
    return out

def english_names(save_path=None, prefer_cache=False):
    """-> (names dict, source)"""
    if not prefer_cache:
        paks = find_paks_dir(save_path)
        if paks:
            try:
                return names_from_game(paks), "game files"
            except Exception as e:
                err = e
        else:
            err = "game files not found"
    try:
        with open(NAMES_CACHE) as f:
            return json.load(f), "names_en.json"
    except OSError:
        return {}, f"no names ({err})"

if __name__ == "__main__":
    paks = find_paks_dir()
    if not paks:
        sys.exit("game files not found")
    data = {m: map_guids_from_game(paks, m) for m in MAPS}
    for m, (t, z) in data.items():
        print(f"{m}: {len(t)} territories, {len(z)} need zones")
    write_cache(data, paks)
    print("wrote", CACHE)
    # names_en.json is also the list of names the app may use: only names already in it are refreshed. A name the game
    # adds (a patch) is listed here and left out; add it to names_en.json by hand once it is really in the game.
    every = names_from_game(paks, every=True)
    keep = released_name_keys() or set()
    names = {k: v for k, v in every.items() if k in keep}
    with open(NAMES_CACHE, "w") as f:
        json.dump(names, f, indent=0, sort_keys=True)
    print(f"wrote {NAMES_CACHE} ({len(names)} names)")
    new = sorted(set(every) - keep)
    if new:
        print(f"left out {len(new)} names not in names_en.json (check by hand):", ", ".join(new))
