"""The Encyclopedia: the game's own Codex (animals, maps and lands, guides, gear, people) read straight from the
game files, plus the chapters on how trophies, stars and herd fitness really work (taken from the game's code,
2026-10-06: star rule FUN_1456dbc20, score sum FUN_1457e4850, measurement blueprints, BP_HerdAnimalSubspecies,
C_FitnessDifferenceMultiplier / C_AgeMultiplier curves, DA_HerdEcosystem_*, BPFL_Commands_UI health states).

build(paks_dir) -> dict; load(paks_dir) caches it per game build next to the map caches.
Output: {"version", "game", "categories": [{"id", "title", "blurb", "articles": [article]}]}
article = {"id", "title", "subtitle", "group", "tags": [str], "blocks": [block]}
block   = {"h": str} | {"p": str} | {"list": [str]} | {"facts": [[label, value]]} |
          {"table": {"cols": [str], "rows": [[str]]}} | {"note": str}
Nothing here touches the save.
"""
import math, json, os, re, struct, sys

VERSION = 33

# Items the game still names in its text but took out of the game (Patch 1.2): never sold, nothing to buy.
PULLED = {"KEY_GEAR_WEAPONS_CROSSBOW08", "KEY_GEAR_ATTACHMENTS_BOWSIGHT06", "KEY_GEAR_ATTACHMENTS_CROSSBOWSIGHT06",
          "KEY_GEAR_ATTACHMENTS_SCOPE04_CUSTOM01",
          "KEY_GEAR_ATTACHMENTS_BIPOD01",            # Primacy Gaya: has an item but is never sold
          "KEY_GEAR_AMBUSHING_HUNTINGSTAND01"}       # the map's built hunting stands, not gear
MAPS = {"Map01": "New Laurentia", "Map02": "Kilimaya Reserve", "Hub": "Hearth & Hunt Headquarters"}
MAP_KEYS = {"Map01": "MAP01", "Map02": "MAP02", "Hub": "MAPHUB"}

# ---------------------------------------------------------------- string tables
def _fstr(b, p):
    n, = struct.unpack_from("<i", b, p); p += 4
    if n == 0:
        return "", p
    if n < 0:
        return b[p:p - 2 * n].decode("utf-16-le", "replace").rstrip("\0"), p - 2 * n
    return b[p:p + n].decode("utf-8", "replace").rstrip("\0"), p + n

def _parse_table(dat):
    for start in range(0, 64):
        try:
            p = start
            ns, p = _fstr(dat, p)
            cnt, = struct.unpack_from("<i", dat, p); p += 4
            if not ns or not (0 < cnt < 100000):
                continue
            out = {}
            for _ in range(cnt):
                k, p = _fstr(dat, p); v, p = _fstr(dat, p); out[k] = v
            return out
        except (struct.error, UnicodeDecodeError):
            continue
    return {}

def clean(s):
    """Game rich text -> plain text."""
    s = re.sub(r"\{([A-Za-z0-9_]+)\}\|displayAs\(Input\)", r"[\1]", s or "")
    s = re.sub(r"\{([A-Za-z0-9_]+)\}\|[a-zA-Z]+\([^)]*\)", r"\1", s)
    s = re.sub(r"<[^>]*>", "", s)
    s = re.sub(r"\[s\].*?\[/s\]\s*", "", s)
    s = re.sub(r"\[/?[a-z]\]", "", s)
    s = s.replace("[IA_", "[").replace("\r", "")
    s = re.sub(r"^Migrating(?=[A-Z])", "Migrating/", s)
    for a, b in GAME_TEXT_FIXES: s = s.replace(a, b)
    return re.sub(r"[ \t]+", " ", s).strip()

# plain typos in the game's own text
GAME_TEXT_FIXES = [
    ("enough or at all. and you", "enough or at all, and you"), ("second-most exporter", "second-largest exporter"),
    ("variety of game animals as in", "variety of game animals than in"), ("other you have to buy", "others you have to buy"),
    ("optics with a night or thermal vision", "optics with night or thermal vision"), ("it‘s", "it's"),
    ("cause hundreds of people killed each year", "kill hundreds of people each year"), ("an hour of more", "an hour or more"),
    ("life cycle exposable to ambushes", "life cycle exposes it to ambushes"), ("isolating their warm skin", "insulating their warm skin"),
    ("shadows of brown", "shades of brown"), ("averagely-sized", "average-sized"), ("antlers-bearing", "antler-bearing"),
    ("Dall's Sheep", "Dall's sheep"), ("Dall’s Sheep", "Dall’s sheep"), ("North-western", "Northwestern"),
    ("mid-sized lense", "mid-sized lens"), ("landfowls", "landfowl"), ("suitable to carry", "suitable for carrying"),
    ("on mid-range and longer distances", "at mid-range and longer distances"), ("offroad", "off-road"),
    ("give animals a bedding", "give animals bedding"), ("a hunch on its back", "a hump on its back"), ("The hunch is", "The hump is"),
    ("Active during 8:00-", "Active during 08:00-"),
]

# ---------------------------------------------------------------- game file scan
def _scan(paks_dir):
    """One pass over the game files: string tables, subspecies assets, guide assets, herd ecosystems."""
    import woth2_paks as paks, zenpkg
    tables, subs, guides, eco = {}, {}, {}, {}
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            b = path.rsplit("/", 1)[-1]
            if not b.endswith(".uasset"):
                continue
            if b.startswith("ST_"):
                try:
                    d = _parse_table(zenpkg.ZenPackage(t.read(i)).export_data[0])
                except Exception:
                    continue
                if d:
                    tables.setdefault(b[:-7], {}).update(d)
            elif b.startswith("DA_AnimalSubspecies_"):
                subs[b[20:-7]] = t.read(i)
            elif re.match(r"DA_Guide\d+\.uasset$", b):
                guides[b[3:-7]] = t.read(i)
            elif b.startswith("DA_HerdEcosystem_"):
                eco[b[17:-7]] = t.read(i)
            elif re.match(r"BP_(Firearm|Bow|Crossbow)(_[A-Za-z0-9_]+)?\.uasset$", b):
                tables.setdefault("_weapon_bp", {})[b[:-7]] = t.read(i)
            elif re.match(r"DA_MetaData_(Rifle|Shotgun|Bow\d|Crossbow\d)", b):
                tables.setdefault("_weapon_meta", {})[b[12:-7]] = t.read(i)
            if b.startswith("DA_MetaData_") and not b.startswith("DA_MetaData_Ammo"):
                # gear the game really has: its shop metadata names it (string tables also hold unreleased gear)
                tables.setdefault("_meta_names", set()).update(k.decode() for k in re.findall(rb"KEY_[A-Z0-9_\-&.]+?_NAME", t.read(i)))
            elif re.match(r"DA_CallerDefinition_Caller\d+_Call\d+\.uasset$", b):
                import woth2_paks as _p
                tables.setdefault("_calls", {})[b[20:-7]] = [n for n in _p.package_names(t.read(i)) if n.startswith("Animals.")]
            if b.startswith("DA_MetaData_Ammo"):
                tables.setdefault("_ammo_sold", set()).add(b[12:-7].lower())
            if b.startswith("DA_MetaData_Ammo"):
                nk = ammo_name_key(b[12:-7])
                if nk: tables.setdefault("_ammo_keys", {})[b[12:-7]] = nk
                try:
                    zz = zenpkg.ZenPackage(t.read(i))
                    am = _ammo_meta(zz)
                except Exception:
                    am = None
                if am: tables.setdefault("_ammo_meta", {})[b[12:-7]] = am
            elif b.startswith("DA_Ballistics_"):
                try:
                    bal = _ballistics(zenpkg.ZenPackage(t.read(i)).export_data[0])
                except Exception:
                    bal = None
                if bal: tables.setdefault("_ballistics", {})[b[14:-7]] = bal
    return tables, subs, guides, eco

# ---------------------------------------------------------------- herd data
_MOD_NAMES = ["FitnessDifferenceCurve", "FemaleMultiplier", "MaleMultiplier", "AgeCurve", "UpwardMultiplier"]
_MOD_KIND = ["obj", "dbl", "dbl", "obj", "dbl"]

def _herd_mods(data):
    """S_AnimalFitnessCalculationModifiers of a DA_AnimalSubspecies (defaults: multipliers 1.0)."""
    import zenpkg
    z = zenpkg.ZenPackage(data); dat = z.export_data[0]
    best = None
    for p in range(len(dat) - 12):
        present, idx, q, ok = [], 0, p, True
        while True:
            h, = struct.unpack_from("<H", dat, q); q += 2
            idx += h & 0x7F; n = h >> 9
            if h & 0x80 or q - p > 8:
                ok = False; break
            present += list(range(idx, idx + n)); idx += n
            if h & 0x100:
                break
        if not ok or not present or max(present) > 4:
            continue
        vals, curves = {}, 0
        try:
            for k in present:
                if _MOD_KIND[k] == "obj":
                    v, = struct.unpack_from("<i", dat, q); q += 4
                    s = zenpkg.split_import(z.imports[-v - 1]) if v < 0 and -v - 1 < len(z.imports) else None
                    if not s or "/C_" not in z.package_names[s[0]][0]:
                        raise ValueError
                    curves += 1
                else:
                    v, = struct.unpack_from("<d", dat, q); q += 8
                    if not 0.5 <= v < 50:
                        raise ValueError
                    vals[_MOD_NAMES[k]] = v
        except (ValueError, struct.error, IndexError):
            continue
        if curves and (best is None or len(vals) > len(best)):
            best = vals
    best = best or {}
    return {"female": best.get("FemaleMultiplier", 1.0), "male": best.get("MaleMultiplier", 1.0),
            "upward": best.get("UpwardMultiplier", 1.0)}

def _ballistics(dat):
    """From a DA_Ballistics_*: projectile weight (kg), diameter (cm), length (cm), muzzle speed (cm/s), drag value
    (the first run of plausible doubles); tissue penetration min/max (the MaterialResponse floats); pellets per
    shell and spread (shotgun shot)."""
    out = None
    for o in range(0, len(dat) - 40):
        w, d, l, v = struct.unpack_from("<4d", dat, o)
        if 0.00005 < w < 0.2 and 0.1 < d < 5 and 0.15 < l < 120 and 3000 < v < 200000:
            bc, = struct.unpack_from("<d", dat, o + 32)
            out = {"kg": w, "cm": d, "len": l, "cms": v, "bc": bc if 0 < bc < 2 else None}; end = o + 40
            break
    if not out:
        return None
    for o in range(end, len(dat) - 12):
        a, b, c = struct.unpack_from("<3f", dat, o)
        if 1 <= a < b <= 500 and a == int(a) and b == int(b) and 0 < c <= 5:
            out["pen"] = (a, b); break
    if end >= 52:                                 # shot shells: ProjectileCount, ProjectileSpread, ProjectileCountDivide right before
        n, sp, div = struct.unpack_from("<IfI", dat, end - 52)
        if 2 <= n <= 2000 and 0 < sp < 50 and 1 <= div <= 64:
            out["pellets"] = (n, sp, div)
    return out

# ---------------------------------------------------------------- tiers and calibers
CALIBER_KEYS = {"22LR": "22", "243W": "243", "270W": "270", "30-06S": "30-06", "300WM": "300", "308W": "308", "338LM": "338",
                "375HHMag": "375", "45-70": "45-70", "65Creedmoor": "65", "65x55SSE": "65X55", "50": "50",
                "12ga": "12GA", "16ga": "16GA", "20ga": "20GA", "28ga": "28GA", "30in": "30IN", "32in": "32IN", "18in": "18IN", "22in": "22IN"}

def caliber_name(tag, tables):
    """'Ammunition.Firearm.Bullet.308W' -> '.308 Winchester' (the game's own caliber names)."""
    last = tag.split(".")[-1]
    k = CALIBER_KEYS.get(last)
    T = tables.get("ST_Ammunition", {})
    if k and T.get(f"KEY_GEAR_AMMUNITION_CALIBERS_{k}_NAME"):
        return clean(T[f"KEY_GEAR_AMMUNITION_CALIBERS_{k}_NAME"])
    return last

AMMO_CAL_KEYS = {"243Win": "243WIN", "270Win": "270WIN", "300WinMag": "300WM", "308Win": "308WIN", "338LapuaMag": "338LM",
                 "375HHMag": "375H&HM", "65Creedmoor": "6.5CREEDMOOR", "65X55SE": "6.5X55SE"}

def ammo_name_key(asset):
    """'AmmoBullet375HHMag_SP01' -> its ST_Ammunition _NAME key (the metadata's own name keys have copy-paste errors)."""
    m = re.match(r"Ammo(Bullet|Shell|Arrow|Bolt)([A-Za-z0-9-]+?)_?((?:[A-Z]{2,4})\d\d)$", asset)
    if not m: return None
    kind, cal, load = m.groups()
    if kind == "Bullet": return f"KEY_GEAR_AMMUNITION_RIFLES_CARTRIDGE{AMMO_CAL_KEYS.get(cal, cal.upper())}{load}_NAME"
    if kind == "Shell": return f"KEY_GEAR_AMMUNITION_SHOTGUNS_SHELL{cal.upper()}{load}_NAME"
    if kind == "Arrow": return f"KEY_GEAR_AMMUNITION_BOWS_ARROW{cal.upper()}{load}_NAME"
    return f"KEY_GEAR_AMMUNITION_CROSSBOWS_BOLT{cal.upper()}{load}_NAME"

def _ammo_meta(z):
    """DA_MetaData_Ammo*: {caliber tag, tiers [ints], desc key} - BP_ItemDefinitionMetaData_Ammunition: caliber tag
    struct, ints, projectile-type tag struct, an optional int (left out when default), then m_tiers (int array)."""
    d = z.export_data[0]; nm = [z.name(i) for i in range(len(z.names))]
    tags = []
    for m in re.finditer(rb"(?=\x00\x03(....)\x00\x00\x00\x00)", d, re.S):
        i, = struct.unpack("<I", m.group(1))
        if i < len(nm) and nm[i].startswith("Ammunition."):
            tags.append((m.start(), nm[i]))
        if len(tags) == 2: break
    if len(tags) < 2: return None
    def arr(p):
        if p + 4 > len(d): return None
        n, = struct.unpack_from("<i", d, p)
        if not 0 < n < 13 or p + 4 + 4 * n > len(d): return None
        t = list(struct.unpack_from("<%di" % n, d, p + 4))
        return t if all(1 <= x <= 12 for x in t) and t == sorted(set(t)) else None
    p = tags[1][0] + 10
    # the int before m_tiers is only written when the first header fragment carries 6 values (01 0c)
    tiers = (arr(p + 4) or arr(p)) if d[2:4] == b"\x01\x0c" else (arr(p) or arr(p + 4))
    if not tiers: return None
    dk = re.search(rb"KEY_GEAR_AMMUNITION_[A-Z0-9_&.\-]+_DESCRIPTION", d)
    return {"caliber": tags[0][1], "tiers": tiers, "desc": dk.group(0).decode() if dk else None}

def _animal_tier(raw):
    """mTier of BP_AnimalSubspecies_DataAsset: the int right after the 'sex' text that follows the four dimension
    strings (height, length, speed, weight)."""
    ds = list(re.finditer(rb"(?:\x02|\x03|\x04|\x05|\x06)\x00\x00\x00(\d{1,5}(?:\.\d+)?)\x00", raw))
    if len(ds) < 4: return None
    m = re.compile(rb"KEY_[A-Z0-9_]+\x00").search(raw, ds[3].end())
    if not m: return None
    t, = struct.unpack_from("<i", raw, m.end())
    return t if 1 <= t <= 12 else None

def _parse_tiers(txt):
    """'3-6' / '1, 2, 4' -> [ints]"""
    out = []
    for part in str(txt).split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1); out += list(range(int(a), int(b) + 1))
        elif part.isdigit():
            out.append(int(part))
    return out

def tier_text(t):
    if not t: return "-"
    t = sorted(set(t))
    runs = []
    for x in t:
        if runs and x == runs[-1][1] + 1: runs[-1][1] = x
        else: runs.append([x, x])
    return ", ".join(str(a) if a == b else f"{a}-{b}" for a, b in runs)

# ---------------------------------------------------------------- weapons
WEAPON_STATS = [("Weapon.Shot.Accuracy", "Accuracy"), ("Weapon.Firearm.Recoil.Amplitude", "Recoil"),
                ("Weapon.Firearm.Recoil.Speed", "Recoil speed"), ("Weapon.Shot.Noise", "Noise"), ("Weapon.Sway", "Sway"),
                ("Weapon.Shot.Spread", "Spread")]

def _weapon_own(data):
    """{attribute: value or None (= inherited)}, parent blueprint names - from a weapon blueprint's Attribute map:
    GameplayTag -> AttributeDouble sub-object of the same package (its 'Value' double, absent = parent's)."""
    import zenpkg
    z = zenpkg.ZenPackage(data); nm = [z.name(i) for i in range(len(z.names))]
    ex = list(zip(z.exports, z.export_data)); out = {}
    for e, d in ex:
        if z.name(e[2] & 0xFFFFFFFF) != "Attribute_GEN_VARIABLE":
            continue
        for m in re.finditer(rb"\x00\x03(.)\x00{7}(....)", d, re.S):
            i = m.group(1)[0]; j, = struct.unpack("<i", m.group(2))
            if i < len(nm) and nm[i].startswith("Attributes.") and 0 < j <= len(ex):
                ed = ex[j - 1][1]
                out[nm[i][11:]] = struct.unpack_from("<d", ed, 2)[0] if ed[:2] == b"\x00\x03" and len(ed) >= 10 else None
    par = []
    for imp in z.imports:
        sp = zenpkg.split_import(imp)
        if sp:
            pn = z.package_names[sp[0]][0].rsplit("/", 1)[-1]
            if re.match(r"BP_(Firearm|Bow|Crossbow)", pn): par.append(pn)
    return out, par

def _weapon_meta(data):
    """The shop's stat sheet: {attribute: value} and the weapon's name key."""
    import zenpkg
    z = zenpkg.ZenPackage(data); d = z.export_data[0]; nm = [z.name(i) for i in range(len(z.names))]
    out = {}
    for m in re.finditer(rb"\x00\x03(.)\x00{7}(.{8})", d, re.S):
        i = m.group(1)[0]
        if i < len(nm) and nm[i].startswith("Attributes."):
            out[nm[i][11:]] = struct.unpack("<d", m.group(2))[0]
    key = next((x.decode() for x in re.findall(rb"KEY_GEAR_WEAPONS_[A-Z0-9_]+_NAME", d)), None)
    return out, key

def _weapon_info(data):
    """Calibers (Ammunition.* tags) and type tags of a weapon's metadata."""
    import zenpkg
    z = zenpkg.ZenPackage(data); nm = [z.name(i) for i in range(len(z.names))]
    cal = [n for n in nm if n.startswith("Ammunition.") and "ProjectileType" not in n]
    typ = [n for n in nm if n.startswith("Gear.Equipment.Weapon.")]
    return cal, typ

def _weapon_type(typ):
    t = " ".join(typ)
    if "Crossbow" in t: return "Crossbow"
    if "Bow" in t: return "Bow"
    act = next((x.split(".")[-1] for x in typ if ".Action." in x), "")
    act = {"Bolt": "Bolt-action", "Lever": "Lever-action", "Semi": "Semi-auto", "SemiAuto": "Semi-auto", "Pump": "Pump-action",
           "Break": "Break-action", "BreakAction": "Break-action", "Automatic": "Semi-auto"}.get(act, act)
    kind = "shotgun" if "Shotgun" in t else "rifle"
    return (act + " " + kind).strip().capitalize() if act else kind.capitalize()

def _tiers_for_calibers(cals, tables):
    AM = tables.get("_ammo_meta", {}); out = set()
    for am in AM.values():
        if any(am["caliber"] == c or am["caliber"].startswith(c + ".") for c in cals):
            out.update(am["tiers"])
    return sorted(out)

def _weapon_articles(tables):
    BP = tables.get("_weapon_bp", {}); META = tables.get("_weapon_meta", {}); T = tables.get("ST_Weapons", {})
    own = {}
    for n, data in BP.items():
        try: own[n] = _weapon_own(data)
        except Exception: pass
    def resolved(n):
        vals = {}; seen = 0
        while n in own and seen < 8:
            o, par = own[n]
            for k, v in o.items():
                if vals.get(k) is None: vals[k] = v
            n = next((p for p in par if p != n), None); seen += 1
        return vals
    rows = []
    for mk, data in sorted(META.items()):
        if "Sight" in mk:
            continue
        try:
            shop, key = _weapon_meta(data); cals, typ = _weapon_info(data)
        except Exception:
            continue
        bpn = next((n for n in BP if n.lower().endswith("_" + mk.lower())), None)
        live = resolved(bpn) if bpn else {}
        name = clean(T.get(key, "")) if key else ""
        val = lambda tag: live.get(tag) if live.get(tag) is not None else shop.get(tag)
        fmt = lambda v: "-" if v is None else f"{v:g}"
        calname = ", ".join(sorted({caliber_name(c, tables) for c in cals})) or "-"
        rows.append([name or mk, _weapon_type(typ), calname, tier_text(_tiers_for_calibers(cals, tables)),
                     fmt(val("Weapon.Shot.Accuracy")), fmt(val("Weapon.Firearm.Recoil.Amplitude")), fmt(val("Weapon.Shot.Noise"))])
    rated = {r[0] for r in rows}
    unrated = sorted({clean(T[k]) for k in T if k.endswith("_NAME") and T.get(k[:-5] + "_DESCRIPTION") and k[:-5] not in PULLED
                      and "_PROPERTIES" not in k and "_TYPES" not in k} - rated - {""})
    tables["_unreleased_weapons"] = [(k[:-5], clean(T[k]), clean(T.get(k[:-5] + "_DESCRIPTION", ""))) for k in sorted(T)
                                     if k.endswith("_NAME") and clean(T[k]) in unrated and T.get(k[:-5] + "_DESCRIPTION")]
    if not rows:
        return []
    rows.sort(key=lambda r: (r[1], r[0]))
    num = lambda v: float(v) if v not in ("-", "", None) else None
    def acc_word(v):
        v = num(v)
        return "-" if v is None else f"{v:g} {'excellent' if v <= 0.65 else 'good' if v <= 1.05 else 'fair' if v <= 2.2 else 'wide'}"
    def rec_word(v):
        v = num(v)
        return "none" if v is None else f"{v:g} {'low' if v <= 0.75 else 'medium' if v <= 1.3 else 'high'}"
    def noise_word(v):
        v = num(v)
        return "-" if v is None else f"{v:g} {'quiet' if v <= 100 else 'medium' if v <= 250 else 'loud'}"
    def tiers_of(r):
        return set(_parse_tiers(r[3]))
    blocks = [
        {"p": "Pick a weapon in three steps: it must cover the animal's tier, then the lower its accuracy number the better, "
              "then lower recoil and noise are a bonus."},
        {"h": "What the numbers mean"},
        {"list": ["Tiers: the animal tiers this weapon's ammunition is rated for. The animal's tier (on its page) must be in this range.",
                  "Accuracy: how far a shot can stray from where you aim. Lower is better: excellent 0.65 or less, good up to 1.05, "
                  "fair up to 2.2, wide above that (shotguns, bows).",
                  "Recoil: how hard it kicks. Lower keeps the animal in the scope for a second shot.",
                  "Noise: how far animals hear the shot (game units). Lower spooks fewer animals. '-' = the game gives no noise value.",
                  "Sway is the same for every weapon: it comes from your stance, breathing, bipods and shooting sticks."]},
        {"h": "The hunter assist circle"},
        {"p": "With hunter assist on, the circle shows where your shot can land at the distance you aim at. Its size comes from "
              "the weapon's accuracy plus your own skill plus the load's accuracy: a 2 MOA rifle at 200 m draws a circle about 23 cm "
              "across on the animal, so a more accurate rifle really does draw a smaller circle. Green = a good hit on the animal, "
              "red = not a good hit, beige = it lands on terrain. Shotgun shot shows no circle."},
        {"p": "The assist follows the live wind: the impact point it shows moves with the wind as soon as it blows, without "
              "waiting for a first shot."},
        {"h": "Most accurate weapon for each tier"}]
    best = []
    for t in range(1, 10):
        cand = [(num(r[4]), r) for r in rows if t in tiers_of(r) and num(r[4]) is not None]
        if not cand:
            continue
        lo = min(c[0] for c in cand)
        names = ", ".join(f"{r[0]} - {r[2]}" for v, r in sorted(cand, key=lambda c: c[1][0]) if v == lo)
        if best and best[-1][1] == names and best[-1][2] == acc_word(lo) and best[-1][3] == t - 1:
            best[-1][3] = t
        else:
            best.append([t, names, acc_word(lo), t])
    best = [[str(a) if a == z else f"{a}-{z}", n, w] for a, n, w, z in best]
    blocks.append({"table": {"cols": ["Tiers", "Weapon", "Accuracy"], "rows": best, "w": [5, 40, 10]}})
    for typ in sorted({r[1] for r in rows}):
        grp = [r for r in rows if r[1] == typ]
        grp.sort(key=lambda r: (num(r[4]) if num(r[4]) is not None else 99, r[0]))
        blocks.append({"h": typ + ("s" if not typ.endswith("s") else "")})
        blocks.append({"table": {"cols": ["Weapon", "Caliber", "Tiers", "Accuracy", "Recoil", "Noise"], "w": [26, 18, 8, 11, 11, 11],
                                 "rows": [[r[0], r[2], r[3], acc_word(r[4]), rec_word(r[5]), noise_word(r[6])] for r in grp]}})
    out = [{"id": "gear:weapons", "title": "Weapons - accuracy and tiers", "subtitle": f"{len(rows)} weapon{'' if len(rows) == 1 else 's'}", "group": "Gear",
            "tags": [r[0] for r in rows] + ["accuracy", "tier", "caliber", "recoil", "noise"], "blocks": blocks}]
    # tiers page: which animal needs which ammunition
    AT = tables.get("_animal_tiers", {}); AM = tables.get("_ammo_meta", {}); keys = tables.get("_ammo_keys", {})
    TA = tables.get("ST_Ammunition", {})
    if AT:
        by_tier = {}
        for animal, t in AT.items(): by_tier.setdefault(t, []).append(animal)
        trows = []
        for t in sorted(by_tier):
            cal = sorted({caliber_name(am["caliber"], tables) for am in AM.values() if t in am["tiers"]})
            trows.append([str(t), ", ".join(sorted(by_tier[t])), ", ".join(cal)])
        arows = []
        for mk, am in sorted(AM.items(), key=lambda kv: (min(kv[1]["tiers"]), kv[0])):
            nk = keys.get(mk); nm_ = clean(TA.get(nk, "")) if nk else mk
            arows.append([caliber_name(am["caliber"], tables), nm_, tier_text(am["tiers"])])
        out.append({"id": "gear:tiers", "title": "Tiers - which ammo for which animal", "subtitle": "Animal tiers 1-9", "group": "Gear",
                    "tags": ["tier", "ammo", "caliber", "energy"] + list(AT), "blocks": [
            {"p": "Every animal has a tier from 1 to 9: how much energy a shot needs to reach its vital organs. Every load of ammunition is "
                  "rated for a range of tiers. Use ammunition whose range includes the animal's tier, at a sensible distance. A weapon "
                  "covers the tiers of the ammunition it fires. Heavier animals have higher tiers."},
            {"table": {"cols": ["Tier", "Animals", "Calibers with a load for this tier"], "rows": trows}},
            {"h": "Every load"},
            {"table": {"cols": ["Caliber", "Ammunition", "Tiers"], "rows": arows}}]})
    return out

def _ecosystems(eco):
    """{subspecies: [(map, land, start lo, start hi, cap)]} from DA_HerdEcosystem_<Map>_<Land>."""
    import zenpkg
    out = {}
    for name, data in eco.items():
        mp, _, land = name.partition("_")
        if mp not in MAPS:
            continue
        z = zenpkg.ZenPackage(data); dat = z.export_data[0]
        names = [z.name(k) for k in range(len(z.names))]
        for m in re.finditer(rb"\x00\x03(.)\x00{7}(.{1,4}?)((?:.{7}[\x3f\x3e\x3d\x3c]){5})", dat, re.S):
            k = m.group(1)[0]
            vals = struct.unpack("<5d", m.group(3))
            if k < len(names) and names[k].startswith("Animals.Subspecies.") and all(0 <= v <= 1 for v in vals):
                out.setdefault(names[k].split(".")[-1], []).append((mp, land, vals[0], vals[1], vals[4]))
    return out

# ---------------------------------------------------------------- per-species trophy facts
MEASURED = {
    "OdocoileusVirginianus": ("M", "main beam, typical points, all points, inside + outside spread, base circumference"),
    "OdocoileusHemionus": ("M", "main beam, typical points, inside + outside spread, base circumference"),
    "CervusCanadensis": ("M", "main beam, typical points, all points, inside + outside spread, base circumference"),
    "AlcesAlces": ("M", "main beam, outside spread, palm width, number of points, base circumference"),
    "AntilocapraAmericana": ("M", "horn length, prong length, inside spread, tip-to-tip, circumference at the base and at the 1st, 2nd and 3rd quarter"),
    "OvisDalli": ("MF", "horn length, outside spread, circumference at the base and at the 1st, 2nd and 3rd quarter"),
    "BisonBison": ("M", "horn length, outside spread, tip-to-tip spread, circumference at the base and at the 1st, 2nd and 3rd quarter"),
    "TragelaphusStrepsiceros": ("M", "horn length, base circumference"),
    "DamaliscusPygargus": ("MF", "horn length, base circumference"),
    "ConnochaetesTaurinus": ("MF", "tip-to-tip length, base circumference"),
    "SyncerusCaffer": ("MF", "boss width, tip-to-tip length"),
    "HippopotamusAmphibius": ("MF", "tusk length, base circumference"),
    "PhacochoerusAfricanus": ("MF", "tusk length, base circumference"),
    "SusScrofa": ("MF", "tusk length, base circumference"),
    "CanisLupus": ("MF", "skull length + width (x10 points per cm)"),
    "UrsusArctos": ("MF", "skull length + width (x10 points per cm)"),
    "PantheraLeo": ("MF", "skull length + width (x10 points per cm)"),
    "CrocutaCrocuta": ("MF", "skull length + width (x10 points per cm)"),
    "CrocodylusNiloticus": ("MF", "body length (1 point per cm)"),
    "EquusZebra": ("MF", "weight (1 point per kg); body length is measured but adds no points"),
}
WEIGHT_RULE = {"AnasPlatyrhynchos": "grams / 5", "AnasUndulata": "grams / 5", "LepusAmericanus": "grams / 5",
               "LagopusLeucura": "grams / 2", "AfrotisAfraoides": "grams / 2", "BrantaCanadensis": "grams / 20",
               "MeleagrisGallopavo": "grams / 50", "MellivoraCapensis": "grams / 50", "GuloGulo": "grams / 100",
               "StruthioCamelus": "kg x 2"}
FEMALE_TOP = {"CanisLupus": 5, "CrocutaCrocuta": 5, "PantheraLeo": 5, "UrsusArctos": 5, "EquusZebra": 5,
              "MellivoraCapensis": 5, "LagopusLeucura": 5, "AnasUndulata": 5, "AfrotisAfraoides": 5,
              "LepusAmericanus": 4, "StruthioCamelus": 4, "CrocodylusNiloticus": 3, "AnasPlatyrhynchos": 2,
              "GuloGulo": 2, "MeleagrisGallopavo": 1}

EXTRA_MAPS = {}      # animals without a herd ecosystem but on a map (none now: those go to COMING)
BIRDS = ("AnasPlatyrhynchos", "AnasUndulata", "MeleagrisGallopavo", "AfrotisAfraoides", "LagopusLeucura", "StruthioCamelus")

def _pick(table, sub):
    return next((v for k, v in table.items() if sub.startswith(k)), None)

# ---------------------------------------------------------------- articles
_LAND_SPOTS = {}
def _land_spots(paks_dir, mp):
    """{land key: 'north-east' ...} from the game's land map (lands.py), cached per map."""
    if mp not in _LAND_SPOTS:
        try:
            import lands
            s = lands.summary(paks_dir, mp)
            _LAND_SPOTS[mp] = {l["key"]: l["where"] for l in s["lands"]} if s else {}
        except Exception:
            _LAND_SPOTS[mp] = {}
    return _LAND_SPOTS[mp]

def _fp(f):
    """Fitness as a percent like the map: 0.83 -> '83%', 0.875 -> '87.5%'."""
    v = round(float(f) * 100, 1)
    return (f"{v:.0f}" if abs(v - round(v)) < 1e-6 else f"{v:.1f}") + "%"

def _fpr(lo, hi):
    """A fitness range: 0.40, 0.75 -> '40-75%'."""
    return _fp(lo)[:-1] + "-" + _fp(hi)

def _best_places(rows, land_names, paks_dir):
    """[[map, 'Land (north-east): starts 40-70%, cap 90%'], ...] - the best land(s) per map for this animal."""
    out = []
    for mp in sorted({r[0] for r in rows}, key=lambda m: list(MAPS).index(m) if m in MAPS else 9):
        here = [r for r in rows if r[0] == mp]
        if mp == "Hub" and len(here) <= 1:
            continue
        top = max((cap, hi, lo) for _, _, lo, hi, cap in here)
        bests = [r for r in here if (r[4], r[3], r[2]) == top]
        spots = _land_spots(paks_dir, mp)
        txt = []
        for _, land, lo, hi, cap in bests:
            nm = clean(land_names.get(f"KEY_ENVIRONMENT_{MAP_KEYS[mp]}_{land.upper()}_NAME", land))
            sp = spots.get(land)
            txt.append(f"{nm}" + (f" ({sp} of the map)" if sp and sp != "centre" else (" (middle of the map)" if sp else "")))
        lo, hi, cap = bests[0][2], bests[0][3], bests[0][4]
        out.append([MAPS[mp], " or ".join(txt) + f": herds start at {_fpr(lo, hi)} fitness and can reach {_fp(cap)}"
                    + ("" if len(here) == 1 else f" ({len(here)} lands have it here)")])
    return out

def _animal_articles(tables, subs, eco_by_sub, paks_dir, coming=()):
    import trophy_score as ts
    A = tables.get("ST_Animals", {})
    try:
        req = ts.thresholds(paks_dir)
    except Exception:
        req = {}
    try:
        ages = ts.game_max_ages(paks_dir)
    except Exception:
        ages = {}
    land_names = tables.get("ST_Levels", {})
    arts = []
    for sub, data in sorted(subs.items()):
        import zenpkg
        try:
            z = zenpkg.ZenPackage(data)
        except Exception:
            continue
        names = [z.name(k) for k in range(len(z.names))]
        raw = z.export_data[0]
        keys = [s.decode() for s in re.findall(rb"KEY_ANIMALS_[A-Z0-9_]+", raw)]
        sp = next((re.match(r"KEY_ANIMALS_SPECIES_([A-Z0-9]+?)_(?:APPEARANCE|DESCRIPTION|HUNTING|TRIVIA)", k).group(1)
                   for k in keys if re.match(r"KEY_ANIMALS_SPECIES_([A-Z0-9]+?)_(?:APPEARANCE|DESCRIPTION|HUNTING|TRIVIA)", k)), None)
        sk = next((m.group(1) for k in keys for m in [re.match(r"(KEY_ANIMALS_SUBSPECIES_[A-Z0-9]+?)_(?:NAME|DESCRIPTION)", k)] if m),
                  "KEY_ANIMALS_SUBSPECIES_" + sub.upper())
        title = A.get(sk + "_NAME") or sub
        rated = bool(req and (ts._match(req, sub, "M") or ts._match(req, sub, "F")))
        if title == sub or (sub not in eco_by_sub and sub not in coming):
            continue                                       # no herds on any map in this build (see COMING)
        g = lambda k: clean(A.get(k, ""))
        blocks = []
        latin = g(sk + "_NAME_LATIN")
        alts = [g(k) for k in A if k.startswith(sk + "_NAME_ALTERNATIVE")]
        desc = [x for x in (g(f"KEY_ANIMALS_SPECIES_{sp}_DESCRIPTION") if sp else "", g(sk + "_DESCRIPTION")) if x]
        for d in desc:
            blocks.append({"p": d})
        facts = []
        tag = lambda pre: next((n.split(".")[-1] for n in names if n.startswith(pre)), None)
        lc, ls, diff = tag("Animals.LifeCycle."), tag("Animals.Lifestyle."), tag("Animals.SubspeciesHuntingDifficulty.")
        if lc:
            facts.append(["Active", clean(A.get(f"KEY_ANIMALS_LIFECYCLES_{lc.upper()}_NAME", lc))])
        if ls:
            facts.append(["Lifestyle", clean(A.get(f"KEY_ANIMALS_LIFESTYLES_{ls.upper()}_NAME", re.sub(r"^Migrating(?=[A-Z])", "Migrating/", ls)))])
        if diff:
            facts.append(["Hunting difficulty", re.sub(r"(?<=[a-z])(?=[A-Z])", " ", diff).capitalize()])
        dims = re.findall(rb"(?:\x03|\x04|\x05)\x00\x00\x00(\d{1,4})\x00", raw)
        if len(dims) >= 4:
            h, l, v, w = (x.decode() for x in dims[:4])
            facts += [["Height", f"up to {h} cm"], ["Length", f"up to {l} cm"], ["Top speed", f"{v} km/h"], ["Weight", f"up to {w} kg"]]
        tier = _animal_tier(raw)
        if tier:
            tables.setdefault("_animal_tiers", {})[title] = tier
            facts.insert(0, ["Tier", f"{tier} - use ammunition rated for tier {tier} (see Gear > Tiers)"])
        if ages.get(sub):
            facts.append(["Oldest age", f"{ages[sub]} years"])
        if alts:
            facts.append(["Also called", ", ".join(alts)])
        if facts:
            blocks.append({"h": "At a glance"}); blocks.append({"facts": facts})
        ap = [(lab, g(f"KEY_ANIMALS_SPECIES_{sp}_APPEARANCE_{k}")) for lab, k in
              (("Age", "AGE"), ("Plumage" if sub.startswith(BIRDS) else "Coat", "COAT"), ("Size", "DIMENSIONS"), ("Sexes", "SEX"))] if sp else []
        ap = [[a, b] for a, b in ap if b]
        if ap:
            blocks.append({"h": "Appearance"}); blocks.append({"facts": ap})
        if sp:
            bi = g(f"KEY_ANIMALS_SPECIES_{sp}_HUNTING_BIOMES")
            st = [g(k) for k in sorted(A) if k.startswith(f"KEY_ANIMALS_SPECIES_{sp}_HUNTING_STRENGTHS")]
            we = [g(k) for k in sorted(A) if k.startswith(f"KEY_ANIMALS_SPECIES_{sp}_HUNTING_WEAKNESSES")]
            if bi or st or we:
                blocks.append({"h": "Hunting"})
                if bi:
                    blocks.append({"facts": [["Where", bi]]})
                if st:
                    blocks.append({"p": "Strengths"}); blocks.append({"list": st})
                if we:
                    blocks.append({"p": "Weaknesses"}); blocks.append({"list": we})
        if sub.startswith("Meleagris"):
            blocks.append({"h": "When spooked"})
            blocks.append({"list": [
                "A spooked flock runs off 300 m on average (150 to 450 m), zig-zagging 1 to 3 m from side to side for the first "
                "30 to 60 m.",
                "Then it flies 50 to 60 m, low: 3 to 5 m above the ground.",
                "It lands and runs again, nearly straight.",
                "Top running speed is about 29 km/h, with sharp turns on the zig-zag.",
                "After an alarm run the flock waits about 4 minutes (200 to 300 s) before it moves on."]})
        # best place: per map, the land whose herds can get fittest (highest fitness cap, then starting fitness)
        best = _best_places(eco_by_sub.get(sub, []), land_names, paks_dir)
        if best:
            blocks.append({"h": "Best place"})
            blocks.append({"facts": best})
            blocks.append({"p": "Herds here start the fittest and can get the fittest."})
        # trophy
        tb = []
        T = [None, None]
        for k, sx in enumerate("MF"):
            T[k] = ts._match(req, sub, sx) if req else None
        meas = _pick(MEASURED, sub)
        wr = _pick(WEIGHT_RULE, sub)
        if meas or wr:
            tb.append({"facts": [["Measured", meas[1] if meas else f"weight: {wr} = points"]]})
        rows = []
        males_only = bool(meas and meas[0] == "M")
        if T[0] and T[1] and T[0] == T[1] and not males_only:
            rows.append(["Both sexes"] + [str(x) for x in T[0]])
        else:
            for k, sx in enumerate(("Male", "Female")):
                if T[k] and not (males_only and k == 1):
                    rows.append([sx] + [str(x) for x in T[k]])
        if rows:
            tb.append({"table": {"cols": ["Sex", "2 stars", "3 stars", "4 stars", "5 stars"], "rows": rows}})
        if tb:
            blocks.append({"h": "Trophy"}); blocks += tb
        if sub not in coming:
            blocks += _rare_coat_blocks(sub)
        # herd
        lands = eco_by_sub.get(sub, [])
        if lands:
            mods = _herd_mods(data)
            blocks.append({"h": "Herd management"})
            blocks.append({"facts": [["Harvesting a female", f"moves herd fitness {mods['female']:g} times as much as a male"],
                                     ["When herd fitness goes up", f"each rise is {mods['upward']:g} times bigger"]]})
            lr = []
            for mp, land, lo, hi, cap in sorted(lands):
                ln = clean(land_names.get(f"KEY_ENVIRONMENT_{MAP_KEYS[mp]}_{land.upper()}_NAME", land))
                lr.append([MAPS[mp], ln, _fpr(lo, hi), _fp(cap)])
            blocks.append({"table": {"cols": ["Map", "Land", "Starting fitness", "Fitness cap"], "rows": lr}})
            blocks.append({"note": "Each habitat enhancement for this animal raises its cap on that land by 10%, up to 100%."})
        if sp:
            tr = [g(k) for k in sorted(A) if k.startswith(f"KEY_ANIMALS_SPECIES_{sp}_TRIVIA")]
            if tr:
                blocks.append({"h": "Trivia"}); blocks.append({"list": tr})
        maps = sorted({MAPS[mp] for mp, *_ in lands}) or EXTRA_MAPS.get(sub, [])
        main_map = next((m for m in maps if m != MAPS["Hub"]), maps[0] if maps else "Other")
        arts.append({"id": "animal:" + sub, "title": clean(title), "subtitle": latin, "group": main_map, "where": ", ".join(maps),
                     "tags": [sub] + alts, "blocks": blocks})
    return arts

# rare coats: fur_odds.json (tools/fur_odds.py) - each map's coat table plus the game's guarantee, as the share of
# newly added animals that get each coat in the long run
TIER_NAMES = {"Rare": "Rare", "VeryRare": "Very rare", "Uncommon": "Uncommon"}
_FUR_ODDS = None
def _fur_odds():
    global _FUR_ODDS
    if _FUR_ODDS is None:
        try:
            _FUR_ODDS = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "fur_odds.json"), encoding="utf-8"))
        except (OSError, ValueError):
            _FUR_ODDS = {}
    return _FUR_ODDS

def _one_in(p):
    if not p:
        return "never"
    x = 1 / p
    return f"1 in {int(round(x, 3 - len(str(int(x))))):,}"

def _rare_coat_blocks(sub):
    odds = _fur_odds()
    if not odds:
        return []
    per_map = odds.get(sub)
    if not per_map:
        return [{"h": "Rare coats"}, {"p": "None: this animal always has its normal coat."}]
    main = next((m for m in ("Map01", "Map02") if m in per_map), next(iter(per_map)))
    d = per_map[main]
    same_everywhere = all(v == d for v in per_map.values())
    order = {"Rare": 0, "Uncommon": 0, "VeryRare": 1}
    coats = sorted(d["coats"].items(), key=lambda kv: (order.get(kv[1]["tier"], 2), -kv[1]["M"], kv[0]))
    split = any(abs(c["M"] - c["F"]) > 1e-12 for _n, c in coats)
    rows = []
    for name, c in coats:
        tier = TIER_NAMES.get(c["tier"], c["tier"])
        rows.append([name, tier, _one_in(c["M"])] + ([_one_in(c["F"])] if split else []))
    anyp = sum(t["share"] for t in d["tiers"].values())
    rows.append(["Any rare coat", "", _one_in(anyp)] + ([_one_in(anyp)] if split else []))
    cols = ["Coat", "Kind", "Males" if split else "Chance"] + (["Females"] if split else [])
    tiers = d["tiers"]
    plain = " and ".join(f"a {TIER_NAMES.get(r, r)} coat {_one_in(t['plain'])}" for r, t in sorted(tiers.items(), key=lambda kv: order.get(kv[0], 2)))
    pity = " and ".join(f"a {TIER_NAMES.get(r, r)} one at least once every {t['pity']:,}" for r, t in sorted(tiers.items(), key=lambda kv: order.get(kv[0], 2)))
    note = ("Chance per animal. The game also hands out a rare coat for sure after a long dry spell, which is counted in. "
            + ("Same for males and females." if not split else ""))
    return [{"h": "Rare coats"}, {"table": {"cols": cols, "rows": rows}}, {"note": note.strip()}]

# COMING: things that are already in the game's files with real content (models, data or codex text) but cannot be
# played yet. Bare names are left out. Each one says what exists so far.
COMING_MAPS = {"AepycerosMelampusMelampus": "Kilimaya Reserve", "AfrotisAfraoides": "Kilimaya Reserve"}   # their spawn data names the map
COMING_BANNER = ("SPECULATIVE - based on what has been found in the game's files, not on anything announced. "
                 "It may change or never come. Not in the game yet.")

def _coming_articles(tables, subs, eco_by_sub, paks_dir, live=()):
    L = tables.get("ST_Levels", {})
    W = tables.get("ST_Weapons", {})
    A = tables.get("ST_Animals", {})
    arts = []
    land = lambda k: clean(L.get(f"KEY_ENVIRONMENT_MAP03_{k}_NAME", ""))
    name = clean(L.get("KEY_ENVIRONMENT_MAP03_NAME", ""))
    if name:
        priv = [x for x in (land(f"LANDPRIVATE0{i}") for i in range(1, 4)) if x]
        pub = [x for x in (land(f"LANDPUBLIC0{i}") for i in range(1, 5)) if x]
        arts.append({"id": "coming:map03", "title": name, "subtitle": "The next map: the Himalayas", "group": "Maps", "where": "", "tags": [name, "Himalaya", "Map03"],
                     "blocks": [{"note": COMING_BANNER},
                                {"p": f"{name} is the next map, set in the Himalayas. Its lands already have names, its herds already have a place "
                                      "in the herd system, and the lodge already holds paintings of it."},
                                {"h": "Lands"}, {"facts": [["Private lands", ", ".join(priv)], ["Public lands", ", ".join(pub)]]}]})
    # animals with a full codex entry but no herds on any map yet get a real article
    nohe = {k for k in subs if k not in eco_by_sub}
    for a in _animal_articles(tables, {k: v for k, v in subs.items() if k in nohe}, eco_by_sub, paks_dir, coming=nohe):
        sub = a["id"].split(":", 1)[1]
        mp = COMING_MAPS.get(sub)
        a["blocks"] = [{"note": COMING_BANNER + " Its look, animal data and codex entry are already there" + (f", set for {mp}." if mp else ".")}] + \
                      [b for b in a["blocks"] if b.get("h") not in ("Rare coats", "Best place", "Herd management")]
        a["blocks"] = _drop_empty_sections(a["blocks"])
        a.update({"id": "coming:" + sub, "group": "Animals", "where": f"{mp} (coming)" if mp else ""})
        arts.append(a)
    if "LynxRufusRufus" in subs:
        arts.append({"id": "coming:LynxRufusRufus", "title": "Bobcat", "subtitle": "Lynx rufus rufus", "group": "Animals", "where": "", "tags": ["Bobcat", "Lynx"],
                     "blocks": [{"note": COMING_BANNER},
                                {"p": "The bobcat is being built: its body, fur and animal data are there, but it has no codex entry and no map yet."}]})
    if "BrantaCanadensisMaxima" in subs:
        arts.append({"id": "coming:BrantaCanadensisMaxima", "title": "Giant Canada goose", "subtitle": "Branta canadensis maxima", "group": "Animals", "where": "",
                     "tags": ["Canada goose", "Goose"],
                     "blocks": [{"note": COMING_BANNER}, {"p": "Only the goose's animal data is there so far: no body, codex entry or map yet."}]})
    mk = "KEY_ANIMALS_SUBSPECIES_MUNTIACUSVAGINALISAUREUS_"
    if A.get(mk + "DESCRIPTION"):
        arts.append({"id": "coming:MuntiacusVaginalisAureus", "title": clean(A.get(mk + "NAME", "Indian muntjac")), "subtitle": clean(A.get(mk + "NAME_LATIN", "")),
                     "group": "Animals", "where": "", "tags": [clean(A.get(mk + "NAME_ALTERNATIVE01", ""))],
                     "blocks": [{"note": COMING_BANNER + " Only its codex text is there so far."}, {"p": clean(A[mk + "DESCRIPTION"])},
                                {"facts": [["Where", "a Himalayan animal, so most likely for Parvata Raj"], ["Also called", clean(A.get(mk + "NAME_ALTERNATIVE01", ""))]]}]})
    arts += _coming_name_animals(tables, subs, eco_by_sub, paks_dir, {a["id"].split(":", 1)[1] for a in arts}, live)
    arts += _coming_gear(tables)
    people = _coming_people(tables)                       # after all the gear: one GEAR heading, then PEOPLE
    cb = clean(W.get("KEY_GEAR_WEAPONS_CROSSBOW08_NAME", ""))
    if cb:
        arts.append({"id": "coming:Crossbow08", "title": cb, "subtitle": "Crossbow", "group": "Gear", "where": "", "tags": [cb, "Crossbow"],
                     "blocks": [{"note": COMING_BANNER}, {"p": f"The {cb} crossbow has its name and its own shooting and reloading sounds; it is not in the shop yet."}]})
    arts.append({"id": "coming:UTV02", "title": "Side-by-side UTV", "subtitle": "A second vehicle", "group": "Gear", "where": "", "tags": ["UTV", "Vehicle", "Side-by-side"],
                 "blocks": [{"note": COMING_BANNER},
                            {"p": "A second vehicle, a side-by-side UTV, is fully built with its own model, seats, animations and sounds, but it has "
                                  "no name and is not in the shop yet. (The Hunter page's vehicle switch can already put it in your game.)"}]})
    return arts + people

# animals the game lists by tag or name only (no body yet); common names for the ones without a name in the game
ANIMAL_NAMES = {"BosMutus": "Wild yak", "CapraFalconeriFalconeri": "Kashmir markhor", "CapraSibiricaSakeen": "Himalayan ibex",
                "HemitragusJemlahicus": "Himalayan tahr", "PantheraUnciaUncioides": "Snow leopard", "RusaUnicolorUnicolor": "Sambar",
                "BubalusArneeArnee": "Wild water buffalo", "LepusNigricollisRuficaudatus": "Indian hare", "VulpesBengalensis": "Bengal fox",
                "AnserAnserRubrirostris": "Eastern greylag goose", "MellivoraCapensisInaurita": "Nepalese honey badger"}
HIMALAYA = set(ANIMAL_NAMES)
SKIP_TAGS = {"AITests", "MuntiacusMuntjakAureus"}      # the developers' AI test tag; the Indian muntjac (own page) under its old name
LATIN = {"ALCESALCESGIGAS": "Alces alces gigas", "CERVUSCANADENSISROOSEVELTI": "Cervus canadensis roosevelti",
         "VULPESLAGOPUSLAGOPUS": "Vulpes lagopus lagopus"}

def _latin(camel):
    w = re.findall(r"[A-Z][a-z]*", camel)
    return " ".join([w[0]] + [x.lower() for x in w[1:]]) if w else camel

def _game_animal_tags(paks_dir):
    try:
        import woth2_paks as paks
        pk = paks.Pak(os.path.join(paks_dir, "pakchunk0-Windows.pak"))
        tags = set()
        for n in pk.files:
            if n.startswith("WOTH2/") and n.endswith(".ini"):
                tags |= {t.decode() for t in re.findall(rb'Tag="Animals\.Subspecies\.([A-Za-z]+)"', pk.read(n))}
        return sorted(tags)
    except Exception:
        return []

def _coming_name_animals(tables, subs, eco_by_sub, paks_dir, done, live=()):
    A = tables.get("ST_Animals", {})
    released = {k.upper() for k in eco_by_sub} | {k.upper() for k in done} | {k.upper() for k in live}
    taken = lambda key: any(key.startswith(r) or r.startswith(key) for r in released)
    found = {}
    for t in _game_animal_tags(paks_dir):                     # registered as a species, nothing else yet
        if not taken(t.upper()) and t not in subs and t not in SKIP_TAGS:
            found[t.upper()] = (ANIMAL_NAMES.get(t, _latin(t)), _latin(t), t in HIMALAYA)
    for k in A:                                               # a name in the game's animal texts, no body yet
        m = re.match(r"KEY_ANIMALS_SUBSPECIES_([A-Z0-9]+)_NAME$", k)
        if m and not taken(m.group(1)) and m.group(1) not in found:
            lat = clean(A.get(f"KEY_ANIMALS_SUBSPECIES_{m.group(1)}_NAME_LATIN", "")) or LATIN.get(m.group(1), "")
            found[m.group(1)] = (clean(A[k]), lat, False)
    arts = []
    for key, (name, lat, him) in sorted(found.items(), key=lambda kv: kv[1][0]):
        where = "a Himalayan animal, so most likely for Parvata Raj" if him else "no map yet"
        arts.append({"id": "coming:" + key, "title": name[:1].upper() + name[1:], "subtitle": lat, "group": "Animals", "where": "",
                     "tags": [name, lat],
                     "blocks": [{"note": COMING_BANNER + " Only its name is in the game so far."}, {"facts": [["Where", where]]}]})
    return arts

def _coming_gear(tables):
    W, At, Am = tables.get("ST_Weapons", {}), tables.get("ST_Attachments", {}), tables.get("ST_Ammunition", {})
    arts = []
    for stem, name, desc in tables.get("_unreleased_weapons", []):
        arts.append({"id": "coming:" + stem, "title": name, "subtitle": "Muzzleloader" if "MUZZLELOAD" in stem else "Bolt-action rifle" if "RIFLEBOLT" in stem else "Rifle" if "RIFLE" in stem else "Weapon", "group": "Gear", "where": "",
                     "tags": [name], "blocks": [{"note": COMING_BANNER + " It has its name and shop text, nothing else yet."}, {"p": desc}]})
    for stem, kind in (("KEY_GEAR_ATTACHMENTS_SCOPE04_CUSTOM01", "Scope"), ("KEY_GEAR_ATTACHMENTS_BOWSIGHT06", "Bow sight"),
                       ("KEY_GEAR_ATTACHMENTS_CROSSBOWSIGHT06", "Crossbow sight")):
        if At.get(stem + "_NAME"):
            n = clean(At[stem + "_NAME"])
            arts.append({"id": "coming:" + stem, "title": n, "subtitle": kind, "group": "Gear", "where": "", "tags": [n],
                         "blocks": [{"note": COMING_BANNER + " It has its name and shop text, nothing else yet."}, {"p": clean(At.get(stem + "_DESCRIPTION", ""))}]})
    loads = [(clean(Am[k]), clean(Am.get(k[:-5] + "_DESCRIPTION", ""))) for k in sorted(Am) if re.match(r"KEY_GEAR_AMMUNITION_RIFLES_CARTRIDGE7MMREMMAG_\w+_NAME$", k)]
    if loads:
        arts.append({"id": "coming:ammo7mmremmag", "title": "7mm Remington Magnum", "subtitle": "Caliber", "group": "Gear", "where": "", "tags": ["7mm Rem Mag"] + [n for n, _ in loads],
                     "blocks": [{"note": COMING_BANNER + " Three loads have their names and shop text; no rifle in the game uses it yet."}]
                               + [x for n, d in loads for x in ({"h": n}, {"p": d})]})
    k = "KEY_GEAR_AMMUNITION_RIFLES_CARTRIDGE45-70SP02"
    if Am.get(k + "_NAME"):
        n = clean(Am[k + "_NAME"])
        arts.append({"id": "coming:ammo4570sp02", "title": n, "subtitle": ".45-70 Government load", "group": "Gear", "where": "", "tags": [n],
                     "blocks": [{"note": COMING_BANNER + " A second .45-70 load with its name and shop text, not sold yet."}, {"p": clean(Am.get(k + "_DESCRIPTION", ""))}]})
    if Am.get("KEY_GEAR_AMMUNITION_CALIBERS_50_NAME"):
        n = clean(Am["KEY_GEAR_AMMUNITION_CALIBERS_50_NAME"])
        arts.append({"id": "coming:ammo50", "title": n, "subtitle": "Caliber", "group": "Gear", "where": "", "tags": [n, ".50"],
                     "blocks": [{"note": COMING_BANNER + " Only the caliber's name so far - most likely for the Primacy Frontier muzzleloader."}]})
    return arts

def _coming_people(tables):
    N = tables.get("ST_NPCs", {})
    arts = []
    for k in sorted(N):
        m = re.match(r"(KEY_NPCMAP03_\d+)_NAME$", k)
        if m:
            arts.append({"id": "coming:" + m.group(1), "title": clean(N[k]), "subtitle": "Parvata Raj", "group": "People", "where": "", "tags": [clean(N[k])],
                         "blocks": [{"note": COMING_BANNER + " Only the name is there so far."},
                                    {"facts": [["Where", "Parvata Raj - the game lists them with that map's people"]]}]})
    return arts

def _drop_empty_sections(blocks):
    out = []
    for i, b in enumerate(blocks):
        if b.get("h") and (i + 1 == len(blocks) or blocks[i + 1].get("h")):
            continue
        out.append(b)
    return out

def _map_articles(tables, eco_by_sub, sub_names):
    L = tables.get("ST_Levels", {})
    arts = []
    for mp, mk in MAP_KEYS.items():
        pre = f"KEY_ENVIRONMENT_{mk}"
        title = clean(L.get(pre + "_NAME", MAPS[mp]))
        blocks = []                                   # the game's flavour text about each map and land is left out: tables only
        lands = sorted({land for v in eco_by_sub.values() for m, land, *_ in v if m == mp})
        for land in lands:
            lp = f"{pre}_{land.upper()}"
            blocks.append({"h": clean(L.get(lp + "_NAME", land)) + (" (private land)" if "Private" in land else " (public land)")})
            rows = [[sub_names.get(s, s), _fpr(lo, hi), _fp(cap)]
                    for s, v in sorted(eco_by_sub.items(), key=lambda kv: sub_names.get(kv[0], kv[0]))
                    for m, ld, lo, hi, cap in v if m == mp and ld == land]
            if rows:
                blocks.append({"table": {"cols": ["Animal", "Starting fitness", "Fitness cap"], "rows": rows}})
        extra = sorted(sub_names.get(s, s) for s, m in EXTRA_MAPS.items() if MAPS[mp] in m)
        if extra:
            blocks.append({"p": "Also found here, with no herd on any land: " + ", ".join(extra) + "."})
        if lands:
            blocks.insert(0, {"p": "Starting fitness is where a herd's fitness starts on that land. The cap is the most it can reach. Each habitat enhancement for an animal raises its cap on that land by 10%, up to 100%."})
        arts.append({"id": "map:" + mp, "title": title, "subtitle": "", "group": "Maps", "tags": [], "blocks": blocks})
    return arts

def _guide_articles(tables, guides):
    G = tables.get("ST_Guides", {})
    arts = []
    for gid, data in sorted(guides.items()):
        keys = [s.decode() for s in re.findall(rb"KEY_METAGAME_ENCYCLOPEDIA_[A-Z0-9_]+", data)]
        seen, order = set(), []
        for k in keys:
            if k not in seen and k in G:
                seen.add(k); order.append(k)
        if not order:
            continue
        title = clean(G[order[0]]) if order[0].endswith("_NAME") else gid
        blocks = []
        for k in order[1:] if order[0].endswith("_NAME") else order:
            blocks.append({"h": clean(G[k])} if re.search(r"_NAME\d*$", k) else {"p": clean(G[k])})
        arts.append({"id": "guide:" + gid, "title": title, "subtitle": "", "group": "Hunting guides", "tags": [], "blocks": blocks})
    tips = [clean(v) for k, v in sorted(G.items()) if re.match(r"KEY_METAGAME_ENCYCLOPEDIA_TIP(LOADING)?\d+_DESCRIPTION$", k)]
    if tips:
        arts.append({"id": "guide:tips", "title": "Hunting tips", "subtitle": "", "group": "Hunting guides", "tags": [],
                     "blocks": [{"list": tips}]})
    return arts

GEAR = [("ST_Weapons", "Weapons"), ("ST_Ammunition", "Ammunition"), ("ST_Optics", "Optics"),
        ("ST_Attachments", "Attachments"), ("ST_Callers", "Callers"), ("ST_Decoys", "Decoys"),
        ("ST_LuringScents", "Luring scents"), ("ST_ScentMasks", "Scent masks"), ("ST_Ambushing", "Blinds and stands"),
        ("ST_Mounting", "Shooting sticks"), ("ST_Backpacks", "Backpacks"), ("ST_Tents", "Tents"),
        ("ST_Vehicles", "Vehicles")]

def _caller_blocks(tables, T):
    """Each caller the game sells, with its calls and what each call brings in (from the game's call data)."""
    A = tables.get("ST_Animals", {})
    sub = lambda s: clean(A.get("KEY_ANIMALS_SUBSPECIES_" + s.upper() + "_NAME", s))
    blocks = []
    callers = sorted({m.group(1) for k in T for m in [re.match(r"KEY_GEAR_(CALLER\d+)_NAME$", k)] if m and k in tables.get("_meta_names", {k})},
                     key=lambda c: clean(T[f"KEY_GEAR_{c}_NAME"]))
    for c in callers:
        blocks.append({"h": clean(T[f"KEY_GEAR_{c}_NAME"])})
        rows = []
        for ck, tags in sorted(tables.get("_calls", {}).items()):
            m = re.match(r"(Caller\d+)_Call(\d+)$", ck)
            if not m or m.group(1).upper() != c: continue
            call = clean(T.get(f"KEY_GEAR_{c}_CALL{m.group(2)}_NAME", "")) or f"Call {int(m.group(2))}"
            spp = sorted({sub(t.split(".")[-1]) for t in tags if t.startswith("Animals.Subspecies.")})
            sex = {t.split(".")[-1] for t in tags if t.startswith("Animals.Sex.")}
            fit = [t.split(".")[-1] for t in tags if t.startswith("Animals.Fitness.")]
            who = "males and females" if len(sex) != 1 else ("males" if "Male" in sex else "females")
            fw = {"High": "high fitness ", "Low": "low fitness "}.get(fit[0] if fit else "", "")
            rows.append([call, ", ".join(spp) or "-", fw + who])
        if rows:
            blocks.append({"table": {"cols": ["Call", "Animals", "Brings in"], "rows": rows, "w": [16, 30, 22]}})
        else:
            d = clean(T.get(f"KEY_GEAR_{c}_DESCRIPTION", ""))
            if d: blocks.append({"p": d})
    return blocks

def _gear_articles(tables):
    arts = []
    for tab, title in GEAR:
        T = tables.get(tab, {})
        items = []
        for k in sorted(T):
            if not k.endswith("_NAME"):
                continue
            stem = k[:-5]
            d = T.get(stem + "_DESCRIPTION")
            if not d or "_PROPERTIES" in stem or "_TYPES" in stem or stem in PULLED \
                    or any(stem == u[0] for u in tables.get("_unreleased_weapons", [])):
                continue
            if tab not in ("ST_Vehicles", "ST_Ammunition", "ST_Weapons") and tables.get("_meta_names") and k not in tables["_meta_names"]:
                continue                                       # named in the game's text but not in the game
            if tab == "ST_Callers" and "_CALL0" in stem: continue
            items.append((clean(T[k]), clean(d)))
        if not items:
            continue
        blocks = []
        if tab == "ST_Ammunition":
            AM = tables.get("_ammo_meta", {}); keys = tables.get("_ammo_keys", {}); sold = tables.get("_ammo_sold", set())
            rows = []
            for mk, am in AM.items():
                n = clean(T.get(keys.get(mk), "")) or mk
                d = clean(T.get(am.get("desc") or "", "") or T.get((keys.get(mk) or "")[:-5] + "_DESCRIPTION", ""))
                rows.append((caliber_name(am["caliber"], tables), am["tiers"][0], n, tier_text(am["tiers"]), d))
            rows.sort()
            cal = None
            for c, _t0, n, t, d in rows:
                if c != cal:
                    blocks.append({"h": c}); cal = c
                blocks.append({"facts": [["Load", n], ["Caliber", c], ["Tiers", t]]})
                if d: blocks.append({"p": d})
            items = [(f"{n} ({c})", d) for c, _t0, n, t, d in rows]
        elif tab == "ST_Callers":
            blocks += _caller_blocks(tables, T)
        else:
          for n, d in sorted(items):
            blocks.append({"h": n}); blocks.append({"p": d})
        arts.append({"id": "gear:" + tab, "title": title, "subtitle": f"{len(items)} item{'s' if len(items) != 1 else ''}", "group": "Gear", "tags": [n for n, _ in items], "blocks": blocks})
    return arts

def _ballistics_articles(tables):
    AMETA = tables.get("_ammo_meta", {})
    B = tables.get("_ballistics", {}); T = tables.get("ST_Ammunition", {})
    names = {}
    for k, v in T.items():
        if k.endswith("_NAME"):
            names[re.sub(r"[^A-Z0-9]", "", k.upper()[len("KEY_GEAR_AMMUNITION_"):-5])] = clean(v)
    keys = tables.get("_ammo_keys", {})
    def label(key):
        k2 = ammo_name_key(key.rstrip("_")) or keys.get(key) or next((v for kk_, v in keys.items() if key.startswith(kk_) or kk_.startswith(key)), None)
        if k2 and T.get(k2): return clean(T[k2])
        kk = re.sub(r"[^A-Z0-9]", "", key.upper().replace("AMMOBULLET", "").replace("AMMOARROW", "").replace("AMMOBOLT", "").replace("AMMOSHELL", ""))
        best = None
        for nk, nv in names.items():
            core = nk.replace("RIFLESCARTRIDGE", "").replace("SHOTGUNSSHELL", "").replace("BOWSARROW", "").replace("CROSSBOWSBOLT", "")
            if core and (core == kk or core.endswith(kk) or kk.endswith(core)):
                if best is None or len(core) > len(best[0]): best = (core, nv)
        return best[1] if best else key
    CAL = {"22LR": ".22 LR", "243Win": ".243 Win", "270Win": ".270 Win", "308Win": ".308 Win", "30-06": ".30-06", "300WinMag": ".300 Win Mag",
           "338LapuaMag": ".338 Lapua Mag", "375HHMag": ".375 H&H Mag", "45-70": ".45-70", "65Creedmoor": "6.5 Creedmoor", "65X55SE": "6.5x55 SE",
           "12ga": "12 ga", "16ga": "16 ga", "20ga": "20 ga", "28ga": "28 ga"}
    def caliber(key):
        m = re.match(r"Ammo(Arrow|Bolt)(\d+)in", key)
        if m: return f'{m.group(2)}" {"arrow" if m.group(1) == "Arrow" else "crossbow bolt"}'
        m = re.match(r"Ammo(?:Bullet|Shell|Arrow|Bolt)([A-Za-z0-9-]+?)_", key)
        c = m.group(1) if m else ""
        return CAL.get(c, c)
    def kind(key):
        k = key.split("_")[1] if "_" in key else ""
        return {"BU": "buckshot", "BI": "birdshot", "RS": "rifled slug"}.get(k[:2], "")
    rows = []
    for key, b in sorted(B.items()):
        ms = b["cms"] / 100.0; kg = b["kg"]; e = 0.5 * kg * ms * ms
        nm = label(key); nm = nm if nm != key else key.split("_", 1)[1]
        sold = key.lower() in tables.get("_ammo_sold", set()) or key.lower().rstrip("_") in tables.get("_ammo_sold", set())
        pel = b.get("pellets"); pen = b.get("pen")
        am = AMETA.get(key) or AMETA.get(key.rstrip("_")) or next((v for k2, v in AMETA.items() if k2.lower() == key.lower().rstrip("_")), None)
        if not sold: continue              # not sold in the game (unused or not released yet)
        calname = caliber_name(am["caliber"], tables) if am else caliber(key)
        kd = kind(key); tag = "" if not kd or kd.lower() in nm.lower() else kd
        tag = ", ".join(x for x in (tag, "per pellet" if pel else "") if x)
        g_ = kg * 1000; gr = kg * 15432.36
        rows.append({"cal": calname, "name": nm + (f" ({tag})" if tag else "") + ("" if sold else "  [NOT SOLD]"),
                     "tiers": am["tiers"] if am else [], "e": e,
                     "energy": f"{e:,.0f} J" + (" each" if pel else ""),
                     "speed": f"{ms:,.0f} m/s ({ms * 3.28084:,.0f} fps)",
                     "weight": (f"{g_:.2f}" if g_ < 1 else f"{g_:.1f}") + " g (" + (f"{gr:.1f}" if gr < 10 else f"{gr:.0f}") + " gr)" + (f" x{pel[0]} pellets" if pel else ""),
                     "bc": f"{b['bc']:.3f}" if b.get("bc") and b["bc"] > 0.001 else "-",
                     "pen": f"{pen[0]:.0f}-{pen[1]:.0f}" if pen else "-"})
    if not rows:
        return []
    def group(c):
        return "Shotgun shells" if "gauge" in c.lower() else "Arrows" if "arrow" in c.lower() else "Crossbow bolts" if "bolt" in c.lower() else "Rifle cartridges"
    GROUPS = ["Rifle cartridges", "Shotgun shells", "Arrows", "Crossbow bolts"]
    cals = {}
    for r in rows: cals.setdefault(r["cal"], []).append(r)
    gauge = lambda c: -int(re.match(r"\d+", c).group(0)) if re.match(r"\d+ Gauge", c) else 0      # 28 ga is the smallest
    ckey = lambda c: (GROUPS.index(group(c)), gauge(c), min((t for r in cals[c] for t in r["tiers"]), default=99), max(r["e"] for r in cals[c]))
    order = sorted(cals, key=ckey)
    hidden = [r["cal"] + " " + r["name"].replace("  [NOT SOLD]", "") for r in rows if "[NOT SOLD]" in r["name"]]
    over = []
    for c in order:
        def rng(es):
            return f"{min(es):,.0f}-{max(es):,.0f} J" if round(min(es)) != round(max(es)) else f"{max(es):,.0f} J"
        one = [r["e"] for r in cals[c] if "each" not in r["energy"]]; pel = [r["e"] for r in cals[c] if "each" in r["energy"]]
        en = ", ".join(x for x in ((("slug " if pel else "") + rng(one)) if one else "", (f"pellets {rng(pel)} each") if pel else "") if x)
        over.append([c, group(c)[:-1].replace("Shotgun shell", "Shotgun").replace("Rifle cartridge", "Rifle").replace("Arrow", "Bow").replace("Crossbow bolt", "Crossbow"),
                     str(len(cals[c])), tier_text(sorted({t for r in cals[c] for t in r["tiers"]})), en])
    blocks = [{"p": f"All {len(rows)} loads in the game by caliber, small to big. The strongest load of each caliber is listed first."},
              {"h": "Calibers at a glance"},
              {"table": {"cols": ["Caliber", "Used in", "Loads", "Tiers", "Muzzle energy"], "rows": over}},
              {"h": "What the columns mean"},
              {"list": ["Tiers: the animal tiers the load is rated for (see Gear > Tiers).",
                        "Energy: at the muzzle, per pellet for shot. Energy at impact is what kills; it drops with range.",
                        "Speed and weight: at the muzzle. 1 g = 15.4 grains (gr).",
                        "Holds speed: higher keeps its speed better over distance.",
                        "Penetration: how deep it goes. Low number at long range, high number up close."]}]
    for g in GROUPS:
        gc = [c for c in order if group(c) == g]
        if not gc: continue
        trows = []
        for c in gc:
            for k, r in enumerate(sorted(cals[c], key=lambda r: -r["e"])):
                trows.append([c if k == 0 else "", r["name"], tier_text(r["tiers"]), r["energy"], r["speed"], r["weight"], r["bc"], r["pen"]])
        blocks += [{"h": g}, {"table": {"cols": ["Caliber", "Ammunition", "Tiers", "Energy", "Speed", "Weight", "Holds speed", "Penetration"], "rows": trows}}]
    blocks += [{"h": "How shots work"},
               {"list": ["Heavier and faster projectiles carry more energy, and they slow down with range.",
                         "Match the load's tiers to the animal's tier (Gear > Tiers).",
                         "Hollow-point bullets open up and do more tissue damage but go less deep; soft-point and polymer-tip bullets go deeper for big game.",
                         "The shop's 'lower / medium / higher-energy' wording does not always match the muzzle energy above - trust the numbers.",
                         "Shotgun shells fire several pellets in a spread; slugs are a single heavy projectile."]}]
    return [{"id": "gear:ballistics", "title": "Ballistics", "subtitle": f"{len(rows)} loads", "group": "Gear", "tags": sorted({r["cal"] for r in rows}) + [r["name"] for r in rows], "blocks": blocks}]

def _people_articles(tables):
    N = tables.get("ST_NPCs", {})
    arts = []
    for k in sorted(N):
        m = re.match(r"(KEY_NPCMAP\d+_\d+)_NAME$", k)
        if not m:
            continue
        p = m.group(1)
        facts = [[lab, clean(N[p + "_" + key])] for lab, key in (("Occupation", "OCCUPATION"), ("Behavior", "BEHAVIOR"),
                 ("Daily life", "LIFECYCLE"), ("Strength", "STRENGTH"), ("Weakness", "WEAKNESS")) if N.get(p + "_" + key)]
        blocks = []
        if N.get(p + "_DESCRIPTION"):
            blocks.append({"p": clean(N[p + "_DESCRIPTION"])})
        if facts:
            blocks.append({"facts": facts})
        tr = [clean(N[x]) for x in sorted(N) if x.startswith(p + "_TRIVIA")]
        if tr:
            blocks.append({"h": "Trivia"}); blocks.append({"list": tr})
        if blocks:
            arts.append({"id": "npc:" + p, "title": clean(N[k]), "subtitle": "", "group": "People", "tags": [], "blocks": blocks})
    # people (and a dog) you meet in the game who have no codex page of their own: written from their dialogue and missions
    for key, blocks in EXTRA_PEOPLE:
        if N.get(key + "_NAME") and not any(a["id"] == "npc:" + key for a in arts):
            arts.append({"id": "npc:" + key, "title": clean(N[key + "_NAME"]), "subtitle": "", "group": "People", "tags": [], "blocks": blocks})
    return arts

EXTRA_PEOPLE = [
    ("KEY_NPCHUB_01", [
        {"p": "Hearth & Hunt's carpenter and builder, waiting for you at the Hearth & Hunt Headquarters. He builds the lodge expansions, "
              "and he knows a thing or two more: mushrooms, and people - \"those two aren't that different\"."},
        {"facts": [["Where", "Hearth & Hunt Headquarters"], ["Occupation", "Carpenter and builder for Hearth & Hunt"],
                   ["Loves", "Mushrooms and gossip"], ["Can't stand", "Being on his own - and Mikael Anderson"]]},
        {"h": "Trivia"},
        {"list": ["He is Irish, and says that once the Irish thought more of fairies than of food when they saw a mushroom.",
                  "He got a world-record hunter's signature in Kilimaya Reserve and cooked him amakhowe mushrooms, a local delicacy.",
                  "He swears by Regina Harper's dreams - he ignored one once and calls it the biggest mistake of his life.",
                  "Talk to him about people: it is his favourite subject."]}]),
    ("KEY_NPCMAP01_08", [
        {"p": "Hearth & Hunt's former representative in New Laurentia - the hunter you are replacing. He comes from Lintukoto Reserve, "
              "speaks plainly, and has looked after an elk herd for years. He shows you how animal daily routines work."},
        {"facts": [["Where", "New Laurentia"], ["Occupation", "Former Hearth & Hunt representative in New Laurentia"],
                   ["Missions", "Fox fires, Loudest deer, Pack dynamics, One shot, no waste"]]}]),
    ("KEY_NPCMAP01_07", [
        {"p": "Juniper's dog, a blood-tracking dog she is training for a national competition. She shows up in Juniper's missions "
              "in New Laurentia - including the night she goes missing."},
        {"facts": [["Where", "New Laurentia"], ["Owner", "Juniper"]]}]),
]

# ---------------------------------------------------------------- the trophy and herd chapters
def _update_articles():
    """Our own pages for the GUIDES tab: the head lamp, selling, and what the latest game update changed."""
    A = []
    A.append({"id": "guide:headlamp", "title": "Head lamp", "subtitle": "Two beams",
              "group": "Hunting guides", "tags": ["head lamp", "headlight", "clip light", "flashlight", "beam", "night", "visibility"], "blocks": [
        {"p": "Press the clip light key to switch between two beams, then off."},
        {"table": {"cols": ["Press", "Beam", "Reach"], "rows": [
            ["1st", "Narrow, for looking far", "about 96 m"],
            ["2nd", "Wide, for the ground around you", "about 36 m"],
            ["3rd", "Off", ""]]}}]})
    A.append({"id": "guide:selling", "title": "Selling gear", "subtitle": "Storage refunds",
              "group": "Hunting guides", "tags": ["sell", "storage", "refund", "money", "discard"], "blocks": [
        {"p": "Gear you bought can be sold from Storage (Manage storage) for half of what it cost. Discard throws an item away for nothing."},
        {"list": ["Ammunition: you get half the price of the rounds still left in the pack.",
                  "The gear you start the game with (Primacy Classic Hunter MK II rifle, ZOOMXD Vision Professional 1.5-6x42 scope, "
                  "Overgaard 8x binoculars, Stone Glacier Avail 2200 backpack) is free, so it sells for nothing."]}]})
    A.append({"id": "guide:update12", "title": "Game update 1.2 - what changed", "subtitle": "October 2026",
              "group": "Hunting guides", "tags": ["patch", "update", "1.2", "changes", "turkey", "wind", "hunter assist", "head lamp"], "blocks": [
        {"p": "What the 1.2 update changed for hunting."},
        {"h": "Weapons and ballistics"},
        {"list": ["No weapon, load or ballistics number changed: speed, energy, drop, accuracy, recoil and noise are the same.",
                  "The hunter assist circle now shows the weapon's real accuracy (see Weapons - accuracy and tiers). Before, it was "
                  "about the same size for every weapon.",
                  "The hunter assist follows the live wind.",
                  "Bullet graph: 'optimal hit' only shows when the bullet's energy is in the animal's recommended range.",
                  "Weapon pages and the shop show which ammunition tiers a weapon takes. Chokes show their pattern spread (denser or wider).",
                  "The hunting log remembers the exact load you used."]},
        {"h": "Animals"},
        {"list": ["Turkeys escape much farther and faster: about 300 m (was 30 to 80 m), up to about 29 km/h (was 23), zig-zag, "
                  "fly low (3 to 5 m, was 11 to 13 m), land and run again. See the Eastern wild turkey page.",
                  "Bird flocks wait about 4 minutes after an alarm run (was about 2.5).",
                  "Animals no longer pick escape spots they cannot reach.",
                  "Some animal paths in New Laurentia and at the HQ were laid out again (most by a few metres).",
                  "Trophy scores, stars, weights, ages, rare coat chances, herds and need zones did not change."]},
        {"h": "Gear"},
        {"list": ["The head lamp has two beams: narrow (about 96 m) and wide (about 36 m).",
                  "Gear can be sold from Storage for half price; the starting gear sells for nothing (see Selling gear).",
                  "Tents and stands you placed no longer disappear."]},
        {"h": "Dog"},
        {"list": ["The dog no longer walks in circles when released and no longer climbs trees.",
                  "It now leaves tracks in snow and splashes puddles."]},
        {"h": "Missions and settings"},
        {"list": ["The 'sell meat of a unique animal species' challenge counts right again (it fixes itself on your next sale).",
                  "Sick moose in Erynnis Lucilius stay in their area.",
                  "Global illumination has two settings now: Low and High.",
                  "The binocular settings were mixed up: 'Binoculars mode' is Hold or Toggle."]},
        {"h": "Maps"},
        {"list": ["New Laurentia loads in smaller pieces: fewer hitches and fewer spots where the ground or water is not ready yet.",
                  "Snow looks sharper on roads and decals, and no longer falls inside cabins and lodges.",
                  "Camps, stands, fast travel, need zones, herds and weather did not change."]}]})
    return A

def _rules_articles():
    A = []
    A.append({"id": "rules:stars", "title": "How stars are given", "subtitle": "Score lines and stars",
              "group": "Trophies", "tags": ["score", "rating", "lines"], "blocks": [
        {"p": "A trophy's score is all its measurements' points added up."},
        {"p": "Each species has four score lines:"},
        {"table": {"cols": ["Score", "Stars"], "rows": [["line 4 or more", "5"],
                   ["line 3 or more", "4"], ["line 2 or more", "3"], ["line 1 or more", "2"], ["below line 1", "1"]]}},
        {"p": "Females of whitetail, mule deer, moose, elk, bison, kudu and pronghorn have no score lines, so they get no trophy stars. Every harvest still gets a separate hunt rating for the shot."},
        {"list": ["The lines are the same for males and females. What differs is how big each sex can grow.",
                  "Stars are set when the trophy is measured. The hunting log keeps them only for animals you harvest."]},
        {"note": "Each animal's page in this encyclopedia lists its four lines."}]})
    A.append({"id": "rules:points", "title": "How measurements become points", "subtitle": "Whole numbers times points per unit",
              "group": "Trophies", "tags": ["measurement", "points", "weight"], "blocks": [
        {"p": "points = measurement (decimals dropped) x points per unit"},
        {"list": ["Lengths are in centimeters and the decimals are cut off, not rounded: 63.9 cm counts as 63.",
                  "Racks, horns, tusks and body length score 1 point per cm. Skull length and width score 10 points per cm.",
                  "Weight trophies: points = weight in grams / grams per point. 5 g: mallard, yellow-billed duck, snowshoe hare. 2 g: ptarmigan. 50 g: turkey, honey badger. 100 g: wolverine. Zebra scores 1 point per kg and ostrich 2 points per kg.",
                  "Example: a 0.86 kg yellow-billed duck hen = 860 g / 5 = 172 points = 2 stars."]},
        {"h": "Typical points and all points"},
        {"list": ["Whitetail: both 'length of typical points' and 'length of all points' count. Non-typical points don't grow in the game yet, so the two are the same and every tine counts twice.",
                  "Elk: 'length of all points' only counts on the rare racks with extra points. It's worth hundreds of points, so those racks jump a star or two.",
                  "Mule deer: only typical points are measured."]}]})
    A.append({"id": "rules:growth", "title": "Growth: age and fitness", "subtitle": "What makes a trophy big",
              "group": "Trophies", "tags": ["age", "fitness", "size"], "blocks": [
        {"p": "Age and fitness together give a growth value between 0 and 1:"},
        {"note": "growth = (age x fitness - offset) / (oldest age - offset), kept between 0 and 1. Fitness counts as a fraction here (83% = 0.83). offset = a tenth of the species' starting age (0.1 for animals that start at 1 year)."},
        {"list": ["An animal's fitness is set when it is born and never changes; only its age goes up.",
                  "Growth 1.0 is the maximum size. It needs age x fitness = oldest age, so only an animal at the oldest age with 100% fitness gets there.",
                  "Half the age or half the fitness is roughly half the size.",
                  "Body size, weight, skulls and body length follow growth in a straight line: value = minimum + (maximum - minimum) x growth.",
                  "Skull, body-length and weight trophies use growth at the moment of the kill.",
                  "Antlers, horns and tusks are rebuilt every year from the animal's new age (see How racks are built and how they age)."]},
        {"table": {"cols": ["Whitetail (oldest 10)", "Growth"], "rows": [["10 years, 100 %", "1.00"], ["10 years, 50 %", "0.49"],
                   ["5 years, 100 %", "0.49"], ["3 years, 60 %", "0.17"]]}}]})
    A.append({"id": "rules:kinds", "title": "Skulls, weights and racks", "subtitle": "Which trophies are luck and which aren't",
              "group": "Trophies", "tags": ["rack", "skull", "template", "level"], "blocks": [
        {"h": "Skull, body length and weight"},
        {"p": "No luck: the same age and fitness always give the same score. Skulls (wolf, grizzly, lion, spotted hyena) score (length + width) x 10."},
        {"table": {"cols": ["Skull", "Length", "Width", "Points"], "rows": [["Wolf", "20-31 cm", "10-17 cm", "300-480"],
                   ["Grizzly", "27-44 cm", "16-27 cm", "430-710"], ["Lion", "25-40 cm", "17-27 cm", "420-670"], ["Hyena", "20-34 cm", "13-21 cm", "330-550"]]}},
        {"p": "Crocodile body length: bulls 170-640 cm, cows 150-450 cm."},
        {"h": "Antlers, horns and tusks"},
        {"list": ["Type: every species has one rack type per sex, except the moose bull, which has four antler types picked by fitness. Female warthogs grow the male tusks.",
                  "Size: every beam, tine and horn section grows with age x fitness, up to its maximum.",
                  "Shape: the bends are rolled at random for each side, so two animals with the same age and fitness can score differently - and the roll is redone every year.",
                  "Tines: an age table gives the trophy a level from 0 to 6 that decides which tines may grow; many tines also need a minimum age and fitness. Whitetail buck: age 1 = level 0, 2 = 1, 3 = 2, 4 = 3, 5 = 4, 6 = 5, 7 and older = 6.",
                  "Measuring: straight lines between the joints of the finished trophy, turned into points."]},
        {"h": "Moose"},
        {"list": ["Four antler types, each with its own age table: cervina, semi-cervina, half palm and full palm. Cervina and semi-cervina have no palm, so their palm width is 0.",
                  "The type is picked by fitness when the first rack is built and kept for life: cervina 0-20%, semi-cervina 10-30%, half palm 30-100%, full palm 40-100%. Where the bands overlap the pick is random.",
                  "Main beam: the longest straight line from the antler base to the tip of the palm (or the last tine), on the left antler.",
                  "Palm width: the widest point of each palm, left plus right. It grows with the antler thickness value, so it follows age x fitness.",
                  "Outside spread: the widest distance between matching tines on the left and right antler. It comes from the random bends, so it changes every year.",
                  "Number of points: every tine that shows, both sides counted.",
                  "Moose tines that do not grow are folded back into the palm, so missing tines also change the palm's shape."]}]})
    A.append({"id": "rules:rackbuild", "title": "How racks grow and change", "subtitle": "Age, fitness and luck",
              "group": "Trophies", "tags": ["random", "shape", "spread", "age", "aging", "tine", "year", "rebuild"], "blocks": [
        {"list": ["A rack is made the first time the animal spawns near you.",
                  "Every in-game year the animal gets a year older and its rack is made again from scratch.",
                  "Lengths and thickness come from age and fitness, so they only grow from year to year.",
                  "Which tines grow depends on age and fitness. A few are a coin flip.",
                  "The bends, and with them the spreads, are random and change every year.",
                  "Left and right are rolled separately."]},
        {"h": "Whitetail tines"},
        {"table": {"cols": ["Whitetail", "Grows at"], "rows": [
            ["Main beam", "age 2+, fitness 20%+. Longer at age 3 (30%+) and age 6 (60%+)"], ["G1 (brow tine)", "age 3+, fitness 20%+, then only half the time on each side"],
            ["G2", "age 3+, fitness 30%+"], ["G3", "age 4+, fitness 50%+"], ["G4", "age 7+, fitness 70%+"], ["G5", "age 7+, fitness 80%+"],
            ["Non-typical points", "don't grow in the game yet"]]}},
        {"h": "Moose antler types"},
        {"p": "A moose bull's antler type is picked by fitness when his first rack is made and kept for life: cervina 0-20%, semi-cervina 10-30%, half palm 30-100%, full palm 40-100%. Where the bands overlap it's random."},
        {"h": "How it's measured"},
        {"list": ["Lengths: straight lines from joint to joint along the antler or horn.",
                  "Spreads: the widest distance between the same tine on the left and right.",
                  "Circumference: from the thickness of the beam."]}]})
    A.append({"id": "rules:herd", "title": "Herd fitness", "subtitle": "The part you control",
              "group": "Herd management", "tags": ["herd", "fitness", "cull", "thriving", "cap"], "blocks": [
        {"p": "Each animal has its own herd fitness on every land, from 0 to 100%. The game shows it as the herd's state:"},
        {"table": {"cols": ["Herd fitness", "State"], "rows": [["30% or lower", "Vulnerable"], ["above 30% to 60%", "Stable"],
                   ["above 60% to 90%", "Healthy"], ["above 90%", "Thriving"]]}},
        {"h": "Start, floor and cap"},
        {"list": ["A herd starts at a random fitness inside its land's start range (on each animal's page).",
                  "A herd never drops below 20%.",
                  "A herd never rises above its cap. Base caps are 50%, 60%, 70% or 80%, so no herd can be Thriving on its base cap.",
                  "Each habitat enhancement built for an animal on a land raises that cap by +10%, up to 100%. Thriving needs enhancements."]}]})
    A.append({"id": "rules:cull", "title": "What a harvest does to the herd", "subtitle": "Culling",
              "group": "Herd management", "tags": ["cull", "harvest", "female", "young"], "blocks": [
        {"p": "Every harvest changes the herd's fitness right away. The game compares the animal with the herd: difference = herd fitness - animal's fitness."},
        {"list": ["Animal less fit than the herd: herd fitness goes up.", "Animal fitter than the herd: herd fitness goes down.", "Same fitness: no change."]},
        {"note": "change = gap value x sex x age x upward bonus"},
        {"table": {"cols": ["Difference", "Gap value"], "rows": [["10%", "1.3%"], ["20%", "2.5%"], ["30%", "3.25%"], ["40%", "3.5%"], ["100%", "3.75% (max)"]]}},
        {"list": ["Sex: males x1.0; females x1.2 for most animals (x1.15 moose; x1.1 warthog, buffalo, hare; x1.05 wolf, grizzly, ducks, ptarmigan).",
                  "Age: young animals count most - x1.3 at the youngest, x1.25 at 30 % of the oldest age, x1.05 at 70 %, x1.0 at the oldest.",
                  "Upward bonus, only when the herd goes up: x1.3 for whitetail, mule deer, elk, pronghorn, Dall sheep, zebra, ostrich, turkey and buffalo; x1.15 for the rest.",
                  "The result is held between 20% and the cap."]},
        {"h": "Examples"},
        {"list": ["Elk herd at 60%, take a young cow at 30%: 3.25% x 1.2 x ~1.27 x 1.3 = about +6.4%.",
                  "Same herd, take a prime old bull at 90%: 3.25% x 1.0 x ~1.03 = about -3.3%."]},
        {"p": "Cull the weak, the young and the females to raise a herd. Every top animal you shoot pulls it down a little."}]})
    A.append({"id": "rules:newanimals", "title": "How herd fitness reaches the animals", "subtitle": "The fitness roll for new animals",
              "group": "Herd management", "tags": ["spawn", "fitness", "roll"], "blocks": [
        {"p": "New animals that join a herd get their fitness rolled around the herd's fitness:"},
        {"list": ["a bell curve centered on the herd fitness, with a spread of 25%,",
                  "kept within 50% of the herd fitness, never below 10% and never above 100%."]},
        {"p": "A herd at 80% mostly produces animals between 55% and 100%, so the rare 95-100 % animals come from high-fitness herds. A herd at 40% almost never makes one. Fitter animals grow bigger trophies (and only moose bulls at 40% or more can grow a full palm)."}]})
    A.append({"id": "rules:howto", "title": "How to get high-star trophies", "subtitle": "Putting it together",
              "group": "Trophies", "tags": ["tips", "5 stars"], "blocks": [
        {"list": ["Raise the herd first: build habitat enhancements on the land (+10% cap each) and harvest weak, young and female animals. Leave the prime males.",
                  "Hunt old animals from that herd: age unlocks tines and grows every length.",
                  "Pick the fittest of them: only the oldest age at 100 % fitness reaches full size.",
                  "Whitetail: look for brow tines (G1) on both sides. Elk: racks with extra points score far higher.",
                  "Moose: full palm bulls are the better bet.",
                  "A rack is rebuilt every year from the animal's new age. The bends (and with them the spread) and a few coin-flip tines are rolled again each time.",
                  "Only animals you harvest keep their stars.",
                  "Skull animals (wolf, grizzly, lion, hyena): females are as good as males.",
                  "How much fitness each animal needs: see Fitness for 5 stars."]}]})
    return A

# ---------------------------------------------------------------- maxed-out odds
def _odds():
    try: return json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "trophy_odds.json"), encoding="utf-8"))
    except (OSError, ValueError): return {}

def _pct(p):
    if p >= 0.995: return "always"
    if p <= 0: return "never"
    if p < 0.01: return "<1%"
    return f"{round(p * 100)}%"

def _odds_key(d, sub, sex):
    return next((k for k in d if k.split("|")[1] == sex and (sub.startswith(k.split("|")[0]) or k.split("|")[0].startswith(sub))), None)

def _max_fact(sub, sex):
    """'5 stars 67%, 4 stars 33%' for an animal at its oldest age and 100 % fitness, or None."""
    O = _odds()
    k = _odds_key(O.get("racks", {}), sub, sex)
    if k:
        st = O["racks"][k]["stars"]
        parts = [f"{n} star{'s' if n > 1 else ''} {_pct(st.get(str(n), 0))}" for n in (5, 4, 3, 2, 1) if st.get(str(n), 0) >= 0.005]
        txt = ", ".join(parts) if len(parts) > 1 else f"always {parts[0].rsplit(' ', 1)[0]}" if parts else None
        if txt and k in O.get("approx", []): txt = txt.replace("always", "almost always", 1) if txt.startswith("always") else txt + " (approximate)"
        return txt
    k = _odds_key(O.get("formula", {}), sub, sex)
    if k:
        n = O["formula"][k]["stars"]
        return f"always {n} star{'s' if n > 1 else ''} (no luck involved)" if n > 1 else "always 1 star (below the 2-star line)"
    return None

def _fit(f):
    return _fp(f) if f is not None else "never"

def _pct_strict(p):
    """Like _pct, but 'always' only when no rack missed."""
    if p >= 1: return "always"
    if p >= 0.995: return f"{min(p * 100, 99.99):.2f}%"
    return _pct(p)

def _fit_up(f):
    """An exact cutoff rounded UP to 0.01, so the shown fitness always makes it."""
    return _fp(math.ceil(f * 100 - 1e-6) / 100) if f is not None else "never"

def _five_fact(sub, sex):
    """'5 stars from fitness 92% ...' at the oldest age, or None."""
    O = _odds()
    k = _odds_key(O.get("fitness", {}), sub, sex)
    if k:
        a = O["fitness"][k]["all"]
        if a["always"] is not None and a["first"] == a["always"]:
            return f"always from fitness {_fit(a['always'])}, never below"
        if a["always"] is not None:
            return f"possible from fitness {_fit(a['first'])}, always from {_fit(a['always'])}"
        if a["first"] is None:
            return "never"
        half = f", half the time from {_fit(a['half'])}" if a["half"] is not None else ""
        return f"possible from fitness {_fit(a['first'])}{half}, never certain: at most {_pct_strict(a['at']['1.00'])} at 100 % fitness (see Trophies > Fitness for 5 stars)"
    if _odds_key(O.get("racks", {}), sub, sex):
        return "never, at any fitness"
    k = _odds_key(O.get("formula", {}), sub, sex)
    if k and "five_from" in O["formula"][k]:
        f = O["formula"][k]["five_from"]
        if f is not None and _fit_up(f) == "100%": return "only at 100 % fitness"
        return f"always from fitness {_fit_up(f)}, never below" if f is not None else "never, at any fitness"
    return None

WT_VARIANT = {"AA both antlers": "brow tine (G1) on both sides", "AA one antler": "brow tine (G1) on one side", "no AA": "no brow tines"}
NOTE_FIX = {"OdocoileusVirginianusBorealis|M": "The brow tine (G1) grows on each side only half the time. G1 on both sides: always 5 stars. On one side: 89%. On neither: never."}

def _fitness_article(names, O):
    FT = O.get("fitness")
    if not FT: return []
    nm = lambda k: next((t for s_, t in names.items() if s_.startswith(k.split("|")[0]) or k.split("|")[0].startswith(s_)), k.split("|")[0])
    order = sorted(FT, key=lambda k: (FT[k]["all"]["always"] is None, FT[k]["all"]["always"] or 9, -(FT[k]["all"]["at"]["1.00"]), nm(k)))
    rows, steps = [], ["0.70", "0.75", "0.80", "0.85", "0.88", "0.90", "0.92", "0.95", "1.00"]
    srows = []
    for k in order:
        for v, a in [("all", FT[k]["all"])] + [(v, a) for v, a in sorted(FT[k].items()) if v != "all"]:
            label = nm(k) + " male" if v == "all" else nm(k) + ", " + WT_VARIANT.get(v, v)
            first = _fit(a["first"])
            rows.append([label, first, _fit(a["half"]), _fit(a["always"]) if a["always"] is not None else "never" if not a["first"] else f"never (best {_pct(a['at']['1.00'])})"])
            srows.append([label] + [_pct_strict(a["at"].get(f, 0)) for f in steps])
    F = O.get("formula", {})
    frows = []
    for base in sorted({k.split("|")[0] for k in F}, key=lambda b: (F.get(b + "|M", {}).get("five_from") or 9, nm(b + "|M"))):
        if nm(base + "|M") == base: continue
        m, f = F.get(base + "|M"), F.get(base + "|F")
        frows.append([nm(base + "|M"), _fit_up(m.get("five_from")) if m else "-", _fit_up(f.get("five_from")) if f else "-"])
    females = sorted({nm(k) for k in O.get("racks", {}) if k.endswith("|F")})
    return [{"id": "rules:fitness5", "title": "Fitness for 5 stars", "subtitle": "Lowest fitness for 5 stars at the oldest age",
             "group": "Trophies", "tags": ["5 stars", "fitness", "threshold", "minimum", "odds", "cutoff"], "blocks": [
        {"p": "All numbers are for an animal at its oldest age. Younger animals need more fitness, and a young one can't make 5 stars at all."},
        {"h": "Racks and horns (males)"},
        {"table": {"cols": ["Animal", "Possible from", "Half the time", "Always"], "rows": rows, "w": [24, 10, 10, 14]}},
        {"note": "Possible from: the lowest fitness that ever made 5 stars. Always: never misses at this fitness or higher. Never (best 91%): even at 100% fitness only 91% make it."},
        {"h": "Chance of 5 stars by fitness"},
        {"table": {"cols": ["Animal"] + [_fp(x) for x in steps], "rows": srows, "w": [24] + [6] * len(steps)}},
        {"h": "Skull, weight and body-length trophies"},
        {"p": "No luck involved. At the oldest age these are 5 stars from this fitness up, every time."},
        {"table": {"cols": ["Animal", "Male", "Female"], "rows": frows, "w": [24, 10, 10]}},
        {"h": "Females with racks or horns"},
        {"p": "Never 5 stars: " + ", ".join(females) + ". Their horns and tusks are smaller and top out around 3 stars."}]}]

def _odds_article(names):
    O = _odds()
    if not O: return []
    nm = lambda k: next((t for s_, t in names.items() if s_.startswith(k.split("|")[0]) or k.split("|")[0].startswith(s_)), k.split("|")[0])
    sx = lambda k: {"M": "male", "F": "female"}[k.split("|")[1]]
    pc = lambda p: "0%" if p <= 0 else "100%" if p >= 1 else ("<0.1%" if p < 0.001 else _pct(p))
    rows = []
    for k, v in sorted(O.get("racks", {}).items(), key=lambda kv: (nm(kv[0]), kv[0])):
        st = v["stars"]; lo = max(0.0, 1 - st.get("5", 0) - st.get("4", 0))
        rows.append([nm(k) + " " + sx(k), pc(st.get("5", 0)), pc(st.get("4", 0)), pc(lo), f"{v['score'][0]}-{v['score'][1]}" if v["score"][0] != v["score"][1] else str(v["score"][0])])
    frows = []
    F = O.get("formula", {})
    for base in sorted({k.split("|")[0] for k in F}, key=nm):
        if nm(base + "|M") == base: continue                # not an animal in the game (no name)
        m, f = F.get(base + "|M"), F.get(base + "|F")
        frows.append([nm(base + "|M"), f"{m['stars']} ({m['score']})" if m else "-", f"{f['stars']} ({f['score']})" if f else "-"])
    notes = [f"{nm(k)}: {NOTE_FIX.get(k, t)}" for k, t in sorted(O.get("notes", {}).items(), key=lambda kv: nm(kv[0]))]
    return [{"id": "rules:maxodds", "title": "Maxed out: chance of 5 stars", "subtitle": "Oldest age, 100% fitness",
             "group": "Trophies", "tags": ["5 stars", "odds", "luck", "max", "chance", "random", "dna"], "blocks": [
        {"p": "At its oldest age with 100% fitness an animal has every length and thickness maxed. It still isn't always 5 stars, because the bends (and so the spreads) are random. They're rolled again every year."},
        {"table": {"cols": ["Animal", "5 stars", "4 stars", "3 or less", "Score range"], "rows": rows, "w": [22, 10, 10, 10, 9]}},
        {"h": "What decides it"},
        {"list": notes},
        {"h": "Skull, weight and body-length trophies"},
        {"p": "Always the same score at the oldest age and 100% fitness. Stars (score):"},
        {"table": {"cols": ["Animal", "Male", "Female"], "rows": frows, "w": [24, 10, 10]}},
        {"h": "Tips"},
        {"list": ["Missed 5 stars? Its rack is rebuilt next year with new rolls, unless it's at the end of its life.",
                  "Whitetail: check the brow tines (G1). No G1 on either side means no 5 stars this year.",
                  "Moose: go for full palm bulls.",
                  "Pronghorn: about half of maxed bucks make 5 stars.",
                  "How much fitness each animal needs: see Fitness for 5 stars."]}]}] + _fitness_article(names, O)

# ---------------------------------------------------------------- build / cache
def build(paks_dir):
    import woth2_paks as paks
    tables, subs, guides, eco = _scan(paks_dir)
    eco_by_sub = _ecosystems(eco)
    A = tables.get("ST_Animals", {})
    sub_names = {s: clean(A.get("KEY_ANIMALS_SUBSPECIES_" + s.upper() + "_NAME", s)) for s in set(subs) | set(eco_by_sub)}
    animals = _animal_articles(tables, subs, eco_by_sub, paks_dir)
    sub_names.update({a["id"].split(":", 1)[1]: a["title"] for a in animals})
    cats = [
        {"id": "trophies", "title": "TROPHIES", "blurb": "How scores, stars and aging work.",
         "articles": [a for a in _rules_articles() if a["group"] == "Trophies"] + _odds_article({a["id"].split(":", 1)[1]: a["title"] for a in animals})},
        {"id": "herds", "title": "HERDS", "blurb": "Herd fitness, culling and habitat enhancements.",
         "articles": [a for a in _rules_articles() if a["group"] == "Herd management"]},
        {"id": "animals", "title": "ANIMALS", "blurb": "Every animal you can hunt.",
         "articles": sorted(animals, key=lambda a: a["title"])},
        {"id": "maps", "title": "MAPS", "blurb": "Maps and lands.", "articles": _map_articles(tables, eco_by_sub, sub_names)},
        {"id": "guides", "title": "GUIDES", "blurb": "Hunting guides, the head lamp, selling gear and the 1.2 update.", "articles": _update_articles() + _guide_articles(tables, guides)},
        {"id": "gear", "title": "GEAR", "blurb": "Weapons, ammunition, ballistics and equipment.", "articles": _weapon_articles(tables) + _ballistics_articles(tables) + _gear_articles(tables)},
        {"id": "people", "title": "PEOPLE", "blurb": "The people you meet.", "articles": _people_articles(tables)},
        {"id": "coming", "hidden": True, "title": "COMING", "blurb": "Speculative, based on findings in the game's files: the next map, animals, gear and people that are not in the game yet.",
         "articles": _coming_articles(tables, subs, eco_by_sub, paks_dir, [a["id"].split(":", 1)[1] for a in animals])},
    ]
    # every load by its game id (the hunting log stores the id): the weekly challenges name an exact load and check it
    AM = tables.get("_ammo_meta", {}); keys = tables.get("_ammo_keys", {}); TA = tables.get("ST_Ammunition", {})
    ammo = [{"id": mk, "name": clean(TA.get(keys[mk], "")) if keys.get(mk) else mk, "caliber": caliber_name(am["caliber"], tables), "tiers": am["tiers"]}
            for mk, am in sorted(AM.items())]
    return {"version": VERSION, "game": paks.game_build(paks_dir), "ammo": ammo, "categories": [c for c in cats if c["articles"] and not c.get("hidden")]}

def _cache_path():
    import mapdata
    return os.path.join(os.path.dirname(mapdata.CACHE_ROOT), "encyclopedia.json")

def load(paks_dir=None, force=False):
    """Cached encyclopedia; rebuilt when the game build changes. Falls back to the copy shipped with the app."""
    import woth2_paks as paks
    pd = paks_dir or paks.find_paks_dir()
    p = _cache_path()
    game = paks.game_build(pd) if pd else None
    if not force:
        try:
            d = json.load(open(p, encoding="utf-8"))
            if d.get("version") == VERSION and (game is None or d.get("game") == game):
                return d
        except (OSError, ValueError):
            pass
    if pd:
        try:
            d = build(pd)
        except Exception as e:                       # a game patch moved something: keep working from an older copy
            print(f"warning: encyclopedia rebuild failed: {e}", file=sys.stderr)
            try:
                return json.load(open(p, encoding="utf-8"))
            except (OSError, ValueError):
                d = None
        if d is not None:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p + ".tmp", "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False)
            os.replace(p + ".tmp", p)
            return d
    shipped = os.path.join(os.path.dirname(os.path.abspath(__file__)), "encyclopedia.json")
    return json.load(open(shipped, encoding="utf-8"))

if __name__ == "__main__":
    import sys
    d = load(force="--force" in sys.argv)
    if "--ship" in sys.argv:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "encyclopedia.json"), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False)
    for c in d["categories"]:
        print(c["title"], len(c["articles"]), [a["title"] for a in c["articles"]][:8])
