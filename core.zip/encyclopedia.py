"""The Encyclopedia: the game's own Codex (animals, maps and lands, guides, gear, people) read straight from the
game files, plus the chapters on how trophies, stars and herd fitness really work (taken from the game's code,
2026-10-06: star rule FUN_1456dbc20, score sum FUN_1457e4850, measurement blueprints, BP_HerdAnimalSubspecies,
C_FitnessDifferenceMultiplier / C_AgeMultiplier curves, DA_HerdEcosystem_*, BPFL_Commands_UI health states).

build(paks_dir) -> dict; load(paks_dir) caches it per game build next to the map caches.
Output: {"version", "game", "categories": [{"id", "title", "blurb", "articles": [article]}]}
article = {"id", "title", "subtitle", "group", "tags": [str], "blocks": [block]}
block   = {"h": str} | {"p": str} | {"list": [str]} | {"facts": [[label, value]]} |
          {"table": {"cols": [str], "rows": [[str]]}} | {"note": str}
Nothing here touches the save.
"""
import math, json, os, re, struct, sys, unicodedata
import i18n

VERSION = 66

# Gear the game names in its text but that is not in the game: everything whose name is not in names_en.json (the
# names the Toybox may use, woth2_paks.released_name_keys), and the map's built hunting stands (not gear).
NOT_GEAR = {"KEY_GEAR_AMBUSHING_HUNTINGSTAND01"}
_NAME_KEYS = []

def _pulled(stem):
    if not _NAME_KEYS:
        import woth2_paks
        _NAME_KEYS.append(woth2_paks.released_name_keys())
    keep = _NAME_KEYS[0]
    return stem in NOT_GEAR or (keep is not None and stem.startswith("KEY_GEAR_") and stem + "_NAME" not in keep)

# Map03 (Parvata Raj, a coming DLC map): listed so its herds are read the day its files arrive; a map with no herds
# gets no page (only a preview page on your own app, see COMING below)
MAPS = {"Map01": "New Laurentia", "Map02": "Kilimaya Reserve", "Hub": "Hearth & Hunt Headquarters", "Map03": "Parvata Raj"}
MAP_KEYS = {"Map01": "MAP01", "Map02": "MAP02", "Hub": "MAPHUB", "Map03": "MAP03"}

# ---------------------------------------------------------------- string tables
def _fstr(b, p):
    n, = struct.unpack_from("<i", b, p); p += 4
    if n == 0:
        return "", p
    if n < 0:
        return b[p:p - 2 * n].decode("utf-16-le", "replace").rstrip("\0"), p - 2 * n
    return b[p:p + n].decode("utf-8", "replace").rstrip("\0"), p + n

def _parse_table(dat):
    for start in range(0, 64):
        try:
            p = start
            ns, p = _fstr(dat, p)
            cnt, = struct.unpack_from("<i", dat, p); p += 4
            if not ns or not (0 < cnt < 100000):
                continue
            out = {}
            for _ in range(cnt):
                k, p = _fstr(dat, p); v, p = _fstr(dat, p); out[k] = v
            return out
        except (struct.error, UnicodeDecodeError):
            continue
    return {}

def clean(s):
    """Game rich text -> plain text."""
    s = re.sub(r"\{([A-Za-z0-9_]+)\}\|displayAs\(Input\)", r"[\1]", s or "")
    s = re.sub(r"\{([A-Za-z0-9_]+)\}\|[a-zA-Z]+\([^)]*\)", r"\1", s)
    s = re.sub(r"<[^>]*>", "", s)
    s = re.sub(r"\[s\].*?\[/s\]\s*", "", s)
    s = re.sub(r"\[/?[a-z]\]", "", s)
    s = s.replace("[IA_", "[").replace("\r", "")
    s = re.sub(r"^Migrating(?=[A-Z])", "Migrating/", s)
    for a, b in (GAME_TEXT_FIXES if not lang() else GAME_TEXT_FIXES_LANG.get(lang(), [])): s = s.replace(a, b)
    return re.sub(r"[ \t]+", " ", s).strip()

# the language the encyclopedia is written in (WOTH2_LANG from the app: "" / unset = English). The game's own text
# (codex, names, trivia, missions, people) comes from the game's translation for that language, word for word.
LANG_LOCRES = {"pt_BR": "pt-BR"}
def lang():
    l = os.environ.get("WOTH2_LANG", "")
    return l if l in LANG_LOCRES else ""

def _lang_tag():
    """the language + its catalog's size and time: a changed translation makes the cached encyclopedia rebuild"""
    l = lang()
    if not l: return ""
    import i18n
    for p in (os.path.join(os.path.dirname(os.path.abspath(__file__)), f"i18n_{l}.json"),
              os.path.join(os.path.dirname(os.path.abspath(__file__)), "app", "assets", "i18n", f"{l}.json")):
        try:
            st = os.stat(p); return f"{l}:{st.st_size}:{int(st.st_mtime)}"
        except OSError:
            continue
    return l

def _game_translation(paks_dir, tables):
    """Swap every game string table line for the game's own translation of it (same table, same key)."""
    loc = LANG_LOCRES.get(lang())
    if not loc: return
    import woth2_paks as paks
    pak = paks.Pak(os.path.join(paks_dir, "pakchunk0-Windows.pak"))
    for p in pak.files:
        if p.endswith(".locres") and f"/{loc}/" in p:
            for ns, kv in paks.parse_locres(pak.read(p)).items():
                t = tables.get(ns)
                if isinstance(t, dict):
                    for k, v in kv.items():
                        if k in t and v: t[k] = v

# mistakes in the game's own Portuguese (word for word otherwise)
GAME_TEXT_FIXES_LANG = {"pt_BR": [("perdem as manchas em suas penas", "perdem as manchas da pelagem")]}

# plain typos in the game's own text (English)
GAME_TEXT_FIXES = [
    ("enough or at all. and you", "enough or at all, and you"), ("second-most exporter", "second-largest exporter"),
    ("variety of game animals as in", "variety of game animals than in"), ("other you have to buy", "others you have to buy"),
    ("optics with a night or thermal vision", "optics with night or thermal vision"), ("it‘s", "it's"),
    ("cause hundreds of people killed each year", "kill hundreds of people each year"), ("an hour of more", "an hour or more"),
    ("life cycle exposable to ambushes", "life cycle exposes it to ambushes"), ("isolating their warm skin", "insulating their warm skin"),
    ("shadows of brown", "shades of brown"), ("averagely-sized", "average-sized"), ("antlers-bearing", "antler-bearing"),
    ("Dall's Sheep", "Dall's sheep"), ("Dall’s Sheep", "Dall’s sheep"), ("North-western", "Northwestern"),
    ("mid-sized lense", "mid-sized lens"), ("landfowls", "landfowl"), ("suitable to carry", "suitable for carrying"),
    ("on mid-range and longer distances", "at mid-range and longer distances"), ("offroad", "off-road"),
    ("give animals a bedding", "give animals bedding"), ("a hunch on its back", "a hump on its back"), ("The hunch is", "The hump is"),
    ("Active during 8:00-", "Active during 08:00-"),
]

# ---------------------------------------------------------------- game file scan
def _scan(paks_dir):
    """One pass over the game files: string tables, subspecies assets, guide assets, herd ecosystems."""
    import woth2_paks as paks, zenpkg
    tables, subs, guides, eco = {}, {}, {}, {}
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            b = path.rsplit("/", 1)[-1]
            if not b.endswith(".uasset"):
                continue
            if b.startswith("ST_"):
                try:
                    d = _parse_table(zenpkg.ZenPackage(t.read(i)).export_data[0])
                except Exception:
                    continue
                if d:
                    tables.setdefault(b[:-7], {}).update(d)
            elif b.startswith("DA_AnimalSubspecies_"):
                subs[b[20:-7]] = t.read(i)
            elif re.match(r"DA_Guide\d+\.uasset$", b):
                guides[b[3:-7]] = t.read(i)
            elif b.startswith("DA_HerdEcosystem_"):
                eco[b[17:-7]] = t.read(i)
            elif re.match(r"BP_(Firearm|Bow|Crossbow)(_[A-Za-z0-9_]+)?\.uasset$", b):
                tables.setdefault("_weapon_bp", {})[b[:-7]] = t.read(i)
            elif re.match(r"DA_MetaData_(Rifle|Shotgun|Bow\d|Crossbow\d)", b):
                tables.setdefault("_weapon_meta", {})[b[12:-7]] = t.read(i)
            if b.startswith("DA_MetaData_") and not b.startswith("DA_MetaData_Ammo"):
                # gear the game really has: its shop metadata names it (string tables also hold unreleased gear)
                _md = t.read(i)
                tables.setdefault("_meta_names", set()).update(k.decode() for k in re.findall(rb"KEY_[A-Z0-9_\-&.]+?_NAME", _md))
                _nk = re.search(rb"KEY_GEAR_[A-Z0-9_\-&.]+?_NAME", _md)      # the name the shop shows for this item
                if _nk: tables.setdefault("_meta_key", {})[b[12:-7]] = _nk.group(0).decode()
            elif b.startswith("DA_Item_"):
                # gear that comes with a DLC (the Night Hunting Pack) or the pre-order pack: owning it unlocks the item, the shop never sells it
                _ent = re.search(rb"Entitlements\.DLCIDW2(NightHunting|PreOrder)", t.read(i))
                if _ent: tables.setdefault("_entitled", {})[_img_key(b[8:-7])] = _ent.group(1).decode()
            elif re.match(r"DA_CallerDefinition_Caller\d+_Call\d+\.uasset$", b):
                import woth2_paks as _p
                tables.setdefault("_calls", {})[b[20:-7]] = [n for n in _p.package_names(t.read(i)) if n.startswith("Animals.")]
            if b.startswith("DA_MetaData_Ammo"):
                tables.setdefault("_ammo_sold", set()).add(b[12:-7].lower())
            if b.startswith("DA_MetaData_Ammo"):
                nk = ammo_name_key(b[12:-7])
                if nk: tables.setdefault("_ammo_keys", {})[b[12:-7]] = nk
                try:
                    zz = zenpkg.ZenPackage(t.read(i))
                    am = _ammo_meta(zz)
                except Exception:
                    am = None
                if am: tables.setdefault("_ammo_meta", {})[b[12:-7]] = am
            elif b.startswith("DA_ShopMetaData_"):
                # BP_ShopMetaData_DA: Price (int, left out = 0: the starting gear), then one more int
                d0 = zenpkg.ZenPackage(t.read(i)).export_data[0]
                # patch 1.3 added a second property fragment, so walk the fragment headers (bit 8 = last one)
                o = 0
                while True:
                    h, = struct.unpack_from("<H", d0, o); o += 2
                    if o == 2: hdr = h
                    if h & 0x100 or o >= len(d0): break
                tables.setdefault("_price", {})[b[16:-7]] = struct.unpack_from("<i", d0, o)[0] if (hdr & 0x7F) == 0 and (hdr >> 9) >= 1 else 0
            elif re.match(r"DA_CharacterLevel_\d+\.uasset$", b):
                # a hunter level: its XP, the rank it gives, and its rewards (shop unlocks, skill points) as imports
                z = zenpkg.ZenPackage(t.read(i)); d0 = z.export_data[0]
                lv, = struct.unpack_from("<i", d0, 2); xp, = struct.unpack_from("<i", d0, 10)
                pk = [n[0].rsplit("/", 1)[-1] for n in z.package_names]
                tables.setdefault("_levels", {})[lv] = {
                    "xp": xp, "rank": next((int(x[-3:]) for x in pk if x.startswith("DA_CharacterRank_")), None),
                    "unlocks": sorted(x[29:] for x in pk if x.startswith("DA_RewardItem_ShopItemUnlock_")),
                    "points": sum({"DA_RewardItem_PlayerSkillPointAddOne": 1, "DA_RewardItem_PlayerSkillPointAddTwo": 2,
                                   "DA_RewardItem_PlayerSkillPointAddThree": 3}.get(x, 0) for x in pk),
                    # money rewards are named by the public export hash of the reward object they import
                    "money": [z.imported_hashes[sp[1]] for sp in map(zenpkg.split_import, z.imports) if sp
                              and z.package_names[sp[0]][0].rsplit("/", 1)[-1].startswith("DA_RewardItem_PlayerResourceAdd_SoftCurrency")
                              and sp[1] < len(z.imported_hashes)]}
            elif re.match(r"DA_RewardItem_PlayerResourceAdd_SoftCurrency\w*\.uasset$", b):
                # a money reward: m_amount (int) right after the resource tag; the asset's name is not always its amount
                z = zenpkg.ZenPackage(t.read(i)); d0 = z.export_data[0]
                if d0[:4] == b"\x00\x04\x02\x03" and len(d0) >= 18:
                    tables.setdefault("_money", {})[z.exports[0][7]] = struct.unpack_from("<i", d0, 14)[0]
            elif re.match(r"DA_CharacterSkillTree_\d+\.uasset$", b):
                z = zenpkg.ZenPackage(t.read(i))
                tables.setdefault("_skill_trees", {})[b[22:-7]] = (z.export_data[0], [z.name(k) for k in range(len(z.names))],
                                                                    [n[0].rsplit("/", 1)[-1] for n in z.package_names])
            elif re.match(r"DA_CharacterSkill_\d+", b):
                z = zenpkg.ZenPackage(t.read(i)); d0 = z.export_data[0]
                nk = re.search(rb"KEY_METAGAME_PROGRESSION_SKILL(\d+)_NAME\x00", d0)
                cost = re.search(rb"\x04\x00{11}(.)\x00{7}\x0b\x02", d0, re.S)
                if nk: tables.setdefault("_skills", {})[b[:-7]] = {"n": nk.group(1).decode(), "cost": cost.group(1)[0] if cost else None}
            elif b.startswith("DA_Ballistics_"):
                try:
                    _bd = zenpkg.ZenPackage(t.read(i)).export_data[0]
                    bal = _ballistics(_bd)
                    if bal:
                        import ballistics_range
                        bal["drag"] = ballistics_range.drag_values(_bd, bal["cm"], bal["cms"])
                except Exception:
                    bal = None
                if bal: tables.setdefault("_ballistics", {})[b[14:-7]] = bal
    return tables, subs, guides, eco

# ---------------------------------------------------------------- herd data
# S_AnimalFitnessCalculationModifiers field order; the subspecies only set MaleMultiplier (BP_HerdAnimalSubspecies uses it for males)
_MOD_NAMES = ["FitnessDifferenceCurve", "MaleMultiplier", "FemaleMultiplier", "AgeCurve", "UpwardMultiplier"]
_MOD_KIND = ["obj", "dbl", "dbl", "obj", "dbl"]

def _herd_mods(data):
    """S_AnimalFitnessCalculationModifiers of a DA_AnimalSubspecies (defaults: multipliers 1.0)."""
    import zenpkg
    z = zenpkg.ZenPackage(data); dat = z.export_data[0]
    best = None
    for p in range(len(dat) - 12):
        present, idx, q, ok = [], 0, p, True
        while True:
            h, = struct.unpack_from("<H", dat, q); q += 2
            idx += h & 0x7F; n = h >> 9
            if h & 0x80 or q - p > 8:
                ok = False; break
            present += list(range(idx, idx + n)); idx += n
            if h & 0x100:
                break
        if not ok or not present or max(present) > 4:
            continue
        vals, curves = {}, 0
        try:
            for k in present:
                if _MOD_KIND[k] == "obj":
                    v, = struct.unpack_from("<i", dat, q); q += 4
                    s = zenpkg.split_import(z.imports[-v - 1]) if v < 0 and -v - 1 < len(z.imports) else None
                    if not s or "/C_" not in z.package_names[s[0]][0]:
                        raise ValueError
                    curves += 1
                else:
                    v, = struct.unpack_from("<d", dat, q); q += 8
                    if not 0.5 <= v < 50:
                        raise ValueError
                    vals[_MOD_NAMES[k]] = v
        except (ValueError, struct.error, IndexError):
            continue
        if curves and (best is None or len(vals) > len(best)):
            best = vals
    best = best or {}
    return {"female": best.get("FemaleMultiplier", 1.0), "male": best.get("MaleMultiplier", 1.0),
            "upward": best.get("UpwardMultiplier", 1.0)}

def _ballistics(dat):
    """From a DA_Ballistics_*: projectile weight (kg), diameter (cm), length (cm), muzzle speed (cm/s), drag value
    (the first run of plausible doubles); tissue penetration min/max (the MaterialResponse floats); pellets per
    shell and spread (shotgun shot)."""
    out = None
    for o in range(0, len(dat) - 40):
        w, d, l, v = struct.unpack_from("<4d", dat, o)
        if 0.00005 < w < 0.2 and 0.1 < d < 5 and 0.15 < l < 120 and 3000 < v < 200000:
            bc, = struct.unpack_from("<d", dat, o + 32)
            out = {"kg": w, "cm": d, "len": l, "cms": v, "bc": bc if 0 < bc < 2 else None}; end = o + 40
            break
    if not out:
        return None
    for o in range(end, len(dat) - 12):
        a, b, c = struct.unpack_from("<3f", dat, o)
        if 1 <= a < b <= 500 and a * 2 == int(a * 2) and b * 2 == int(b * 2) and 0 < c <= 5:
            out["pen"] = (a, b); break
    if end >= 52:                                 # shot shells: ProjectileCount, ProjectileSpread, ProjectileCountDivide right before
        n, sp, div = struct.unpack_from("<IfI", dat, end - 52)
        if 2 <= n <= 2000 and 0 < sp < 50 and 1 <= div <= 64:
            out["pellets"] = (n, sp, div)
    return out

# ---------------------------------------------------------------- tiers and calibers
CALIBER_KEYS = {"22LR": "22", "243W": "243", "270W": "270", "30-06S": "30-06", "300WM": "300", "308W": "308", "338LM": "338",
                "375HHMag": "375", "45-70": "45-70", "65Creedmoor": "65", "65x55SSE": "65X55", "50": "50",
                "12ga": "12GA", "16ga": "16GA", "20ga": "20GA", "28ga": "28GA", "30in": "30IN", "32in": "32IN", "18in": "18IN", "22in": "22IN"}

def caliber_name(tag, tables):
    """'Ammunition.Firearm.Bullet.308W' -> '.308 Winchester' (the game's own caliber names)."""
    last = tag.split(".")[-1]
    k = CALIBER_KEYS.get(last)
    T = tables.get("ST_Ammunition", {})
    if k and T.get(f"KEY_GEAR_AMMUNITION_CALIBERS_{k}_NAME"):
        return clean(T[f"KEY_GEAR_AMMUNITION_CALIBERS_{k}_NAME"])
    return last

AMMO_CAL_KEYS = {"243Win": "243WIN", "270Win": "270WIN", "300WinMag": "300WM", "308Win": "308WIN", "338LapuaMag": "338LM",
                 "375HHMag": "375H&HM", "65Creedmoor": "6.5CREEDMOOR", "65X55SE": "6.5X55SE"}

def ammo_name_key(asset):
    """'AmmoBullet375HHMag_SP01' -> its ST_Ammunition _NAME key (the metadata's own name keys have copy-paste errors)."""
    m = re.match(r"Ammo(Bullet|Shell|Arrow|Bolt)([A-Za-z0-9-]+?)_?((?:[A-Z]{2,4})\d\d)$", asset)
    if not m: return None
    kind, cal, load = m.groups()
    if kind == "Bullet": return f"KEY_GEAR_AMMUNITION_RIFLES_CARTRIDGE{AMMO_CAL_KEYS.get(cal, cal.upper())}{load}_NAME"
    if kind == "Shell": return f"KEY_GEAR_AMMUNITION_SHOTGUNS_SHELL{cal.upper()}{load}_NAME"
    if kind == "Arrow": return f"KEY_GEAR_AMMUNITION_BOWS_ARROW{cal.upper()}{load}_NAME"
    return f"KEY_GEAR_AMMUNITION_CROSSBOWS_BOLT{cal.upper()}{load}_NAME"

def _ammo_meta(z):
    """DA_MetaData_Ammo*: {caliber tag, tiers [ints], desc key} - BP_ItemDefinitionMetaData_Ammunition: caliber tag
    struct, ints, projectile-type tag struct, an optional int (left out when default), then m_tiers (int array)."""
    d = z.export_data[0]; nm = [z.name(i) for i in range(len(z.names))]
    tags = []
    for m in re.finditer(rb"(?=\x00\x03(....)\x00\x00\x00\x00)", d, re.S):
        i, = struct.unpack("<I", m.group(1))
        if i < len(nm) and nm[i].startswith("Ammunition."):
            tags.append((m.start(), nm[i]))
        if len(tags) == 2: break
    if len(tags) < 2: return None
    def arr(p):
        if p + 4 > len(d): return None
        n, = struct.unpack_from("<i", d, p)
        if not 0 < n < 13 or p + 4 + 4 * n > len(d): return None
        t = list(struct.unpack_from("<%di" % n, d, p + 4))
        return t if all(1 <= x <= 12 for x in t) and t == sorted(set(t)) else None
    p = tags[1][0] + 10
    # the int before m_tiers is only written when the first header fragment carries 6 values (01 0c)
    tiers = (arr(p + 4) or arr(p)) if d[2:4] == b"\x01\x0c" else (arr(p) or arr(p + 4))
    if not tiers: return None
    dk = re.search(rb"KEY_GEAR_AMMUNITION_[A-Z0-9_&.\-]+_DESCRIPTION", d)
    pt = next((n for n in nm if n.startswith("Ammunition.ProjectileType.")), None)
    return {"caliber": tags[0][1], "tiers": tiers, "desc": dk.group(0).decode() if dk else None,
            "ptype": pt.rsplit(".", 1)[-1] if pt else None}

def _animal_tier(raw):
    """mTier of BP_AnimalSubspecies_DataAsset: the int right after the 'sex' text that follows the four dimension
    strings (height, length, speed, weight)."""
    ds = list(re.finditer(rb"(?:\x02|\x03|\x04|\x05|\x06)\x00\x00\x00(\d{1,5}(?:\.\d+)?)\x00", raw))
    if len(ds) < 4: return None
    m = re.compile(rb"KEY_[A-Z0-9_]+\x00").search(raw, ds[3].end())
    if not m: return None
    t, = struct.unpack_from("<i", raw, m.end())
    return t if 1 <= t <= 12 else None

def _parse_tiers(txt):
    """'3-6' / '1, 2, 4' -> [ints]"""
    out = []
    for part in str(txt).split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1); out += list(range(int(a), int(b) + 1))
        elif part.isdigit():
            out.append(int(part))
    return out

def tier_text(t):
    if not t: return "-"
    t = sorted(set(t))
    runs = []
    for x in t:
        if runs and x == runs[-1][1] + 1: runs[-1][1] = x
        else: runs.append([x, x])
    return ", ".join(str(a) if a == b else f"{a}-{b}" for a, b in runs)

# ---------------------------------------------------------------- weapons
WEAPON_STATS = [("Weapon.Shot.Accuracy", "Accuracy"), ("Weapon.Firearm.Recoil.Amplitude", "Recoil"),
                ("Weapon.Firearm.Recoil.Speed", "Recoil speed"), ("Weapon.Shot.Noise", "Noise"), ("Weapon.Sway", "Sway"),
                ("Weapon.Shot.Spread", "Spread")]

def _weapon_own(data):
    """{attribute: value or None (= inherited)}, parent blueprint names - from a weapon blueprint's Attribute map:
    GameplayTag -> AttributeDouble sub-object of the same package (its 'Value' double, absent = parent's)."""
    import zenpkg
    z = zenpkg.ZenPackage(data); nm = [z.name(i) for i in range(len(z.names))]
    ex = list(zip(z.exports, z.export_data)); out = {}
    for e, d in ex:
        if z.name(e[2] & 0xFFFFFFFF) != "Attribute_GEN_VARIABLE":
            continue
        for m in re.finditer(rb"\x00\x03(.)\x00{7}(....)", d, re.S):
            i = m.group(1)[0]; j, = struct.unpack("<i", m.group(2))
            if i < len(nm) and nm[i].startswith("Attributes.") and 0 < j <= len(ex):
                ed = ex[j - 1][1]
                out[nm[i][11:]] = struct.unpack_from("<d", ed, 2)[0] if ed[:2] == b"\x00\x03" and len(ed) >= 10 else None
    par = []
    for imp in z.imports:
        sp = zenpkg.split_import(imp)
        if sp:
            pn = z.package_names[sp[0]][0].rsplit("/", 1)[-1]
            if re.match(r"BP_(Firearm|Bow|Crossbow)", pn): par.append(pn)
    return out, par

def _weapon_meta(data):
    """The shop's stat sheet: {attribute: value} and the weapon's name key."""
    import zenpkg
    z = zenpkg.ZenPackage(data); d = z.export_data[0]; nm = [z.name(i) for i in range(len(z.names))]
    out = {}
    for m in re.finditer(rb"\x00\x03(.)\x00{7}(.{8})", d, re.S):
        i = m.group(1)[0]
        if i < len(nm) and nm[i].startswith("Attributes."):
            out[nm[i][11:]] = struct.unpack("<d", m.group(2))[0]
    key = next((x.decode() for x in re.findall(rb"KEY_GEAR_WEAPONS_[A-Z0-9_]+_NAME", d)), None)
    return out, key

def _weapon_info(data):
    """Calibers (Ammunition.* tags) and type tags of a weapon's metadata."""
    import zenpkg
    z = zenpkg.ZenPackage(data); nm = [z.name(i) for i in range(len(z.names))]
    cal = [n for n in nm if n.startswith("Ammunition.") and "ProjectileType" not in n]
    typ = [n for n in nm if n.startswith("Gear.Equipment.Weapon.")]
    return cal, typ

def _weapon_type(typ):
    t = " ".join(typ)
    if "Crossbow" in t: return "Crossbow"
    if "Bow" in t: return "Bow"
    act = next((x.split(".")[-1] for x in typ if ".Action." in x), "")
    act = {"Bolt": "Bolt-action", "Lever": "Lever-action", "Semi": "Semi-automatic", "SemiAuto": "Semi-automatic", "Pump": "Pump-action",
           "Break": "Break-action", "BreakAction": "Break-action", "Automatic": "Semi-automatic"}.get(act, act)
    kind = "shotgun" if "Shotgun" in t else "rifle"
    return (act + " " + kind).strip().capitalize() if act else kind.capitalize()

def _weapon_kind_heading(typ):
    """'Bolt-action rifle' -> 'Bolt-action rifles', in the app's language"""
    plural = typ + ("s" if not typ.endswith("s") else "")
    return {"Bolt-action rifles": i18n.t("Bolt-action rifles"), "Lever-action rifles": i18n.t("Lever-action rifles"),
            "Semi-automatic rifles": i18n.t("Semi-automatic rifles"), "Pump-action rifles": i18n.t("Pump-action rifles"),
            "Break-action rifles": i18n.t("Break-action rifles"), "Rifles": i18n.t("Rifles"),
            "Bolt-action shotguns": i18n.t("Bolt-action shotguns"), "Lever-action shotguns": i18n.t("Lever-action shotguns"),
            "Semi-automatic shotguns": i18n.t("Semi-automatic shotguns"), "Pump-action shotguns": i18n.t("Pump-action shotguns"),
            "Break-action shotguns": i18n.t("Break-action shotguns"), "Shotguns": i18n.t("Shotguns"),
            "Bows": i18n.t("Bows"), "Crossbows": i18n.t("Crossbows")}.get(plural, plural)

def _tiers_for_calibers(cals, tables):
    AM = tables.get("_ammo_meta", {}); out = set()
    for am in AM.values():
        if any(am["caliber"] == c or am["caliber"].startswith(c + ".") for c in cals):
            out.update(am["tiers"])
    return sorted(out)

def _weapon_articles(tables):
    BP = tables.get("_weapon_bp", {}); META = tables.get("_weapon_meta", {}); T = tables.get("ST_Weapons", {})
    own = {}
    for n, data in BP.items():
        try: own[n] = _weapon_own(data)
        except Exception: pass
    def resolved(n):
        vals = {}; seen = 0
        while n in own and seen < 8:
            o, par = own[n]
            for k, v in o.items():
                if vals.get(k) is None: vals[k] = v
            n = next((p for p in par if p != n), None); seen += 1
        return vals
    rows = []; base_names = set()          # the game's names, before a pack mark is added
    for mk, data in sorted(META.items()):
        if "Sight" in mk:
            continue
        try:
            shop, key = _weapon_meta(data); cals, typ = _weapon_info(data)
        except Exception:
            continue
        bpn = next((n for n in BP if n.lower().endswith("_" + mk.lower())), None)
        live = resolved(bpn) if bpn else {}
        name = clean(T.get(key, "")) if key else ""
        # the game copies the shop sheet over the weapon blueprint when the weapon is set up (BP_Firearm.LoadAttributesFromMetadata),
        # so the shop number wins; the blueprint (or its parent) only fills what the sheet leaves out
        val = lambda tag: shop.get(tag) if shop.get(tag) is not None else live.get(tag)
        fmt = lambda v: "-" if v is None else f"{v:g}"
        calname = ", ".join(sorted({caliber_name(c, tables) for c in cals})) or "-"
        if name and calname != "-": tables.setdefault("_weapon_cal", {})[name] = calname     # the shop list names it too
        if name: base_names.add(name)
        if _dlc(tables, mk): name = _dlc_name(name or mk, _dlc(tables, mk))
        rows.append([name or mk, _weapon_type(typ), calname, tier_text(_tiers_for_calibers(cals, tables)),
                     fmt(val("Weapon.Shot.Accuracy")), fmt(val("Weapon.Firearm.Recoil.Amplitude")),
                     fmt(val("Weapon.Shot.Noise") if val("Weapon.Shot.Noise") is not None else 300.0)])   # BP_Firearm's own default
    rated = {r[0] for r in rows} | base_names
    unrated = sorted({clean(T[k]) for k in T if k.endswith("_NAME") and T.get(k[:-5] + "_DESCRIPTION") and not _pulled(k[:-5])
                      and "_PROPERTIES" not in k and "_TYPES" not in k} - rated - {""})
    tables["_unreleased_weapons"] = [(k[:-5], clean(T[k]), clean(T.get(k[:-5] + "_DESCRIPTION", ""))) for k in sorted(T)
                                     if k.endswith("_NAME") and clean(T[k]) in unrated and T.get(k[:-5] + "_DESCRIPTION")]
    if not rows:
        return []
    rows.sort(key=lambda r: (r[1], r[0]))
    num = lambda v: float(v) if v not in ("-", "", None) else None
    def acc_word(v):
        v = num(v)
        if v is None: return "-"
        w = i18n.t("{n} excellent") if v <= 0.65 else i18n.t("{n} good") if v <= 1.05 else i18n.t("{n} fair") if v <= 2.2 else i18n.t("{n} wide")
        return w.format(n=f"{v:g}")
    def rec_word(v):
        v = num(v)
        if v is None: return i18n.t("none")
        return (i18n.t("{n} low") if v <= 0.75 else i18n.t("{n} medium") if v <= 1.3 else i18n.t("{n} high")).format(n=f"{v:g}")
    def noise_word(v):
        v = num(v)
        if v is None: return "-"
        return (i18n.t("{n} quiet") if v <= 100 else i18n.t("{n} medium") if v <= 250 else i18n.t("{n} loud")).format(n=f"{v:g}")
    def tiers_of(r):
        return set(_parse_tiers(r[3]))
    blocks = [
        {"p": i18n.t("Pick a weapon in three steps: it must cover the animal's tier, then the lower its accuracy number the better, "
              "then lower recoil and noise are a bonus.")},
        {"h": i18n.t("What the numbers mean")},
        {"list": [i18n.t("Tiers: the animal tiers this weapon's ammunition is rated for. The animal's tier (on its page) must be in this range."),
                  i18n.t("Accuracy: how far a shot can stray from where you aim. Lower is better: excellent 0.65 or less, good up to 1.05, "
                  "fair up to 2.2, wide above that (shotguns, bows)."),
                  i18n.t("Recoil: how hard it kicks. Lower keeps the animal in the scope for a second shot."),
                  i18n.t("Noise: how loud the shot is. Every animal can hear a shot from up to 400 m. Suppressors lower the noise (Panther x0.7, "
                  "Whisper Magnum x0.5, Mercury Ti30 x0.3)."),
                  i18n.t("Sway is the same for every weapon: it comes from your stance, breathing, bipods and shooting sticks.")]},
        {"h": i18n.t("The hunter assist circle")},
        {"p": i18n.t("With hunter assist on, the circle shows where your shot can land at the distance you aim at. Its size comes from "
              "the weapon's accuracy plus your own skill plus the load's accuracy: a combined 2 MOA (rifle + you + load) at 200 m draws a "
              "circle about 23 cm across on the animal, so a more accurate rifle really does draw a smaller circle. Green = a good hit on the animal, "
              "red = not a good hit, beige = it lands on terrain. Shotgun shot shows no circle.")},
        {"p": i18n.t("The assist follows the live wind: the impact point it shows moves with the wind as soon as it blows, without "
              "waiting for a first shot.")},
        {"h": i18n.t("Most accurate weapon for each tier")}]
    best = []
    for t in range(1, 10):
        cand = [(num(r[4]), r) for r in rows if t in tiers_of(r) and num(r[4]) is not None and not r[0].endswith(_dlc_marks())]
        if not cand:
            continue
        lo = min(c[0] for c in cand)
        names = ", ".join(f"{r[0]} - {r[2]}" for v, r in sorted(cand, key=lambda c: c[1][0]) if v == lo)
        if best and best[-1][1] == names and best[-1][2] == acc_word(lo) and best[-1][3] == t - 1:
            best[-1][3] = t
        else:
            best.append([t, names, acc_word(lo), t])
    best = [[str(a) if a == z else f"{a}-{z}", n, w] for a, n, w, z in best]
    blocks.append({"table": {"cols": [i18n.t("Tiers"), i18n.t("Weapon"), i18n.t("Accuracy")], "rows": best, "w": [5, 40, 10]}})
    if any(r[0].endswith(_dlc_marks()) for r in rows):
        blocks.append({"p": i18n.t("DLC weapons (Heirloom Pack) are left out here: the shop never sells them.")})
    for typ in sorted({r[1] for r in rows}):
        grp = [r for r in rows if r[1] == typ]
        grp.sort(key=lambda r: (num(r[4]) if num(r[4]) is not None else 99, r[0]))
        blocks.append({"h": _weapon_kind_heading(typ)})
        blocks.append({"table": {"cols": [i18n.t("Weapon"), i18n.t("Caliber"), i18n.t("Tiers"), i18n.t("Accuracy"), i18n.t("Recoil"), i18n.t("Noise")], "w": [26, 18, 8, 11, 11, 11],
                                 "rows": [[r[0], r[2], r[3], acc_word(r[4]), rec_word(r[5]), noise_word(r[6])] for r in grp]}})
    out = [{"id": "gear:weapons", "title": i18n.t("Weapons - accuracy and tiers"),
            "subtitle": (i18n.t("{n} weapon") if len(rows) == 1 else i18n.t("{n} weapons")).format(n=len(rows)), "group": i18n.t("Gear"),
            "tags": [r[0] for r in rows] + ["accuracy", "tier", "caliber", "recoil", "noise"], "blocks": blocks}]
    # tiers page: which animal needs which ammunition
    AT = tables.get("_animal_tiers", {}); AM = tables.get("_ammo_meta", {}); keys = tables.get("_ammo_keys", {})
    TA = tables.get("ST_Ammunition", {})
    if AT:
        by_tier = {}
        for animal, t in AT.items(): by_tier.setdefault(t, []).append(animal)
        trows = []
        for t in sorted(by_tier):
            cal = sorted({caliber_name(am["caliber"], tables) for am in AM.values() if t in am["tiers"]})
            trows.append([str(t), ", ".join(sorted(by_tier[t])), ", ".join(cal)])
        arows = []
        for mk, am in sorted(AM.items(), key=lambda kv: (min(kv[1]["tiers"]), kv[0])):
            nk = keys.get(mk); nm_ = clean(TA.get(nk, "")) if nk else mk
            arows.append([caliber_name(am["caliber"], tables), nm_, tier_text(am["tiers"])])
        out.append({"id": "gear:tiers", "title": i18n.t("Tiers - which ammo for which animal"), "subtitle": i18n.t("Animal tiers 1-9"), "group": i18n.t("Gear"),
                    "tags": ["tier", "ammo", "caliber", "energy"] + list(AT), "blocks": [
            {"p": i18n.t("Every animal has a tier from 1 to 9: how much energy a shot needs to reach its vital organs. Every load of ammunition is "
                  "rated for a range of tiers. Use ammunition whose range includes the animal's tier, at a sensible distance. A weapon "
                  "covers the tiers of the ammunition it fires. Heavier animals have higher tiers.")},
            {"table": {"cols": [i18n.t("Tier"), i18n.t("Animals"), i18n.t("Calibers with a load for this tier")], "rows": trows}},
            {"h": i18n.t("Every load")},
            {"table": {"cols": [i18n.t("Caliber"), i18n.t("Ammunition"), i18n.t("Tiers")], "rows": arows}}]})
    return out

def _ecosystems(eco):
    """{subspecies: [(map, land, start lo, start hi, cap)]} from DA_HerdEcosystem_<Map>_<Land>."""
    import zenpkg
    out = {}
    for name, data in eco.items():
        mp, _, land = name.partition("_")
        if mp not in MAPS:
            continue
        z = zenpkg.ZenPackage(data); dat = z.export_data[0]
        names = [z.name(k) for k in range(len(z.names))]
        for m in re.finditer(rb"\x00\x03(.)\x00{7}(.{1,4}?)((?:.{7}[\x3f\x3e\x3d\x3c]){5})", dat, re.S):
            k = m.group(1)[0]
            vals = struct.unpack("<5d", m.group(3))
            if k < len(names) and names[k].startswith("Animals.Subspecies.") and all(0 <= v <= 1 for v in vals):
                out.setdefault(names[k].split(".")[-1], []).append((mp, land, vals[0], vals[1], vals[4]))
    return out

# ---------------------------------------------------------------- per-species trophy facts
MEASURED = {
    "OdocoileusVirginianus": ("M", "main beam, typical points, all points, inside + outside spread, base circumference"),
    "OdocoileusHemionus": ("M", "main beam, typical points, inside + outside spread, base circumference"),
    "CervusCanadensis": ("M", "main beam, typical points, inside + outside spread, base circumference"),
    "AlcesAlces": ("M", "main beam, outside spread, palm width, number of points, base circumference"),
    "AntilocapraAmericana": ("M", "horn length, prong length, inside spread, tip-to-tip, circumference at the base and at the 1st, 2nd and 3rd quarter"),
    "OvisDalli": ("MF", "horn length, outside spread, circumference at the base and at the 1st, 2nd and 3rd quarter"),
    "BisonBison": ("M", "horn length, outside spread, tip-to-tip spread, circumference at the base and at the 1st, 2nd and 3rd quarter"),
    "TragelaphusStrepsiceros": ("M", "horn length, base circumference"),
    "AepycerosMelampus": ("M", "horn length, base circumference"),
    "DamaliscusPygargus": ("MF", "horn length, base circumference"),
    "ConnochaetesTaurinus": ("MF", "tip-to-tip length, base circumference"),
    "SyncerusCaffer": ("MF", "boss width, tip-to-tip length"),
    "HippopotamusAmphibius": ("MF", "tusk length, base circumference"),
    "PhacochoerusAfricanus": ("MF", "tusk length, base circumference"),
    "SusScrofa": ("MF", "tusk length, base circumference"),
    "CanisLupus": ("MF", "skull length + width (x10 points per cm)"),
    "UrsusArctos": ("MF", "skull length + width (x10 points per cm)"),
    "PantheraLeo": ("MF", "skull length + width (x10 points per cm)"),
    "CrocutaCrocuta": ("MF", "skull length + width (x10 points per cm)"),
    "CrocodylusNiloticus": ("MF", "body length (1 point per cm)"),
    "EquusZebra": ("MF", "weight (1 point per kg) + body length (1 point per cm)"),
}
WEIGHT_RULE = {"AnasPlatyrhynchos": "grams / 5", "AnasUndulata": "grams / 5", "LepusAmericanus": "grams / 5",
               "LagopusLeucura": "grams / 2", "AfrotisAfraoides": "grams / 2",
               "MeleagrisGallopavo": "grams / 50", "MellivoraCapensis": "grams / 50", "GuloGulo": "grams / 100",
               "StruthioCamelus": "kg x 2"}
FEMALE_TOP = {"CanisLupus": 5, "CrocutaCrocuta": 5, "PantheraLeo": 5, "UrsusArctos": 5, "EquusZebra": 5,
              "MellivoraCapensis": 5, "LagopusLeucura": 5, "AnasUndulata": 5, "AfrotisAfraoides": 5,
              "LepusAmericanus": 4, "StruthioCamelus": 4, "CrocodylusNiloticus": 3, "AnasPlatyrhynchos": 2,
              "GuloGulo": 2, "MeleagrisGallopavo": 1}

# who the lone animals (Solitary herds) are: DA_AnimalTerritoryInfrastructure_*_Solitary and each animal's
# mGroupSexProportions, game update 1.3 against 1.2; 1.4: lone turkeys + ptarmigan (Family_Phasianid_Solitary) Male -> Balanced, wolverine Balanced 2:1 -> 1:1
_LONE_NEW = "always males (since game update 1.3; before, half males and half females)"
_LONE_MALE = "always males"
_LONE_HALF = "half males, half females"
LONE = {"AntilocapraAmericana": _LONE_NEW, "CervusCanadensis": _LONE_NEW, "OdocoileusHemionus": _LONE_NEW,
        "OdocoileusVirginianus": _LONE_NEW, "CrocutaCrocuta": _LONE_NEW, "PantheraLeo": _LONE_NEW, "SyncerusCaffer": _LONE_NEW,
        "BisonBison": _LONE_MALE, "ConnochaetesTaurinus": _LONE_MALE, "CrocodylusNiloticus": _LONE_MALE, "DamaliscusPygargus": _LONE_MALE,
        "EquusZebra": _LONE_MALE, "HippopotamusAmphibius": _LONE_MALE, "PhacochoerusAfricanus": _LONE_MALE, "SusScrofa": _LONE_MALE,
        "StruthioCamelus": _LONE_MALE, "TragelaphusStrepsiceros": _LONE_MALE, "OvisDalli": _LONE_MALE,
        "AepycerosMelampusMelampus": _LONE_MALE, "AfrotisAfraoides": _LONE_MALE,
        "AlcesAlces": _LONE_HALF, "CanisLupus": _LONE_HALF, "UrsusArctos": _LONE_HALF, "AnasPlatyrhynchos": _LONE_HALF,
        "AnasUndulata": _LONE_HALF, "LepusAmericanus": _LONE_HALF, "MellivoraCapensis": _LONE_HALF,
        "MeleagrisGallopavo": _LONE_HALF, "LagopusLeucura": _LONE_HALF, "GuloGulo": _LONE_HALF}

def _measured_text(s):
    """MEASURED in the app's language (the tables above stay English: tools/trophy_txt.py reads them)"""
    return {
        "main beam, typical points, all points, inside + outside spread, base circumference": i18n.t("main beam, typical points, all points, inside + outside spread, base circumference"),
        "main beam, typical points, inside + outside spread, base circumference": i18n.t("main beam, typical points, inside + outside spread, base circumference"),
        "main beam, outside spread, palm width, number of points, base circumference": i18n.t("main beam, outside spread, palm width, number of points, base circumference"),
        "horn length, prong length, inside spread, tip-to-tip, circumference at the base and at the 1st, 2nd and 3rd quarter": i18n.t("horn length, prong length, inside spread, tip-to-tip, circumference at the base and at the 1st, 2nd and 3rd quarter"),
        "horn length, outside spread, circumference at the base and at the 1st, 2nd and 3rd quarter": i18n.t("horn length, outside spread, circumference at the base and at the 1st, 2nd and 3rd quarter"),
        "horn length, outside spread, tip-to-tip spread, circumference at the base and at the 1st, 2nd and 3rd quarter": i18n.t("horn length, outside spread, tip-to-tip spread, circumference at the base and at the 1st, 2nd and 3rd quarter"),
        "horn length, base circumference": i18n.t("horn length, base circumference"),
        "tip-to-tip length, base circumference": i18n.t("tip-to-tip length, base circumference"),
        "boss width, tip-to-tip length": i18n.t("boss width, tip-to-tip length"),
        "tusk length, base circumference": i18n.t("tusk length, base circumference"),
        "skull length + width (x10 points per cm)": i18n.t("skull length + width (x10 points per cm)"),
        "body length (1 point per cm)": i18n.t("body length (1 point per cm)"),
        "weight (1 point per kg) + body length (1 point per cm)": i18n.t("weight (1 point per kg) + body length (1 point per cm)"),
    }.get(s, s)

def _weight_rule_text(s):
    """WEIGHT_RULE in the app's language"""
    return {
        "grams / 2": i18n.t("grams / 2"),
        "grams / 5": i18n.t("grams / 5"),
        "grams / 50": i18n.t("grams / 50"),
        "grams / 100": i18n.t("grams / 100"),
        "kg x 2": i18n.t("kg x 2"),
    }.get(s, s)

def _lone_text(s):
    """LONE in the app's language (None stays None)"""
    return {
        "always males (since game update 1.3; before, half males and half females)": i18n.t("always males (since game update 1.3; before, half males and half females)"),
        "always males": i18n.t("always males"),
        "half males, half females": i18n.t("half males, half females"),
        "2 males to every female": i18n.t("2 males to every female"),
    }.get(s, s)

EXTRA_MAPS = {}      # animals without a herd ecosystem but on a map (none now)
BIRDS = ("AnasPlatyrhynchos", "AnasUndulata", "MeleagrisGallopavo", "LagopusLeucura", "StruthioCamelus", "AfrotisAfraoides")

# PREVIEW (your own desktop app only): animals that are in the game files but on no map yet. tools/preview_facts.py
# writes their facts to your config folder and turns this on; nothing of it ships (build_dist.sh checks). When a game
# update gives them herds, they show up the normal way and the preview just stops adding anything for them.
COMING = {"AfrotisAfraoides": "Map02"}     # impala came out in 1.4
PREVIEW_FLAG = os.path.join(os.path.expanduser("~"), ".config", "woth2-toybox", "preview", "on")
PREVIEW_FILE = os.path.join(os.path.dirname(PREVIEW_FLAG), "facts.json")
_NO_PREVIEW = False                                   # set by --ship: the shipped copy never has the preview
def preview_mode():
    """None (off), "coming" (pages say COMING SOON) or "live" (written as if released: a staged build for update night).
    WOTH2_PREVIEW=off|coming|live wins over the flag file (web/build_web.sh sets it, off unless asked)."""
    if _NO_PREVIEW: return None
    env = os.environ.get("WOTH2_PREVIEW")
    if env is not None:
        return env if env in ("coming", "live") else None
    if not os.path.exists(PREVIEW_FLAG): return None
    try: m = open(PREVIEW_FLAG, encoding="utf-8").read().strip()
    except OSError: m = ""
    return "live" if m == "live" else "coming"
def preview_on():
    return preview_mode() is not None
def _preview_maps():
    return os.environ.get("WOTH2_PREVIEW_MAPS", "1") != "0"      # WOTH2_PREVIEW_MAPS=0: coming animals only, no coming map pages
def preview_tag():
    """what a cached copy was made with (mode, and -nomaps when map pages were left out)"""
    m = preview_mode()
    return m and (m if _preview_maps() else m + "-nomaps")
def _soon():
    return preview_mode() == "coming"
_PREVIEW = None
def _preview():
    global _PREVIEW
    if _PREVIEW is None:
        try: _PREVIEW = json.load(open(PREVIEW_FILE, encoding="utf-8")) if preview_on() else {}
        except (OSError, ValueError): _PREVIEW = {}
    return _PREVIEW

def _pick(table, sub):
    return next((v for k, v in table.items() if sub.startswith(k)), None)

# ---------------------------------------------------------------- articles
_LAND_SPOTS = {}
def _land_spots(paks_dir, mp):
    """{land key: 'north-east' ...} from the game's land map (lands.py), cached per map."""
    if mp not in _LAND_SPOTS:
        try:
            import lands
            s = lands.summary(paks_dir, mp)
            _LAND_SPOTS[mp] = {l["key"]: l["where"] for l in s["lands"]} if s else {}
        except Exception:
            _LAND_SPOTS[mp] = {}
    return _LAND_SPOTS[mp]

def _fp(f):
    """Fitness as a percent like the map: 0.83 -> '83%', 0.875 -> '87.5%'."""
    v = round(float(f) * 100, 1)
    return (f"{v:.0f}" if abs(v - round(v)) < 1e-6 else f"{v:.1f}") + "%"

def _fpr(lo, hi):
    """A fitness range: 0.40, 0.75 -> '40-75%'."""
    return _fp(lo)[:-1] + "-" + _fp(hi)

def _job_caps(sub):
    """{(map, land): cap raise} for this animal from every habitat job (enhancements and clean-ups), opportunities.json."""
    try: opp = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "opportunities.json"), encoding="utf-8"))
    except (OSError, ValueError): return {}
    out = {}
    for mp, jobs in opp.items():
        for j in jobs:
            inc = sum(v for k, v in (j.get("cap") or {}).items() if k == sub or sub.startswith(k) or k.startswith(sub))
            if inc: out[(mp, j.get("land", ""))] = out.get((mp, j.get("land", "")), 0.0) + inc
    return out

def _spot_text(land, sp):
    """'Land (north-east of the map)' in the app's language (sp: lands.py's compass word)"""
    if not sp: return land
    if sp == "centre": return i18n.t("{land} (middle of the map)").format(land=land)
    words = {"north": i18n.t("north"), "south": i18n.t("south"), "east": i18n.t("east"), "west": i18n.t("west"),
             "north-east": i18n.t("north-east"), "north-west": i18n.t("north-west"), "south-east": i18n.t("south-east"),
             "south-west": i18n.t("south-west")}
    return i18n.t("{land} ({spot} of the map)").format(land=land, spot=words.get(sp, sp))

def _best_places(rows, land_names, paks_dir, sub="", jobs=None):
    """[[map, 'Land (north-east): starts 40-70%, can reach 100% with every job done'], ...] - the best land(s) per map
    for this animal, by the highest herd fitness it can reach (base cap + every habitat job there, at most 100%).
    jobs (a list): gets True added when a line counts every habitat job done."""
    jc = _job_caps(sub) if sub else {}
    rows = [(mp, land, lo, hi, min(1.0, cap + jc.get((mp, land), 0.0)), cap) for mp, land, lo, hi, cap in rows]
    out = []
    for mp in sorted({r[0] for r in rows}, key=lambda m: list(MAPS).index(m) if m in MAPS else 9):
        here = [r for r in rows if r[0] == mp]
        if mp == "Hub" and len(here) <= 1:
            continue
        top = max((cap, hi, lo) for _, _, lo, hi, cap, _b in here)
        bests = sorted((r for r in here if (r[4], r[3], r[2]) == top), key=lambda r: r[1])    # stable order (game file order shifts)
        spots = _land_spots(paks_dir, mp)
        txt = []
        for _, land, lo, hi, cap, _b in bests:
            nm = clean(land_names.get(f"KEY_ENVIRONMENT_{MAP_KEYS[mp]}_{land.upper()}_NAME", land))
            sp = spots.get(land)
            txt.append(_spot_text(f"{nm}", sp))
        lo, hi, cap, base = bests[0][2], bests[0][3], bests[0][4], bests[0][5]
        job = cap > base + 1e-6
        if job and jobs is not None: jobs.append(True)
        if len(here) == 1:
            t = (i18n.t("{lands}: herds start at {start} fitness and can reach {cap} with every habitat job done") if job
                 else i18n.t("{lands}: herds start at {start} fitness and can reach {cap}"))
        else:
            t = (i18n.t("{lands}: herds start at {start} fitness and can reach {cap} with every habitat job done (best of the {n} lands it lives on here)") if job
                 else i18n.t("{lands}: herds start at {start} fitness and can reach {cap} (best of the {n} lands it lives on here)"))
        lands = txt[0]
        for x in txt[1:]: lands = i18n.t("{a} or {b}").format(a=lands, b=x)
        out.append([MAPS[mp], t.format(lands=lands, start=_fpr(lo, hi), cap=_fp(cap), n=len(here))])
    return out

# game_facts.json (tools/game_facts.py, from the decoded game data): senses on Normal, meat price, XP per animal and land,
# how long a hit animal lives
_GAME_FACTS = None
def _game_facts():
    global _GAME_FACTS
    if _GAME_FACTS is None:
        try:
            _GAME_FACTS = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "game_facts.json"), encoding="utf-8"))
        except (OSError, ValueError):
            _GAME_FACTS = {}
    return _GAME_FACTS

def _nose(x):
    if not x: return i18n.t("can't smell you")
    return i18n.t("normal") if x <= 1.0 else i18n.t("a little sharper than most") if x <= 1.05 else i18n.t("sharp") if x <= 1.125 else i18n.t("very sharp")

def _heaviest(f):
    """(top weight in kg, 'male' / 'female' / 'animal') - the heavier sex's top weight from the game's body data."""
    m, w = (f.get("weight_m") or [0, 0])[1], (f.get("weight_f") or [0, 0])[1]
    if not (m or w): return None
    return (m, "male") if m > w else (w, "female") if w > m else (m, "animal")

def _sense_blocks(sub):
    f = _game_facts().get("species", {}).get(sub) or (_preview().get(sub) or {}).get("facts")
    if not f or not f.get("sight"): return []
    rows = [[i18n.t("Sees you from"), i18n.t("{m} m (wide view: {deg}°)").format(m=f['sight'], deg=f['cone']) if f.get("cone", 130) > 130 else f"{f['sight']} m"],
            [i18n.t("Hears your steps from"), f"{f['hear']} m"], [i18n.t("Nose"), _nose(f.get("smell"))]]
    out = [{"h": i18n.t("Senses (Normal)")}, {"facts": rows}]
    pk = f.get("price_kg"); hv = _heaviest(f)
    if pk and hv:
        best = int(hv[0] * 0.6 * pk)
        sale = {"male": i18n.t("about {money} (heaviest male, clean shot, sold fresh)"), "female": i18n.t("about {money} (heaviest female, clean shot, sold fresh)"),
                "animal": i18n.t("about {money} (heaviest animal, clean shot, sold fresh)")}[hv[1]]
        out += [{"h": i18n.t("Meat and XP")}, {"facts": [[i18n.t("Meat price"), i18n.t("{money} per kg").format(money=f"${pk:g}")],
                                                  [i18n.t("Best sale"), sale.format(money=f"${best:,}")],
                                                  [i18n.t("XP for the animal"), i18n.t("{xp} (see Guides > Money and XP from a kill)").format(xp=f"+{f['xp']}")]]}]
    return out

# lifestyle tag -> its text key, as the game's tag table (DT_TagInterpreter_Animals_Misc) maps it
LIFESTYLE_KEYS = {"Migrating": "MIGRATORY", "MigratingNomadic": "NOMADIC", "MigratingTerritorial": "MIGRATORYTERRITORIAL"}

def _animal_articles(tables, subs, eco_by_sub, paks_dir):
    import trophy_score as ts
    A = tables.get("ST_Animals", {})
    try:
        req = ts.thresholds(paks_dir)
        req_nt = ts.thresholds(paks_dir, "NonTypical")
    except Exception:
        req, req_nt = {}, {}
    try:
        ages = ts.game_max_ages(paks_dir)
    except Exception:
        ages = {}
    land_names = tables.get("ST_Levels", {})
    arts = []
    for sub, data in sorted(subs.items()):
        import zenpkg
        try:
            z = zenpkg.ZenPackage(data)
        except Exception:
            continue
        names = [z.name(k) for k in range(len(z.names))]
        raw = z.export_data[0]
        keys = [s.decode() for s in re.findall(rb"KEY_ANIMALS_[A-Z0-9_]+", raw)]
        sp = next((re.match(r"KEY_ANIMALS_SPECIES_([A-Z0-9]+?)_(?:APPEARANCE|DESCRIPTION|HUNTING|TRIVIA)", k).group(1)
                   for k in keys if re.match(r"KEY_ANIMALS_SPECIES_([A-Z0-9]+?)_(?:APPEARANCE|DESCRIPTION|HUNTING|TRIVIA)", k)), None)
        sk = next((m.group(1) for k in keys for m in [re.match(r"(KEY_ANIMALS_SUBSPECIES_[A-Z0-9]+?)_(?:NAME|DESCRIPTION)", k)] if m),
                  "KEY_ANIMALS_SUBSPECIES_" + sub.upper())
        title = A.get(sk + "_NAME") or sub
        rated = bool(req and (ts._match(req, sub, "M") or ts._match(req, sub, "F")))
        pv = _preview().get(sub) if sub not in eco_by_sub and sub in COMING else None
        if title == sub or (sub not in eco_by_sub and not pv):
            continue                                       # no herds on any map in this build: not in the game
        g = lambda k: clean(A.get(k, ""))
        blocks = []
        if pv and _soon():
            blocks.append({"note": i18n.t("COMING SOON - not in the game yet. Everything here is from the game files and can still change when the update comes out.")})
        latin = g(sk + "_NAME_LATIN")
        alts = [g(k) for k in A if k.startswith(sk + "_NAME_ALTERNATIVE")]
        desc = [x for x in (g(f"KEY_ANIMALS_SPECIES_{sp}_DESCRIPTION") if sp else "", g(sk + "_DESCRIPTION")) if x]
        for d in desc:
            blocks.append({"p": d})
        facts = []
        tag = lambda pre: next((n.split(".")[-1] for n in names if n.startswith(pre)), None)
        lc, ls, diff = tag("Animals.LifeCycle."), tag("Animals.Lifestyle."), tag("Animals.SubspeciesHuntingDifficulty.")
        if lc:
            facts.append([i18n.t("Active"), clean(A.get(f"KEY_ANIMALS_LIFECYCLES_{lc.upper()}_NAME", lc))])
        if ls:
            lk = LIFESTYLE_KEYS.get(ls, ls.upper())
            facts.append([i18n.t("Lifestyle"), clean(A.get(f"KEY_ANIMALS_LIFESTYLES_{lk}_NAME", re.sub(r"^Migrating(?=[A-Z])", "Migratory/", ls)))])
        if diff:
            dw = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", diff).capitalize()
            facts.append([i18n.t("Hunting difficulty"), {"Very low": i18n.t("Very low"), "Low": i18n.t("Low"), "Medium": i18n.tc("difficulty", "Medium"),
                                                        "High": i18n.t("High"), "Very high": i18n.t("Very high")}.get(dw, dw)])
        dims = re.findall(rb"(?:\x02|\x03|\x04|\x05|\x06)\x00\x00\x00(\d{1,5}(?:\.\d+)?)\x00", raw)   # the same four strings _animal_tier reads
        if len(dims) >= 4:
            h, l, v, w = (x.decode() for x in dims[:4])
            hv = _heaviest(_game_facts().get("species", {}).get(sub) or (_preview().get(sub) or {}).get("facts") or {})
            wt = i18n.t("up to {n} kg").format(n=f"{hv[0]:g}" if hv else w)           # the real top weight; the codex figure is only a guide
            facts += [[i18n.t("Height"), i18n.t("up to {n} cm").format(n=h)], [i18n.t("Length"), i18n.t("up to {n} cm").format(n=l)],
                      [i18n.t("Top speed"), f"{v} km/h"], [i18n.t("Weight"), wt]]
        tier = _animal_tier(raw)
        if tier:
            tables.setdefault("_animal_tiers", {})[title] = tier
            facts.insert(0, [i18n.t("Tier"), i18n.t("{tier} - use ammunition rated for tier {tier} (see Gear > Tiers)").format(tier=tier)])
        if ages.get(sub):
            facts.append([i18n.t("Oldest age"), i18n.t("{n} years").format(n=ages[sub])])
        if alts:
            facts.append([i18n.t("Also called"), ", ".join(alts)])
        if facts:
            blocks.append({"h": i18n.t("At a glance")}); blocks.append({"facts": facts})
        ap = [(lab, g(f"KEY_ANIMALS_SPECIES_{sp}_APPEARANCE_{k}")) for lab, k in
              ((i18n.t("Age"), "AGE"), (i18n.t("Plumage") if sub.startswith(BIRDS) else i18n.t("Coat"), "COAT"), (i18n.t("Size"), "DIMENSIONS"), (i18n.t("Sexes"), "SEX"))] if sp else []
        ap = [[a, b] for a, b in ap if b]
        if ap:
            blocks.append({"h": i18n.t("Appearance")}); blocks.append({"facts": ap})
        if sp:
            bi = g(f"KEY_ANIMALS_SPECIES_{sp}_HUNTING_BIOMES")
            st = [g(k) for k in sorted(A) if k.startswith(f"KEY_ANIMALS_SPECIES_{sp}_HUNTING_STRENGTHS")]
            we = [g(k) for k in sorted(A) if k.startswith(f"KEY_ANIMALS_SPECIES_{sp}_HUNTING_WEAKNESSES")]
            if bi or st or we:
                blocks.append({"h": i18n.t("Hunting")})
                if bi:
                    blocks.append({"facts": [[i18n.t("Where"), bi]]})
                if st:
                    blocks.append({"p": i18n.t("Strengths")}); blocks.append({"list": st})
                if we:
                    blocks.append({"p": i18n.t("Weaknesses")}); blocks.append({"list": we})
        blocks += _sense_blocks(sub)
        if sub.startswith("Meleagris"):
            blocks.append({"h": i18n.t("When spooked")})
            blocks.append({"list": [
                i18n.t("A spooked flock runs off about 100 m (90 to 110 m)."),
                i18n.t("Then it flies about 300 m (290 to 310 m).")]})
        # best place: per map, the land whose herds can get fittest (highest fitness cap, then starting fitness)
        jobs = []
        best = _best_places(eco_by_sub.get(sub, []), land_names, paks_dir, sub, jobs)
        if best:
            blocks.append({"h": i18n.t("Best place")})
            blocks.append({"facts": best})
            blocks.append({"p": i18n.t("Herds here can get the fittest (with every habitat job done).") if jobs else i18n.t("Herds here can get the fittest.")})
        # trophy
        tb = []
        T = [None, None]
        for k, sx in enumerate("MF"):
            T[k] = ts._match(req, sub, sx) if req else None
        meas = _pick(MEASURED, sub)
        wr = _pick(WEIGHT_RULE, sub)
        if meas or wr:
            tb.append({"facts": [[i18n.t("Measured"), _measured_text(meas[1]) if meas else i18n.t("weight: {rule} = points").format(rule=_weight_rule_text(wr))]]})
        rows = []; has_nt = False
        males_only = bool(meas and meas[0] == "M")
        if T[0] and T[1] and T[0] == T[1] and not males_only:
            rows.append([i18n.t("Both sexes")] + [str(x) for x in T[0]])
        else:
            for k, sx in enumerate(("Male", "Female")):
                if T[k] and not (males_only and k == 1):
                    nt = ts._match(req_nt, sub, sx[0]) if req_nt else None
                    nt = nt if nt and nt != T[k] else None
                    sxt = {"Male": (i18n.t("Male"), i18n.t("Male, typical"), i18n.t("Male, non-typical")),
                           "Female": (i18n.t("Female"), i18n.t("Female, typical"), i18n.t("Female, non-typical"))}[sx]
                    rows.append([sxt[1] if nt else sxt[0]] + [str(x) for x in T[k]])
                    if nt:
                        rows.append([sxt[2]] + [str(x) for x in nt]); has_nt = True
        if T[0] or T[1]:
            tables.setdefault("_plain_titles", {})[sub] = clean(title)            # its name without "(coming soon)"
            tables.setdefault("_score_lines", {})[sub] = {"M": list(T[0]) if T[0] else None,
                                                          "F": list(T[1]) if T[1] and not males_only else None}
            nt_m = ts._match(req_nt, sub, "M") if req_nt else None
            if nt_m and T[0] and list(nt_m) != list(T[0]):          # 1.3: non-typical bucks have their own lines
                tables["_score_lines"][sub]["M_NT"] = list(nt_m)
        if rows:
            tb.append({"p": i18n.t("Score lines: the points each star needs (see Trophies > How stars are given).")})
            tb.append({"table": {"cols": [i18n.t("Sex"), i18n.t("2 stars"), i18n.t("3 stars"), i18n.t("4 stars"), i18n.t("5 stars")], "rows": rows}})
            if has_nt:
                tb.append({"p": i18n.t("Non-typical bucks (since game update 1.3): about 1 buck in 18 grows a non-typical rack, and you "
                                "never go more than 40 bucks without one. It can grow every extra tine a typical rack never gets, "
                                "so it has its own, higher star lines. The animal analysis screen (binoculars) shows it under Trophy rarity, which "
                                "is on by default (Settings > Hunter Assist > Animal analysis customization).")})
                ntf = _nt_fact()
                if ntf: tb.append({"p": ntf})
        if pv and wr and T[0]:
            per = {"grams / 2": 2, "grams / 5": 5, "grams / 50": 50, "grams / 100": 100}.get(wr)
            if per:
                rows_w = [[sx] + [f"{x * per / 1000:.3f} kg" for x in T[k]] for k, sx in enumerate((i18n.t("Male"), i18n.t("Female"))) if T[k]]
                if len(rows_w) == 2 and rows_w[0][1:] == rows_w[1][1:]: rows_w = [[i18n.t("Both sexes")] + rows_w[0][1:]]
                fw = (pv.get("facts") or {})
                tops = [lab.format(n=f"{w[1]:g}") for lab, w in ((i18n.t("males up to {n} kg"), fw.get("weight_m")), (i18n.t("females up to {n} kg"), fw.get("weight_f"))) if w]
                tb.append({"p": i18n.t("Weight each star needs:")})
                tb.append({"table": {"cols": [i18n.t("Sex"), i18n.t("2 stars"), i18n.t("3 stars"), i18n.t("4 stars"), i18n.t("5 stars")], "rows": rows_w}})
                if tops: tb.append({"p": i18n.t("Heaviest: {list}. Only the very top birds make 5 stars.").format(list=", ".join(tops))})
        if pv and not tb:
            tb.append({"p": i18n.t("No trophy scoring in the game files yet: no score lines, nothing measured. It should come with the update.")
                            if _soon() else i18n.t("Trophy scoring for this animal is coming soon.")})
        if tb:
            blocks.append({"h": i18n.t("Trophy")}); blocks += tb
        blocks += _rare_coat_blocks(sub)
        # herd
        lands = eco_by_sub.get(sub, [])
        if lands:
            mods = _herd_mods(data)
            blocks.append({"h": i18n.t("Herd management")})
            sexrow = ([i18n.t("Harvesting a male"), i18n.t("moves herd fitness {x} times as much as a female").format(x=f"{mods['male'] / mods['female']:g}")]
                      if abs(mods["male"] - mods["female"]) > 1e-9 else [i18n.t("Males and females"), i18n.t("move herd fitness the same")])
            lone = _lone_text(_pick(LONE, sub))
            blocks.append({"facts": [sexrow,
                                     [i18n.t("When herd fitness goes up"), i18n.t("each rise is {x} times bigger").format(x=f"{mods['upward']:g}")]]
                                    + ([[i18n.t("Lone animals"), lone]] if lone else [])})
            lr = []
            for mp, land, lo, hi, cap in sorted(lands):
                ln = clean(land_names.get(f"KEY_ENVIRONMENT_{MAP_KEYS[mp]}_{land.upper()}_NAME", land))
                lr.append([MAPS[mp], ln, _fpr(lo, hi), _fp(cap)])
            # "Map" stays English: the app finds the herd table by it (enc_page.gd: only the map it was opened under)
            blocks.append({"table": {"cols": [i18n.t("Map"), i18n.t("Land"), i18n.t("Herd starts at"), i18n.t("Herd cap")], "rows": lr}})
            blocks.append({"note": i18n.t("These are herd fitness, not single animals: animals are born around their herd's fitness and can be fitter than the cap. Habitat jobs on a private land raise the herd cap there, up to 100% (an enhancement for this animal +10%, a clean-up +10% to +30%), and give the herd a small fitness boost right away.")})
        if pv:
            mp = pv.get("map", "Map02")
            terr = (pv.get("territories") or {}).get(mp) or {}
            if terr:
                lr = []
                for land, r in sorted(terr.items()):
                    ln = clean(land_names.get(f"KEY_ENVIRONMENT_{MAP_KEYS[mp]}_{land.upper()}_NAME", land))
                    kw = {"Big": i18n.t("{n} big"), "Medium": i18n.tc("herds", "{n} medium"), "Small": i18n.t("{n} small"), "Solitary": i18n.t("{n} solitary")}
                    kinds = ", ".join(kw[k].format(n=r[k]) for k in ("Big", "Medium", "Small", "Solitary") if r.get(k))
                    lr.append([ln, kinds])
                nh = sum(sum(v for k, v in r.items() if k != 'animals') for r in terr.values())
                blocks.append({"h": i18n.t("Where it will live") if _soon() else i18n.t("Where it lives")})
                blocks.append({"p": (i18n.t("{map}: {n} herds, already on the map in the game files.") if _soon() else i18n.t("{map}: {n} herds.")).format(map=MAPS[mp], n=nh)})
                blocks.append({"table": {"cols": [i18n.t("Land"), i18n.t("Herds")], "rows": lr}})
                lone = _lone_text(_pick(LONE, sub))
                if lone: blocks.append({"facts": [[i18n.t("Lone animals"), lone]]})
            ms = pv.get("missions") or []
            if ms:
                blocks.append({"h": i18n.t("Missions")})
                for m in ms:
                    blocks.append({"facts": [[m["name"], m["objective"]]]})
                    if m.get("about"): blocks.append({"p": clean(m["about"])})
        # trivia: every line the game's own animal data lists, in its order (species and subspecies lines)
        tr = [g(k) for k in dict.fromkeys(k for k in keys if "_TRIVIA" in k) if g(k)]
        if tr:
            blocks.append({"h": i18n.t("Trivia")}); blocks.append({"list": tr})
        maps = sorted({MAPS[mp] for mp, *_ in lands}) or EXTRA_MAPS.get(sub, []) or ([MAPS[pv["map"]]] if pv else [])
        main_map = next((m for m in maps if m != MAPS["Hub"]), maps[0] if maps else i18n.t("Other"))
        arts.append({"id": "animal:" + sub, "title": i18n.t("{name} (coming soon)").format(name=clean(title)) if pv and _soon() else clean(title), "subtitle": latin, "group": main_map,
                     "where": ", ".join(maps), "tags": [sub] + alts + ((["coming soon"] if _soon() else []) + ["new"] if pv else []), "blocks": blocks,
                     **({"preview": True} if pv else {})})
    return arts

# rare coats: fur_odds.json (tools/fur_odds.py) - each map's coat table plus the game's guarantee, as the share of
# newly added animals that get each coat in the long run
TIER_NAMES = {"Rare": "Rare", "VeryRare": "Very rare", "Uncommon": "Uncommon"}
_FUR_ODDS = None
def _fur_odds():
    global _FUR_ODDS
    if _FUR_ODDS is None:
        try:
            _FUR_ODDS = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "fur_odds.json"), encoding="utf-8"))
        except (OSError, ValueError):
            _FUR_ODDS = {}
        _exact_fur_odds(_FUR_ODDS)
    return _FUR_ODDS

def _exact_fur_odds(odds):
    """Swap the long-run shares from the spawn simulation for the exact ones. Each spawn the tier is rolled with
    chance p (its weight / the total weight); its counter forces it after N spawns without one (N = the pity value).
    So the gap between two coats of the tier is min(rolls until a hit, N): mean (1 - (1 - p)^N) / p, and the share is
    p / (1 - (1 - p)^N). (The tiers only meet on a forced spawn, which moves this by far less than the rounding.)
    Each coat keeps its part of its tier, which the file gives exactly."""
    for per_map in odds.values():
        for d in per_map.values():
            tiers = d.get("tiers", {})
            for r, t in tiers.items():
                p, n = t.get("plain"), t.get("pity")
                if not p or not n or not t.get("share"): continue
                exact = p / (1 - (1 - p) ** n)
                k = exact / t["share"]
                for c in d.get("coats", {}).values():
                    if c.get("tier") == r:
                        c["M"] *= k; c["F"] *= k
                t["share"] = exact

def _one_in(p):
    if not p:
        return i18n.t("never")
    x = 1 / p
    return i18n.t("1 in {n}").format(n=f"{int(round(x, 3 - len(str(int(x))))):,}")

def _coat_text(name):
    """a coat (fur_odds.json) or coat tier name in the app's language"""
    return {"Albino": i18n.t("Albino"), "Erythristic": i18n.t("Erythristic"), "Leucistic": i18n.t("Leucistic"),
            "Melanistic": i18n.t("Melanistic"), "Piebald": i18n.t("Piebald"),
            "Rare": i18n.t("Rare"), "Very rare": i18n.t("Very rare"), "Uncommon": i18n.t("Uncommon")}.get(name, name)

def _rare_coat_blocks(sub):
    odds = _fur_odds()
    if not odds:
        return []
    per_map = odds.get(sub)
    if not per_map:
        return [{"h": i18n.t("Rare coats")}, {"p": i18n.t("None: this animal always has its normal coat.")}]
    main = next((m for m in ("Map01", "Map02") if m in per_map), next(iter(per_map)))
    d = per_map[main]
    same_everywhere = all(v == d for v in per_map.values())
    order = {"Rare": 0, "Uncommon": 0, "VeryRare": 1}
    coats = sorted(d["coats"].items(), key=lambda kv: (order.get(kv[1]["tier"], 2), -kv[1]["M"], kv[0]))
    split = any(abs(c["M"] - c["F"]) > 1e-12 for _n, c in coats)
    rows = []
    for name, c in coats:
        tier = TIER_NAMES.get(c["tier"], c["tier"])
        rows.append([_coat_text(name), _coat_text(tier), _one_in(c["M"])] + ([_one_in(c["F"])] if split else []))
    anyp = sum(t["share"] for t in d["tiers"].values())
    rows.append([i18n.t("Any rare coat"), "", _one_in(anyp)] + ([_one_in(anyp)] if split else []))
    cols = [i18n.t("Coat"), i18n.t("Kind"), i18n.t("Males") if split else i18n.t("Chance")] + ([i18n.t("Females")] if split else [])
    tiers = d["tiers"]
    plain = " and ".join(f"a {TIER_NAMES.get(r, r)} coat {_one_in(t['plain'])}" for r, t in sorted(tiers.items(), key=lambda kv: order.get(kv[0], 2)))
    pity = " and ".join(f"a {TIER_NAMES.get(r, r)} one at least once every {t['pity']:,}" for r, t in sorted(tiers.items(), key=lambda kv: order.get(kv[0], 2)))
    note = (i18n.t("Chance per animal. The game also hands out a rare coat for sure after a long dry spell, which is counted in.") if split else
            i18n.t("Chance per animal. The game also hands out a rare coat for sure after a long dry spell, which is counted in. Same for males and females."))
    return [{"h": i18n.t("Rare coats")}, {"table": {"cols": cols, "rows": rows}}, {"note": note}]

def _rare_coat_list():
    """{subspecies: [[coat, tier, males, females], ...]} every rare coat that spawns on some map (Stats > RARES)."""
    order = {"Rare": 0, "Uncommon": 0, "VeryRare": 1}
    out = {}
    for sub, per_map in _fur_odds().items():
        coats = {}
        for d in per_map.values():
            for name, c in d["coats"].items():
                was = coats.get(name, [name, TIER_NAMES.get(c["tier"], c["tier"]), False, False])
                coats[name] = [name, was[1], was[2] or c["M"] > 0, was[3] or c["F"] > 0]
        out[sub] = sorted(coats.values(), key=lambda c: (order.get(next((k for k, v in TIER_NAMES.items() if v == c[1]), ""), 2), c[0]))
    return out

def _how_maps_articles():
    """MAPS > How the maps work + Multiplayer: only what the game files, the game's own text and the official
    known issues say (multiplayer rules = the Quick play screen's own list)."""
    return [
        {"id": "guide:maps", "title": i18n.t("How the maps work"), "subtitle": i18n.t("What each map keeps"), "group": i18n.t("Maps"),
         "tags": ["map", "maps", "save", "clock", "year", "fast travel", "markers", "tents", "reset"], "blocks": [
            {"p": i18n.t("There are three maps: New Laurentia, Kilimaya Reserve and Hearth & Hunt Headquarters. Your save keeps each "
                  "map on its own: its animals, its clock, the jobs you've done there and the places you've found.")},
            {"h": i18n.t("Animals stay put")},
            {"list": [i18n.t("When you first go to a map, the game makes all its herds. From then on they are the same herds every "
                      "time you come back, until you hunt them."),
                      i18n.t("Every herd lives in its own territory and walks between its feeding, drinking and resting zones on a "
                      "daily routine. It doesn't wander off to the other side of the map."),
                      i18n.t("A game year is 3 game days. At midnight when a new year starts, every animal gets a year older and its "
                      "antlers or horns grow again from scratch. Right after, herds that lost animals get young ones back, up "
                      "to a number set by the herd's fitness (see Herd size).")]},
            {"h": i18n.t("Time")},
            {"list": [i18n.t("Each map has its own game clock, so it can be Day 3 on one map and Day 10 on another."),
                      i18n.t("A game day lasts about 5 real hours (the clock runs 4 times real time by day and 6 times at night)."),
                      i18n.t("A new New Laurentia game starts at 08:09. Kilimaya and Headquarters start at 11:00."),
                      i18n.t("Changing the weather setting only takes effect 48 game hours later.")]},
            {"h": i18n.t("Getting around")},
            {"list": [i18n.t("Fast travel is free and doesn't move the clock. It goes to any camp, cabin, station, lodge or "
                      "shooting range you have found, and to your own tents (up to 16)."),
                      i18n.t("Places you haven't found yet show as ? on the game map."),
                      i18n.t("You can put up to 16 of your own markers on the map in single player (8 in multiplayer), and track "
                      "one animal at a time up to 400 m away.")]},
            {"note": i18n.t("Each map's own page (in the list) shows its lands and how fit the herds there can get. "
                     "Multiplayer works differently: see Multiplayer (co-op).")}]},
        {"id": "guide:multiplayer", "title": i18n.t("Multiplayer (co-op)"), "subtitle": i18n.t("The world isn't kept"), "group": i18n.t("Maps"),
         "tags": ["multiplayer", "co-op", "coop", "online", "host", "join", "quick play", "friends", "reset", "persistent", "session"], "blocks": [
            {"p": i18n.t("Co-op is still a beta. Two players hunt together: one creates the game (the host) and the other joins.")},
            {"h": i18n.t("The map starts fresh every time")},
            {"p": i18n.t("Quick play is the co-op mode that's out (\"Short hunts with friends and random players\"). The game's own "
                  "rules for it:")},
            {"list": [i18n.t("The game world isn't kept for the next session. Every co-op session is a new world: animals, herds and "
                      "what you found are gone when it ends."),
                      i18n.t("Your hunter's progress is kept. It carries over to single player and to your next co-op game."),
                      i18n.t("No Shop and no Storage during co-op."),
                      i18n.t("No sleeping, no hanging up taxidermy and no habitat jobs during co-op.")]},
            {"p": i18n.t("So scouting a herd in co-op doesn't help next time: the herds are new. Your single-player map is separate: "
                  "what you found there doesn't show in co-op (the developers list this as a known issue), and since the "
                  "co-op world isn't kept, nothing in it changes your single-player map.")},
            {"h": i18n.t("The host")},
            {"list": [i18n.t("The host picks the map and the difficulty, and can give the game a name and a password. The host's "
                      "difficulty is the one that counts."),
                      i18n.t("When the host fast travels to another map, everyone goes along."),
                      i18n.t("Both players need the same game version. Update the game if it says the host or the session is out "
                      "of date.")]},
            {"h": i18n.t("Playing together")},
            {"list": [i18n.t("An animal the other player has a claim on can't be harvested by you."),
                      i18n.t("A vehicle or a stand that is full can't take another player."),
                      i18n.t("Own map markers: 8 in co-op (16 in single player)."),
                      i18n.t("Finish the tutorial before joining a co-op game. Joining without it can lock up your save (official "
                      "known issue).")]},
            {"note": i18n.t("Herd Management and Expeditions are on the multiplayer screen but say Coming soon. The official list of "
                     "co-op problems is in GUIDES > Known issues (official).")},
            {"h": i18n.t("And the Toybox")},
            {"p": i18n.t("The Toybox reads your single-player save. Co-op worlds aren't saved, so the Toybox can't show the animals "
                  "of a co-op game, and your Toybox notes and pins are for your single-player maps.")}]}]

def _map_articles(tables, eco_by_sub, sub_names):
    L = tables.get("ST_Levels", {})
    arts = []
    for mp, mk in MAP_KEYS.items():
        pre = f"KEY_ENVIRONMENT_{mk}"
        title = clean(L.get(pre + "_NAME", MAPS[mp]))
        blocks = []                                   # the game's flavour text about each map and land is left out: tables only
        lands = sorted({land for v in eco_by_sub.values() for m, land, *_ in v if m == mp})
        for land in lands:
            lp = f"{pre}_{land.upper()}"
            blocks.append({"h": (i18n.t("{land} (private land)") if "Private" in land else i18n.t("{land} (public land)")).format(land=clean(L.get(lp + "_NAME", land)))})
            rows = [[sub_names.get(s, s), _fpr(lo, hi), _fp(cap)]
                    for s, v in sorted(eco_by_sub.items(), key=lambda kv: sub_names.get(kv[0], kv[0]))
                    for m, ld, lo, hi, cap in v if m == mp and ld == land]
            if rows:
                blocks.append({"table": {"cols": [i18n.t("Animal"), i18n.t("Herd starts at"), i18n.t("Herd cap")], "rows": rows, "links": "animals"}})
        extra = sorted(sub_names.get(s, s) for s, m in EXTRA_MAPS.items() if MAPS[mp] in m)
        if extra:
            blocks.append({"p": i18n.t("Also found here, with no herd on any land: {list}.").format(list=", ".join(extra))})
        if not lands and not extra:
            pm = (_preview().get("_maps") or {}).get(mp) if _preview_maps() else None
            if not pm: continue                       # no herds on this map in this build: not in the game (yet)
            blocks = _coming_map_blocks(pm, L, pre)
            arts.append({"id": "map:" + mp, "title": i18n.t("{name} (coming soon)").format(name=title) if _soon() else title, "subtitle": "", "group": i18n.t("Maps"),
                         "tags": ["coming soon", "new", "dlc"], "blocks": blocks, "preview": True})
            continue
        if lands:
            blocks.insert(0, {"p": i18n.t("Herd starts at: where a herd's fitness starts on that land. Herd cap: the most the herd's fitness can reach. Single animals can be fitter than their herd. Each habitat enhancement for an animal raises its cap on that land by 10%, up to 100%. Click an animal to open its page.")})
        arts.append({"id": "map:" + mp, "title": title, "subtitle": "", "group": i18n.t("Maps"), "tags": [], "blocks": blocks})
    return arts

def _coming_map_blocks(pm, L, pre):
    """A map that is named in the game files but not out yet (preview only): its lands, people, weather and the
    animals the game already lists for it."""
    b = [{"note": i18n.t("COMING SOON - not in the game yet. Only names are in the game files so far: no terrain, no herds, no animal data. "
                  "Everything here can still change.")}] if _soon() else []
    if pm.get("about"): b.append({"p": pm["about"]})
    rows = []
    for land, doms in sorted(pm.get("lands", {}).items(), key=lambda kv: ("Public" in kv[0], kv[0])):
        rows.append([clean(L.get(f"{pre}_{land.upper()}_NAME", land)), i18n.t("private") if "Private" in land else i18n.t("public"), str(doms)])
    if rows:
        b.append({"h": i18n.t("Lands")}); b.append({"table": {"cols": [i18n.t("Land"), i18n.t("Type"), i18n.t("Areas")], "rows": rows}})
    if pm.get("animals"):
        b.append({"h": i18n.t("Animals")}); b.append({"table": {"cols": [i18n.t("Animal"), i18n.t("Latin name")], "rows": pm["animals"]}})
    if pm.get("people"):
        b.append({"h": i18n.t("People")}); b.append({"list": pm["people"]})
    if pm.get("weather"):
        b.append({"h": i18n.t("Weather")}); b.append({"list": pm["weather"]})
    return b

def _dlc_article():
    """Guides > DLC: the DLC packs that are out (store pages, checked 2026-10-15). Nothing unreleased."""
    items = [
        i18n.t("Night Hunting Pack ($4.99): Overgaard Night Hawk 4-16x binoculars, Overgaard Night Stalker 5-15x scope, "
        "ZOOMXD Blackout-NV collimator and ZOOMXD ShadowView 1-5x crossbow scope. Free if you own the first Way of the Hunter "
        "on the same platform."),
        i18n.t("Heirloom Pack ($4.99, the pre-order pack): Strasser RS14 WotH Edition (.243 Win), Primacy Vision Deluxe 4-16x50 "
        "WotH Edition scope, Primacy Superior 7700 with MDT Oryx chassis (.270 Win) and a bronze elk statue at your lodge."),
        i18n.t("Lodge Decoration ($1.99): big animal statues by the lodge entrances. It is part of the Season Pass."),
        i18n.t("Season Pass ($34.99): includes Lodge Decoration. The Deluxe Edition (game + Season Pass) is $59.99.")]
    return {"id": "guide:dlc", "title": i18n.t("DLC"), "subtitle": i18n.t("The packs that are out"),
            "group": i18n.t("Hunting guides"), "tags": ["dlc", "season pass", "night hunting", "heirloom", "lodge decoration"],
            "blocks": [{"p": i18n.t("Every DLC pack for Way of the Hunter 2 that is out now, and what's in it.")}, {"list": items}]}

def _guide_articles(tables, guides):
    G = tables.get("ST_Guides", {})
    arts = []
    for gid, data in sorted(guides.items()):
        keys = [s.decode() for s in re.findall(rb"KEY_METAGAME_ENCYCLOPEDIA_[A-Z0-9_]+", data)]
        seen, order = set(), []
        for k in keys:
            if k not in seen and k in G:
                seen.add(k); order.append(k)
        if not order:
            continue
        title = clean(G[order[0]]) if order[0].endswith("_NAME") else gid
        blocks = []
        for k in order[1:] if order[0].endswith("_NAME") else order:
            blocks.append({"h": clean(G[k])} if re.search(r"_NAME\d*$", k) else {"p": clean(G[k])})
        arts.append({"id": "guide:" + gid, "title": title, "subtitle": "", "group": i18n.t("Hunting guides"), "tags": [], "blocks": blocks})
    tips = [clean(v) for k, v in sorted(G.items()) if re.match(r"KEY_METAGAME_ENCYCLOPEDIA_TIP(LOADING)?\d+_DESCRIPTION$", k)]
    if tips:
        arts.append({"id": "guide:tips", "title": i18n.t("Hunting tips"), "subtitle": "", "group": i18n.t("Hunting guides"), "tags": [],
                     "blocks": [{"list": tips}]})
    return arts

GEAR = [("ST_Weapons", "Weapons"), ("ST_Ammunition", "Ammunition"), ("ST_Optics", "Optics"),
        ("ST_Attachments", "Attachments"), ("ST_Callers", "Callers"), ("ST_Decoys", "Decoys"),
        ("ST_LuringScents", "Luring scents"), ("ST_Ambushing", "Blinds and stands"),
        ("ST_Mounting", "Shooting sticks"), ("ST_Backpacks", "Backpacks"), ("ST_Tents", "Tents"),
        ("ST_Vehicles", "Vehicles")]

def _caller_blocks(tables, T):
    """Each caller the game sells, with its calls and what each call brings in (from the game's call data)."""
    A = tables.get("ST_Animals", {})
    sub = lambda s: clean(A.get("KEY_ANIMALS_SUBSPECIES_" + s.upper() + "_NAME", s))
    blocks = []
    callers = sorted({m.group(1) for k in T for m in [re.match(r"KEY_GEAR_(CALLER\d+)_NAME$", k)] if m and k in tables.get("_meta_names", {k})},
                     key=lambda c: clean(T[f"KEY_GEAR_{c}_NAME"]))
    pics = _enc_images().get("gear", {})
    for c in callers:
        blocks.append({"h": clean(T[f"KEY_GEAR_{c}_NAME"])})
        if pics.get(c): blocks.append({"imgs": [{"img": pics[c]}]})
        rows = []
        for ck, tags in sorted(tables.get("_calls", {}).items()):
            m = re.match(r"(Caller\d+)_Call(\d+)$", ck)
            if not m or m.group(1).upper() != c: continue
            call = clean(T.get(f"KEY_GEAR_{c}_CALL{m.group(2)}_NAME", "")) or i18n.t("Call {n}").format(n=int(m.group(2)))
            spp = sorted({sub(t.split(".")[-1]) for t in tags if t.startswith("Animals.Subspecies.")})
            sex = {t.split(".")[-1] for t in tags if t.startswith("Animals.Sex.")}
            fit = [t.split(".")[-1] for t in tags if t.startswith("Animals.Fitness.")]
            who = "both" if len(sex) != 1 else ("males" if "Male" in sex else "females")
            fw = fit[0] if fit and fit[0] in ("High", "Low") else ""
            brings = {("", "both"): i18n.t("males and females"), ("", "males"): i18n.t("males"), ("", "females"): i18n.t("females"),
                      ("High", "both"): i18n.t("high fitness males and females"), ("High", "males"): i18n.t("high fitness males"),
                      ("High", "females"): i18n.t("high fitness females"), ("Low", "both"): i18n.t("low fitness males and females"),
                      ("Low", "males"): i18n.t("low fitness males"), ("Low", "females"): i18n.t("low fitness females")}[(fw, who)]
            rows.append([call, ", ".join(spp) or "-", brings])
        if rows:
            blocks.append({"table": {"cols": [i18n.t("Call"), i18n.t("Animals"), i18n.t("Brings in")], "rows": rows, "w": [16, 30, 22]}})
        else:
            d = clean(T.get(f"KEY_GEAR_{c}_DESCRIPTION", ""))
            if d: blocks.append({"p": d})
    return blocks

def _enc_images():
    try: return json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "enc_images.json"), encoding="utf-8"))
    except (OSError, ValueError): return {}

def _img_key(s):
    return re.sub(r"[^A-Z0-9]", "", s.upper())

DLC_MARK = {"PreOrder": " (Heirloom Pack DLC)", "NightHunting": " (Night Hunting Pack DLC)"}

def _dlc_name(name, pack):
    """The game's name plus its pack, without double brackets: 'Primacy Superior 7700 (MDT Oryx Chassis)' ->
    'Primacy Superior 7700 MDT Oryx Chassis (Heirloom Pack DLC)'."""
    if not pack: return name
    return re.sub(r"\s*\(([^()]*)\)", r" \1", name).strip() + " " + _dlc_mark(pack)

def _dlc_mark(pack):
    """DLC_MARK in the app's language, without its leading space"""
    return {"PreOrder": i18n.t("(Heirloom Pack DLC)"), "NightHunting": i18n.t("(Night Hunting Pack DLC)")}[pack]

def _dlc_marks():
    """every pack mark as a name ends with it (for str.endswith)"""
    return tuple(" " + _dlc_mark(p) for p in DLC_MARK)

def _dlc(tables, stem):
    """'NightHunting' / 'PreOrder' / None for a text key or item id (KEY_GEAR_ATTACHMENTS_SCOPENV03, RifleBolt26_Preorder)."""
    k = _img_key(stem)
    return next((v for iid, v in tables.get("_entitled", {}).items() if k.endswith(iid)), None)

def _match_img(stem, pics):
    """The picture for a game text key (KEY_GEAR_WEAPONS_RIFLEBOLT28) among {ITEM ID: file}: the longest item id inside
    the key (not followed by another digit), else the shortest id that starts with the key's end."""
    k = _img_key(stem); best = None
    for pid in pics:
        i = k.find(pid)
        if i >= 0 and not (i + len(pid) < len(k) and k[i + len(pid)].isdigit() and pid[-1].isdigit()):
            if best is None or len(pid) > len(best): best = pid
    if best: return pics[best]
    for n in range(len(k) - 6, 0, -1):
        tail = k[n:]
        c = sorted((pid for pid in pics if pid.startswith(tail) and len(tail) >= 7), key=len)
        if c: return pics[c[0]]
    return None

def _canon(gid):
    """Shop / unlock / item ids written the same way (the game spells some calibers two ways)."""
    u = re.sub(r"[^A-Z0-9]", "", gid.upper())
    for x, y in (("338LAPUAMAGNUM", "LAPUAMAG"), ("338LAPUAMAG", "LAPUAMAG"), ("270WIN", "270W")): u = u.replace(x, y)
    return u

def _shop_info(tables):
    """{canon item id: {"price": int, "level": int or None}} from the shop data and the hunter level rewards."""
    if "_shop" in tables: return tables["_shop"]
    out = {}
    for gid, pr in tables.get("_price", {}).items():
        out[_canon(gid)] = {"price": pr, "level": None, "id": gid}
    # the same item under the name its own data gives it (Scope14 is shown as KEY_..._SCOPE14_CUSTOM01): both spellings
    # lead to one entry, so a level reward that uses the shown name still finds the price
    for mid, key in tables.get("_meta_key", {}).items():
        e = out.get(_canon(mid))
        m = re.match(r"KEY_GEAR_(?:WEAPONS|ATTACHMENTS|OPTICS|AMMUNITION_[A-Z]+|[A-Z]+)_(.+)_NAME$", key)
        if e and m and _canon(m.group(1)) not in out: out[_canon(m.group(1))] = e
    for lv, d in sorted(tables.get("_levels", {}).items()):
        if not (1 <= lv <= 200 and d.get("xp", 0) > 0): continue
        for gid in d["unlocks"]:
            c = _canon(gid)
            # the unlock names the item (RifleBolt11), the shop its sold version (RifleBolt11_LR), or the other way round
            hits = [c] if c in out else [k for k in out if k.startswith(c) and not k[len(c)].isdigit() and out[k]["price"]]
            if not hits:
                out[c] = {"price": None, "level": None}; hits = [c]
            for k in hits:
                if out[k]["level"] is None: out[k]["level"] = lv
            tables.setdefault("_unlock_keys", {})[c] = hits
    tables["_shop"] = out
    return out

def _shop_facts(info):
    """[label, value] rows for an item's price and the hunter level that unlocks it in the shop."""
    if not info: return []
    rows = []
    if info.get("price"): rows.append([i18n.t("Price"), f"${info['price']:,}"])
    if info.get("level"): rows.append([i18n.t("Unlocks at"), i18n.t("Hunter level {n}").format(n=info['level'])])
    elif info.get("price"): rows.append([i18n.t("Unlocks at"), i18n.t("From the start")])
    return rows

# the game's projectile types: (plain name, its icon T_UI_AmmoType_<code>)
AMMO_TYPES = {"SoftPoint": ("Soft point", "S"), "HollowPoint": ("Hollow point", "H"), "PolymerTippedHollowPoint": ("Polymer tip", "P"),
              "RifledSlug": ("Rifled slug", "SL"), "Buckshot": ("Buckshot", "BU"), "Pellet": ("Birdshot", "PE"),
              "FixedBladeBroadhead": ("Fixed-blade broadhead", "F"), "MechanicalBroadhead": ("Mechanical broadhead", "M"),
              "UnloseableMiraclePoint": ("Judo point (small game)", "U")}

def _ammo_type_text(s):
    """an AMMO_TYPES name in the app's language"""
    return {"Soft point": i18n.t("Soft point"), "Hollow point": i18n.t("Hollow point"), "Polymer tip": i18n.t("Polymer tip"),
            "Rifled slug": i18n.t("Rifled slug"), "Buckshot": i18n.t("Buckshot"), "Birdshot": i18n.t("Birdshot"),
            "Fixed-blade broadhead": i18n.t("Fixed-blade broadhead"), "Mechanical broadhead": i18n.t("Mechanical broadhead"),
            "Judo point (small game)": i18n.t("Judo point (small game)")}.get(s, s)

def _gear_title(s):
    """a GEAR page title in the app's language (GEAR keeps the English: _item_names uses it as the item kind)"""
    return {"Weapons": i18n.t("Weapons"), "Ammunition": i18n.t("Ammunition"), "Optics": i18n.t("Optics"),
            "Attachments": i18n.t("Attachments"), "Callers": i18n.t("Callers"), "Decoys": i18n.t("Decoys"),
            "Luring scents": i18n.t("Luring scents"), "Blinds and stands": i18n.t("Blinds and stands"),
            "Shooting sticks": i18n.t("Shooting sticks"), "Backpacks": i18n.t("Backpacks"), "Tents": i18n.t("Tents"),
            "Vehicles": i18n.t("Vehicles"), "Gear": i18n.t("Gear"), "Scopes and sights": i18n.t("Scopes and sights"),
            "Bows and crossbows": i18n.t("Bows and crossbows"), "Shotguns": i18n.t("Shotguns"), "Rifles": i18n.t("Rifles"),
            "Other": i18n.t("Other")}.get(s, s)

def _gear_articles(tables):
    arts = []
    for tab, title in GEAR:
        T = tables.get(tab, {})
        items = []
        for k in sorted(T):
            if not k.endswith("_NAME"):
                continue
            stem = k[:-5]
            d = T.get(stem + "_DESCRIPTION")
            if not d or "_PROPERTIES" in stem or "_TYPES" in stem or _pulled(stem) \
                    or any(stem == u[0] for u in tables.get("_unreleased_weapons", [])):
                continue
            if tab not in ("ST_Vehicles", "ST_Ammunition", "ST_Weapons") and tables.get("_meta_names") and k not in tables["_meta_names"]:
                continue                                       # named in the game's text but not in the game
            if tab == "ST_Callers" and "_CALL0" in stem: continue
            items.append((_dlc_name(clean(T[k]), _dlc(tables, stem)), clean(d), stem))
        if not items:
            continue
        blocks = []
        if tab == "ST_Ammunition":
            AM = tables.get("_ammo_meta", {}); keys = tables.get("_ammo_keys", {}); sold = tables.get("_ammo_sold", set())
            rows = []
            for mk, am in AM.items():
                n = clean(T.get(keys.get(mk), "")) or mk
                d = clean(T.get(am.get("desc") or "", "") or T.get((keys.get(mk) or "")[:-5] + "_DESCRIPTION", ""))
                rows.append((caliber_name(am["caliber"], tables), am["tiers"][0], n, tier_text(am["tiers"]), d, mk))
            rows.sort()
            bal = {r["key"].lower().rstrip("_"): r for r in tables.get("_bal_rows", [])}
            tpics = _enc_images().get("ammotypes", {})
            cal = None
            for c, _t0, n, t, d, mk in rows:
                if c != cal:
                    blocks.append({"h": c}); cal = c
                pt = AM[mk].get("ptype"); tn = AMMO_TYPES.get(pt, (None, None))
                render = _enc_images().get("gear", {}).get(_img_key(mk.replace("Ammo", "", 1)))   # the arrow/bolt renders
                if render: blocks.append({"imgs": [{"img": render}]})
                icon = tpics.get(tn[1]) if tn[1] else None
                f = [[i18n.t("Load"), n], [i18n.t("Caliber"), c]] + ([[i18n.t("Bullet type"), _ammo_type_text(tn[0])]] if tn[0] else []) + [[i18n.t("Tiers"), t]]
                b = bal.get(mk.lower().rstrip("_"))
                if b:
                    f += [[i18n.t("Energy"), i18n.t("{energy} at the muzzle").format(energy=b["energy"])], [i18n.t("Speed"), b["speed"]], [i18n.t("Weight"), b["weight"]]]
                    if b["bc"] != "-": f.append([i18n.t("Holds speed"), i18n.t("{n} (higher keeps its speed better)").format(n=b["bc"])])
                    if b["pen"] != "-": f.append([i18n.t("Penetration"), i18n.t("{n} (low far away, high up close)").format(n=b["pen"])])
                blocks.append({"facts": f + _shop_facts(_shop_info(tables).get(_canon(mk))), **({"icon": icon} if icon else {})})
                if d: blocks.append({"p": d})
            items = [(f"{n} ({c})", d, "") for c, _t0, n, t, d, _mk in rows]
        elif tab == "ST_Callers":
            blocks += _caller_blocks(tables, T)
        else:
          IM = _enc_images(); pics = IM.get("gear", {}); rets = {_img_key(k): v for k, v in IM.get("reticles", {}).items()}
          for n, d, stem in sorted(items):
            blocks.append({"h": n})
            pic = _match_img(stem, pics) if stem else None
            ret = _match_img(stem, rets) if stem and tab == "ST_Attachments" else None
            row = ([{"img": pic}] if pic else []) + ([{"img": ret, "caption": i18n.t("Reticle"), "round": True}] if ret else [])
            if row: blocks.append({"imgs": row})
            sf = _shop_facts(_match_img(stem, _shop_info(tables))) if stem else []
            if sf: blocks.append({"facts": sf})
            blocks.append({"p": d})
        arts.append({"id": "gear:" + tab, "title": _gear_title(title), "subtitle": (i18n.t("{n} items") if len(items) != 1 else i18n.t("{n} item")).format(n=len(items)),
                     "group": i18n.t("Gear"), "tags": [it[0] for it in items], "blocks": blocks})
    return arts

def _ballistics_articles(tables):
    AMETA = tables.get("_ammo_meta", {})
    B = tables.get("_ballistics", {}); T = tables.get("ST_Ammunition", {})
    names = {}
    for k, v in T.items():
        if k.endswith("_NAME"):
            names[re.sub(r"[^A-Z0-9]", "", k.upper()[len("KEY_GEAR_AMMUNITION_"):-5])] = clean(v)
    keys = tables.get("_ammo_keys", {})
    def label(key):
        k2 = ammo_name_key(key.rstrip("_")) or keys.get(key) or next((v for kk_, v in keys.items() if key.startswith(kk_) or kk_.startswith(key)), None)
        if k2 and T.get(k2): return clean(T[k2])
        kk = re.sub(r"[^A-Z0-9]", "", key.upper().replace("AMMOBULLET", "").replace("AMMOARROW", "").replace("AMMOBOLT", "").replace("AMMOSHELL", ""))
        best = None
        for nk, nv in names.items():
            core = nk.replace("RIFLESCARTRIDGE", "").replace("SHOTGUNSSHELL", "").replace("BOWSARROW", "").replace("CROSSBOWSBOLT", "")
            if core and (core == kk or core.endswith(kk) or kk.endswith(core)):
                if best is None or len(core) > len(best[0]): best = (core, nv)
        return best[1] if best else key
    CAL = {"22LR": ".22 LR", "243Win": ".243 Win", "270Win": ".270 Win", "308Win": ".308 Win", "30-06": ".30-06", "300WinMag": ".300 Win Mag",
           "338LapuaMag": ".338 Lapua Mag", "375HHMag": ".375 H&H Mag", "45-70": ".45-70", "65Creedmoor": "6.5 Creedmoor", "65X55SE": "6.5x55 SE",
           "12ga": "12 ga", "16ga": "16 ga", "20ga": "20 ga", "28ga": "28 ga"}
    def caliber(key):
        m = re.match(r"Ammo(Arrow|Bolt)(\d+)in", key)
        if m: return f'{m.group(2)}" {"arrow" if m.group(1) == "Arrow" else "crossbow bolt"}'
        m = re.match(r"Ammo(?:Bullet|Shell|Arrow|Bolt)([A-Za-z0-9-]+?)_", key)
        c = m.group(1) if m else ""
        return CAL.get(c, c)
    def kind(key):
        k = key.split("_")[1] if "_" in key else ""
        return {"BU": "buckshot", "BI": "birdshot", "RS": "rifled slug"}.get(k[:2], "")
    rows = []
    for key, b in sorted(B.items()):
        ms = b["cms"] / 100.0; kg = b["kg"]; e = 0.5 * kg * ms * ms
        nm = label(key); nm = nm if nm != key else key.split("_", 1)[1]
        sold = key.lower() in tables.get("_ammo_sold", set()) or key.lower().rstrip("_") in tables.get("_ammo_sold", set())
        pel = b.get("pellets"); pen = b.get("pen")
        am = AMETA.get(key) or AMETA.get(key.rstrip("_")) or next((v for k2, v in AMETA.items() if k2.lower() == key.lower().rstrip("_")), None)
        if not sold: continue              # not sold in the game (unused or not released yet)
        calname = caliber_name(am["caliber"], tables) if am else caliber(key)
        kd = kind(key); tag = "" if not kd or kd.lower() in nm.lower() else kd
        tag = {"buckshot": i18n.t("buckshot"), "birdshot": i18n.t("birdshot"), "rifled slug": i18n.t("rifled slug")}.get(tag, tag)
        short = nm + (f" ({tag})" if tag else "")                       # the name without "per pellet"
        tag = ", ".join(x for x in (tag, i18n.t("per pellet") if pel else "") if x)
        g_ = kg * 1000; gr = kg * 15432.36
        wt = (f"{g_:.2f}" if g_ < 1 else f"{g_:.1f}") + " g (" + (f"{gr:.1f}" if gr < 10 else f"{gr:.0f}") + " gr)"
        rows.append({"key": key, "kg": kg, "v0": ms, "drag": b.get("drag"), "pellets": pel[0] if pel else 0,
                     "cal": calname, "name": nm + (f" ({tag})" if tag else "") + ("" if sold else "  [NOT SOLD]"), "short": short,
                     "tiers": am["tiers"] if am else [], "e": e,
                     "energy": i18n.t("{n} J each").format(n=f"{e:,.0f}") if pel else f"{e:,.0f} J",
                     "speed": f"{ms:,.0f} m/s ({ms * 3.28084:,.0f} fps)",
                     "weight": i18n.t("{w} x{n} pellets").format(w=wt, n=pel[0]) if pel else wt,
                     "bc": f"{b['bc']:.3f}" if b.get("bc") and b["bc"] > 0.001 else "-",
                     "pen": f"{pen[0]:g}-{pen[1]:g}" if pen else "-"})
    tables["_bal_rows"] = rows
    if not rows:
        return []
    # grouped by the load ids (AmmoShell12ga_..., AmmoArrow30in...), not the caliber names: those are in the app's language
    kinds = {r["cal"]: _load_kind(r["key"]) for r in rows}
    def group(c):
        return {"Shell": "Shotgun shells", "Arrow": "Arrows", "Bolt": "Crossbow bolts"}.get(kinds.get(c), "Rifle cartridges")
    GROUPS = ["Rifle cartridges", "Shotgun shells", "Arrows", "Crossbow bolts"]
    cals = {}
    for r in rows: cals.setdefault(r["cal"], []).append(r)
    gauge = lambda c: -max(int(m.group(1)) for r in cals[c] for m in [re.match(r"AmmoShell(\d+)ga", r["key"])] if m) if kinds.get(c) == "Shell" else 0   # 28 ga is the smallest
    ckey = lambda c: (GROUPS.index(group(c)), gauge(c), min((t for r in cals[c] for t in r["tiers"]), default=99), max(r["e"] for r in cals[c]))
    order = sorted(cals, key=ckey)
    hidden = [r["cal"] + " " + r["name"].replace("  [NOT SOLD]", "") for r in rows if "[NOT SOLD]" in r["name"]]
    over = []
    for c in order:
        def rng(es):
            return f"{min(es):,.0f}-{max(es):,.0f} J" if round(min(es)) != round(max(es)) else f"{max(es):,.0f} J"
        one = [r["e"] for r in cals[c] if not r["pellets"]]; pel = [r["e"] for r in cals[c] if r["pellets"]]
        en = ", ".join(x for x in (((i18n.t("slug {e}").format(e=rng(one)) if pel else rng(one)) if one else ""),
                                   i18n.t("pellets {e} each").format(e=rng(pel)) if pel else "") if x)
        used_in = {"Shotgun shells": i18n.t("Shotgun"), "Rifle cartridges": i18n.t("Rifle"), "Arrows": i18n.t("Bow"), "Crossbow bolts": i18n.t("Crossbow")}
        over.append([c, used_in[group(c)],
                     str(len(cals[c])), tier_text(sorted({t for r in cals[c] for t in r["tiers"]})), en])
    blocks = [{"p": i18n.t("All {n} loads in the game by caliber, small to big. The strongest load of each caliber is listed first.").format(n=len(rows))},
              {"h": i18n.t("Calibers at a glance")},
              {"table": {"cols": [i18n.t("Caliber"), i18n.t("Used in"), i18n.t("Loads"), i18n.t("Tiers"), i18n.t("Muzzle energy")], "rows": over}},
              {"h": i18n.t("What the columns mean")},
              {"list": [i18n.t("Tiers: the animal tiers the load is rated for (see Gear > Tiers)."),
                        i18n.t("Energy: at the muzzle, per pellet for shot. Energy at impact is what kills; it drops with range."),
                        i18n.t("Speed and weight: at the muzzle. 1 g = 15.4 grains (gr)."),
                        i18n.t("Holds speed: higher keeps its speed better over distance."),
                        i18n.t("Penetration: how deep it goes. Low number at long range, high number up close.")]}]
    for g in GROUPS:
        gc = [c for c in order if group(c) == g]
        if not gc: continue
        trows = []
        for c in gc:
            for k, r in enumerate(sorted(cals[c], key=lambda r: -r["e"])):
                trows.append([c if k == 0 else "", r["name"], tier_text(r["tiers"]), r["energy"], r["speed"], r["weight"], r["bc"], r["pen"]])
        gh = {"Rifle cartridges": i18n.t("Rifle cartridges"), "Shotgun shells": i18n.t("Shotgun shells"), "Arrows": i18n.t("Arrows"), "Crossbow bolts": i18n.t("Crossbow bolts")}[g]
        blocks += [{"h": gh}, {"table": {"cols": [i18n.t("Caliber"), i18n.t("Ammunition"), i18n.t("Tiers"), i18n.t("Energy"), i18n.t("Speed"), i18n.t("Weight"), i18n.t("Holds speed"), i18n.t("Penetration")], "rows": trows}}]
    blocks += [{"h": i18n.t("How shots work")},
               {"list": [i18n.t("Heavier and faster projectiles carry more energy, and they slow down with range."),
                         i18n.t("Match the load's tiers to the animal's tier (Gear > Tiers)."),
                         i18n.t("Hollow-point bullets open up and do more tissue damage but go less deep; soft-point and polymer-tip bullets go deeper for big game."),
                         i18n.t("The shop's 'lower / medium / higher-energy' wording does not always match the muzzle energy above - trust the numbers."),
                         i18n.t("Shotgun shells fire several pellets in a spread; slugs are a single heavy projectile.")]}]
    return [{"id": "gear:ballistics", "title": i18n.t("Ballistics"), "subtitle": i18n.t("{n} loads").format(n=len(rows)), "group": i18n.t("Gear"), "tags": sorted({r["cal"] for r in rows}) + [r["name"] for r in rows], "blocks": blocks}]

def _load_kind(key):
    """'AmmoShell12ga_BU01' -> 'Shell' (Bullet / Shell / Arrow / Bolt)"""
    m = re.match(r"Ammo(Bullet|Shell|Arrow|Bolt)", key)
    return m.group(1) if m else "Bullet"

ENERGY_SIZES = [("0-3kg", "Up to 3 kg"), ("3-15kg", "3-15 kg"), ("15-30kg", "15-30 kg"), ("30-75kg", "30-75 kg"), ("75-150kg", "75-150 kg"),
                ("150-250kg", "150-250 kg"), ("250-500kg", "250-500 kg"), ("500-1000kg", "500-1000 kg"), ("1000kg+", "Over 1000 kg")]

def _energy_articles(tables, hit, sub_names, weapon_arts):
    """Energy of every load at range (ballistics_range: the game's own projectile flight), in meters and in yards
    (the app shows the one the Units setting asks for): one page for what each animal needs, one per weapon kind."""
    import ballistics_range as BR
    rows = [r for r in tables.get("_bal_rows", []) if r.get("drag") and "[NOT SOLD]" not in r["name"]]
    if not rows: return []
    maps, animal_size = hit
    used = {}
    for a in weapon_arts:
        for b in a.get("blocks", []):
            t = b.get("table")
            if t and t["cols"][:2] == [i18n.t("Weapon"), i18n.t("Caliber")]:
                for r in t["rows"]: used.setdefault(r[1], []).append(r[0])
    kinds = {r["cal"]: _load_kind(r["key"]) for r in rows}         # by load id: the caliber names are in the app's language
    def group(c):
        return {"Shell": "Shotguns", "Arrow": "Bows", "Bolt": "Crossbows"}.get(kinds.get(c), "Rifles")
    STEPS = {"Rifles": {"m": (50, 1000), "yd": (50, 1100)}, "Bows": {"m": (10, 100), "yd": (20, 120)},
             "Crossbows": {"m": (10, 100), "yd": (20, 120)}, "Shotguns": {"m": (10, 100), "yd": (10, 110)}}
    cals = {}
    for r in rows:
        if used.get(r["cal"]): cals.setdefault(r["cal"], []).append(r)      # only calibers a weapon in the game fires
    order = sorted(cals, key=lambda c: (["Rifles", "Shotguns", "Bows", "Crossbows"].index(group(c)), max(x["v0"] ** 2 * x["kg"] * max(1, x["pellets"]) for x in cals[c])))
    size_names = {}
    for sub, cls in animal_size.items():
        base = cls.replace("_AirSacs", "")
        if sub in sub_names: size_names.setdefault(base, []).append(sub_names[sub])
    sizes = [(base, label) for base, label in ENERGY_SIZES if base in maps]
    def win(base, typ):
        lo, hi = maps.get(base, {}).get(typ, (0, 0))
        return "-" if hi <= 0 else i18n.t("up to {n} J").format(n=f"{hi:,.0f}") if lo <= 0 else f"{lo:,.0f}-{hi:,.0f} J"
    def ammo_type(r):
        g = group(r["cal"])
        if g == "Shotguns": return "Shot" if r["pellets"] else "Slug"
        return {"Rifles": "Bullet", "Bows": "Arrow", "Crossbows": "Bolt"}[g]
    AT = tables.get("_animal_tiers", {})
    tier_of = {sub: AT[n] for sub, n in sub_names.items() if n in AT}
    size_tiers = {}
    for sub, cls in animal_size.items():
        if sub in tier_of: size_tiers.setdefault(cls.replace("_AirSacs", ""), set()).add(tier_of[sub])
    def fits(r, e):
        """The animal tiers this hit is right for: the load is rated for the tier, and every animal of the tier has e
        inside its energy window (the game shows optimal only inside it; under it is low, over it is high)."""
        ok = {}
        for sub, cls in animal_size.items():
            if sub not in tier_of: continue
            lo, hi = maps.get(cls.replace("_AirSacs", ""), {}).get(ammo_type(r), (0, 0))
            t = tier_of[sub]; ok[t] = ok.get(t, True) and hi > 0 and lo <= e <= hi
        rated = set(r.get("tiers") or [])
        return {t for t, v in ok.items() if v and (not rated or t in rated)}
    def low_for_all(r, e):
        """True when e is under the window of every animal this ammo type is used on."""
        return all(e < maps.get(cls.replace("_AirSacs", ""), {}).get(ammo_type(r), (0, 0))[0]
                   for sub, cls in animal_size.items() if sub in tier_of
                   and maps.get(cls.replace("_AirSacs", ""), {}).get(ammo_type(r), (0, 0))[1] > 0)
    def common_prefix(names):
        if len(names) < 2: return ""
        w = [n.split() for n in names]; k = 0
        while all(len(x) > k + 1 for x in w) and len({x[k] for x in w}) == 1: k += 1
        return " ".join(w[0][:k])
    size_label = lambda l: {"Up to 3 kg": i18n.t("Up to 3 kg"), "Over 1000 kg": i18n.t("Over 1000 kg")}.get(l, l)
    srows = [[size_label(label), tier_text(sorted(size_tiers.get(base, []))), ", ".join(sorted(size_names.get(base, []))) or "-", win(base, "Bullet"), win(base, "Slug"), win(base, "Shot"), win(base, "Arrow")]
             for base, label in sizes]
    needs = {"id": "gear:energy", "title": i18n.t("Energy: what each animal needs"), "subtitle": i18n.t("The energy window per animal size"), "group": i18n.t("Gear"),
             "tags": ["energy", "joules", "tier", "minimum", "window"], "blocks": [
        {"p": i18n.t("Energy at the hit is what counts. Every animal has an energy window for each kind of ammunition, set by its size. "
              "Under the window the scope shows the hit as low energy, inside it as optimal, over it as high.")},
        {"table": {"cols": [i18n.t("Animal size"), i18n.t("Tiers"), i18n.t("Animals"), i18n.t("Bullet"), i18n.t("Slug"), i18n.t("Shot (all pellets)"), i18n.t("Arrow or bolt")], "rows": srows, "w": [10, 5, 28, 10, 10, 10, 10]}},
        {"p": i18n.t("The tier is the animal's tier (on its page, and Gear > Tiers). Bigger animals have higher tiers and need more energy.")},
        {"h": i18n.t("How far each load carries enough")},
        {"list": [i18n.t("Rifles: Gear > Energy: rifles"), i18n.t("Shotguns: Gear > Energy: shotguns"), i18n.t("Bows: Gear > Energy: bows"), i18n.t("Crossbows: Gear > Energy: crossbows")]},
        {"note": i18n.t("Calm air at sea level. The game keeps the air at 20 °C whatever the weather, so only wind and high ground change these numbers, and only a little. Meters or yards: Settings > Units.")}]}
    arts = [needs]
    for g in ["Rifles", "Shotguns", "Bows", "Crossbows"]:
        gc = [c for c in order if group(c) == g]
        if not gc: continue
        blocks = [{"p": {"Rifles": i18n.t("Every rifle caliber, every 50 meters (or yards)."),
                         "Shotguns": i18n.t("Every gauge, every 10 meters (or yards). Shot is all pellets of one shell together, as the game counts it; a slug is one projectile."),
                         "Bows": i18n.t("Every arrow, every 10 meters (20 yards)."), "Crossbows": i18n.t("Every bolt, every 10 meters (20 yards).")}[g]
                       + " " + i18n.t("Right energy for: the animal tiers at least one load here suits at that range. The load must be rated for the tier, "
                         "and every animal of that tier must get a hit inside its energy window: not too little, not too much (Gear > Energy: what each animal needs).")}]
        for unit in ("m", "yd"):
            uk = "metric" if unit == "m" else "imperial"; conv = 1.0 if unit == "m" else 0.9144
            step, far = STEPS[g][unit]
            dists = list(range(0, far + 1, step))
            for c in gc:
                loads = sorted(cals[c], key=lambda r: -r["kg"] * r["v0"] ** 2 * max(1, r["pellets"]))
                names = [r["short"] for r in loads]                 # the names without "per pellet"
                pre = common_prefix(names)
                cols = [i18n.t("Range")] + [n[len(pre):].strip() or n for n in names] + [i18n.t("Right energy for")]
                sims = []
                for r in loads:
                    area, cof, curve = r["drag"]
                    sims.append(BR.energies(r["kg"], r["v0"], area, cof, [d * conv for d in dists], curve=curve))
                trows = []
                for d in dists:
                    row = [f"{d} {unit}"]; good = set(); low = True
                    for r, e in zip(loads, sims):
                        v = e.get(d * conv)
                        en = None if v is None else v[0] * max(1, r["pellets"])
                        row.append("-" if en is None else f"{en:,.0f} J")
                        if en is not None:
                            good |= fits(r, en); low = low and low_for_all(r, en)
                    row.append((i18n.t("tier {t}") if len(good) == 1 else i18n.t("tiers {t}")).format(t=tier_text(good)) if good
                               else i18n.t("too little") if low else i18n.t("none"))
                    trows.append(row)
                who = sorted(set(used.get(c, [])))
                blocks.append({"h": c, "units": uk})
                if who and pre: fired = i18n.t("Fired by {weapons}. Every load here is a {load} load.").format(weapons=", ".join(who), load=pre)
                elif who: fired = i18n.t("Fired by {weapons}.").format(weapons=", ".join(who)) + " "
                elif pre: fired = i18n.t("Every load here is a {load} load.").format(load=pre)
                else: fired = ""
                blocks.append({"p": fired, "units": uk})
                blocks.append({"table": {"cols": cols, "rows": trows}, "units": uk})
                areas = sorted(r["drag"][0] for r in loads)
                for r, n in zip(loads, names):                   # a load the game files give a much wider projectile than its siblings
                    if len(loads) > 2 and r["drag"][0] > 3 * areas[len(areas) // 2]:
                        blocks.append({"p": i18n.t("{load}: the game gives it a much wider shaft than the other {caliber} loads, so it slows down faster.").format(load=n, caliber=c), "units": uk})
        etitle = {"Rifles": i18n.t("Energy: rifles"), "Shotguns": i18n.t("Energy: shotguns"), "Bows": i18n.t("Energy: bows"), "Crossbows": i18n.t("Energy: crossbows")}[g]
        arts.append({"id": "gear:energy_" + g.lower(), "title": etitle,
                     "subtitle": (i18n.t("{n} calibers, near to far") if len(gc) != 1 else i18n.t("{n} caliber, near to far")).format(n=len(gc)),
                     "group": i18n.t("Gear"), "tags": ["energy", "range", "distance", "joules", "ballistics"] + gc, "blocks": blocks})
    return arts

# text only, no character in the game: KEY_NPCMAP01_06 has no character profile (BP_CharacterProfilesManager_GS
# lists every real person), no model and no dialogue
PEOPLE_NOT_IN_GAME = {"KEY_NPCMAP01_06"}

def _people_articles(tables):
    N = tables.get("ST_NPCs", {})
    arts = []
    for k in sorted(N):
        m = re.match(r"(KEY_NPCMAP\d+_\d+)_NAME$", k)
        if not m:
            continue
        p = m.group(1)
        if p in PEOPLE_NOT_IN_GAME:
            continue
        facts = [[lab, clean(N[p + "_" + key])] for lab, key in ((i18n.t("Occupation"), "OCCUPATION"), (i18n.t("Behavior"), "BEHAVIOR"),
                 (i18n.t("Daily routine"), "LIFECYCLE"), (i18n.t("Strength"), "STRENGTH"), (i18n.t("Potential weakness"), "WEAKNESS")) if N.get(p + "_" + key)]
        blocks = []
        if N.get(p + "_DESCRIPTION"):
            blocks.append({"p": clean(N[p + "_DESCRIPTION"])})
        if facts:
            blocks.append({"facts": facts})
        tr = [clean(N[x]) for x in sorted(N) if x.startswith(p + "_TRIVIA")]
        if tr:
            blocks.append({"h": i18n.t("Trivia")}); blocks.append({"list": tr})
        if blocks:
            arts.append({"id": "npc:" + p, "title": clean(N[k]), "subtitle": "", "group": i18n.t("People"), "tags": [], "blocks": blocks})
    # people (and a dog) you meet in the game who have no codex page of their own: written from their dialogue and missions
    for key, blocks in _extra_people():
        if N.get(key + "_NAME") and not any(a["id"] == "npc:" + key for a in arts):
            arts.append({"id": "npc:" + key, "title": clean(N[key + "_NAME"]), "subtitle": "", "group": i18n.t("People"), "tags": [], "blocks": blocks})
    pics = _enc_images().get("people", {})                 # the game's own portraits (tools/enc_images.py people())
    for a in arts:
        pic = pics.get(re.sub(r"[^A-Z0-9]", "", unicodedata.normalize("NFKD", a["title"]).upper()))     # "Júniper" -> JUNIPER
        if pic: a["blocks"] = [{"imgs": [{"img": pic, "big": True}]}] + list(a["blocks"])
    return arts

def _extra_people():
    """people (and a dog) with no codex page of their own: [(text key, blocks)], in the app's language"""
    return [
    ("KEY_NPCHUB_01", [
        {"p": i18n.t("Hearth & Hunt's carpenter and builder, waiting for you at the Hearth & Hunt Headquarters. He builds the lodge expansions, "
              "and he knows a thing or two more: mushrooms, and people - \"those two aren't that different\".")},
        {"facts": [[i18n.t("Where"), i18n.t("Hearth & Hunt Headquarters")], [i18n.t("Occupation"), i18n.t("Carpenter and builder for Hearth & Hunt")],
                   [i18n.t("Loves"), i18n.t("Mushrooms and gossip")], [i18n.t("Can't stand"), i18n.t("Being on his own - and Mikael Anderson")]]},
        {"h": i18n.t("Trivia")},
        {"list": [i18n.t("He is Irish, and says that once the Irish thought more of fairies than of food when they saw a mushroom."),
                  i18n.t("He got a world-record hunter's signature in Kilimaya Reserve and cooked him amakhowe mushrooms, a local delicacy."),
                  i18n.t("He swears by Regina Harper's dreams - he ignored one once and calls it the biggest mistake of his life."),
                  i18n.t("Talk to him about people: it is his favorite subject.")]}]),
    ("KEY_NPCMAP01_08", [
        {"p": i18n.t("Hearth & Hunt's former representative in New Laurentia - the hunter you are replacing. He comes from Lintukoto Reserve, "
              "speaks plainly, and has looked after an elk herd for years. He shows you how animal daily routines work.")},
        {"facts": [[i18n.t("Where"), i18n.t("New Laurentia")], [i18n.t("Occupation"), i18n.t("Former Hearth & Hunt representative in New Laurentia")],
                   [i18n.t("Missions"), i18n.t("Fox fires, Loudest deer, Pack dynamics, One shot, no waste")]]}]),
    ("KEY_NPCMAP01_07", [
        {"p": i18n.t("Juniper's dog, a blood-tracking dog she is training for a national competition. She shows up in Juniper's missions "
              "in New Laurentia - including the night she goes missing.")},
        {"facts": [[i18n.t("Where"), i18n.t("New Laurentia")], [i18n.t("Owner"), "Juniper"]]}]),
    ]

# ---------------------------------------------------------------- the trophy and herd chapters
def _hunter_guides(tables, sub_names, released=()):
    """Our own GUIDES pages from the decoded game data: how animals notice you, how fast a hit animal goes down,
    and what a kill pays in money and XP."""
    F = _game_facts(); sp = F.get("species", {}); A = []
    if not sp: return A
    live = {k: v for k, v in sp.items() if k in released and k in sub_names and v.get("sight")}
    rows = [[sub_names[k], f"{v['sight']} m", f"{v['hear']} m", _nose(v.get("smell"))] for k, v in sorted(live.items(), key=lambda kv: (-kv[1]["sight"], sub_names[kv[0]]))]
    A.append({"id": "guide:senses", "title": i18n.t("How animals notice you"), "subtitle": i18n.t("Sight, hearing, nose - every animal"),
              "group": i18n.t("Hunting guides"), "tags": ["senses", "sight", "hearing", "smell", "scent", "noise", "visibility", "spook", "wind", "crouch", "prone"], "blocks": [
        {"p": i18n.t("Every animal has a sight range, a hearing range for your steps and a nose. Inside those ranges what counts is how much you move.")},
        {"h": i18n.t("Moving is what gets you seen")},
        {"table": {"cols": [i18n.t("What you do"), i18n.t("How much you stand out")], "rows": [
            [i18n.t("Standing or crouching still"), "x0.5"], [i18n.t("Lying still"), "x1"], [i18n.t("Crawling"), "x2"], [i18n.t("Crouch-walking"), "x2"],
            [i18n.t("Walking"), "x2.25"], [i18n.t("Jogging"), "x4.1"], [i18n.t("Crouch-running"), "x4.75"], [i18n.t("Running"), "x5"]]}},
        {"note": i18n.t("Crouch-running stands out more than jogging upright. To close in, walk slow or crawl.")},
        {"h": i18n.t("Things that hold for every animal")},
        {"list": [i18n.t("Every animal can hear a shot from up to 400 m. A suppressor makes the shot quieter."),
                  i18n.t("Every animal hears a vehicle out to 250 m."),
                  i18n.t("Inside 20 m any land animal (and turkey and ptarmigan) senses you even if it can't see, hear or smell you. Ducks don't."),
                  i18n.t("Rain, fog and snow don't make animals see or hear you any less."),
                  i18n.t("A wounded animal sees only 40 m and hears your steps only 50 m, so it's much easier to walk up on."),
                  i18n.t("A blind cuts how much you are seen, heard and smelled to 40%. A tripod stand cuts it to 60%."),
                  i18n.t("Clothes and camo do nothing: the jacket colors only tell co-op players apart.")]},
        {"h": i18n.t("When they spook")},
        {"list": [i18n.t("Something odd: the herd steps away about 35 m."),
                  i18n.t("Sure something is wrong: it walks off about 50 m."),
                  i18n.t("Full alarm: it runs about 300 m, then waits close to 3 minutes before it calms down."),
                  i18n.t("Smelled you: about 30 m."),
                  i18n.t("Hippos run only about 30 m and crocodiles 25 m, both toward deep water.")]},
        {"h": i18n.t("Every animal (Normal)")},
        {"table": {"cols": [i18n.t("Animal"), i18n.t("Sees you from"), i18n.t("Hears your steps from"), i18n.t("Nose")], "rows": rows, "links": "animals", "w": [22, 10, 12, 16]}},
        {"note": i18n.t("Sight is the same on every difficulty, except the honey badger, which sees only 40 m on Hard. On Hard most big game hears 10 m farther.")}]})
    W = F.get("wounds", {}); N = W.get("Medium", {})
    if N:
        order = [("Heart", i18n.t("Heart")), ("Brain", i18n.t("Brain")), ("Spine", i18n.t("Spine")), ("Lungs", i18n.t("Both lungs")), ("LungLeft", i18n.t("One lung")),
                 ("Artery", i18n.t("Artery")), ("Skull", i18n.t("Skull")), ("Liver", i18n.t("Liver")), ("Flesh", i18n.t("Meat only")), ("Stomach", i18n.t("Stomach")),
                 ("Intestine", i18n.t("Guts")), ("Bone", i18n.t("Bone"))]
        fs = lambda v: f"{v:.0f}" if v >= 10 or v == int(v) else f"{v:.1f}".rstrip("0").rstrip(".")
        def cell(t): return f"{fs(t[0])}-{fs(t[1])}" if t and t[0] >= 1 else i18n.t("up to {n}").format(n=fs(t[1])) if t else "-"
        wrows = [[name, cell(N[k][0]) + " s", cell(N[k][1]) + " m"] for k, name in order if k in N]
        A.append({"id": "guide:wounds", "title": i18n.t("Where to shoot: how fast they go down"), "subtitle": i18n.t("Time and distance by organ"),
                  "group": i18n.t("Hunting guides"), "tags": ["shot placement", "heart", "lungs", "liver", "wounded", "blood", "tracking", "vitals"], "blocks": [
            {"p": i18n.t("A hit animal runs off and dies after a while. How long and how far depends on what you hit and how badly. "
                  "The smaller number is for an organ that is wrecked, the bigger one for an organ that is only just hit hard enough.")},
            {"table": {"cols": [i18n.t("Hit"), i18n.t("Dies within"), i18n.t("Runs up to")], "rows": wrows, "w": [14, 12, 12]}},
            {"list": [i18n.t("This is big game on Normal. On Easy it's about three quarters of these times and distances, on Hard about a quarter more."),
                      i18n.t("Hippos and crocodiles take about a third longer than this."),
                      i18n.t("Small game and birds drop within seconds and a few meters."),
                      i18n.t("The heart needs about a sixth of the energy a lung needs to be wrecked, so it is the most forgiving shot at long range."),
                      i18n.t("One lung is never quick. Gut and stomach hits take minutes and up to half a kilometer, a bad meat-only hit too.")]}]})
    L = F.get("lands", {}); LN = tables.get("ST_Levels", {})
    lrows = []
    for mp in ("Map01", "Map02", "Hub"):
        for k, xp in sorted(L.get(mp, {}).items(), key=lambda kv: (-kv[1], kv[0])):
            lrows.append([MAPS.get(mp, mp), clean(LN.get(k, k)), f"+{xp}"])
    sale = lambda v: int(_heaviest(v)[0] * 0.6 * v["price_kg"])
    arows = [[sub_names[k], f"+{v['xp']}", f"${v['price_kg']:g}", f"${sale(v):,}"]
             for k, v in sorted(live.items(), key=lambda kv: -sale(kv[1]) if kv[1].get("price_kg") and _heaviest(kv[1]) else 0)
             if v.get("price_kg") and _heaviest(v)]
    A.append({"id": "guide:payout", "title": i18n.t("Money and XP from a kill"), "subtitle": i18n.t("What selling, the shot and the stars are worth"),
              "group": i18n.t("Hunting guides"), "tags": ["xp", "money", "sell", "price", "meat", "spoil", "rating", "taxidermy", "rank", "land"], "blocks": [
        {"h": i18n.t("XP")},
        {"p": i18n.t("Every harvest, sold or mounted, gives XP from four parts added up:")},
        {"table": {"cols": [i18n.t("Part"), i18n.t("XP")], "rows": [
            [i18n.t("The animal (its hunting difficulty)"), i18n.t("5 to 25")],
            [i18n.t("The land its herd lives on"), i18n.t("5 to 25")],
            [i18n.t("Your hunt rating"), "E 5, D 10, C 20, B 30, A 40, A+ 50, A++ 60, S 70, S+ 90, S++ 110"],
            [i18n.t("Trophy stars"), i18n.t("1 star 5, 2 stars 20, 3 stars 40, 4 stars 70, 5 stars 110")]]}},
        {"note": i18n.t("Top is about 270 XP: a 5-star grizzly with a clean shot on Lake Sasquatch. Roadkill gives nothing. The land is where the herd lives, not where you stand.")},
        {"h": i18n.t("XP by land")},
        {"table": {"cols": [i18n.t("Map"), i18n.t("Land"), i18n.t("XP")], "rows": lrows}},
        {"h": i18n.t("Money")},
        {"list": [i18n.t("Selling pays for meat only: weight, less 40% dressing waste, less what the shot ruined, times the animal's price per kg."),
                  i18n.t("Rare coats, stars, fitness and age don't change the price."),
                  i18n.t("Meat keeps for 2 game hours. After that it loses value, and from 4 game days (96 hours) it is worth nothing. Spoiled meat also lowers your hunt rating."),
                  i18n.t("Taxidermy pays nothing: you pay for the mount instead. The XP is the same either way."),
                  i18n.t("Sold antlers and horns keep only their stars in your hunting log. Taxidermy keeps the full score.")]},
        {"h": i18n.t("Hunt rating")},
        {"p": i18n.t("It starts at 100. The share of meat lost to the shot and to spoiling comes off, and so does skull damage. Every 10 points is a grade: "
              "0-9 E, 10-19 D, 20-29 C, 30-39 B, 40-49 A, 50-59 A+, 60-69 A++, 70-79 S, 80-89 S+, 90-100 S++.")},
        {"h": i18n.t("Best sale by animal")},
        {"table": {"cols": [i18n.t("Animal"), i18n.t("XP for the animal"), i18n.t("Price per kg"), i18n.t("Best sale")], "rows": arows, "links": "animals", "w": [22, 10, 10, 10]}},
        {"note": i18n.t("Best sale = the heaviest animal of either sex, a clean shot, sold fresh.")}]})
    A.append({"id": "guide:facts", "title": i18n.t("Good to know"), "subtitle": i18n.t("Small facts"),
              "group": i18n.t("Hunting guides"), "tags": ["time", "day", "fast travel", "suppressor", "calls", "shooting stick"], "blocks": [
        {"list": [i18n.t("A game day lasts about 5 real hours: the clock runs 4 times real time by day and 6 times at night."),
                  i18n.t("Fast travel is free and doesn't move the clock."),
                  i18n.t("A shooting stick cuts your own shake and your recoil to a quarter, and sway to under a third. It works crouched or standing."),
                  i18n.t("Suppressors: Primacy Panther makes the shot 30% quieter, Primacy Whisper Magnum 50%, Bergara Mercury Ti30 70%."),
                  i18n.t("Most calls carry 250 m. The rattling bag, the doe bleat and the ptarmigan call 150 m, the duck call 500 m."),
                  i18n.t("The head lamp doesn't make animals see you more.")]}]})
    return A

# The developers' own words, copied from their Steam announcements and the Nine Rocks Games known issues page
# (known issues fetched 2026-10-28). Update both after every game patch.
OFFICIAL_PATCH_NOTES = [{'version': '1.4',
  'build': '217015',
  'date': 'October 28, 2026',
  'url': 'https://store.steampowered.com/news/app/2543830/view/1847920302231949',
  'blocks': [{'h': 'ANIMALS'},
             {'list': ['Added: Common Impala to the Kilimaya Reserve',
                       'Tweaked: Reduced the excessive number of droppings and footprint investigation points for Rocky Mountain Mule Deer in a '
                       'specific area of the Wetiko Foothills region in New Laurentia',
                       'Fixed: Taxidermies disappearing under certain circumstances. All previously lost taxidermies should now be available to '
                       'display again. Affected players will automatically receive a refund of 1,500 in-game currency for each recovered taxidermy.',
                       'Fixed: Common Hippopotamus tusks moving incorrectly during yawning animations',
                       'Fixed: Missing animation for damaged Central European Boar while lying down',
                       'Fixed: Incorrect placement of the lower tusks on Common Hippopotamus trophies',
                       'Fixed: Common Hippopotamuses freezing in place instead of charging when they should']},
             {'h': 'GEAR'},
             {'list': ['Tweaked: Adjusted the ballistics of the .375 H&H (Lewellings Grande Strike) to correct underreported impact energy at short '
                       'and medium ranges and ensure headshots can lethally take down wood bison.',
                       'Tweaked: Improved the visual size of shotgun slugs to better reflect their actual dimensions',
                       'Tweaked: Reduced the spread of shotgun pellets to make landing lethal hits more consistent (we’re still looking into the '
                       'damage and spread of the pellets)',
                       'Fixed: Shotguns occasionally failing to fire projectiles',
                       'Fixed: Corrected the scope reticle scaling to ensure the markings accurately represent 1 mRad instead of approximately 1.65 '
                       'mRad',
                       'Fixed: Timer UI on callers displaying and functioning incorrectly',
                       'Fixed: Only one decoy being placed in Storage when collecting multiple decoys from the hunting map']},
             {'h': 'MISC'},
             {'list': ['Fixed: “Teacher’s Pet” mission not completing when ostriches were hunted using non-default bow ammunition',
                       'Fixed: “Chalk and Talk” mission not completing when zebras were hunted using non-default bow ammunition',
                       'Fixed: Challenges not completing when the required number of animals was not available within the reserve',
                       'Fixed: Broken bridge near the New Laurentia Shooting Range not being repairable when approaching it from one side',
                       'Fixed: Snow appearing inside buildings',
                       'Fixed: Mission notifications reappearing every time a saved game was loaded',
                       'Tweaked: Doors now close automatically',
                       'Fixed: Parked vehicles flipping upside down after returning from a hunt',
                       'Fixed: Collision issue that allowed players to clip through one side of a wooden pier in New Laurentia',
                       'Fixed: Collision issue that allowed players to clip inside a rock on the northern side of Mishipeshu Swamp',
                       'Fixed: Mud and debris props near the polluted lake in the HUB appearing unnaturally rotated or floating in mid-air',
                       'Fixed: Missing sections of the river and stream water surfaces in the HUB',
                       'Fixed: Snow temporarily disappearing beneath the player’s feet while walking over it']},
             {'h': 'UI'},
             {'list': ['Fixed: Missing UI text entry for the Indicators toggle when Hints are turned off',
                       'Fixed: Crosshair color slider occasionally failing to respond to mouse input',
                       'Fixed: Selection focus being lost in the Hunting Log',
                       'Fixed: Actions in the Claim screen that could stop working under certain circumstances',
                       'Fixed: Softlock when interacting with the Sleep menu in certain ways',
                       'Fixed: Objectives menu becoming unresponsive after completing a mission']}]},
 {'version': '1.3',
  'build': '215031',
  'date': 'October 15, 2026',
  'url': 'https://store.steampowered.com/news/app/2543830/view/1846651706677625',
  'blocks': [{'h': 'UI'},
             {'list': ['Added: HUD customization options in Settings',
                       'Fixed: Slider in the Sleep menu is no longer interactable after confirming the Sleep action',
                       'Fixed: Dog status indicator being displayed without the dog being active',
                       'Fixed: “Dog Companion Marker” setting appearing twice',
                       'Fixed: Action to browse previous pages in the Hunting Log not working correctly']},
             {'h': 'GEAR'},
             {'list': ['Fixed: The Wildheart front cover clipping when placed on slightly curved surfaces',
                       'Fixed: .338 Lapua Magnum ammo types (“Grande Hunter” and “Grande Swift”) having no difference in performance']},
             {'h': 'ANIMALS'},
             {'list': ['Added: Non-typical Mule deer',
                       'Tweaked: Infrastructure enhancements that improve animal populations now give an instant fitness boost to the new spawns',
                       'Fixed: Issue where animals sometimes survive multiple shots instead of dying immediately',
                       'Fixed: Fleeing Nile crocodiles running around the player instead of entering the water',
                       'Fixed: Hippos getting stuck in one place underwater after being spooked',
                       'Fixed: Hippos ending up under the map after being killed']},
             {'h': 'TAXIDERMIES'},
             {'list': ['Fixed: Taxidermied animals disappearing from dioramas (For those already affected, we hope to recover your taxidermies as '
                       'soon as possible)']},
             {'h': 'ENVIRONMENT'},
             {'list': ['Fixed: Multiple spots in New Laurentia where players could get stuck',
                       'Fixed: Bridge collisions which caused problems when driving over bridges',
                       'Fixed: Water being cut off abruptly on multiple spots on New Laurentia',
                       'Fixed: A piece of terrain in a polygon shape not lining up with the terrain around it',
                       'Fixed: Corrected vegetation placement around the South African Ostrich drinking spot',
                       'Fixed: Wrong textures on birch trees']},
             {'h': 'LOCALIZATION'},
             {'list': ['Fixed: Incorrect text for the “Clear” weather forecast in some localizations',
                       'Fixed: The Jackrabbit predator item being translated in the store but not in the voice-over and subtitles in some '
                       'localizations',
                       'Fixed: Untranslated text in the Hunting Log when opening it from the pause menu in some localizations']},
             {'h': 'OTHER'},
             {'list': ['Fixed: Wrong blood color in the tutorial',
                       'Fixed: Lodge cutscene audio in the New Laurentia map being cut off after the first sentence']}]},
 {'version': '1.2',
  'build': '213891',
  'date': 'October 8, 2026',
  'url': 'https://store.steampowered.com/news/app/2543830/view/1846018067929961',
  'blocks': [{'h': 'GEAR'},
             {'list': ['Added: Ability to sell purchased items from Storage for 50% of their original price.',
                       'Added: New flashlight mode',
                       'Tweaked: Increased flashlight intensity',
                       'Tweaked: Issue where holding the Buy button after completing a purchase would continue the hold action',
                       'Fixed: issue where placed tents and deployable items would disappear from the map and Storage',
                       'Fixed: Hunter assist dispersion circle (aim assist) not representing the weapon accuracy correctly',
                       'Fixed: Tripod stands can now be used again after exiting Photo mode',
                       'Fixed: Missing accuracy boost information in Encyclopedia for Choke',
                       'Fixed: Aim assist now accounts for wind without requiring a shot to trigger recalculation']},
             {'h': 'ANIMALS'},
             {'list': ['Fixed: Optimal energy and velocity values are now displayed in the bullet graph',
                       'Tweaked: Turkey escape behavior over longer distances during the following sequence: run, then fly, then run again. Further '
                       'improvements to turkey behavior are planned to make their movement more natural.']},
             {'h': 'DOG'},
             {'list': ['Fixed: Dog no longer walks in circles after being released when there are no obstacles nearby',
                       'Fixed: Dog being able to “climb trees” in some circumstances']},
             {'h': 'MISSIONS'},
             {'list': ['Fixed: Sick moose in mission “Erynnis Lucilius” now stay within the highlighted area',
                       'Fixed: Challenge “Sell meat of a unique animal species in New Laurentia” no longer gets stuck at 14/15. If you have already '
                       'completed the challenge, the counter will update with your next harvest.',
                       'Fixed: Missing interactions on NPCs']},
             {'h': 'ENVIRONMENT'},
             {'list': ['Fixed: Improved multiple locations where the environment could appear as if the player were underwater, turning the screen '
                       'blue',
                       'Fixed: Specific tree (Birch) model stretching',
                       'Fixed: Collisions on multiple\xa0locations (falling through roof, umbrellas colliding)',
                       'Fixed: Multiple locations in lodge where player could get stuck',
                       'Fixed: Low-res decals on assets when snowing',
                       'Fixed: Character clipping through the bridge in Popobawa Vlei region in Kilimaya Reserve']},
             {'h': 'UI'},
             {'list': ['Tweaked: Adjusted sound cues for better visibility on snow',
                       'Fixed: The main menu freezing when you canceled the job application form',
                       'Fixed: The game getting stuck when accepting a multiplayer invite with a brand-new save',
                       'Fixed: Incorrect animal icons displayed in the Opportunities window for Infrastructure locations in Kilimaya Reserve',
                       'Fixed: Ability to sleep for 0 hours',
                       'Fixed: Weather forecast icons updating few seconds after sleep',
                       'Fixed: Unable to move camera with controller in Photo mode',
                       'Fixed: Unable to move camera around after pausing the game in Photo mode',
                       'Fixed: Weather setting required 2 clicks to activate',
                       'Fixed: “Get DLC” text still present in shop even after purchasing the DLC',
                       'Fixed: Empty encyclopedia for all players in multiplayer',
                       'Fixed: Fulfill opportunity button set on hold, instead of press']},
             {'h': 'SETTINGS'},
             {'list': ['Fixed: Extra space between numbers in several localizations',
                       'Fixed: Global illumination quality settings explained in description',
                       'Fixed: Missing voiceover for Hearth & Hunt Headquarters intro cutscene in Simplified Chinese and Italian localization',
                       'Fixed: Fixed description of Arcade zoom to better describe the functionality in the Encyclopedia']}]},
 {'version': '1.1',
  'build': '212672',
  'date': 'October 1, 2026',
  'url': 'https://store.steampowered.com/news/app/2543830/view/1845383656381696',
  'blocks': [{'h': 'GEAR'},
             {'list': ['Fixed: Minor animation issues with Strasser RS14 WotH Edition',
                       'Fixed: Inaccurate ammo stats in Shop and Storage for .375 H&H Magnum (Grande Strike), .45-70 Government (Nucleus Break), '
                       '.270 Winchester (Nucleus Break), and .300 Winchester Magnum (Nucleus Break Buffed)']},
             {'h': 'MULTIPLAYER'},
             {'list': ['Fixed: Client not being able to equip/unequip clip-ons using the Radial menu',
                       'Fixed: Vehicle shaking for client after leaving the session from inside the vehicle and rejoining']},
             {'h': 'DOG'},
             {'list': ['Fixed: Animation issues when petting the dog while using the Shooting stick']},
             {'h': 'ENVIRONMENT'},
             {'list': ['Added: Ability to change long-term weather forecast via the in-game menu (takes effect after 48 in-game hours)',
                       'Fixed: Stretching bushes in front of Hub lodge']},
             {'h': 'CONTROLS'},
             {'list': ['Added: Settings for Inverted Horizontal Look and Inverted Vertical Look',
                       'Tweaked: Default Inner Look Deadzone setting was increased to 12 to alleviate stick drift issues. If you are still '
                       'experiencing camera drift, please try increasing the setting further.',
                       'Fixed: (Controller) Rotating camera in Photo mode does not work']},
             {'h': 'UI'},
             {'list': ['Fixed: Incorrect marker on Damian and Malachi after completing their storyline',
                       'Tweaked: Enabled menu navigation with the left analog stick']}]}]

KNOWN_ISSUES_URL = "https://ninerocksgames.com/posts/way-of-the-hunter-2-known-issues"
KNOWN_ISSUES_VERSION = "1.4"
KNOWN_ISSUES_UPDATED = "October 28, 2026"         # the newest "added on" date on the developers' page
KNOWN_ISSUES = [{'h': 'Misc'},
 {'list': ['On a rare occasion, a taxidermy can appear as disappeared, while occupying its taxidermy stand. Equally as rarely, it may be possible to '
           'display an already displayed taxidermies. Both are resolved by reloading your current save.',
           'Damage caused to animals by the vehicle is not fully consistent',
           'Mission “Who Runs The World?” fails to advance upon harvesting the Spotted Hyena',
           'Mission Crocodile Tears - the vicious Crocodile may be missing from the marked location']},
 {'h': 'UI'},
 {'list': ['Localization: Some UI texts are untranslated. In non-English languages, some texts may still appear untranslated (in English or as '
           'placeholder text). This affects the claim screen, the encyclopedia (for example the choke pattern spread entries), selling/discarding '
           'items, and some settings descriptions (difficulty, binocular modes, global illumination).',
           '(PS5/Xbox) The player is not able to discard any taxidermy from the Hunting Log menu',
           'Hunter assist: Animal analysis doesn’t display the current alert correctly']},
 {'h': 'Gear'},
 {'list': ['Equipped items may stay invisible after sleeping or fast traveling',
           'Ammo Lewellings Firefly Shock has incorrect energy loss over distance',
           'Buffden Apex Predator crossbow with mounted scope has increased ADS mouse sensitivity while zoomed in',
           'Missing Accuracy stat in the Shop and Storage for slugs, bolts and arrows',
           'Stats of some ammo are not accurate in the Shop and Storage: .308 Winchester (Grande Swift): Recoil is lower than listed',
           '12 Gauge (Rapid Buckshot): Recoil is higher than listed',
           'Shotguns equipped with Pellets or Buckshots fail to work in the Shooting Range',
           'Shotguns: pellets can be weak or miss at longer range (about 35 m and beyond)',
           'Tripod stands (controller): the reload button also dismounts you from the tripod, so you can’t reload the weapon while mounted.']},
 {'h': 'Multiplayer'},
 {'list': ['Cabins, stations and other facilities you discovered in single player don’t carry over to Multiplayer. The Hunting Map in Multiplayer '
           'shows only the starting lodge, so you have to discover everything again.',
           'Client crashes when Host switches to any Caller or Scent',
           'Client’s weapon starts empty when joining a session or after fast traveling',
           'Animals hunted by Client have a chance to disappear on their own while the Host is far away',
           'Difficulty hitting animals that are in motion for the client',
           'Temporary instances of desync in certain situations, resolved by closing the distance to the Host, or by waiting briefly',
           'Rare instances of being unable to interact with doors and parking signs, resolved by reconnecting to the session',
           'Animal sounds may not be audible',
           'Snowshoe Hare lacks animation for the Client when viewing the animal in Multiplayer',
           'Flashlight state is not replicated correctly in Multiplayer',
           'It is possible to join a session via an invite without having completed the Tutorial first, leading to a locked state. This is resolved '
           'by deleting the save files manually, and prevented by completing the Tutorial before trying to participate in Multiplayer.',
           '(Xbox) Inventory may clear after fast-travel',
           'Crash caused by the Host using Buffden Apex Predator']},
 {'h': 'Animals'},
 {'list': ['Common hippopotamus: Turns are too slow while charging',
           'Common hippopotamus: Spooked and dying animals don’t escape far from the player and their animations are not blended smoothly',
           'Common hippopotamus: Charging animals make insufficient noise',
           'Moose: No sound ripple visual when the moose makes a sound']},
 {'h': 'Performance'},
 {'list': ['(PC) Players with some AMD GPUs may experience crashes in 1.4 caused by a bug in the newest AMD drivers. We recommend rolling back to a '
           'previous driver version in the meantime. A hotfix is in the works.',
           'GPU crash occurs after entering a Hunting Reserve, exiting, then entering another different Hunting Reserve while Alt-Tabbed in the '
           'Loading Screen',
           'Animals flashing/disappearing visual effect when viewed through binoculars',
           '(PC) The game may crash repeatedly on AMD GPUs since v1.1. One player reported that turning off AMD’s Instant Replay stopped the '
           'crashes, but this is not confirmed.',
           '(PC) Random “Fatal Error” crashes since 1.2, mostly on sleep and fast travel',
           '(PC) Antialiasing > FSR option may not take effect, resolved by setting to TSR first, then FSR',
           'FPS drops in certain locations during sunset',
           '(Xbox) Title fails to reach 60 FPS in Performance mode',
           '(Xbox Series S) Game may crash in memory-intensive situations, such as near a lodge with heavily populated dioramas',
           '(Xbox) Disconnecting a controller and plugging in another one will not allow the user to dismiss the Disconnect message',
           '(PS5) Performance Mode: Mountain disappears/renders see-through near Sasquatch Lake',
           '(PS5/Xbox) UI: User is unable to scroll down the Animals list in the Encyclopedia after loading into any map',
           'Autosave causes stutter on a short interval for some players']},
 {'h': 'Environment'},
 {'list': ['Visible switching of ground texture around the player']},
 {'h': 'Snow'},
 {'list': ['(PS5/Xbox) Raindrops and snowflakes are not visible in Performance Mode',
           'Visual issues may appear while using antialiasing options TSR or TAAU during snowy weather',
           'Animal droppings and footprints are not visible in fallen snow']}]

def _newest_first(blocks):
    """The developers add new issues at the bottom under "Added on <date>": shown at the top here, so they're seen"""
    i = next((k for k, b in enumerate(blocks) if str(b.get("h", "")).startswith("Added on")), None)
    return blocks if i is None else blocks[i:] + blocks[:i]

def _update_articles():
    """Our own pages for the GUIDES tab (the head lamp, selling) and the official patch notes and known issues."""
    A = []
    A.append({"id": "guide:headlamp", "title": i18n.t("Head lamp"), "subtitle": i18n.t("Two beams"),
              "group": i18n.t("Hunting guides"), "tags": ["head lamp", "headlight", "clip light", "flashlight", "beam", "night", "visibility"], "blocks": [
        {"p": i18n.t("Press the clip light key to switch between two beams, then off.")},
        {"table": {"cols": [i18n.t("Press"), i18n.t("Beam"), i18n.t("Reach")], "rows": [
            [i18n.t("1st"), i18n.t("Narrow, for looking far"), i18n.t("about 96 m")],
            [i18n.t("2nd"), i18n.t("Wide, for the ground around you"), i18n.t("about 36 m")],
            [i18n.t("3rd"), i18n.t("Off"), ""]]}},
        {"p": i18n.t("Both beams are the same white light. Using the lamp doesn't make animals see you more.")}]})
    A.append({"id": "guide:selling", "title": i18n.t("Selling gear"), "subtitle": i18n.t("Storage refunds"),
              "group": i18n.t("Hunting guides"), "tags": ["sell", "storage", "refund", "money", "discard"], "blocks": [
        {"p": i18n.t("Gear you bought can be sold from Storage (Manage storage) for half of what it cost. Discard throws an item away for nothing.")},
        {"list": [i18n.t("Ammunition: you get half the price of the rounds still left in the pack."),
                  i18n.t("The gear you start the game with (Primacy Classic Hunter MK II rifle, ZOOMXD Vision Professional 1.5-6x42 scope, "
                  "Overgaard 8x binoculars, Stone Glacier Avail 2200 backpack) is free, so it sells for nothing.")]}]})
    # the developers' own text (KNOWN_ISSUES, OFFICIAL_PATCH_NOTES) is shown word for word, in English: only our lines around it change
    A.append({"id": "guide:knownissues", "title": i18n.t("Known issues (official)"),
              "subtitle": i18n.t("Version {version} · updated {date}").format(version=KNOWN_ISSUES_VERSION, date=KNOWN_ISSUES_UPDATED),
              "group": i18n.t("Game updates"), "tags": ["known issues", "bugs", "patch", "update", "workaround", "crash"], "blocks": [
        {"note": i18n.t("The developers' own list of known problems, word for word. Source: Nine Rocks Games, {url}").format(url=KNOWN_ISSUES_URL)}] + _newest_first(KNOWN_ISSUES)})
    for n in OFFICIAL_PATCH_NOTES:
        A.append({"id": "guide:update" + n["version"].replace(".", ""), "title": i18n.t("Game update {version} - patch notes").format(version=n["version"]),
                  "subtitle": i18n.t("{date} · version {build}").format(date=n["date"], build=n["build"]), "group": i18n.t("Game updates"),
                  "tags": ["patch", "update", n["version"], "patch notes", "changes", "fixes"], "blocks": [
            {"note": i18n.t("The official patch notes, word for word. Source: the developers' Steam announcement, {url}").format(url=n["url"])}] + n["blocks"]})
    dlc = _dlc_article()
    if dlc: A.append(dlc)
    A.sort(key=lambda x: x["group"] != i18n.t("Game updates"))     # the update pages together at the top
    return A

def _habitat_article(tables, paks_dir, released):
    """Every map job (habitat enhancements, clean-ups, bridges, blocked roads, hunting stand spots) from the maps'
    BP_Opportunity actors: cost (m_fulfillmentPrice) and how much each raises the fitness cap of which animal in
    its land (m_incrementAnimalFitnessCap)."""
    try:
        import opportunities_scan as osc
        text = osc.english(paks_dir)
        opp = {m: osc.scan(paks_dir, m, text) for m in osc.UMAPS}
    except Exception as e:
        print(f"warning: habitat jobs: {e!r}", file=sys.stderr)
        try: opp = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "opportunities.json"), encoding="utf-8"))
        except (OSError, ValueError): return []
    L = tables.get("ST_Levels", {})
    land_of = lambda mp, land: clean(L.get(f"KEY_ENVIRONMENT_{MAP_KEYS[mp]}_{land.upper()}_NAME", "")) or land
    name = lambda sid: released.get(sid) or next((v for k, v in released.items() if k.startswith(sid) or sid.startswith(k)), sid)
    cost = lambda o: f"${o['price']:,}" if o.get("price") else i18n.t("free")
    pct = lambda v: f"+{v * 100:.0f}%"
    blocks = [{"p": i18n.t("Every job on every map: what it costs and what it does. Habitat enhancements and "
                    "clean-ups raise the highest fitness the named animals' herds can reach on that land, as soon as the job is done. "
                    "Since game update 1.3, doing the job also gives those herds a small fitness boost right away (up to about 8%), "
                    "so the animals born there next come out fitter. Herds already close to their old cap get the most. "
                    "The rest still has to be brought up (Herds > Herd fitness). The cap never goes past 100%.")},
              {"list": [i18n.t("Habitat enhancement, invasive plants, litter: +10% fitness cap for each animal named."),
                        i18n.t("Big clean-ups (polluted lake, dry lake): +20% or +30% for each animal named."),
                        i18n.t("Bridges and blocked roads open a way through. Hunting stand spots give you a stand there.")]}]
    for mp in ("Map01", "Map02", "Hub"):
        jobs = opp.get(mp, [])
        if not jobs: continue
        blocks.append({"h": MAPS.get(mp, mp)})
        fit = [o for o in jobs if o.get("cap")]
        fit.sort(key=lambda o: (land_of(mp, o["land"]), o["kind"] != "enhancement", -max(o["cap"].values()), o["tag"]))
        rows = []
        for o in fit:
            vals = sorted(set(o["cap"].values()))
            who = ", ".join(sorted(name(k) for k in o["cap"]))
            rows.append([o["name"], land_of(mp, o["land"]), cost(o), " / ".join(pct(v) for v in vals), who])
        if rows: blocks.append({"table": {"cols": [i18n.t("Job"), i18n.t("Land"), i18n.t("Cost"), i18n.t("Fitness cap"), i18n.t("Animals")], "rows": rows, "w": [14, 12, 6, 6, 34]}})
        tot = {}
        for o in fit:
            for k, v in o["cap"].items():
                key = (name(k), land_of(mp, o["land"])); t = tot.setdefault(key, [0.0, 0]); t[0] += v; t[1] += 1
        if tot:
            blocks.append({"p": i18n.t("All of them done, per animal and land:")})
            blocks.append({"table": {"cols": [i18n.t("Animal"), i18n.t("Land"), i18n.t("Fitness cap raised by"), i18n.t("Jobs")],
                                     "rows": [[a, r, pct(t[0]), str(t[1])] for (a, r), t in sorted(tot.items())], "w": [18, 14, 10, 5]}})
        other = [o for o in jobs if not o.get("cap")]
        other.sort(key=lambda o: (o["kind"], land_of(mp, o["land"]), o["tag"]))
        if other:
            blocks.append({"table": {"cols": [i18n.t("Job"), i18n.t("Land"), i18n.t("Cost")], "rows": [[o["name"], land_of(mp, o["land"]), cost(o)] for o in other], "w": [16, 14, 6]}})
    return [{"id": "herds:habitat", "title": i18n.t("Habitat jobs: every map"), "subtitle": i18n.t("Enhancements, clean-ups, bridges and stand spots"), "group": i18n.t("Herd management"),
             "tags": ["habitat", "enhancement", "opportunity", "fitness cap", "pollution", "bridge", "stand", "cost"], "blocks": blocks}]

def _herd_size_article(paks_dir, released):
    """Herd size: the four herd types, each animal's numbers (released animals only) and how herd fitness sets the
    number a herd grows back to every game year (herds.py)."""
    try:
        import herds
        gs = herds.group_sizes(paks_dir)
    except Exception:
        return []
    rows = []
    for sid, title in sorted(released.items(), key=lambda kv: kv[1]):
        g = gs.get(sid) or next((v for k, v in gs.items() if k.startswith(sid) or sid.startswith(k)), None)
        if not g: continue
        cell = lambda k: ("%d-%d" % tuple(g[k])) if k in g and g[k][0] != g[k][1] else ("1" if k in g else "-")
        rows.append([title, cell("Big"), cell("Medium"), cell("Small"), cell("Solitary")])
    if not rows:
        return []
    return [{"id": "rules:herdsize", "title": i18n.t("Herd size"), "subtitle": i18n.t("How many animals a herd has, and why"),
             "group": i18n.t("Herd management"), "tags": ["herd size", "group", "big", "small", "solitary", "thriving", "vulnerable"], "blocks": [
        {"p": i18n.t("Every herd lives in its own territory, and every territory is one of four types: Big, Medium, Small or Solitary. "
              "Each animal has its own numbers for each type (below). A herd's type never changes.")},
        {"table": {"cols": [i18n.t("Animal"), i18n.t("Big"), i18n.t("Medium"), i18n.t("Small"), i18n.t("Solitary")], "rows": rows}},
        {"h": i18n.t("How herd fitness changes the size")},
        {"list": [i18n.t("When a map is first made, every herd gets a random number of animals inside its range."),
                  i18n.t("Every game year, right after the animals age, the game counts each herd. A herd with fewer animals than its number for this year gets young animals until it has that many. Their fitness is rolled around the herd's fitness."),
                  i18n.t("The number for the year comes from the herd fitness: the lowest starting fitness of that animal on that land gives the smallest herd, the top gives the biggest. The top is 100% on private lands and the land's base cap on public lands."),
                  i18n.t("A herd never loses animals this way. Only hunting and old age make it smaller, so an overhunted herd stays small until the next year.")]},
        {"note": i18n.t("Halfway between the lowest start and the top gives a herd about halfway between the smallest and the biggest size, rounded down.")},
        {"h": i18n.t("Example")},
        {"list": [i18n.t("Big elk herd (11-18) on a private land where elk start from 31%:"),
                  i18n.t("herd fitness 31% (Vulnerable): 11 elk, 45% (Stable): 12, 60%: 14, 75% (Healthy): 16, 90%: 17, 100% (Thriving): 18.")]},
        {"p": i18n.t("So a Vulnerable herd grows back to few animals, a Thriving one to its biggest. Raise the herd fitness (cull the weak, build habitat enhancements on private land) and every herd of that animal on the land grows back bigger next year. In the Toybox, click a herd on the map to see its type and how many animals it has now (Toybox Unlocked also shows its herd fitness and the number it grows back to).")}]}]

def _rules_articles():
    A = []
    A.append({"id": "rules:stars", "title": i18n.t("How stars are given"), "subtitle": i18n.t("Score lines and stars"),
              "group": i18n.t("Trophies"), "tags": ["score", "rating", "lines"], "blocks": [
        {"p": i18n.t("A trophy's score is all its measurements' points added up.")},
        {"p": i18n.t("Each species has four score lines (mule deer have a second, higher set for non-typical bucks). They are on every animal's page (Animals tab, under Trophy):")},
        {"table": {"cols": [i18n.t("Score"), i18n.t("Stars")], "rows": [[i18n.t("line 4 or more"), "5"],
                   [i18n.t("line 3 or more"), "4"], [i18n.t("line 2 or more"), "3"], [i18n.t("line 1 or more"), "2"], [i18n.t("below line 1"), "1"]]}},
        {"p": i18n.t("Females of whitetail, mule deer, moose, elk, bison, kudu and pronghorn have no score lines, so they get no trophy stars. Every harvest still gets a separate hunt rating for the shot.")},
        {"list": [i18n.t("Where both sexes have lines, they are the same. What differs is how big each sex can grow."),
                  i18n.t("Stars are set when the trophy is measured. The hunting log keeps them only for animals you harvest."),
                  i18n.t("Sell antlers or horns and the hunting log keeps the stars but not the measurements. Send the animal to taxidermy if you want to keep the full score.")]}]})
    A.append({"id": "rules:points", "title": i18n.t("How measurements become points"), "subtitle": i18n.t("Whole numbers times points per unit"),
              "group": i18n.t("Trophies"), "tags": ["measurement", "points", "weight"], "blocks": [
        {"p": i18n.t("Points are the measurement, with the decimals dropped, times the points per unit.")},
        {"note": i18n.t("Example: a 0.86 kg yellow-billed duck hen = 860 g / 5 = 172 points = 2 stars.")},
        {"list": [i18n.t("Lengths are in centimeters and the decimals are cut off, not rounded: 63.9 cm counts as 63."),
                  i18n.t("Racks, horns, tusks and body length score 1 point per cm. Skull length and width score 10 points per cm."),
                  i18n.t("Weight trophies: points = weight in grams / grams per point. 5 g: mallard, yellow-billed duck, snowshoe hare. 2 g: ptarmigan. 50 g: turkey, honey badger. 100 g: wolverine. Ostrich scores 2 points per kg. Zebra scores 1 point per kg plus 1 point per cm of body length (stallions up to 400 kg and 260 cm = 660, mares up to 360 kg and 255 cm = 615).")]},
        {"h": i18n.t("Typical points and all points")},
        {"list": [i18n.t("Whitetail: the score adds both 'length of typical points' and 'length of all points'. 'All points' is the typical points plus the small extra points that grow off them on bigger bucks. So the typical points do count twice, and the extra points once. Young or poor bucks have no extra points, so the two numbers match. A 10-year-old buck at 100% fitness: typical 302 cm, all points 365 cm."),
                  i18n.t("Elk: a bull 17 years or older with 95% fitness or more grows one more tine on each side (the BA tine), and the game adds about 157 cm per side for it to his typical points. That's over 300 points: every one of those bulls is 5 stars."),
                  i18n.t("Mule deer: only typical points are measured. On a non-typical rack the extra side tines count as typical points, which is why it scores so much higher.")]}]})
    A.append({"id": "rules:growth", "title": i18n.t("Growth: age and fitness"), "subtitle": i18n.t("What makes a trophy big"),
              "group": i18n.t("Trophies"), "tags": ["age", "fitness", "size"], "blocks": [
        {"p": i18n.t("Age and fitness together give a growth value between 0 and 1:")},
        {"note": i18n.t("Growth is age times fitness, measured against the species' oldest age. Fitness counts as a fraction here (83% = 0.83).")},
        {"list": [i18n.t("An animal's fitness is set when it is born and never changes; only its age goes up."),
                  i18n.t("Growth 1.0 is the maximum size. It needs age x fitness = oldest age, so only an animal at the oldest age with 100% fitness gets there."),
                  i18n.t("Half the age or half the fitness is roughly half the size."),
                  i18n.t("Body size, weight, skulls and body length follow growth in a straight line from the smallest to the biggest: growth 0.5 is halfway."),
                  i18n.t("Skull, body-length and weight trophies use growth at the moment of the kill."),
                  i18n.t("Antlers, horns and tusks are rebuilt every year from the animal's new age (see How racks grow and change).")]},
        {"h": i18n.t("Example: whitetail (oldest age 10)")},
        {"table": {"cols": [i18n.t("Age and fitness"), i18n.t("Growth")], "rows": [[i18n.t("10 years, 100 %"), "1.00"], [i18n.t("10 years, 50 %"), "0.49"],
                   [i18n.t("5 years, 100 %"), "0.49"], [i18n.t("3 years, 60 %"), "0.17"]]}}]})
    A.append({"id": "rules:kinds", "title": i18n.t("Skulls, weights and racks"), "subtitle": i18n.t("Which trophies are luck and which aren't"),
              "group": i18n.t("Trophies"), "tags": ["rack", "skull", "template", "level"], "blocks": [
        {"h": i18n.t("Skull, body length and weight")},
        {"p": i18n.t("No luck: the same age and fitness always give the same score. Skulls (wolf, grizzly, lion, spotted hyena) score (length + width) x 10.")},
        {"table": {"cols": [i18n.t("Skull"), i18n.t("Length"), i18n.t("Width"), i18n.t("Points")], "rows": [[i18n.t("Wolf"), "20-31 cm", "10-17 cm", "300-480"],
                   [i18n.t("Grizzly"), "27-44 cm", "16-27 cm", "430-710"], [i18n.t("Lion"), "25-40 cm", "17-27 cm", "420-670"], [i18n.t("Hyena"), "20-34 cm", "13-21 cm", "330-550"]]}},
        {"p": i18n.t("Crocodile body length: bulls 170-640 cm, cows 150-450 cm.")},
        {"h": i18n.t("Antlers, horns and tusks")},
        {"list": [i18n.t("Type: every species has one rack type per sex (moose bulls are the exception, see Moose below)."),
                  i18n.t("Warthog sows grow tusks too, the same kind as the boars."),
                  i18n.t("Size: every beam, tine and horn section grows with age x fitness, up to its maximum."),
                  i18n.t("Shape: the bends are rolled at random for each side, so two animals with the same age and fitness can score differently - and the roll is redone every year."),
                  i18n.t("Tines: an age table gives the trophy a level from 0 to 6 that decides which tines may grow; many tines also need a minimum age and fitness. Whitetail buck: age 1 = level 0, 2 = 1, 3 = 2, 4 = 3, 5 = 4, 6 = 5, 7 and older = 6."),
                  i18n.t("Measuring: straight lines between the joints of the finished trophy, turned into points.")]},
        {"h": i18n.t("Moose")},
        {"list": [i18n.t("A moose bull has one of four antler types: cervina, semi-cervina, half palm or full palm. It is picked by his fitness when his first rack is built and kept for life: cervina 0-20%, semi-cervina 10-30%, half palm 30-100%, full palm 40-100%. Where the bands overlap the pick is random."),
                  i18n.t("Each type has its own age table. Cervina and semi-cervina have no palm, so their palm width is 0."),
                  i18n.t("Main beam: the longest straight line from the antler base to the tip of the palm (or the last tine), on the left antler."),
                  i18n.t("Palm width: the widest point of each palm, left plus right. It grows with the antler thickness value, so it follows age x fitness."),
                  i18n.t("Outside spread: the widest distance between matching tines on the left and right antler. It comes from the random bends, so it changes every year."),
                  i18n.t("Number of points: every tine that shows, both sides counted."),
                  i18n.t("Moose tines that do not grow are folded back into the palm, so missing tines also change the palm's shape."),
                  i18n.t("Under 75% fitness a moose can grow the small set of points (fewer tines on the palm). No moose makes 5 stars under 75%.")]}]})
    A.append({"id": "rules:rackbuild", "title": i18n.t("How racks grow and change"), "subtitle": i18n.t("Age, fitness and luck"),
              "group": i18n.t("Trophies"), "tags": ["random", "shape", "spread", "age", "aging", "tine", "year", "rebuild"], "blocks": [
        {"list": [i18n.t("A rack is made the first time the animal spawns near you."),
                  i18n.t("Every in-game year the animal gets a year older and its rack is made again from scratch."),
                  i18n.t("Lengths and thickness come from age and fitness, so they only grow from year to year."),
                  i18n.t("Which tines grow depends on age and fitness. A few are a coin flip."),
                  i18n.t("The bends, and with them the spreads, are random and change every year."),
                  i18n.t("Left and right are rolled separately.")]},
        {"h": i18n.t("Whitetail tines")},
        {"table": {"cols": [i18n.t("Whitetail"), i18n.t("Grows at")], "rows": [
            [i18n.t("Main beam"), i18n.t("age 2+, fitness 20%+. Longer at age 3 (30%+) and age 6 (60%+)")], [i18n.t("G1 (brow tine)"), i18n.t("age 3+, fitness 20%+, then only half the time on each side")],
            ["G2", i18n.t("every buck")], ["G3", i18n.t("every buck from age 2")],
            ["G4", i18n.t("age 3+, fitness 30%+")], ["G5", i18n.t("age 4+, fitness 50%+")], ["G6", i18n.t("age 7+, fitness 70%+")],
            [i18n.t("Small fork near the tip"), i18n.t("age 7+, fitness 80%+. Not one of the typical points")],
            [i18n.t("Non-typical points"), i18n.t("don't grow in the game yet")]]}},
        {"h": i18n.t("Moose antler types")},
        {"p": i18n.t("A moose bull's antler type is picked by fitness when his first rack is made and kept for life: cervina 0-20%, semi-cervina 10-30%, half palm 30-100%, full palm 40-100%. Where the bands overlap it's random.")},
        {"h": i18n.t("How it's measured")},
        {"list": [i18n.t("Lengths: straight lines from joint to joint along the antler or horn."),
                  i18n.t("Spreads: the widest distance between the same tine on the left and right."),
                  i18n.t("Circumference: from the thickness of the beam.")]}]})
    A.append({"id": "rules:herd", "title": i18n.t("Herd fitness"), "subtitle": i18n.t("The part you control"),
              "group": i18n.t("Herd management"), "tags": ["herd", "fitness", "cull", "thriving", "cap"], "blocks": [
        {"p": i18n.t("Each animal has its own herd fitness on every land, from 20 to 100%. The game shows it as the herd's state:")},
        {"table": {"cols": [i18n.t("Herd fitness"), i18n.t("State")], "rows": [["20-40%", i18n.t("Vulnerable")], ["40-70%", i18n.t("Stable")],
                   ["70-90%", i18n.t("Healthy")], ["90-100%", i18n.t("Thriving")]]}},
        {"p": i18n.t("A herd right on a line (40%, 70%, 90%) counts as the lower state. The bar on the game's map only runs up to the herd's cap.")},
        {"p": i18n.t("The game never shows a Critical state: no herd can drop below 20% on any land.")},
        {"note": i18n.t("These are the herd's numbers, not single animals. Animals are born around the herd's fitness and can be up to 50% fitter than it, so a Stable herd at 50% can still hold a 90% animal (see How herd fitness reaches the animals).")},
        {"h": i18n.t("Start, floor and cap")},
        {"list": [i18n.t("A herd starts at a random fitness inside its land's start range (on each animal's page)."),
                  i18n.t("A herd never drops below 20%."),
                  i18n.t("A herd never rises above its cap. Base caps are 50%, 60%, 70% or 80%, so no herd can be Thriving on its base cap."),
                  i18n.t("Habitat jobs on private lands raise that cap, up to 100%: an enhancement for that animal +10%, a clean-up +10% to +30%. Thriving needs jobs done."),
                  i18n.t("Building one also gives that animal's herds on the land a small fitness boost right away (up to about 8%).")]}]})
    A.append({"id": "rules:cull", "title": i18n.t("What a harvest does to the herd"), "subtitle": i18n.t("Culling"),
              "group": i18n.t("Herd management"), "tags": ["cull", "harvest", "female", "young"], "blocks": [
        {"p": i18n.t("Every harvest changes the herd's fitness right away. The game compares the animal's fitness with the herd's: the bigger the gap, the bigger the change.")},
        {"list": [i18n.t("Animal less fit than the herd: herd fitness goes up."), i18n.t("Animal fitter than the herd: herd fitness goes down."), i18n.t("Same fitness: no change.")]},
        {"note": i18n.t("The change is the gap value below, times the sex, age and upward bonus factors.")},
        {"table": {"cols": [i18n.t("Difference"), i18n.t("Gap value")], "rows": [["10%", "1.3%"], ["20%", "2.5%"], ["30%", "3.25%"], ["40%", "3.5%"], ["100%", i18n.t("3.75% (max)")]]}},
        {"list": [i18n.t("Sex: females x1.0; males x1.2 for most animals (x1.15 moose; x1.1 warthog, buffalo, hare; x1.05 wolf, grizzly, ducks, ptarmigan)."),
                  i18n.t("Age: young animals count most - x1.3 at the youngest, x1.25 at 30 % of the oldest age, x1.05 at 70 %, x1.0 at the oldest."),
                  i18n.t("Upward bonus, only when the herd goes up: x1.3 for whitetail, mule deer, elk, pronghorn, Dall sheep, zebra, ostrich, turkey and buffalo; x1.15 for the rest."),
                  i18n.t("The result is held between 20% and the cap.")]},
        {"h": i18n.t("Examples")},
        {"list": [i18n.t("Elk herd at 60%, take a young cow at 30%: 3.25% x 1.0 x about 1.27 x 1.3 = about +5.4%."),
                  i18n.t("Same herd, take a young bull at 30%: 3.25% x 1.2 x about 1.27 x 1.3 = about +6.4%."),
                  i18n.t("Same herd, take a prime old bull at 90%: 3.25% x 1.2 x about 1.03 = about -4.0%.")]},
        {"p": i18n.t("Cull the weak and the young to raise a herd; a weak young male lifts it the most. Every top animal you shoot pulls it down a little, a top male the most.")}]})
    A.append({"id": "rules:newanimals", "title": i18n.t("How herd fitness reaches the animals"), "subtitle": i18n.t("The fitness roll for new animals"),
              "group": i18n.t("Herd management"), "tags": ["spawn", "fitness", "roll"], "blocks": [
        {"p": i18n.t("New animals that join a herd get their fitness rolled around the herd's fitness:")},
        {"list": [i18n.t("a bell curve centered on the herd fitness, with a spread of 25%,"),
                  i18n.t("kept within 50% of the herd fitness, never below 10% and never above 100%.")]},
        {"p": i18n.t("So the fittest animals come from the fittest herds. Fitter animals grow bigger trophies (and only moose bulls at 40% or more can grow a full palm).")},
        {"h": i18n.t("The numbers: 100 new animals")},
        {"p": i18n.t("Out of 100 new animals born into a herd, how many land in each fitness band. Every row adds up to 100. "
              "The last column is a perfect 100.0% animal: much rarer than 99%, because the game only gives it when its roll misses 10 times in a row.")},
        {"table": {"cols": [i18n.t("Herd fitness")] + [i18n.t("under 50%") if b[2] == "under 50%" else b[2] for b in NEWBORN_BANDS] + [i18n.t("Perfect 100%")],
                   "rows": _newborn_rows(), "w": [10, 8, 6, 6, 6, 6, 6, 6, 7, 11]}},
        {"list": [i18n.t("A herd practically never makes an animal more than 50 points fitter than itself: a 40% herd tops out just under 90%, a 30% herd under 80%."),
                  i18n.t("For a 95%+ animal you want the herd at 90% or more: about 1 in 8 there, 1 in 20 at 70%, 1 in 70 at 50%, never at 40% or lower."),
                  i18n.t("Only new animals get rolled. Animals already alive keep their fitness for life, so a herd's best animals change only as old ones die and young ones are born.")]}]})
    A.append({"id": "rules:howto", "title": i18n.t("How to get high-star trophies"), "subtitle": i18n.t("Putting it together"),
              "group": i18n.t("Trophies"), "tags": ["tips", "5 stars"], "blocks": [
        {"list": [i18n.t("Raise the herd first: build habitat enhancements on the land (+10% cap each and a small boost right away) and harvest weak and young animals, weak young males most of all. Leave the prime males."),
                  i18n.t("Hunt old animals from that herd: age unlocks tines and grows every length."),
                  i18n.t("Pick the fittest of them: only the oldest age at 100 % fitness reaches full size."),
                  i18n.t("Whitetail: look for brow tines (G1) on both sides. Elk: a bull 17+ with 95%+ fitness is always 5 stars."),
                  i18n.t("Moose: full palm bulls are the better bet."),
                  i18n.t("A rack is rebuilt every year from the animal's new age. The bends (and with them the spread) and a few coin-flip tines are rolled again each time."),
                  i18n.t("Only animals you harvest keep their stars."),
                  i18n.t("Skull animals (wolf, grizzly, lion, hyena): females are as good as males."),
                  i18n.t("How much fitness each animal needs: see Fitness for 5 stars.")]}]})
    return A

# ---------------------------------------------------------------- maxed-out odds
def _odds():
    try: return json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "trophy_odds.json"), encoding="utf-8"))
    except (OSError, ValueError): return {}

def _pct(p):
    if p >= 0.995: return i18n.t("always")
    if p <= 0: return i18n.t("never")
    if p < 0.01: return "<1%"
    return f"{round(p * 100)}%"

def _odds_key(d, sub, sex):
    return next((k for k in d if k.split("|")[1] == sex and (sub.startswith(k.split("|")[0]) or k.split("|")[0].startswith(sub))), None)

def _newborn_share(m, t, sd=0.25, tmin=0.1, tmax=1.0, tries=10):
    """Share of new animals with fitness >= t in a herd at fitness m: the game's fitness roll (a bell curve around m,
    spread 0.25, kept strictly within m +- 0.5 and 0.1-1.0; 10 tries, then the last roll is pinned to 0.1-1.0)."""
    phi = lambda x: 0.5 * (1 + math.erf((x - m) / (sd * math.sqrt(2))))
    a, b = max(m - 0.5, 0.0, tmin), min(m + 0.5, 1.0, tmax)
    p = phi(b) - phi(a)
    acc = (phi(b) - phi(max(t, a))) / p if t < b else 0.0
    q = (1 - p) ** tries
    out = (1 - phi(max(t, b))) + (max(0.0, phi(a) - phi(t)) if t <= a else 0.0)
    return (1 - q) * acc + q * out / (1 - p)

NEWBORN_BANDS = [(0.0, 0.5, "under 50%"), (0.5, 0.6, "50-60%"), (0.6, 0.7, "60-70%"), (0.7, 0.8, "70-80%"),
                 (0.8, 0.9, "80-90%"), (0.9, 0.95, "90-95%"), (0.95, 0.99, "95-99%"), (0.99, 1.01, "99-100%")]

def _newborn_perfect(m, sd=0.25, tmin=0.1, tmax=1.0, tries=10):
    """Chance a new animal is exactly 100%: only when all 10 rolls miss and the last one is at or above 100%."""
    phi = lambda x: 0.5 * (1 + math.erf((x - m) / (sd * math.sqrt(2))))
    a, b = max(m - 0.5, 0.0, tmin), min(m + 0.5, 1.0, tmax)
    p = phi(b) - phi(a)
    return (1 - p) ** tries * (1 - phi(1.0)) / (1 - p)

def _newborn_rows():
    """Per herd fitness: out of 100 new animals, how many land in each fitness band (whole numbers that add to 100),
    then the chance of a perfect 100%."""
    rows = []
    for m in (0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0):
        at = lambda t: 1.0 if t <= 0 else (0.0 if t > 1 else _newborn_share(m, t))
        raw = [(at(lo) - at(hi)) * 100 for lo, hi, _n in NEWBORN_BANDS]
        n = [int(v) for v in raw]                                 # round so the row adds to exactly 100
        for k in sorted(range(len(raw)), key=lambda k: raw[k] - n[k], reverse=True)[:100 - sum(n)]: n[k] += 1
        pf = _newborn_perfect(m)
        perf = i18n.t("never") if pf < 1e-7 else i18n.t("1 in {n}").format(n=f"{round(1 / pf, -1 if pf > 1e-3 else (-3 if pf > 1e-5 else -5)):,.0f}")
        rows.append([f"{m * 100:.0f}%"] + [("-" if raw[k] < 0.05 else ("<1" if v == 0 else str(v))) for k, v in enumerate(n)] + [perf])
    return rows

def _nt_fact():
    """Mule deer page: what a maxed non-typical buck makes (rack/odds.py + fitness runs, --quality=NonTypical)."""
    N = _odds().get("nontypical", {})
    r, f = N.get("racks"), N.get("fitness")
    if not r: return None
    st = r["stars"]; p5 = st.get("5", 0)
    a = f["all"] if f else {"first": None}
    if a["first"] is None:
        t = i18n.t("At its oldest age with 100% fitness a non-typical buck scores {lo}-{hi} and is 5 stars {pct} of the time.")
    elif a["half"] is None:
        t = i18n.t("At its oldest age with 100% fitness a non-typical buck scores {lo}-{hi} and is 5 stars {pct} of the time. "
                   "5 stars are possible from fitness {first}.")
    else:
        t = i18n.t("At its oldest age with 100% fitness a non-typical buck scores {lo}-{hi} and is 5 stars {pct} of the time. "
                   "5 stars are possible from fitness {first}, half the time from {half}.")
    return t.format(lo=r['score'][0], hi=r['score'][1], pct=_pct(p5), first=_fit(a["first"]), half=_fit(a.get("half")))

def _fit(f):
    return _fp(f) if f is not None else i18n.t("never")

def _pct_strict(p):
    """Like _pct, but 'always' only when no rack missed."""
    if p >= 1: return i18n.t("always")
    if p >= 0.995: return f"{min(p * 100, 99.99):.2f}%"
    return _pct(p)

def _fit_up(f):
    """An exact cutoff rounded UP to 0.01, so the shown fitness always makes it."""
    return _fp(math.ceil(f * 100 - 1e-6) / 100) if f is not None else i18n.t("never")

WT_VARIANT = {"AA both antlers": "brow tine (G1) on both sides · 1 in 4 bucks", "AA one antler": "brow tine (G1) on one side · 1 in 2 bucks", "no AA": "no brow tine (G1) · 1 in 4 bucks"}
WT_NOTE = ("Whitetail: the brow tine (G1) decides it. Each side grows one half the time. Both sides: all 5 stars from 95%, but only at "
           "10 years old. One side: at most 9 in 10 make it. No G1: never.")
NOTE_FIX = {"OdocoileusVirginianusBorealis|M": WT_NOTE}

def _odds_text(s):
    """WT_VARIANT / NOTE_FIX / trophy_odds.json notes and variants in the app's language (a line not listed stays English)"""
    return {"full palm": i18n.t("full palm"), "half palm": i18n.t("half palm"),
            "The last horn piece is a coin flip (50% per horn); it only moves the score, not the star.":
            i18n.t("The last horn piece is a coin flip (50% per horn); it only moves the score, not the star."),
            "Maxed bucks score 205-245 against a 5-star line of 227: the spreads (how far apart the tips end up) are luck, so it is about a coin flip.":
            i18n.t("Maxed bucks score 205-245 against a 5-star line of 227: the spreads (how far apart the tips end up) are luck, so it is about a coin flip."),
            "Maxed bulls score 295-312 against a 5-star line of 300; the spreads decide the last few points.":
            i18n.t("Maxed bulls score 295-312 against a 5-star line of 300; the spreads decide the last few points."),"brow tine (G1) on both sides · 1 in 4 bucks": i18n.t("brow tine (G1) on both sides · 1 in 4 bucks"),
            "brow tine (G1) on one side · 1 in 2 bucks": i18n.t("brow tine (G1) on one side · 1 in 2 bucks"),
            "no brow tine (G1) · 1 in 4 bucks": i18n.t("no brow tine (G1) · 1 in 4 bucks"),
            WT_NOTE: i18n.t("Whitetail: the brow tine (G1) decides it. Each side grows one half the time. Both sides: all 5 stars from 95%, but only at "
                            "10 years old. One side: at most 9 in 10 make it. No G1: never.")}.get(s, s)

def _fitness_article(names, O):
    FT = O.get("fitness")
    if not FT: return []
    nm = lambda k: next((t for s_, t in names.items() if s_.startswith(k.split("|")[0]) or k.split("|")[0].startswith(s_)), k.split("|")[0])
    order = sorted(FT, key=lambda k: (FT[k]["all"]["always"] is None, FT[k]["all"]["always"] or 9, -(FT[k]["all"]["at"]["1.00"]), nm(k)))
    rows, steps = [], ["0.70", "0.75", "0.80", "0.85", "0.88", "0.90", "0.92", "0.95", "1.00"]
    srows = []
    for k in order:
        for v, a in [("all", FT[k]["all"])] + [(v, a) for v, a in sorted(FT[k].items()) if v != "all"]:
            has_nt = bool(O.get("nontypical", {}).get("fitness")) and k.startswith("OdocoileusHemionus") and k.endswith("|M")
            label = ((i18n.t("{animal}, all bulls") if k.startswith("AlcesAlces") else i18n.t("{animal}, all bucks")) if len(FT[k]) > 1
                     else i18n.t("{animal}, typical bucks") if has_nt else i18n.t("{animal} male")) if v == "all" else i18n.t("{animal}, {variant}")
            label = label.format(animal=nm(k), variant=_odds_text(WT_VARIANT.get(v, v)))
            rows.append([label, _fit(a["first"]), _fit(a["half"]), _fit(a["always"]), _pct_strict(a["at"]["1.00"])])
            srows.append([label] + [_pct_strict(a["at"].get(f, 0)) for f in steps])
        nf = O.get("nontypical", {}).get("fitness") if k.startswith("OdocoileusHemionus") and k.endswith("|M") else None
        if nf:                                           # 1.3: non-typical bucks, their own rack and star lines
            a = nf["all"]; label = i18n.t("{animal}, non-typical bucks").format(animal=nm(k))
            rows.append([label, _fit(a["first"]), _fit(a["half"]), _fit(a["always"]), _pct_strict(a["at"]["1.00"])])
            srows.append([label] + [_pct_strict(a["at"].get(f, 0)) for f in steps])
    F = O.get("formula", {})
    frows = []
    for base in sorted({k.split("|")[0] for k in F}, key=lambda b: (F.get(b + "|M", {}).get("five_from") or 9, nm(b + "|M"))):
        if nm(base + "|M") == base: continue
        m, f = F.get(base + "|M"), F.get(base + "|F")
        frows.append([nm(base + "|M"), _fit_up(m.get("five_from")) if m else "-", _fit_up(f.get("five_from")) if f else "-"])
    females = sorted({nm(k) for k in O.get("racks", {}) if k.endswith("|F")})
    best_f = {}                                          # the most stars a maxed female makes, from the rack runs
    for k, v in O.get("racks", {}).items():
        if not k.endswith("|F"): continue
        st = {int(n): p for n, p in v["stars"].items() if p >= 0.005}
        top = max(st); best_f.setdefault(top, []).append((nm(k), st))
    fem_txt = []
    for top in sorted(best_f, reverse=True):
        for name, st in sorted(best_f[top]):
            low = [n for n in st if n < top]
            if not low: t = i18n.t("{animal}: {n} stars") if top > 1 else i18n.t("{animal}: {n} star")
            else: t = i18n.t("{animal}: {n} stars ({pct} of the time, else {low} stars)") if min(low) > 1 else i18n.t("{animal}: {n} stars ({pct} of the time, else {low} star)")
            fem_txt.append(t.format(animal=name, n=top, pct=_pct(st[top]) if low else "", low=min(low) if low else ""))
    _bf = FT.get("SyncerusCafferCaffer|M", {}).get("all")    # the example under the table (numbers from the same data)
    if _bf and None in (_bf.get("first"), _bf.get("half"), _bf.get("always")): _bf = None
    return [{"id": "rules:fitness5", "title": i18n.t("Fitness for 5 stars"), "subtitle": i18n.t("How fit an old male has to be for 5 stars"),
             "group": i18n.t("Trophies"), "tags": ["5 stars", "fitness", "threshold", "minimum", "odds", "cutoff"], "blocks": [
        {"p": i18n.t("These numbers are for males at their oldest age. Even one year younger, most can't reach 5 stars.")},
        {"h": i18n.t("Racks and horns")},
        {"p": i18n.t("No two racks grow the same, so two males with the same fitness can score differently. Each row shows:")},
        {"list": [i18n.t("First 5★: the lowest fitness where a 5-star rack can happen"),
                  i18n.t("Half 5★: from here, about half of them are 5 stars"),
                  i18n.t("All 5★: from here, every one is 5 stars (\"never\" means some always fall short)"),
                  i18n.t("At 100%: how many are 5 stars at full fitness")]},
        {"p": i18n.t("Same number in all three: no luck. Below it never 5 stars, from it always.")},
        *([{"p": i18n.t("Example: Cape buffalo {a} · {b} · {c}. At {a} a few make 5 stars, at {b} about half, from {c} all of them.").format(
            a=_fp(_bf["first"]), b=_fp(_bf["half"]), c=_fp(_bf["always"]))}] if _bf else []),
        {"table": {"cols": [i18n.t("Animal"), i18n.t("First 5★"), i18n.t("Half 5★"), i18n.t("All 5★"), i18n.t("At 100%")], "rows": rows, "w": [26, 9, 9, 9, 10]}},
        {"note": _odds_text(WT_NOTE)},
        {"h": i18n.t("Chance of 5 stars at each fitness")},
        {"p": i18n.t("Out of 100 old males at that fitness, how many are 5 stars.")},
        {"table": {"cols": [i18n.t("Animal")] + [i18n.t("{pct} fit").format(pct=_fp(x)) for x in steps], "rows": srows, "w": [26] + [6] * len(steps)}},
        {"h": i18n.t("Skull, weight and body-length trophies")},
        {"p": i18n.t("No luck involved. At the oldest age these are 5 stars from this fitness up, every time.")},
        {"table": {"cols": [i18n.t("Animal"), i18n.t("Male"), i18n.t("Female")], "rows": frows, "w": [24, 10, 10]}},
        {"h": i18n.t("Females with racks or horns")},
        {"p": i18n.t("Never 5 stars: {list}. The most a female makes at her oldest age with 100% fitness:").format(list=", ".join(females))},
        {"list": fem_txt}]}]

def _odds_article(names):
    O = _odds()
    if not O: return []
    nm = lambda k: next((t for s_, t in names.items() if s_.startswith(k.split("|")[0]) or k.split("|")[0].startswith(s_)), k.split("|")[0])
    sx = lambda k: {"M": i18n.t("{animal} male"), "F": i18n.t("{animal} female")}[k.split("|")[1]]
    pc = lambda p: "0%" if p <= 0 else "100%" if p >= 1 else ("<0.1%" if p < 0.001 else _pct(p))
    rows = []
    for k, v in sorted(O.get("racks", {}).items(), key=lambda kv: (nm(kv[0]), kv[0])):
        st = v["stars"]; lo = max(0.0, 1 - st.get("5", 0) - st.get("4", 0))
        nv = O.get("nontypical", {}).get("racks") if k.startswith("OdocoileusHemionus") and k.endswith("|M") else None
        rows.append([(i18n.t("{animal}, typical bucks") if nv else sx(k)).format(animal=nm(k)), pc(st.get("5", 0)), pc(st.get("4", 0)), pc(lo), f"{v['score'][0]}-{v['score'][1]}" if v["score"][0] != v["score"][1] else str(v["score"][0])])
        if nv:                                           # 1.3: the non-typical rack, right under the typical buck
            st = nv["stars"]; lo = max(0.0, 1 - st.get("5", 0) - st.get("4", 0))
            rows.append([i18n.t("{animal}, non-typical bucks").format(animal=nm(k)), pc(st.get("5", 0)), pc(st.get("4", 0)), pc(lo), f"{nv['score'][0]}-{nv['score'][1]}"])
    frows = []
    F = O.get("formula", {})
    for base in sorted({k.split("|")[0] for k in F}, key=nm):
        if nm(base + "|M") == base: continue                # not an animal in the game (no name)
        m, f = F.get(base + "|M"), F.get(base + "|F")
        frows.append([nm(base + "|M"), f"{m['stars']} ({m['score']})" if m else "-", f"{f['stars']} ({f['score']})" if f else "-"])
    def note(k, t):
        fv = O.get("fitness", {}).get(k, {})
        if k.startswith("AlcesAlces") and "full palm" in fv and "half palm" in fv:
            t = i18n.t("Full palm: 5 stars {full} of the time. Half palm: {half}. "
                       "Above 40% fitness the type is 50/50, picked once when the first rack is built.").format(
                full=_pct_strict(fv['full palm']['at']['1.00']), half=_pct_strict(fv['half palm']['at']['1.00']))
        else: t = _odds_text(t)
        return i18n.t("{animal}: {text}").format(animal=nm(k), text=_odds_text(NOTE_FIX[k]) if k in NOTE_FIX else t)
    notes = [note(k, t) for k, t in sorted(O.get("notes", {}).items(), key=lambda kv: nm(kv[0]))]
    return [{"id": "rules:maxodds", "title": i18n.t("Maxed out: chance of 5 stars"), "subtitle": i18n.t("Oldest age, 100% fitness"),
             "group": i18n.t("Trophies"), "tags": ["5 stars", "odds", "luck", "max", "chance", "random", "dna"], "blocks": [
        {"p": i18n.t("At its oldest age with 100% fitness an animal has every length and thickness maxed. It still isn't always 5 stars, because the bends (and so the spreads) are random. They're rolled again every year.")},
        {"table": {"cols": [i18n.t("Animal"), i18n.t("5 stars"), i18n.t("4 stars"), i18n.t("3 or less"), i18n.t("Score range")], "rows": rows, "w": [22, 10, 10, 10, 9]}},
        {"h": i18n.t("What decides it")},
        {"list": notes},
        {"h": i18n.t("Skull, weight and body-length trophies")},
        {"p": i18n.t("Always the same score at the oldest age and 100% fitness. Stars (score):")},
        {"table": {"cols": [i18n.t("Animal"), i18n.t("Male"), i18n.t("Female")], "rows": frows, "w": [24, 10, 10]}},
        {"h": i18n.t("Tips")},
        {"list": [i18n.t("Missed 5 stars? Its rack is rebuilt next year with new rolls, unless it's at the end of its life."),
                  i18n.t("Whitetail: check the brow tines (G1). No G1 on either side means no 5 stars this year."),
                  i18n.t("Moose: go for full palm bulls."),
                  i18n.t("Pronghorn: about half of maxed bucks make 5 stars."),
                  i18n.t("How much fitness each animal needs: see Fitness for 5 stars.")]}]}] + _fitness_article(names, O)

# ---------------------------------------------------------------- build / cache
# ---------------------------------------------------------------- skills, hunter levels, the shop
SKILL_TREE_NAMES = {}      # filled from the game text: tree number -> name

def _skill_trees(tables):
    """[(tree number, [[skill asset, ...] per layer])] from DA_CharacterSkillTree_*: a category, then the layers, each a
    list of soft paths to the skills (package name, asset name, sub path)."""
    out = []
    for num, (d, names, _pk) in sorted(tables.get("_skill_trees", {}).items()):
        try:
            p = 6; n, = struct.unpack_from("<i", d, p); p += 4
            layers = []
            for _ in range(n):
                p += 2; c, = struct.unpack_from("<i", d, p); p += 4
                row = []
                for _ in range(c):
                    _pkg, _n1, an, _n2, sl = struct.unpack_from("<5i", d, p); p += 20 + max(sl, 0)
                    row.append(names[an])
                layers.append(row)
            out.append((num, layers))
        except (struct.error, IndexError):
            continue
    return out

# what each skill really does, from its effect data (the game's own text is vague or, for 024, wrong)
def _skill_real():
    """skill number -> what it really does, in the app's language"""
    return {
        "001": i18n.t("Animals see you 25% less."), "002": i18n.t("Inside a blind, animals see you a third less."),
        "003": i18n.t("Inside a tripod stand you placed, animals see you a third less. The fixed stands on the map don't count."),
        "004": i18n.t("Luring scents are 50% stronger."), "005": i18n.t("Callers are 50% stronger."), "006": i18n.t("Decoys are 50% stronger."),
        "013": i18n.t("Looking an animal over with binoculars takes a quarter second instead of three quarters."),
        "014": i18n.t("Falls hurt a third as much."), "015": i18n.t("30% more health."),
        "016": i18n.t("Carry 50% more rounds: each ammo stack in the backpack holds 30 instead of 20."),
        "017": i18n.t("With no backpack you get 5 small slots and 3 ammo slots instead of 3 and 2."),
        "018": i18n.t("16 tents per reserve instead of 8. Take the skill off and the tents over 8 are removed."),
        "019": i18n.t("25% less sway."), "020": i18n.t("Breath comes back twice as fast."), "021": i18n.t("Hold your breath 50% longer."),
        "022": i18n.t("Your own shake on the shot is a third smaller."), "023": i18n.t("25% less sway on a shooting stick."),
        "024": i18n.t("Doesn't touch meat damage. What it really does: shots with a suppressor are 25% quieter."),
        "025": i18n.t("You make 25% less noise."), "026": i18n.t("You leave 25% less scent."),
        "028": i18n.t("Crouch 25% faster and 20% quieter."), "029": i18n.t("Crawl 50% faster and 20% quieter."), "030": i18n.t("Walk 25% faster and 20% quieter."),
    }
SKILL_TREE_OFF = {"02"}     # WBP_UiPage_Skills: this tree has mSkillTreeDisabled: not in the game yet

def _skill_articles(tables):
    P = tables.get("ST_CharacterProgression", {}); SK = tables.get("_skills", {})
    icons = _enc_images().get("skills", {})
    levels = {lv: d for lv, d in tables.get("_levels", {}).items() if 1 <= lv <= 200 and d.get("xp", 0) > 0}
    def skill(asset):
        sk = SK.get(asset, {}); n = sk.get("n", "")
        desc = clean(P.get(f"KEY_METAGAME_PROGRESSION_SKILL{n}_DESCRIPTION", "")).replace("{dog} has its", "Your dog has its").replace("{dog}", i18n.t("Your dog"))
        real = _skill_real().get(n)
        return {"id": n, "name": clean(P.get(f"KEY_METAGAME_PROGRESSION_SKILL{n}_NAME", asset)), "desc": real or desc, "game_desc": desc,
                "cost": sk.get("cost") or 0, "icon": icons.get(n, "")}
    trees = _skill_trees(tables)
    if not trees: return []
    arts = []; total_cost = 0; tree_rows = []; tree_blocks = []
    for num, layers in trees:
        tname = clean(P.get(f"KEY_METAGAME_PROGRESSION_CATEGORY{num}_NAME", i18n.t("Tree {n}").format(n=num)))
        tdesc = clean(P.get(f"KEY_METAGAME_PROGRESSION_CATEGORY{num}_DESCRIPTION", ""))
        pyr = [[skill(a) for a in row] for row in layers]
        if str(num).zfill(2) in SKILL_TREE_OFF:          # not in the game yet: left out
            continue
        cost = sum(x["cost"] for row in pyr for x in row); total_cost += cost
        tree_rows.append([tname, str(sum(len(r) for r in pyr)), str(cost)])
        rows = [[x["name"], str(x["cost"]), x["desc"]] for row in pyr for x in row]
        tree_blocks += [{"h": i18n.t("{tree}  ·  {cost} points for all {n}").format(tree=tname, cost=cost, n=len(rows))},
                        {"table": {"cols": [i18n.t("Skill"), i18n.t("Points"), i18n.t("What it does")], "rows": rows, "w": [16, 5, 30]}}]
        arts.append({"id": f"skills:tree{num}", "title": tname, "subtitle": tdesc, "group": i18n.t("Skill trees"),
                     "tags": ["skill", "skills", "skill points", tname] + [r[0] for r in rows], "blocks": [
            {"pyramid": pyr},
            {"p": i18n.t("All {n} skills of this tree cost {cost} skill points together.").format(n=len(rows), cost=cost)}]})
    got = [(lv, d["points"]) for lv, d in sorted(levels.items()) if d["points"]]
    total_pts = sum(x for _lv, x in got)
    by_n = {}
    for lv, x in got: by_n.setdefault(x, []).append(str(lv))
    def pts_line(x, v):
        if len(v) > 1: t = i18n.t("Levels {levels}: {n} points each") if x != 1 else i18n.t("Levels {levels}: {n} point each")
        else: t = i18n.t("Level {levels}: {n} points") if x != 1 else i18n.t("Level {levels}: {n} point")
        return t.format(levels=", ".join(v), n=x)
    pts_txt = [pts_line(x, v) for x, v in sorted(by_n.items())]
    arts.insert(0, {"id": "skills:points", "title": i18n.t("Skill points"), "subtitle": i18n.t("Where they come from and what everything costs"), "group": i18n.t("Skills"),
                    "tags": ["skill", "skills", "skill points", "level", "reset"], "blocks": [
        {"p": i18n.t("You get skill points as you level up. Spend them on skills in the skill trees (Skills in the game's menu). "
              "Each tree is a pyramid: one skill at the top, more below it, and the lower skills cost more.")},
        {"facts": [[i18n.t("Skill points in all"), i18n.t("{n} (by level {level})").format(n=total_pts, level=max(lv for lv, _x in got))],
                   [i18n.t("All skills cost"), i18n.t("{n} points").format(n=total_cost)]]},
        {"h": i18n.t("Points by level")}, {"list": pts_txt},
        {"h": i18n.t("The trees")}, {"table": {"cols": [i18n.t("Tree"), i18n.t("Skills"), i18n.t("Points for all of them")], "rows": tree_rows, "links": "skills"}},
        {"note": i18n.t("You can't have every skill: {points} points against {cost}. The game lets you reset your skills and spend the points again.").format(points=total_pts, cost=total_cost)},
        *tree_blocks]})
    # hunter levels: XP, skill points and what each level unlocks in the shop
    names = _item_names(tables)
    lrows = []
    for lv, d in sorted(levels.items()):
        un = sorted({names.get(k) for g in d["unlocks"] for k in tables.get("_unlock_keys", {}).get(_canon(g), [_canon(g)]) if names.get(k)})
        cash = sum(tables.get("_money", {}).get(x, 0) for x in d.get("money", []))
        lrows.append([str(lv), f"{d['xp']:,}", f"${cash:,}" if cash else "-", str(d["points"] or "-"), ", ".join(un) or "-"])
    arts.insert(1, {"id": "skills:levels", "title": i18n.t("Hunter levels"), "subtitle": i18n.t("Levels 2-{n}: XP, skill points and shop unlocks").format(n=max(levels)), "group": i18n.t("Skills"),
                 "tags": ["level", "xp", "unlock", "shop", "rank", "money", "reward"], "blocks": [
        {"p": i18n.t("XP is the total you need to reach the level. Money is paid to you when you reach the level. Each level adds new items to the shop; they still have to be bought.")},
        {"table": {"cols": [i18n.t("Level"), i18n.t("XP"), i18n.t("Money"), i18n.t("Skill points"), i18n.t("New in the shop")], "rows": lrows, "w": [5, 7, 6, 6, 40]}}]})
    return arts

def _item_names(tables):
    """{canon shop id: item name} for every item with a shop entry (gear text + ammunition)."""
    out = {}
    shop = _shop_info(tables)
    meta = tables.get("_meta_names")
    for tab, _t in GEAR:
        T = tables.get(tab, {})
        for k in sorted(T):
            st = k[:-5]
            if not k.endswith("_NAME") or not T.get(st + "_DESCRIPTION") or _pulled(st) or "_CALL0" in st \
                    or "_PROPERTIES" in st or "_TYPES" in st: continue
            if tab not in ("ST_Vehicles", "ST_Ammunition", "ST_Weapons") and meta and k not in meta: continue
            info = _match_img(st, shop)
            if info is None: continue
            kind = "Gear" if tab in ("ST_Ambushing", "ST_Mounting", "ST_Backpacks", "ST_Tents", "ST_Vehicles") else _t
            if tab == "ST_Attachments":
                kind = "Scopes and sights" if re.search(r"SCOPE|SIGHT|COLLIMATOR", st) else "Attachments"
            elif tab == "ST_Weapons":
                kind = "Bows and crossbows" if re.search(r"_BOW|CROSSBOW", st) else "Shotguns" if "SHOTGUN" in st else "Rifles"
            for c, v in shop.items():
                if v is info and c not in out: out[c] = clean(T[k]); tables.setdefault("_item_kind", {})[c] = kind
    # the name the item's own data gives it wins over a text-file match (RifleBolt27 is the B14 HMR, not the
    # "B14² Crest Carbon" left in the text file)
    for mid, key in tables.get("_meta_key", {}).items():
        info = shop.get(_canon(mid))
        for tab, _t in GEAR:
            if info is not None and tables.get(tab, {}).get(key):
                for c, v in shop.items():
                    if v is info and c in out: out[c] = clean(tables[tab][key])
    TA = tables.get("ST_Ammunition", {})
    for mk, nk in tables.get("_ammo_keys", {}).items():
        am = tables.get("_ammo_meta", {}).get(mk)
        n = clean(TA.get(nk, ""))
        if n:
            out[_canon(mk)] = f"{n} ({caliber_name(am['caliber'], tables)})" if am else n
            tables.setdefault("_item_kind", {})[_canon(mk)] = "Ammunition"
    return out

STARTING_GEAR = {"Primacy Classic Hunter MK II", "ZOOMXD Vision Professional 1.5-6x42", "Overgaard 8x", "Stone Glacier Avail 2200"}
STARTING_GEAR_IDS = {"RIFLEBOLT02", "SCOPE12", "BINOCULAR01", "BACKPACKMEDIUM01"}     # the same, by shop id (the names are in the app's language)

def _shop_article(tables):
    """Every item the shop sells: price and the hunter level it unlocks at (free ones too: the starting gear and its ammo)."""
    shop = _shop_info(tables); names = _item_names(tables); wcal = tables.get("_weapon_cal", {})
    rows = []; seen = set()
    for c, v in shop.items():
        if v.get("price") is None or id(v) in seen: continue
        c = next((k for k, w in shop.items() if w is v and k in names), None)
        if c is None: continue
        seen.add(id(v))
        kind = tables.get("_item_kind", {}).get(c, "Other")
        if not v["price"] and kind != "Ammunition" and names[c] not in STARTING_GEAR and c not in STARTING_GEAR_IDS: continue    # other free ones come with packs
        nm = names[c]; cal = ""
        if kind in ("Rifles", "Shotguns", "Bows and crossbows"): cal = wcal.get(nm, "")
        elif kind == "Ammunition":
            m = re.match(r"(.*) \((.+)\)$", nm)
            if m: nm, cal = m.groups()
        rows.append([nm, cal, kind, f"${v['price']:,}" if v["price"] else "free", str(v["level"]) if v.get("level") else "start"])
    if not rows: return []
    rows.sort(key=lambda r: (0 if r[4] == "start" else int(r[4]), r[3] != "free", r[0]))
    # in the app's language once sorted (the app sorts a "free" / "start" cell as 0)
    rows = [[n, c, _gear_title(k), i18n.t("free") if p == "free" else p, i18n.t("start") if lv == "start" else lv] for n, c, k, p, lv in rows]
    return [{"id": "gear:shop", "title": i18n.t("Shop: prices and levels"), "subtitle": i18n.t("{n} items").format(n=len(rows)), "group": i18n.t("Gear"),
             "tags": ["price", "cost", "shop", "level", "unlock", "buy"], "blocks": [
        {"p": i18n.t("What everything costs in the shop and the hunter level that unlocks it. 'start' = in the shop from the start. 'free' = the gear you start with, and ammo that costs nothing. Click a column title to sort by it.")},
        {"table": {"cols": [i18n.t("Item"), i18n.t("Caliber"), i18n.t("Kind"), i18n.t("Price"), i18n.t("Level")], "rows": rows, "w": [26, 14, 12, 7, 5], "filter": 2}}]}]

def _rares_article(names):
    """Every animal's rare coats on one page (the same odds as each animal's own page)."""
    odds = _fur_odds()
    if not odds: return []
    order = {"Rare": 0, "Uncommon": 0, "VeryRare": 1}
    rows = []; none = []
    for sub, title in sorted(names.items(), key=lambda kv: kv[1]):
        per_map = odds.get(sub)
        if not per_map:
            none.append(title); continue
        d = per_map[next((m for m in ("Map01", "Map02") if m in per_map), next(iter(per_map)))]
        for cname, c in sorted(d["coats"].items(), key=lambda kv: (order.get(kv[1]["tier"], 2), -kv[1]["M"], kv[0])):
            ch = _one_in(c["M"]) if abs(c["M"] - c["F"]) <= 1e-12 else i18n.t("males {m}, females {f}").format(m=_one_in(c['M']), f=_one_in(c['F']))
            rows.append([title, _coat_text(cname), _coat_text(TIER_NAMES.get(c["tier"], c["tier"])), ch])
    blocks = [{"p": i18n.t("Every rare coat in the game, by animal. The chance is per animal. Open an animal (Animals tab) for more.")},
              {"table": {"cols": [i18n.t("Animal"), i18n.t("Coat"), i18n.t("Kind"), i18n.t("Chance")], "rows": rows, "w": [16, 14, 8, 18], "links": "animals"}}]
    if none: blocks += [{"h": i18n.t("No rare coats")}, {"p": ", ".join(none) + "."}]
    blocks.append({"note": i18n.t("The game also hands out a rare coat for sure after a long dry spell, which is counted in.")})
    return [{"id": "trophies:rares", "title": i18n.t("Rare coats: every animal"), "subtitle": i18n.t("{n} rare coats").format(n=len(rows)), "group": i18n.t("Trophies"),
             "tags": ["rare", "rares", "coat", "fur", "albino", "melanistic", "leucistic", "piebald", "odds"], "blocks": blocks}]

def _drop_unfired_ammo(tables):
    """Leave out loads no weapon in the game fires (the shop never sells them)."""
    fired = set()
    for data in tables.get("_weapon_meta", {}).values():
        try: fired.update(_weapon_info(data)[0])
        except Exception: pass
    if not fired: return
    AM = tables.get("_ammo_meta", {})
    gone = {mk for mk, am in AM.items() if not any(am["caliber"] == c or am["caliber"].startswith(c + ".") for c in fired)}
    for mk in gone:
        AM.pop(mk, None); tables.get("_ammo_keys", {}).pop(mk, None)
        tables.get("_ammo_sold", set()).discard(mk.lower())

def _disclaimers():
    """(short, long) disclaimer, in the app's language"""
    return (i18n.t("Unofficial fan tool. Not made by, affiliated with or endorsed by THQ Nordic or Nine Rocks Games. "
                   "All information here is unofficial and may be wrong or out of date."),
            i18n.t("WOTH2 Toybox is an unofficial fan-made tool. It is not made by, affiliated with, sponsored by or endorsed by THQ Nordic, "
                   "Nine Rocks Games (NRG) or anyone involved with Way of the Hunter 2. Way of the Hunter is a trademark of its owners. "
                   "All information in the Toybox is unofficial and speculative: it may be wrong, incomplete "
                   "or out of date after a game update. Use it at your own risk and always back up your save."))

SHOW_ANIMAL_PICTURES = False          # off until the renders look like the game (2026-10-12: raw bind-pose renders pulled)

def build(paks_dir):
    import woth2_paks as paks
    tables, subs, guides, eco = _scan(paks_dir)
    _game_translation(paks_dir, tables)
    _drop_unfired_ammo(tables)
    eco_by_sub = _ecosystems(eco)
    A = tables.get("ST_Animals", {})
    sub_names = {s: clean(A.get("KEY_ANIMALS_SUBSPECIES_" + s.upper() + "_NAME", s)) for s in set(subs) | set(eco_by_sub)}
    animals = _animal_articles(tables, subs, eco_by_sub, paks_dir)
    apics = {} if not SHOW_ANIMAL_PICTURES else _enc_images().get("animals", {})   # the game's models, rendered (tools/animal_pictures.py)
    for a_ in animals:
        row = apics.get(a_["id"].split(":", 1)[1])
        if row: a_["blocks"].insert(0, {"imgs": [{"img": f, "caption": c, "big": True} for f, c in row]})
    sub_names.update({a["id"].split(":", 1)[1]: a["title"] for a in animals})
    cats = [
        {"id": "trophies", "title": i18n.t("TROPHIES"), "blurb": i18n.t("How scores, stars and aging work."),
         "articles": [a for a in _rules_articles() if a["group"] == i18n.t("Trophies")] + _odds_article({a["id"].split(":", 1)[1]: a["title"] for a in animals})
                     + _rares_article({a["id"].split(":", 1)[1]: a["title"] for a in animals})},
        {"id": "herds", "title": i18n.t("HERDS"), "blurb": i18n.t("Herd fitness, herd size, culling and habitat enhancements."),
         "articles": [a for a in _rules_articles() if a["group"] == i18n.t("Herd management")] + _herd_size_article(paks_dir, {a["id"].split(":", 1)[1]: a["title"] for a in animals})
                     + _habitat_article(tables, paks_dir, {a["id"].split(":", 1)[1]: a["title"] for a in animals})},
        {"id": "animals", "title": i18n.t("ANIMALS"), "blurb": i18n.t("Every animal you can hunt."),
         "articles": sorted(animals, key=lambda a: a["title"])},
        {"id": "maps", "title": i18n.t("MAPS"), "blurb": i18n.t("How the maps work, multiplayer, and each map's lands."), "articles": _how_maps_articles() + _map_articles(tables, eco_by_sub, sub_names)},
        {"id": "guides", "title": i18n.t("GUIDES"), "blurb": i18n.t("Hunting guides: senses, shot placement, money and XP, the head lamp, selling gear and the game updates."), "articles": _update_articles() + _hunter_guides(tables, sub_names, {a["id"].split(":", 1)[1] for a in animals}) + _guide_articles(tables, guides)},
        {"id": "gear", "title": i18n.t("GEAR"), "blurb": i18n.t("Weapons, ammunition, ballistics and equipment."), "articles": _gear_cat(tables, paks_dir, {x["id"].split(":", 1)[1]: x["title"] for x in animals})},
        {"id": "skills", "title": i18n.t("SKILLS"), "blurb": i18n.t("The skill trees, skill points and what each hunter level unlocks."), "articles": _skill_articles(tables)},
        {"id": "people", "title": i18n.t("PEOPLE"), "blurb": i18n.t("The people you meet."), "articles": _people_articles(tables)},
    ]
    # every load by its game id (the hunting log stores the id): the weekly challenges name an exact load and check it
    AM = tables.get("_ammo_meta", {}); keys = tables.get("_ammo_keys", {}); TA = tables.get("ST_Ammunition", {})
    ammo = [{"id": mk, "name": clean(TA.get(keys[mk], "")) if keys.get(mk) else mk, "caliber": caliber_name(am["caliber"], tables), "tiers": am["tiers"]}
            for mk, am in sorted(AM.items())]
    # each animal's four score lines (2-5 stars) per sex: the Stats page turns a score you type into stars
    lines = {sub: {"name": tables.get("_plain_titles", {}).get(sub, sub_names.get(sub, sub)), **v} for sub, v in tables.get("_score_lines", {}).items()}
    cats = [c for c in cats if c["articles"] and not c.get("hidden")]
    _mark_spoilers(cats)
    disc_short, disc = _disclaimers()
    for c in cats:
        for a_ in c["articles"]:
            a_["blocks"] = [{"note": disc_short}] + list(a_["blocks"])
    return {"version": VERSION, "game": paks.game_build(paks_dir), "preview": preview_tag(), "lang": _lang_tag(), "disclaimer": disc, "ammo": ammo, "score_lines": lines,
            "rare_coats": _rare_coat_list(), "categories": cats}

# How the game works under the hood (numbers the game never shows): the app covers these until clicked.
SPOILER_CATS = {"trophies", "herds"}
SPOILER_ARTICLES = {"guide:headlamp", "guide:selling", "guide:senses", "guide:wounds", "guide:payout", "guide:facts", "guide:tips",
                    "gear:weapons", "gear:ballistics", "gear:energy", "gear:energy_rifles", "gear:energy_shotguns",
                    "gear:energy_bows", "gear:energy_crossbows"}
SPOILER_HEADINGS = {"Best place", "Trophy", "Rare coats", "Herd management", "Senses (Normal)"}          # sections of each animal

def _mark_spoilers(cats):
    heads = {i18n.t(h) for h in SPOILER_HEADINGS}           # the headings as the pages have them, in the app's language
    for c in cats:
        for a in c["articles"]:
            if c["id"] in SPOILER_CATS or a["id"] in SPOILER_ARTICLES:
                a["spoiler"] = True
            elif c["id"] == "animals":
                for b in a["blocks"]:
                    if b.get("h") in heads or str(b.get("h", "")).startswith("Senses"):
                        b["spoiler"] = True

def _gear_cat(tables, paks_dir, sub_names):
    import ballistics_range
    w = _weapon_articles(tables); b = _ballistics_articles(tables)
    try:
        e = _energy_articles(tables, ballistics_range.hit_energy_maps(paks_dir), sub_names, w)
    except Exception as ex:
        print(f"warning: energy at range: {ex!r}", file=sys.stderr); e = []
    return w + _shop_article(tables) + b + e + _gear_articles(tables)

def _cache_path():
    import mapdata
    m = preview_tag()                                # each preview mode keeps its own copy: a staged web build never clobbers the app's
    l = lang()                                       # and each language its own
    return os.path.join(os.path.dirname(mapdata.CACHE_ROOT), "encyclopedia" + (f"_preview_{m}" if m else "") + (f"_{l}" if l else "") + ".json")

def load(paks_dir=None, force=False):
    """Cached encyclopedia; rebuilt when the game build changes. Falls back to the copy shipped with the app."""
    import woth2_paks as paks
    pd = paks_dir or paks.find_paks_dir()
    p = _cache_path()
    game = paks.game_build(pd) if pd else None
    if not force:
        try:
            d = json.load(open(p, encoding="utf-8"))
            if d.get("version") == VERSION and (game is None or d.get("game") == game) and d.get("preview") == preview_tag() and d.get("lang", "") == _lang_tag():
                return d
        except (OSError, ValueError):
            pass
        try:                                         # the copy shipped with the app, made from this same game build: use it
            shipped = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "encyclopedia.json"), encoding="utf-8"))
            if shipped.get("version") == VERSION and game is not None and shipped.get("game") == game and not preview_on() and not lang():
                return shipped
        except (OSError, ValueError):
            pass
    if pd:
        try:
            d = build(pd)
        except Exception as e:                       # a game patch moved something: keep working from an older copy
            print(f"warning: encyclopedia rebuild failed: {e}", file=sys.stderr)
            try:
                return json.load(open(p, encoding="utf-8"))
            except (OSError, ValueError):
                d = None
        if d is not None:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p + ".tmp", "w", encoding="utf-8") as f:
                f.write(json.dumps(d, ensure_ascii=False))
            os.replace(p + ".tmp", p)
            return d
    shipped = os.path.join(os.path.dirname(os.path.abspath(__file__)), "encyclopedia.json")
    return json.load(open(shipped, encoding="utf-8"))

if __name__ == "__main__":
    import sys
    if "--ship" in sys.argv:
        _NO_PREVIEW = True                           # what ships never has the preview animals
        os.environ.pop("WOTH2_LANG", None)           # and is the English one
    d = load(force="--force" in sys.argv)
    if "--ship" in sys.argv:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "encyclopedia.json"), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False)
    for c in d["categories"]:
        print(c["title"], len(c["articles"]), [a["title"] for a in c["articles"]][:8])
