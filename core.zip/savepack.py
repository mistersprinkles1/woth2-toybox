"""Settings > "Help make trophy scores better": a copy of the save for the Toybox cloud (/v1/saves), so trophy
scores, herds, fitness and the rest can be checked against many players' games. Every hunter name in it (the
player's and any co-op hunter's: the names the hunting logs give as who shot what) is written over with x's of the
same length, so the copy still opens in our tools and nobody's name leaves the PC. Nothing else in a save is about
the player (no Steam id, account or folder names: checked on a real save 2026-10-28). The copy is gzip'd.

    pack(save_path) -> {"b64": gzip'd save, base64, "bytes": its size, "names": how many names were taken out}
                       or {"error"} (no hunter name found: nothing to send, so nothing is sent)"""
import base64, gzip, re, struct
import nrgs

# the hunting logs: FString map name ("Map01" / "Map02" / "Hub"...) | u32 0 | FString ownerId (the hunter's name)
_OWNER = re.compile(rb"(?:\x06\x00\x00\x00Map\d\d\x00|\x04\x00\x00\x00Hub\x00)\x00\x00\x00\x00")

def _fstring(d, p):
    """(bytes as stored incl. length and end, text) of the UE FString at p, or None"""
    if p + 4 > len(d): return None
    n, = struct.unpack_from("<i", d, p)
    if 1 < n <= 65:                                       # 1-byte letters, ends in \0
        raw = d[p + 4:p + 4 + n]
        if raw[-1:] == b"\0" and b"\0" not in raw[:-1]: return d[p:p + 4 + n], raw[:-1].decode("latin-1")
    elif -65 <= n < -1:                                   # UTF-16, ends in \0\0
        raw = d[p + 4:p + 4 - 2 * n]
        if raw[-2:] == b"\0\0": return d[p:p + 4 - 2 * n], raw[:-2].decode("utf-16-le", "replace")
    return None

def hunter_names(sf):
    """{stored FString bytes} of every hunter name the save's hunting logs name"""
    out = set()
    for e in sf.entries:
        if e[2] != "v2": continue
        d = e[3].data
        for m in _OWNER.finditer(d):
            f = _fstring(d, m.end())
            if f and f[1].strip(): out.add(f[0])
    return out

def _blank(stored):
    """the same FString with x's for letters (same length, so nothing after it moves)"""
    n, = struct.unpack_from("<i", stored, 0)
    if n > 0: return stored[:4] + b"x" * (n - 1) + b"\0"
    return stored[:4] + "x".encode("utf-16-le") * (-n - 1) + b"\0\0"

def anonymize(sf):
    """takes every hunter name out of sf (in place); how many were taken out, or 0 when none was found"""
    names = hunter_names(sf)
    if not names: return 0
    n = 0
    for e in sf.entries:
        if e[2] != "v2": continue
        part = e[3]
        d = part.data
        for s in names:
            c = d.count(s)
            if c: d = d.replace(s, _blank(s)); n += c
        part.data = d
    for s in names:                                       # never send one that is still in it
        bare = s[4:-1] if struct.unpack_from("<i", s, 0)[0] > 0 else s[4:-2]
        if any(e[2] == "v2" and bare in e[3].data for e in sf.entries):
            raise ValueError("a hunter name is still in the copy")
    return n

def pack(path):
    sf = nrgs.SaveFile(path)
    n = anonymize(sf)
    if not n: return {"error": "no hunter name found"}
    z = gzip.compress(sf.build(), 6)
    return {"b64": base64.b64encode(z).decode("ascii"), "bytes": len(z), "names": n}
