"""Decode the ACL 2.1 (compressed_tracks_version 10) transform clips the game's trophy additive poses use.
Only single-frame clips (every sub-track default or constant) are supported - all AP_* trophy poses are that.
-> {"tracks": [bone index...], "rot": {track: (x,y,z,w)}, "trans": {track: (x,y,z)}, "scale": {track: (x,y,z)}}"""
import math, struct

TAG = 0xAC11AC11

def find(blob):
    i = blob.find(struct.pack("<I", TAG))
    if i < 8:
        raise ValueError("no ACL buffer")
    return i - 8                                   # raw_buffer_header (size, hash) precedes the tag

def decode(blob, start=None):
    p = find(blob) if start is None else start
    size, _h = struct.unpack_from("<II", blob, p)
    tag, ver, alg, ttype, ntracks, nsamples, rate, misc = struct.unpack_from("<IHBBIIfI", blob, p + 8)
    if tag != TAG or ver != 10 or ttype != 12:
        raise ValueError(f"unsupported ACL clip (version {ver}, type {ttype})")
    has_scale = misc & 1
    default_scale = 1.0 if (misc >> 1) & 1 else 0.0
    rot_fmt = (misc >> 4) & 15
    h = p + 32                                     # transform_tracks_header
    (nseg, n_anim_var, n_anim_r, n_anim_t, n_anim_s, n_cr, n_ct, n_cs,
     db_off, seg_off, types_off, const_off, range_off) = struct.unpack_from("<13I", blob, h)
    if n_anim_r or n_anim_t or n_anim_s:
        raise ValueError("animated tracks not supported")
    kinds = 3 if has_scale else 2
    words_per = (ntracks + 15) // 16
    types = []
    for k in range(kinds):
        ws = struct.unpack_from("<%dI" % words_per, blob, h + types_off + 4 * words_per * k)
        types.append([(ws[i // 16] >> ((15 - i % 16) * 2)) & 3 for i in range(ntracks)])
    q = h + const_off
    out = {"rot": {}, "trans": {}, "scale": {}, "default_scale": default_scale}
    rots = [i for i in range(ntracks) if types[0][i] == 1]
    drop_w = rot_fmt in (1, 2, 3)                  # quatf_drop_w_full / _variable variants store x, y, z
    if drop_w:
        for g in range(0, len(rots), 4):
            grp = rots[g:g + 4]; n = len(grp)
            xs = struct.unpack_from("<%df" % n, blob, q); q += 4 * n
            ys = struct.unpack_from("<%df" % n, blob, q); q += 4 * n
            zs = struct.unpack_from("<%df" % n, blob, q); q += 4 * n
            for j, t in enumerate(grp):
                x, y, z = xs[j], ys[j], zs[j]
                out["rot"][t] = (x, y, z, math.sqrt(max(0.0, 1 - x * x - y * y - z * z)))
    else:
        for t in rots:
            out["rot"][t] = struct.unpack_from("<4f", blob, q); q += 16
    for t in range(ntracks):
        if types[1][t] == 1:
            out["trans"][t] = struct.unpack_from("<3f", blob, q); q += 12
    if has_scale:
        for t in range(ntracks):
            if types[2][t] == 1:
                out["scale"][t] = struct.unpack_from("<3f", blob, q); q += 12
    if (len(rots), sum(1 for x in types[1] if x == 1)) != (n_cr, n_ct):
        raise ValueError("constant sample count mismatch")
    out["n"] = ntracks
    return out

def decode_bitwise(dat):
    """UE AnimCompress_BitwiseCompressOnly single-key clips -> {"rot", "trans", "scale", "n", "bones"}.
    Layout (before the codec name FString): 05 00 01 00, i32 ?, i32 size, i32 n tracks, n x i32 track->bone,
    i32 ?, i32 stream bytes, i32 ?, n x (trans off, trans keys, rot off, rot keys), [n x (scale off, scale keys)],
    then the byte stream (ends right before the codec name); single keys are 3 floats (rotations drop W)."""
    k = dat.find(b"AnimCompress_BitwiseCompressOnly")
    if k < 0:
        raise ValueError("not a bitwise clip")
    end = k - 4
    j = dat.rfind(b"\x05\x00\x01\x00", 0, k)
    if j < 0:
        raise ValueError("bitwise header not found")
    _a, _size, n = struct.unpack_from("<3i", dat, j + 2)
    if not 0 < n < 2000:
        raise ValueError("bad track count")
    q = j + 14
    bones = list(struct.unpack_from("<%di" % n, dat, q)); q += 4 * n
    q += 12
    tro = struct.unpack_from("<%di" % (4 * n), dat, q); q += 16 * n
    has_scale = q + 8 * n <= end
    sco = struct.unpack_from("<%di" % (2 * n), dat, q) if has_scale else ()
    offs = [o for o in list(tro[0::2]) + list(sco[0::2]) if o >= 0]
    L = max(offs) + 12
    stream = end - L
    f3 = lambda o: struct.unpack_from("<3f", dat, stream + o)
    out = {"rot": {}, "trans": {}, "scale": {}, "n": n, "bones": bones}
    for t in range(n):
        b = bones[t]
        if tro[4 * t] >= 0 and tro[4 * t + 1] > 0:
            v = f3(tro[4 * t])
            if any(abs(x) > 1e-6 for x in v): out["trans"][b] = v
        if tro[4 * t + 2] >= 0 and tro[4 * t + 3] > 0:
            x, y, z = f3(tro[4 * t + 2])
            if any(abs(c) > 1e-6 for c in (x, y, z)):
                out["rot"][b] = (x, y, z, math.sqrt(max(0.0, 1 - x * x - y * y - z * z)))
        if sco and sco[2 * t] >= 0 and sco[2 * t + 1] > 0:
            v = f3(sco[2 * t])
            if any(abs(x) > 1e-6 for x in v): out["scale"][b] = v
    return out
