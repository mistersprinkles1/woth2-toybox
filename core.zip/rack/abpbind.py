"""Which ABP property drives which blend-space layer, read from the compiled anim blueprint (UE5 folded node data):
the CDO's property-access copy records map each BS_* property to a mutable slot __FloatProperty_k, and slot k is
the X input of the k-th blend-space player node (node order = order of the blend-space references in the
anim-node constant data)."""
import struct, re
import zenpkg

def _fnames(z, d):
    nm = [z.name(i) for i in range(len(z.names))]
    out = []
    for o in range(0, len(d) - 8):
        i, n = struct.unpack_from("<II", d, o)
        if i < len(nm) and n < 256:
            out.append((o, nm[i], n))
    return out

def copy_records(z, cdo):
    """[(source property, slot k)]. A record: prop @o, ..., __FloatProperty_src, ..., __FloatProperty_k (dest, the
    last float slot inside the record, which is ~100 bytes long). FName number n -> slot n."""
    fr = _fnames(z, cdo)
    props = [(o, s) for o, s, n in fr if s.startswith("BS_") and n == 0]
    out = []; seen = set()
    for j, (o, s) in enumerate(props):
        if s in seen: continue                           # each record names its property twice
        end = min(o + 100, next((o2 for o2, s2 in props[j + 1:] if s2 != s), o + 100))
        fl = [n for o2, s2, n in fr if s2 == "__FloatProperty" and o < o2 < end]
        if fl:
            out.append((s, fl[-1])); seen.add(s)
    return out

def node_blendspaces(z, cdo):
    """blend-space asset of every blend-space player node, in node order (the CDO holds one node struct each;
    two nodes can share an asset)"""
    seen = []
    for o in range(0, len(cdo) - 4):
        v, = struct.unpack_from("<i", cdo, o)
        if v < 0 and -v - 1 < len(z.imports):
            sp = zenpkg.split_import(z.imports[-v - 1])
            if not sp: continue
            nums = getattr(z, "package_numbers", [0] * len(z.package_names))
            n = z.package_names[sp[0]][0].rsplit("/", 1)[-1] + (f"_{nums[sp[0]] - 1}" if nums[sp[0]] else "")   # FName number
            if n.startswith("BS_"): seen.append((o, n))
            elif n.startswith("AP_") and seen: break
    out = []
    for o, n in seen:                                   # one ref per node struct (~85 bytes apart)
        if out and o - out[-1][0] < 40 and out[-1][1] == n: continue
        out.append((o, n))
    return [n for o, n in out]

def binding(z, cdo):
    """-> [(property, blend-space asset)] in node order. X-input records sorted by slot follow the node order;
    *_alpha records weight the layer of the same property."""
    nodes = node_blendspaces(z, cdo)
    recs = [r for r in copy_records(z, cdo) if not r[0].endswith("_alpha")]
    recs.sort(key=lambda r: r[1])
    if len(nodes) == len(recs) + 1:                     # one stray asset reference in the CDO: drop the one that
        def score(ns):                                  # leaves the most property == asset_Var pairs
            return sum(1 for (p, k), n in zip(recs, ns) if p == n + "_Var")
        nodes = max((nodes[:i] + nodes[i + 1:] for i in range(len(nodes))), key=score)
    if len(recs) != len(nodes):
        return None
    return [(p, nodes[i]) for i, (p, k) in enumerate(recs)]
