"""1-D blend spaces of the trophy ABPs: -> [(anim name, sample value)]."""
import struct, zenpkg

def samples(data):
    z = zenpkg.ZenPackage(data); dat = z.export_data[0]
    anims = {}
    for k, v in enumerate(z.imports):
        s = zenpkg.split_import(v)
        if s:
            n = z.package_numbers[s[0]] if hasattr(z, "package_numbers") else 0
            anims[-k - 1] = z.package_names[s[0]][0].rsplit("/", 1)[-1] + (f"_{n - 1}" if n else "")
    out = []
    p = 0
    while p < len(dat) - 7:
        if dat[p] == 0x80 and dat[p + 1] == 0x0B:            # sample struct header: 5 props, zero mask follows
            mask = dat[p + 2]; q = p + 3
            anim = None; val = 0.0
            try:
                if not mask & 1:
                    a, = struct.unpack_from("<i", dat, q); q += 4; anim = anims.get(a)
                if not mask & 2:
                    val, = struct.unpack_from("<d", dat, q); q += 24
            except struct.error:
                break
            if anim and anim.startswith("AP_"):
                out.append((anim, val)); p = q; continue
        p += 1
    return out
