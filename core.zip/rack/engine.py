"""Offline trophy measuring: rebuilds a grown trophy (antlers / horns / tusks) from its DNA the way the game does and
measures it with the game's own measurement settings.

Pipeline (all verified against the game's harvest records, see rack/README):
  trophy mesh ref skeleton (SK_*Trophy*) -> base pose (AP_*BASE*, full pose; default tracks = ref pose)
  -> every blend space of the trophy ABP as an additive layer (value from the DNA, missing = ABP default 50):
     translations add locally, rotations are mesh-space offsets (AAT_RotationOffsetMeshSpace), scale deltas
     (Slim/Thick) multiply  -> component-space bone positions.
  World space for left/right measurements: body skeleton socket S_Trophy<..><Left|Right> on the head bone,
  times the animal's body scale (lerp of the body config scale range by growth).
Measurements (BP_TrophyMeasurement_*): Base_Length, MultiLength (GetTrophyMultipleBoneLength), GreatestSpread
(GetLongestDistanceBetweenBones), DistanceSockets, Thickness (bone scale Z -> range -> range).
"""
import math, os, re, struct, sys, functools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import acl, skel, bspace, pose as P
import zenpkg, woth2_paks as paks

# ---------------------------------------------------------------- game files
class Files:
    def __init__(self, paks_dir=None):
        self.pd = paks_dir or paks.find_paks_dir()
        self.index = {}
        for t in paks.all_tocs(self.pd):
            for p, i in t.files.items():
                if p.endswith(".uasset") and "/Content/" in p:
                    key = ("/Game/" + p.split("/Content/", 1)[1][:-7]).lower()
                    self.index.setdefault(key, (t, i))
        self.by_base = {}
        for k in self.index:
            self.by_base.setdefault(k.rsplit("/", 1)[-1], k)

    @functools.lru_cache(maxsize=4096)
    def pkg(self, path):
        path = path.split(".")[0].lower()
        if path not in self.index:
            path = self.by_base.get(path.rsplit("/", 1)[-1], path)
        t, i = self.index[path]
        return zenpkg.ZenPackage(t.read(i))

    def path_of(self, base):
        return self.by_base.get(base.lower())

def names(z):
    return [z.name(k) for k in range(len(z.names))]

def cdo(z):
    for e, d in zip(z.exports, z.export_data):
        if z.name(e[2] & 0xFFFFFFFF).startswith("Default__"):
            return d
    return z.export_data[0]

def refs(z):
    """Hard imports + soft object paths (names starting with /Game/)."""
    return imports_pkgs(z) + [n for n in names(z) if n.startswith("/Game/") and "." not in n.rsplit("/", 1)[-1]]

def imports_pkgs(z):
    nums = getattr(z, "package_numbers", [0] * len(z.package_names))
    return [x[0] + (f"_{n - 1}" if n else "") for x, n in zip(z.package_names, nums)]

# ---------------------------------------------------------------- unversioned helpers
def fname_arrays(z, dat, prefix=("CATRig",)):
    nm = names(z); out = []; p = 0
    while p < len(dat) - 4:
        n, = struct.unpack_from("<i", dat, p)
        if 1 <= n <= 80 and p + 4 + 8 * n <= len(dat):
            ids = [struct.unpack_from("<I", dat, p + 4 + 8 * k)[0] for k in range(n)]
            if all(i < len(nm) and not nm[i].startswith(("/", "Default__", "Trophies.", "BP_", "Animals.")) and nm[i] not in ("None", "Engine", "BlueprintType") for i in ids):
                out.append([nm[i] for i in ids]); p += 4 + 8 * n; continue
        p += 1
    return out

def tag_refs(z, dat):
    """FGameplayTag values (00 03 <name>) referencing Trophies.* tags, in order."""
    nm = names(z); out = []
    for m in re.finditer(rb"\x00\x03(....)\x00\x00\x00\x00", dat, re.S):
        i, = struct.unpack("<I", m.group(1))
        if i < len(nm) and nm[i].startswith("Trophies.") and "MeasurementTypes" not in nm[i]:
            out.append(nm[i])
    return out

def single_names(z, dat, prefix=None):
    nm = names(z); out = []
    bad = ("/", "Default__", "Trophies.", "BP_", "Animals.", "None", "Engine", "BlueprintType")
    for p in range(0, len(dat) - 7, 1):
        i, num = struct.unpack_from("<II", dat, p)
        if num == 0 and 0 < i < len(nm) and not nm[i].startswith(bad) and (dat[p - 2:p] == b"\x00\x03" or p < 2 or True) and re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", nm[i]):
            out.append(nm[i])
    return out

def mesh_maps(z, dat):
    """TMap<mesh, S_BoneNameArrayHolder> values in a CDO: [{mesh basename: [bone names]}] in order."""
    nm = names(z); nums = getattr(z, "package_numbers", [0] * len(z.package_names))
    def imp(v):
        if v >= 0 or -v - 1 >= len(z.imports): return None
        s_ = zenpkg.split_import(z.imports[-v - 1])
        return z.package_names[s_[0]][0].rsplit("/", 1)[-1] if s_ else None
    out = []; p = 0
    while p < len(dat) - 16:
        zero, cnt = struct.unpack_from("<Ii", dat, p)
        if zero == 0 and 1 <= cnt <= 16:
            q = p + 8; m = {}; ok = True
            for _ in range(cnt):
                if q + 10 > len(dat): ok = False; break
                key, = struct.unpack_from("<i", dat, q)
                mesh = imp(key)
                if not mesh or dat[q + 4:q + 6] != b"\x00\x03": ok = False; break
                n, = struct.unpack_from("<i", dat, q + 6)
                if not 0 <= n <= 200: ok = False; break
                bones = []
                for k in range(n):
                    i, num = struct.unpack_from("<II", dat, q + 10 + 8 * k)
                    if i >= len(nm): ok = False; break
                    bones.append(nm[i] + (f"_{num - 1}" if num else ""))
                if not ok: break
                m[mesh] = bones; q += 10 + 8 * n
            if ok and m:
                out.append(m); p = q; continue
        p += 1
    return out

# ---------------------------------------------------------------- measurement definitions
KINDS = ("Base_Length", "MultiLength", "GreatestSpread", "DistanceSockets", "Thickness", "TipToTipLength",
         "Shovel_Length", "Base_Shovel_Width", "ShovelGreatestSpread", "NumberOfPoints", "Base_Shovel")

class Measurement:
    def __init__(self, files, path):
        self.path = path; self.name = path.rsplit("/", 1)[-1]
        chain = []; z = files.pkg(path)
        cur = z
        for _ in range(8):
            par = [p for p in imports_pkgs(cur) if "/Trophy/Measurements/BP_TrophyMeasurement_" in p or "/_Shared/Trophy/Measurements/" in p]
            par = [p for p in par if p.rsplit("/", 1)[-1].startswith("BP_TrophyMeasurement_")]
            if not par: break
            chain.append(par[0].rsplit("/", 1)[-1].replace("BP_TrophyMeasurement_", ""))
            cur = files.pkg(par[0])
        self.kind = next((c for c in chain if c in KINDS), chain[0] if chain else "?")
        if self.kind == "Base":
            nm0 = names(z)
            if any("GetTrophyBoneTransform" in n for n in nm0) or "BoneName" in nm0: self.kind = "Thickness"
            elif any("GetTrophyMultipleBoneLength" in n for n in nm0): self.kind = "Base_Length"
            elif any("GetOverallTrophyLength" in n for n in nm0): self.kind = "TipToTipLength"
            else: self.kind = "Zero"
        self.chain = chain
        d = cdo(z); nm = names(z)
        self.tag = next((n.split(".")[-1] for n in nm if n.startswith("Trophies.MeasurementTypes.")), None)
        if self.tag is None:
            for c in chain:
                zz = files.pkg(files.path_of("BP_TrophyMeasurement_" + c))
                self.tag = next((n.split(".")[-1] for n in names(zz) if n.startswith("Trophies.MeasurementTypes.")), None)
                if self.tag: break
        self.arrays = fname_arrays(z, d)
        self.tags = tag_refs(z, d) or self._parent_tags(files)
        named = [n for n in nm if re.match(r"^Trophies\.(Head|Mouth)\.", n)]
        if len(set(self.tags)) < 2 and len(named) >= 2:
            self.tags = named
        self.singles = single_names(z, d)
        if not self.singles or not self.floats if False else not self.singles:
            for c in chain:
                pp = files.path_of("BP_TrophyMeasurement_" + c)
                if pp:
                    zz = files.pkg(pp); sn = single_names(zz, cdo(zz))
                    if sn: self.singles = sn; break
        self.floats = [struct.unpack_from("<f", d, m.start() + 2)[0] for m in re.finditer(rb"\x01\x03", d) if m.start() + 6 <= len(d)]
        if len([x for x in self.floats if abs(x) < 1000]) < 4:
            self.floats = [struct.unpack("<f", m.group(1))[0] for m in re.finditer(rb"\x80\x05\x01(....)", d, re.S)]
        self.mult = 1
        self.maps = mesh_maps(z, d)
        if not self.maps:
            for c in chain:
                pp = files.path_of("BP_TrophyMeasurement_" + c)
                if pp:
                    zz = files.pkg(pp); mm = mesh_maps(zz, cdo(zz))
                    if mm: self.maps = mm; break
        mm = re.search(rb"\x03(.)\x00\x00\x00$", d[-8:], re.S)

    def _parent_tags(self, files):
        for c in self.chain:
            p = files.path_of("BP_TrophyMeasurement_" + c)
            if p:
                zz = files.pkg(p); t = tag_refs(zz, cdo(zz))
                if t: return t
        return ["Trophies.Head.Left", "Trophies.Head.Right"]

# ---------------------------------------------------------------- poses
SKE_DEFAULT_TRANS = True
SKE_DEFAULT_ROT = False

class PoseLib:
    def __init__(self, files):
        self.files = files; self.clips = {}; self.skels = {}; self.bs = {}

    def skel_ref(self, path):
        """(names, parents, ref pose) of a USkeleton (SKE_*) package."""
        key = ("skeref", path)
        if key not in self.skels:
            z = self.files.pkg(path); r = None
            for d in z.export_data:
                try: r = skel.ref_skeleton(z, d); break
                except ValueError: continue
            self.skels[key] = r
        return self.skels[key]

    def skel_names(self, path):
        """Bone names of a USkeleton (SKE_*) package."""
        key = ("ske", path)
        if key not in self.skels:
            z = self.files.pkg(path); r = None
            for d in z.export_data:
                try: r = skel.ref_skeleton(z, d)[0]; break
                except ValueError: continue
            self.skels[key] = r
        return self.skels[key]

    def clip_for(self, path, mesh_names, full=False):
        """A clip with its tracks re-indexed onto the given mesh skeleton (by bone name)."""
        key = (path, tuple(mesh_names), full)
        if key not in self.clips:
            c = self.clip(path, full)
            z = self.files.pkg(path)
            ske = next((p for p in imports_pkgs(z) if p.rsplit("/", 1)[-1].startswith("SKE_")), None)
            sn = self.skel_names(ske) if ske else None
            if full and ske and SKE_DEFAULT_TRANS:
                # a full pose's DEFAULT translation sub-tracks are the clip's USkeleton reference pose, not the mesh's
                # (blesbok AP_Base_13-15 stores no translations; its SKE bones are ~13 % shorter than the mesh's)
                sref = self.skel_ref(ske)
                if sref:
                    c = dict(c); tr = dict(c["trans"]); ro = dict(c["rot"])
                    for i, rt in enumerate(sref[2]):
                        if i not in tr: tr[i] = tuple(rt[1])
                        if SKE_DEFAULT_ROT and i not in ro: ro[i] = tuple(rt[0])
                    c["trans"] = tr; c["rot"] = ro
            if sn and list(sn) != list(mesh_names):
                mi = {n: i for i, n in enumerate(mesh_names)}
                remap = lambda dct: {mi[sn[i]]: v for i, v in dct.items() if i < len(sn) and sn[i] in mi}
                c = {"rot": remap(c["rot"]), "trans": remap(c["trans"]), "scale": remap(c.get("scale", {}))}
            self.clips[key] = c
        return self.clips[key]

    def clip(self, path, full=False):
        key = (path, full)
        if key not in self.clips:
            z = self.files.pkg(path); d = z.export_data[0]
            try:
                c = acl.decode(d); c.setdefault("scale", {})
            except ValueError:
                try:
                    c = acl.decode_bitwise(d)
                    c.setdefault("default_scale", 0.0 if not full else 1.0)
                except ValueError: c = {"rot": {}, "trans": {}, "scale": {}}
            self.clips[key] = c
        return self.clips[key]

    def skeleton(self, mesh_path):
        if mesh_path not in self.skels:
            z = self.files.pkg(mesh_path)
            for d in z.export_data:
                try:
                    self.skels[mesh_path] = skel.ref_skeleton(z, d); break
                except ValueError:
                    continue
        return self.skels[mesh_path]

    def mesh_sockets(self, mesh_path):
        key = ("sock", mesh_path)
        if key not in self.skels:
            z = self.files.pkg(mesh_path); sk = sockets(z)
            for q in refs(z):
                if q.rsplit("/", 1)[-1].startswith("SKE_"):
                    for k2, v2 in sockets(self.files.pkg(q)).items(): sk.setdefault(k2, v2)
            self.skels[key] = sk
        return self.skels[key]

    def abp_base(self, abp):
        try: imps = imports_pkgs(self.files.pkg(self.files.path_of(abp.rsplit("/", 1)[-1])))
        except Exception: return None
        return next((q for q in imps if re.match(r"AP_BASE", q.rsplit("/", 1)[-1], re.I)), None)

    def blendspaces(self, abp_path):
        """{var name: [(clip path, sample value)]} for every BS_* the ABP uses, + ABP defaults (50)."""
        if abp_path not in self.bs:
            z = self.files.pkg(abp_path); out = {}
            for p in imports_pkgs(z):
                b = p.rsplit("/", 1)[-1]
                if b.startswith("BS_"):
                    zz = self.files.pkg(p)
                    smp = bspace.samples(self.files.pkg(p).raw if False else _raw(self.files, p))
                    base = {x.rsplit("/", 1)[-1]: x for x in imports_pkgs(zz)}
                    out[b + "_Var"] = [(base.get(a, a), v) for a, v in smp]
            # the AnimGraph is one chain Root -> Add(BS 1) -> Add(BS 2) -> ... -> base pose: every
            # ApplyMeshSpaceAdditive's Base links to the next one. The CDO stores the players in that chain
            # order, so the game APPLIES them in reverse (the last stored layer goes on first).
            try:
                cd = cdo(z); seen = []
                for o in range(len(cd) - 4):
                    v, = struct.unpack_from("<i", cd, o)
                    if v < 0 and -v - 1 < len(z.imports):
                        sp_ = zenpkg.split_import(z.imports[-v - 1])
                        nm_ = z.package_names[sp_[0]][0].rsplit("/", 1)[-1] if sp_ else ""
                        if nm_.startswith("BS_") and nm_ + "_Var" in out and nm_ + "_Var" not in seen:
                            seen.append(nm_ + "_Var")
                if GRAPH_ORDER and len(seen) == len(out):
                    out = {k: out[k] for k in reversed(seen)}
            except Exception:
                pass
            # the real wiring (compiled ABP property-access records): one layer per blend-space node, keyed by the
            # property that drives it - pronghorn/kudu/moose rename some, bison/wildebeest/buffalo/Dall drive one
            # blend space from 2-3 properties. Node order = chain order; applied last-first like above.
            if BIND:
                try:
                    import abpbind
                    b = abpbind.binding(z, cdo(z))
                    if b and all(a + "_Var" in out for p, a in b):
                        out = {p: out[a + "_Var"] for p, a in reversed(b)}
                except Exception:
                    pass
            self.bs[abp_path] = out
        return self.bs[abp_path]

def _raw(files, path):
    path = path.split(".")[0].lower()
    if path not in files.index:
        path = files.by_base[path.rsplit("/", 1)[-1]]
    t, i = files.index[path]
    return t.read(i)

DEFAULT_VAR = 50.0
UE_SCALE = True         # every blend layer's scale moves the child bones (Unreal's own transform composition)
THICK_UE = True         # Thickness exactly as BP_TrophyMeasurement_Thickness: avg Z of the component-space scale of the
                        # bone on TrophyTagA and TrophyTagB; a tag with no trophy gives the identity (scale 1, FUN_1456db740)
SCALE_TO_CHILDREN_RE = None   # research: species whose blend-layer scale also moves child bones
BIND = True             # use the ABP's compiled property bindings (abpbind.py) instead of blend-space file names
GRAPH_ORDER = True       # apply blend layers in the AnimGraph chain order (False = old import order)
# research switches (all off): count hidden tines in spreads, re-sort layers (1/-1 by bone depth, 2/-2 by name),
# apply matching layers as local-space additives, moose unsaved-layer value, skip matching layers
SPREAD_HIDDEN = False
LAYER_ORDER = 0
LOCAL_RE = None
MOOSE_MISSING = None
SKIP_RE = None
MOOSE_ZERO = {"BS_A_ShortLong_Var"}
ABP_BASE_FALLBACK = False   # old: use the ABP's imported AP_BASE pose when the save has none
UNSAVED_ABP_DEFAULTS = True  # old (False): every unsaved layer 0 on ABPs that have *_Hidden_Var layers

def build_side(lib, side):
    """side: {"mesh", "abp", "base", "bs": {var: value}, "hidden_names": set} -> posed P.Pose with .scale_cs."""
    names_, parents, ref = lib.skeleton(side["mesh"])
    p = P.Pose(names_, parents, ref)
    # a saved base pose of "None" means no base pose (moose palm racks: applying the ABP's AP_BASE_Palm_NoPalm
    # cost ~4 of spread and ~0.5 of beam; checked against 7 kills measured in the game 2026-10-09, 35/35 exact)
    base = side.get("base") or (lib.abp_base(side["abp"]) if ABP_BASE_FALLBACK else None)
    if base:
        p.set_full(lib.clip_for(base, names_, True))
    bss = lib.blendspaces(side["abp"])
    # unsaved DNA keeps the ABP defaults: 50 (CDO doubles), *_Hidden_Var 0 (moose palm bulls never save
    # BS_A_ShortLong_Var; at 50 it gives the game's spreads once no base pose is applied)
    dflt = 0.0 if any(k.endswith("_Hidden_Var") for k in bss) else DEFAULT_VAR
    vals = {k: (0.0 if k.endswith("_Hidden_Var") else DEFAULT_VAR) for k in bss} if UNSAVED_ABP_DEFAULTS else {k: dflt for k in bss}
    if MOOSE_MISSING is not None and dflt == 0.0:
        vals = {k: (0.0 if k.endswith("_Hidden_Var") or k in MOOSE_ZERO else MOOSE_MISSING) for k in bss}
    vals.update(side["bs"])
    scl = [1.0] * len(names_); scl3 = [(1.0, 1.0, 1.0)] * len(names_)
    order = list(vals.items())
    if LAYER_ORDER:                            # experiment: apply bend layers by depth of the bones they move
        def depth(var):
            sm = bss.get(var)
            if not sm or len(sm) != 2: return 0
            c = lib.clip_for(sm[1][0], names_); bones = list(c.get("rot", {})) + list(c.get("trans", {}))
            if not bones: return 0
            def dp(b):
                n = 0
                while b >= 0 and n < 200: b = parents[b]; n += 1
                return n
            return min(dp(b) for b in bones)
        if LAYER_ORDER == 2: order.sort(key=lambda kv: kv[0])
        elif LAYER_ORDER == -2: order.sort(key=lambda kv: kv[0], reverse=True)
        else: order.sort(key=lambda kv: depth(kv[0]) * LAYER_ORDER)
    for var, v in order:
        sm = bss.get(var)
        if not sm or len(sm) != 2: continue
        (a0, x0), (a1, x1) = sm
        w = 0.0 if x1 == x0 else max(0.0, min(1.0, (v - x0) / (x1 - x0)))
        c0 = lib.clip_for(a0, names_); c1 = lib.clip_for(a1, names_)
        alpha = float(vals.get(var + "_alpha", 1.0))
        if alpha <= 0.0: continue
        add = P.blend_additive(c0, c1, w)
        if alpha < 1.0: add = P.blend_additive({"rot": {}, "trans": {}}, add, alpha)
        if SKIP_RE and re.match(SKIP_RE, var): continue
        if LOCAL_RE and re.match(LOCAL_RE, var): p.add(add); p._M = None
        else: p.add_mesh_rot(add)
        for b in set(c0.get("scale", {})) | set(c1.get("scale", {})):
            # additive scale is stored as a delta (scale - 1) when the clip's default scale is 0
            dz0 = 0.0 if c0.get("default_scale", 0.0) == 0.0 else 1.0
            dz1 = 0.0 if c1.get("default_scale", 0.0) == 0.0 else 1.0
            s0 = tuple(x - dz0 for x in c0.get("scale", {}).get(b, (dz0,) * 3)); s1 = tuple(x - dz1 for x in c1.get("scale", {}).get(b, (dz1,) * 3))
            d = tuple(x + (y - x) * w for x, y in zip(s0, s1))
            scl3[b] = tuple(a * (1 + dd) for a, dd in zip(scl3[b], d))
    base_scale = list(p.scale)
    p.bone_scale = scl3                       # Thickness reads the blend (Slim/Thick) scale
    p.scale = list(base_scale)     # only the base pose's scale moves the children; Slim/Thick-type scale is for Thickness
    if dflt == 0.0 or UE_SCALE or (SCALE_TO_CHILDREN_RE and re.search(SCALE_TO_CHILDREN_RE, side["mesh"])):
        # moose: the Slim/Thick layer scales the palm, so it moves the tines too
        p.scale = [tuple(a * b for a, b in zip(bs_, sc_)) for bs_, sc_ in zip(base_scale, scl3)]
    p.component()
    for sname, (bone, loc, q, sc) in lib.mesh_sockets(side["mesh"]).items():
        if sname in p.index or bone not in p.index: continue
        b = p.index[bone]
        lt = tuple(a * c for a, c in zip(loc, p.cs_scale[b]))
        pos = tuple(a + c for a, c in zip(P.qrot(p.cs_rot[b], lt), p.cs[b]))
        p.index[sname] = len(p.cs); p.cs.append(pos); p.names.append(sname); p.parents.append(b)
        p.bone_scale.append(tuple(a * c for a, c in zip(scl3[b], sc)))
    return p

# ---------------------------------------------------------------- body placement
def rotq(pitch, yaw, roll):
    d = math.pi / 360
    sp, cp = math.sin(pitch * d), math.cos(pitch * d); sy, cy = math.sin(yaw * d), math.cos(yaw * d)
    sr, cr = math.sin(roll * d), math.cos(roll * d)
    return (cr * sp * sy - sr * cp * cy, -cr * sp * cy - sr * cp * sy, cr * cp * sy - sr * sp * cy, cr * cp * cy + sr * sp * sy)

def sockets(z):
    """{socket name: (bone, loc, rot quat, scale)} from SkeletalMeshSocket exports (unversioned)."""
    nm = names(z); out = {}
    for e, d in zip(z.exports, z.export_data):
        if z.name(e[2] & 0xFFFFFFFF) != "SkeletalMeshSocket": continue
        try:
            h, = struct.unpack_from("<H", d, 0); q = 2
            present = []; idx = 0
            while True:
                idx += h & 0x7F; n = h >> 9
                zero = h & 0x80
                present += list(range(idx, idx + n)); idx += n
                if h & 0x100: break
                h, = struct.unpack_from("<H", d, q); q += 2
            if zero:
                mask = d[q]; q += 1
                present = [pp for k, pp in enumerate(present) if not (mask >> k) & 1]
            vals = {}
            for pr in present:
                if pr in (0, 1): vals[pr] = nm[struct.unpack_from("<I", d, q)[0]]; q += 8
                elif pr in (2, 3, 4): vals[pr] = struct.unpack_from("<3d", d, q); q += 24
                else: break
            loc = vals.get(2, (0.0, 0.0, 0.0)); r = vals.get(3, (0.0, 0.0, 0.0)); s = vals.get(4, (1.0, 1.0, 1.0))
            out[vals.get(0)] = (vals.get(1), loc, rotq(*r), s)
        except (struct.error, IndexError):
            continue
    return out

def comp_transform(d):
    """(relative location, rotation quat, scale vec) of a trophy component template. The unversioned header lists
    the serialized properties; RelativeLocation / RelativeRotation / RelativeScale3D are property indices 233-235
    (3 doubles each) and come last, right before the trailing 8 zero bytes."""
    p = 0; idx = 0; present = []
    while True:
        h, = struct.unpack_from("<H", d, p); p += 2
        idx += h & 0x7F; n = h >> 9
        present += list(range(idx, idx + n)); idx += n
        if h & 0x100: break
    vec = [i for i in present if i in (233, 234, 235)]
    end = len(d) - 8
    vals = {}
    q = end - 24 * len(vec)
    for i in vec:
        vals[i] = struct.unpack_from("<3d", d, q); q += 24
    loc = vals.get(233, (0.0, 0.0, 0.0)); rot = vals.get(234, (0.0, 0.0, 0.0)); sc = vals.get(235, (1.0, 1.0, 1.0))
    return (tuple(loc), rotq(*rot), tuple(sc))

def comp_for(comps, tag):
    side = "".join(tag.split(".")[2:])          # Left, Right, LowerLeft ...
    for n, v in comps.items():
        nn = n.replace("_GEN_VARIABLE", "")
        if nn.endswith(side) or nn.endswith("_" + side) or (side in ("LowerLeft", "LowerRight", "UpperLeft", "UpperRight") and
                                                          nn.endswith(side.replace("Lower", "Low").replace("Upper", "Up")[:-4] + side[-4:][0])):
            return v
    return ((0.0, 0.0, 0.0), (0.0, 0.0, 0.0, 1.0), (1.0, 1.0, 1.0))

def socket_name(tag):
    parts = tag.split(".")[2:]          # Head.Left -> [Left]; Mouth.Lower.Left -> [Lower, Left]
    return "S_Trophy" + "".join(parts)

def to_world(sock, pt, body_scale, comp=((0.0, 0.0, 0.0), (0.0, 0.0, 0.0, 1.0), (1.0, 1.0, 1.0))):
    _bone, loc, q, s = sock
    cl, cq, cs = comp
    pt = tuple(a + b for a, b in zip(P.qrot(cq, tuple(x * y for x, y in zip(pt, cs))), cl))
    v = tuple(a * b for a, b in zip(pt, s))
    r = P.qrot(q, v)
    return tuple((a + b) * body_scale for a, b in zip(r, loc))

# ---------------------------------------------------------------- measuring
SCALE_POS = True
THICK_BASE = True
TIP_HIDDEN = True
TIP_BODY = True
THICK_BODY = False; THICK_BODY_NOBONE = False; NOBONE_ROOT = True

def measure(meas, sides, socks, body_scale, comps=None):
    comps = comps or {}
    _tw = to_world
    def to_world_(sock, pt, bs, tag=None):
        return _tw(sock, pt, bs, comp_for(comps, tag)) if tag else _tw(sock, pt, bs)
    """sides: {tag: (pose, hidden set[, mesh name])} -> float value of one measurement."""
    meshes = {t: v[2] for t, v in sides.items() if len(v) > 2}
    sides = {t: tuple(v[:2]) for t, v in sides.items()}
    k = meas.kind
    if k in ("Base_Length",):
        tags = meas.tags[:2]; arrs = meas.arrays
        tot = 0.0
        for tg, arr in zip(tags[::-1], arrs[:2][::-1]) if len(arrs) >= 2 else []:
            if tg in sides:
                p, hid = sides[tg]; tot += p.chain_length(arr, hid)
        if len(arrs) == 1 and tags and tags[0] in sides:        # BoneNameArray_B empty: only side A is measured
            p, hid = sides[tags[0]]; tot += p.chain_length(arrs[0], hid)
        return tot
    if k == "MultiLength":
        tot = 0.0
        for tg in meas.tags:
            if tg not in sides: continue
            p, hid = sides[tg]
            for arr in meas.arrays:
                tot += p.chain_length(arr, hid)
        return tot
    if k == "Zero":
        return 0.0
    if k in ("Shovel_Length", "Base_Shovel_Width", "ShovelGreatestSpread", "NumberOfPoints"):
        tags = [t for t in meas.tags if t in sides][:2]
        if not tags: return 0.0
        mesh = meshes.get(tags[0])
        pick = lambda mp: mp.get(mesh) if mesh else next(iter(mp.values()), None)
        if k == "NumberOfPoints":
            arr = pick(meas.maps[0]) if meas.maps else None
            if arr is None: return 0.0
            tot = 0
            for tg in tags:
                p, hid = sides[tg][:2]
                tot += sum(1 for b in arr if not p.hidden(b, hid))
            return float(tot)
        if k == "ShovelGreatestSpread":
            arr = pick(meas.maps[0]) if meas.maps else None
            if arr is None or len(tags) < 2: return 0.0
            m2 = type("M", (), {"kind": "GreatestSpread", "tags": tags, "arrays": [arr]})
            return measure(m2, {t: sides[t][:2] for t in tags}, socks, body_scale, comps)
        if len(meas.maps) < 2: return 0.0
        A = pick(meas.maps[0]); B = pick(meas.maps[1])
        if A is None or B is None: return 0.0
        def one(tg):
            p, hid = sides[tg][:2]; best = 0.0
            for a in A:
                if a not in p.index or p.hidden(a, hid): continue
                for b in B:
                    if b not in p.index or p.hidden(b, hid): continue
                    sk = socks[socket_name(tg)]      # actor space (socket transform space 1)
                    best = max(best, math.dist(to_world_(sk, p.cs[p.index[a]], body_scale, tg), to_world_(sk, p.cs[p.index[b]], body_scale, tg)))
            return best
        if k == "Shovel_Length":
            return one(tags[0])
        return sum(one(t) for t in tags)
    if k == "TipToTipLength":
        if len(meas.tags) < 2 or meas.tags[0] not in sides or meas.tags[1] not in sides or not meas.arrays: return 0.0
        bones = meas.arrays[0]; ta, tb = meas.tags[0], meas.tags[1]
        (pa, ha), (pb, hb) = sides[ta], sides[tb]
        W = lambda tg, p, b: to_world_(socks[socket_name(tg)], p.cs[p.index[b]], body_scale if TIP_BODY else 1.0, tg)
        if bones[-1] not in pa.index: return 0.0
        tot = 0.0; prev = W(ta, pa, bones[-1])
        for b in reversed(bones):                 # tip of horn A back to its base
            if b not in pa.index: continue
            cur = W(ta, pa, b); tot += math.dist(prev, cur); prev = cur
            if not TIP_HIDDEN and pa.hidden(b, ha): break
        for b in bones:                           # then across to horn B and out to its tip
            if b not in pb.index: continue
            cur = W(tb, pb, b); tot += math.dist(prev, cur); prev = cur
            if not TIP_HIDDEN and pb.hidden(b, hb): break
        return tot
    if k == "GreatestSpread":
        ta, tb = meas.tags[:2]
        if ta not in sides or tb not in sides: return 0.0
        (pa, ha), (pb, hb) = sides[ta], sides[tb]; best = 0.0
        bones = meas.arrays[0] if meas.arrays else []
        for b in bones:
            if b not in pa.index or b not in pb.index: continue
            if not (SPREAD_HIDDEN or getattr(meas, "measure_hidden", False)) and (pa.hidden(b, ha) or pb.hidden(b, hb)): continue
            wa = to_world_(socks[socket_name(ta)], pa.cs[pa.index[b]], body_scale, ta)
            wb = to_world_(socks[socket_name(tb)], pb.cs[pb.index[b]], body_scale, tb)
            best = max(best, math.dist(wa, wb))
        return best
    if k == "DistanceSockets":
        ta, tb = meas.tags[:2]
        if ta not in sides or tb not in sides or not meas.singles: return 0.0
        (pa, _), (pb, _) = sides[ta], sides[tb]
        bn = [b for b in meas.singles if b in pa.index]
        if not bn: return 0.0
        sa = bn[0]; sb = bn[1] if len(bn) > 1 else sa
        if sa not in pa.index or sb not in pb.index: return 0.0
        wa = to_world_(socks[socket_name(ta)], pa.cs[pa.index[sa]], body_scale, ta)
        wb = to_world_(socks[socket_name(tb)], pb.cs[pb.index[sb]], body_scale, tb)
        return math.dist(wa, wb)
    if k == "Thickness" and THICK_UE:
        anyp = next((v[0] for v in sides.values()), None)
        bone = next((b for b in meas.singles if anyp and b in anyp.index), None)
        zs = []
        for tg in (meas.tags + ["", ""])[:2]:
            if tg not in sides or bone is None or bone not in sides[tg][0].index:
                zs.append(1.0); continue
            p = sides[tg][0]; zs.append(p.cs_scale[p.index[bone]][2])
        fl = meas.floats
        smin, smax, rmin, rmax = (fl + [0.0, 0.0, 0.0, 0.0][len(fl):])[:4]      # unset ranges are 0..0
        v = (zs[0] + zs[1]) / 2
        if smax == smin: a_ = 0.0 if v < smin else 1.0                      # UKismetMathLibrary::NormalizeToRange
        else: a_ = (v - smin) / (smax - smin)
        return rmin + (rmax - rmin) * a_                                     # Lerp, unclamped
    if k == "Thickness":
        anyp = next((v[0] for v in sides.values()), None)
        bone = next((b for b in meas.singles if anyp and b in anyp.index), None)
        zs = []
        for tg in meas.tags[:2]:
            if tg not in sides: continue
            p = sides[tg][0]
            if bone in p.index: zs.append(p.bone_scale[p.index[bone]][2] * (p.scale[p.index[bone]][2] if THICK_BASE else 1.0) * (body_scale if THICK_BODY else 1.0))
            else: zs.append((p.bone_scale[0][2] if NOBONE_ROOT else 1.0) * (body_scale if THICK_BODY_NOBONE else 1.0))
        if not zs: return 0.0
        fl = meas.floats
        smin, smax, rmin, rmax = (fl + [0.75, 1.4, 9.0, 15.0][len(fl):])[:4]
        v = sum(zs) / len(zs)
        a = (v - smin) / (smax - smin) if smax != smin else 0.0
        return rmin + (rmax - rmin) * a
    return None

# ---------------------------------------------------------------- per-config game data
class Species:
    def __init__(self, files, cfg):
        self.files = files
        z = files.pkg(files.path_of(cfg))
        imp = refs(z)
        tcfg = next((p for p in imp if "TrophyConfig" in p), None)
        self.meas = []
        if tcfg:
            for p in refs(files.pkg(tcfg)):
                if p.rsplit("/", 1)[-1].startswith("BP_TrophyMeasurement_"):
                    self.meas.append(Measurement(files, p))
        body = next((p for p in imp if "BP_BodyConfig" in p), None)
        self.scale_range = self._scale_range(body) if body else (1.0, 1.0)
        self.weight_range = self._weight_range(body) if body else None     # THIS config's body: the rare buffalo bulls'
                                                                           # bodies carry the whitetail's 40-137 kg (game slip)
        bp = next((p for p in imp if re.search(r"/BP_[A-Za-z]+_(M|F)(_[A-Za-z]+)?$", p)), None)
        self.socks = {}; self.comps = {}
        if bp:
            zb = files.pkg(bp)
            for e, d in zip(zb.exports, zb.export_data):
                n = zb.name(e[2] & 0xFFFFFFFF)
                if "rophy" in n and "GEN_VARIABLE" in n:
                    self.comps[n] = comp_transform(d)
        if bp:
            for p in refs(files.pkg(bp)):
                b = p.rsplit("/", 1)[-1]
                if b.startswith("SK_") and "Trophy" not in b and "Fur" not in b and "Vitals" not in b:
                    zm = files.pkg(p); self.socks.update(sockets(zm))
                    for q in refs(zm):
                        if q.rsplit("/", 1)[-1].startswith("SKE_"):
                            s = sockets(files.pkg(q))
                            for k, v in s.items(): self.socks.setdefault(k, v)

    def _weight_range(self, body):
        """m_weightRange (kg) of the body config, from its parents when it has none of its own."""
        cur = body
        for _ in range(5):
            z = self.files.pkg(cur); d = cdo(z)
            ms = list(re.finditer(rb"\x00\x05\x01\x03(....)\x01\x03(....)", d, re.S))
            if ms:
                lo, hi = struct.unpack("<ff", ms[-1].group(1) + ms[-1].group(2))
                if 0 < lo < hi: return lo, hi
            par = [p for p in imports_pkgs(z) if "BP_BodyConfig" in p]
            if not par: return None
            cur = par[0]
        return None

    def _scale_range(self, body):
        vals = []; cur = body
        for _ in range(5):
            z = self.files.pkg(cur); d = cdo(z)
            m = re.search(rb"\x00\x04((?:\x01\x03)*)", d)
            found = []
            for mm in re.finditer(rb"(?=\x01\x03(....))", d, re.S):
                v, = struct.unpack("<f", mm.group(1))
                if 0.3 < v < 3: found.append(v)
            vals.append(found)
            par = [p for p in imports_pkgs(z) if "BP_BodyConfig" in p]
            if not par: break
            cur = par[0]
        own = vals[0] if vals else []
        if len(own) >= 2: return own[0], own[1]
        lo = next((v[0] for v in vals[1:] if v), 1.0)
        hi = own[0] if own else lo
        return lo, hi

