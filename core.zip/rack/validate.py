"""Check the offline trophy engine against every measured kill in the save: per species and measurement, the share
of kills where int(value) * multiplier equals the game's own points.
usage: validate.py [species-prefix] [--save=PATH] [--kills=PATH]
  --save=PATH   read the kills from this save (a copy!) instead of the old kills pickle; nothing is cached
  --kills=PATH  kills pickle to use (default: the 2026-10-07 one below; built from the save if missing)"""
import sys, os, re, struct, collections, pickle, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import engine as E
import trainer_core as tc, nrgs, trophy_score as ts

def fstr(b, p):
    n, = struct.unpack_from("<i", b, p); p += 4
    return b[p:p + n - 1].decode("latin1"), p + n

def parse_sides(seg):
    """[{tag, mesh, abp, base, bs, hidden_names}] from a kill / trophy record."""
    out = []
    for m in re.finditer(rb"(Trophies\.(?:Head|Mouth)[A-Za-z.]*)\x00\x01\x02", seg):
        p = m.end() + 4
        try:
            mesh, p = fstr(seg, p); _n, p = fstr(seg, p); p += 4
            abp, p = fstr(seg, p); _n, p = fstr(seg, p); p += 4
            nh, = struct.unpack_from("<I", seg, p); p += 4 + nh
            nv, = struct.unpack_from("<I", seg, p); p += 4
            bs = {}
            for _ in range(nv):
                if seg[p:p + 2] != b"\x01\x01": raise ValueError
                p += 6; name, p = fstr(seg, p); v, = struct.unpack_from("<f", seg, p); p += 4; bs[name] = v
            base, p2 = fstr(seg, p)
            hid = set()
            mm = re.match(rb"(?:.{0,40}?)\x00\x00\x00\x00\x00\x00\x00\x00(....)", seg[p2:p2 + 60], re.S)
            q = p2
            # base pose path FString, its name FString, 8 bytes, u32 count, names
            if base.startswith("/Game") or base == "None":
                _b, q = fstr(seg, p2); q += 8
                cnt, = struct.unpack_from("<I", seg, q); q += 4
                if cnt < 200:
                    for _ in range(cnt):
                        s, q = fstr(seg, q); hid.add(s)
            if not base.startswith("/Game"):
                base = None
            out.append({"tag": m.group(1).decode(), "mesh": mesh.split(".")[0], "abp": abp.split(".")[0], "base": base,
                        "bs": bs, "hidden_names": hid})
        except (ValueError, struct.error, UnicodeDecodeError):
            continue
    return out

KILLS_PKL = "/home/mistersprinkles/.claude/jobs/156f1e98/tmp/allkills.pkl"
SAVE = None                                          # a save path: read kills from it, no pickle cache

def kills(prefix=""):
    cache = None if SAVE else KILLS_PKL
    try:
        K = pickle.load(open(cache, "rb"))
    except Exception:
        sf = nrgs.SaveFile(SAVE or tc.find_save()); K = []; seen = set()
        for part, sec in [("Game_0/GameData", ts.HUNTINGLOG_SECTION)] + [(f"Game_0/World_0/{m}", ts.KILLS_SECTION) for m in ("Map01", "Map02", "Hub")]:
            try: secs = nrgs.split_sections(sf.part(part).data)[1]
            except Exception: continue
            for h, _v, blob in secs:
                if h != sec: continue
                ms = list(ts._CFG.finditer(blob))
                for k, m in enumerate(ms):
                    seg = blob[m.end():ms[k + 1].start() if k + 1 < len(ms) else len(blob)]
                    meas = {mm.group(5).decode(): (struct.unpack("<I", mm.group(2))[0], struct.unpack("<I", mm.group(3))[0]) for mm in ts._MT.finditer(seg)}
                    sides = parse_sides(seg)
                    if not meas or not sides: continue
                    st = blob.rfind(b"AnimalConfigDataAsset", 0, m.start())
                    lid, age, fit = struct.unpack_from("<IIf", blob, st - 30); w, = struct.unpack_from("<f", blob, st - 17)
                    cfg = m.group(0)[:-1].decode()
                    key = (m.group(1), lid, age, round(fit, 4))
                    if key in seen: continue
                    seen.add(key)
                    K.append({"species": m.group(1).decode(), "sex": m.group(2).decode(), "cfg": cfg, "age": age, "fit": fit, "w": w, "meas": meas, "sides": sides})
        if cache: pickle.dump(K, open(cache, "wb"))
    return [k for k in K if k["species"].startswith(prefix)]

# ---------------------------------------------------------------- per-config game data
Species = E.Species

def run(prefix=""):
    files = E.Files(); lib = E.PoseLib(files); specs = {}
    stat = collections.defaultdict(lambda: [0, 0, []])
    for k in kills(prefix):
        sp = specs.get(k["cfg"])
        if sp is None:
            try: sp = specs[k["cfg"]] = Species(files, k["cfg"])
            except Exception as ex: print("species fail", k["cfg"], ex); specs[k["cfg"]] = sp = False
        if not sp: continue
        try:
            sides = {s["tag"]: (E.build_side(lib, s), s["hidden_names"], s["mesh"].rsplit("/", 1)[-1]) for s in k["sides"]}
        except Exception as ex:
            stat[(k["species"], "BUILD")][1] += 1; stat[(k["species"], "BUILD")][2].append(str(ex)[:80]); continue
        br = ts._match(ts.body_ranges(files.pd), k["species"], k["sex"]) if not hasattr(run, "br") else None
        wr = sp.weight_range or BR.get((k["species"], k["sex"]))       # the animal's own body config first
        t = max(0.0, min(1.0, (k["w"] - wr[0]) / (wr[1] - wr[0]))) if wr else 0.5
        bscale = sp.scale_range[0] + (sp.scale_range[1] - sp.scale_range[0]) * t
        for m in sp.meas:
            if m.tag not in k["meas"]: continue
            try: v = E.measure(m, sides, sp.socks, bscale, sp.comps)
            except Exception as ex: v = None; stat[(k["species"], m.tag)][2].append(str(ex)[:60])
            st = stat[(k["species"] + "_" + k["sex"], m.tag + ":" + m.kind)]
            st[1] += 1
            if v is not None:
                ok = int(v + 1e-4) == k["meas"][m.tag][1]
                st[0] += ok
                if not ok and len(st[2]) < 4: st[2].append((k["meas"][m.tag][1], round(v, 2)))
    for key, (ok, n, ex) in sorted(stat.items()):
        print(f"{key[0]:40s} {key[1]:40s} {ok:4d}/{n:<4d} {ex[:4]}")

BR = {}
if __name__ == "__main__":
    for a in [a for a in sys.argv[1:] if a.startswith("--")]:
        if a.startswith("--save="): SAVE = a[7:]
        elif a.startswith("--kills="): KILLS_PKL = a[8:]
        sys.argv.remove(a)
    files0 = E.Files()
    raw = ts.body_ranges(files0.pd)
    for k in kills(sys.argv[1] if len(sys.argv) > 1 else ""):
        BR[(k["species"], k["sex"])] = ts._match(raw, k["species"], k["sex"])
    run(sys.argv[1] if len(sys.argv) > 1 else "")

def stars_check(prefix=""):
    """Total score and stars vs the game, per species (kills where every measurement could be computed)."""
    files = E.Files(); lib = E.PoseLib(files); raw = ts.body_ranges(files.pd); req = ts.thresholds(files.pd)
    specs = {}; res = collections.defaultdict(lambda: [0, 0, 0, []])
    st = lambda T, s: 0 if s < 1 else 1 + sum(1 for x in T if s >= x)
    for k in kills(prefix):
        sp = specs.get(k["cfg"])
        if sp is None:
            try: sp = specs[k["cfg"]] = Species(files, k["cfg"])
            except Exception: sp = specs[k["cfg"]] = False
        if not sp: continue
        try: sides = {s["tag"]: (E.build_side(lib, s), s["hidden_names"], s["mesh"].rsplit("/", 1)[-1]) for s in k["sides"]}
        except Exception: continue
        wr = sp.weight_range or ts._match(raw, k["species"], k["sex"]); t = max(0, min(1, (k["w"] - wr[0]) / (wr[1] - wr[0]))) if wr else .5
        bs = sp.scale_range[0] + (sp.scale_range[1] - sp.scale_range[0]) * t
        tot = 0; ok = True
        for m in sp.meas:
            if m.tag not in k["meas"]: continue
            pts, val = k["meas"][m.tag]
            mult = pts // val if val else 1
            v = E.measure(m, sides, sp.socks, bs, sp.comps)
            if v is None: ok = False; break
            tot += int(v + 1e-4) * mult
        key = k["species"] + "_" + k["sex"]
        r = res[key]; r[2] += 1
        if not ok: continue
        game = sum(p for p, _ in k["meas"].values())
        T = ts._match(req, k["species"], k["sex"])
        r[0] += 1
        if T and st(T, tot) == st(T, game): r[1] += 1
        r[3].append(tot - game)
    for key, (n, okst, all_, d) in sorted(res.items()):
        import statistics
        print(f"{key:40s} computed {n:3d}/{all_:<3d} stars right {okst:3d}/{n:<3d}  score diff mean {statistics.mean(d) if d else 0:6.1f}  max |{max((abs(x) for x in d), default=0)}|")
