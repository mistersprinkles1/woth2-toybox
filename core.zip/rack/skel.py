"""Reference skeleton (bone names, parents, local ref pose) from a cooked USkeleton / USkeletalMesh export."""
import struct

def ref_skeleton(z, dat):
    names = [z.name(k) for k in range(len(z.names))]
    for p in range(0, len(dat) - 16):
        n, = struct.unpack_from("<i", dat, p)
        if not (3 <= n <= 2000) or p + 4 + 12 * n + 4 > len(dat):
            continue
        q = p + 4; bones = []; ok = True
        for k in range(n):
            ni, nn, par = struct.unpack_from("<IIi", dat, q); q += 12
            if ni >= len(names) or not (-1 <= par < max(k, 1)) or (k == 0) != (par == -1):
                ok = False; break
            bones.append((names[ni] + (f"_{nn - 1}" if nn else ""), par))
        if not ok:
            continue
        m, = struct.unpack_from("<i", dat, q)
        if m != n:
            continue
        pose = [struct.unpack_from("<10d", dat, q + 4 + 80 * k) for k in range(n)]
        return [b[0] for b in bones], [b[1] for b in bones], [((x[0], x[1], x[2], x[3]), x[4:7], x[7:10]) for x in pose]
    raise ValueError("no reference skeleton")
