"""Pose a trophy skeleton the way ABP_Trophy_* does (ref pose -> template base pose -> every DNA blend space as an
additive layer) and measure bone chains like GetTrophyMultipleBoneLength (FUN_1456dba80)."""
import math, struct

def qmul(a, b):
    ax, ay, az, aw = a; bx, by, bz, bw = b
    return (aw * bx + ax * bw + ay * bz - az * by, aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw, aw * bw - ax * bx - ay * by - az * bz)

def qrot(q, v):
    x, y, z, w = q; vx, vy, vz = v
    tx, ty, tz = 2 * (y * vz - z * vy), 2 * (z * vx - x * vz), 2 * (x * vy - y * vx)
    return (vx + w * tx + (y * tz - z * ty), vy + w * ty + (z * tx - x * tz), vz + w * tz + (x * ty - y * tx))

def qnorm(q):
    x, y, z, w = q
    n = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    return (x / n, y / n, z / n, w / n)

def nlerp(a, b, t):
    ax, ay, az, aw = a; bx, by, bz, bw = b
    if ax * bx + ay * by + az * bz + aw * bw < 0:
        bx, by, bz, bw = -bx, -by, -bz, -bw
    x = ax + (bx - ax) * t; y = ay + (by - ay) * t; z = az + (bz - az) * t; w = aw + (bw - aw) * t
    n = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    return (x / n, y / n, z / n, w / n)

ID = (0.0, 0.0, 0.0, 1.0)

def blend_additive(p0, p1, w):
    """Two additive poses {"rot": {i: q}, "trans": {i: v}} blended (w = weight of p1)."""
    r0, r1, t0, t1 = p0["rot"], p1["rot"], p0["trans"], p1["trans"]
    Z = (0.0, 0.0, 0.0)
    rot = {i: nlerp(r0.get(i, ID), r1.get(i, ID), w) for i in set(r0) | set(r1)}
    trans = {}
    for i in set(t0) | set(t1):
        (ax, ay, az), (bx, by, bz) = t0.get(i, Z), t1.get(i, Z)
        trans[i] = (ax + (bx - ax) * w, ay + (by - ay) * w, az + (bz - az) * w)
    return {"rot": rot, "trans": trans}

class Pose:
    def __init__(self, names, parents, ref):
        self.names, self.parents = names, parents
        self.index = {n: i for i, n in enumerate(names)}
        self.rot = [r[0] for r in ref]; self.trans = [tuple(r[1]) for r in ref]; self.scale = [tuple(r[2]) for r in ref]

    def _set_full_old(self, clip):
        """A non-additive clip: its constant tracks replace the bones' local rotation / translation."""
        for i, q in clip["rot"].items(): self.rot[i] = q
        for i, v in clip["trans"].items(): self.trans[i] = v
        for i, v in clip.get("scale", {}).items(): self.scale[i] = tuple(v)

    def add(self, clip, rot_first=True):
        """UE local-space additive: R = A.R * B.R, T = B.T + A.T."""
        for i, q in clip["rot"].items():
            self.rot[i] = qnorm(qmul(q, self.rot[i]) if rot_first else qmul(self.rot[i], q))
        for i, v in clip["trans"].items(): self.trans[i] = tuple(a + b for a, b in zip(self.trans[i], v))

    def _mesh(self):
        if getattr(self, "_M", None) is None:
            M = [None] * len(self.names)
            for i in range(len(self.names)):
                p = self.parents[i]
                M[i] = self.rot[i] if p < 0 else qnorm(qmul(M[p], self.rot[i]))
            self._M = M
            kids = [[] for _ in self.names]
            for i, p in enumerate(self.parents):
                if p >= 0: kids[p].append(i)
            self._kids = kids
        return self._M

    def set_full(self, clip):  # noqa: F811 (redefined below to reset the mesh cache)
        for i, q in clip["rot"].items(): self.rot[i] = q
        for i, v in clip["trans"].items(): self.trans[i] = v
        for i, v in clip.get("scale", {}).items(): self.scale[i] = tuple(v)
        self._M = None

    def add_mesh_rot(self, clip):
        """UE AAT_RotationOffsetMeshSpace: each listed bone's mesh-space rotation is pre-multiplied by its offset
        (children keep their mesh rotation unless listed too); translations add locally. Incremental: only the
        listed bones and their children get new local rotations."""
        rot = clip["rot"]
        if rot:
            M = self._mesh(); sqrt = math.sqrt
            for i, (ax, ay, az, aw) in rot.items():      # qnorm(qmul(q, M[i])), inlined
                bx, by, bz, bw = M[i]
                x = aw * bx + ax * bw + ay * bz - az * by; y = aw * by - ax * bz + ay * bw + az * bx
                z = aw * bz + ax * by - ay * bx + az * bw; w = aw * bw - ax * bx - ay * by - az * bz
                n = sqrt(x * x + y * y + z * z + w * w) or 1.0
                M[i] = (x / n, y / n, z / n, w / n)
            key = tuple(rot); tc = self.__dict__.setdefault("_touch", {})
            touched = tc.get(key)
            if touched is None:
                touched = set(rot)
                for i in rot:
                    touched.update(self._kids[i])
                touched = tc[key] = [(i, self.parents[i]) for i in touched]
            R = self.rot
            for i, p in touched:
                if p < 0:
                    R[i] = M[i]
                else:
                    ax, ay, az, aw = M[p]; ax, ay, az = -ax, -ay, -az     # qnorm(qmul(conj(M[p]), M[i]))
                    bx, by, bz, bw = M[i]
                    x = aw * bx + ax * bw + ay * bz - az * by; y = aw * by - ax * bz + ay * bw + az * bx
                    z = aw * bz + ax * by - ay * bx + az * bw; w = aw * bw - ax * bx - ay * by - az * bz
                    n = sqrt(x * x + y * y + z * z + w * w) or 1.0
                    R[i] = (x / n, y / n, z / n, w / n)
        for i, v in clip["trans"].items(): self.trans[i] = tuple(a + b for a, b in zip(self.trans[i], v))

    def component(self):
        n = len(self.names); R = [None] * n; T = [None] * n; S = [None] * n
        for i in range(n):
            p = self.parents[i]
            if p < 0:
                R[i], T[i], S[i] = self.rot[i], self.trans[i], self.scale[i]
            else:
                lt = tuple(a * b for a, b in zip(self.trans[i], S[p]))
                T[i] = tuple(a + b for a, b in zip(qrot(R[p], lt), T[p]))
                R[i] = qnorm(qmul(R[p], self.rot[i])); S[i] = tuple(a * b for a, b in zip(S[p], self.scale[i]))
        self.cs = T; self.cs_rot = R; self.cs_scale = S
        self.names = list(self.names); self.parents = list(self.parents)
        return T

    def hidden(self, name, hidden_roots):
        i = self.index.get(name)
        while i is not None and i >= 0:
            if self.names[i] in hidden_roots:
                return True
            i = self.parents[i]
        return False

    def chain_length(self, bones, hidden_roots, measure_hidden=False, extra=0):
        """GetTrophyMultipleBoneLength: sum of distances between consecutive bones; 0 when the first is hidden,
        stops right after the first hidden bone; a name the mesh lacks counts as the mesh origin (see below)."""
        if len(bones) < 2 or any(b not in self.index for b in bones[:1]):
            return 0.0
        if not measure_hidden and self.hidden(bones[0], hidden_roots):
            return 0.0
        cs = self.cs; total = 0.0
        prev = cs[self.index[bones[0]]]
        for b in bones[1:]:
            # a name the mesh lacks reads as the mesh's own origin (the socket lookup falls back to the component
            # transform) and the walk goes on: the 1.3 elk typical points list ends BA6 -> BA62, a bone the rack
            # does not have (it ends at BA61), so every elk with a BA tine gets |BA6 - origin| (~150) per side
            cur = cs[self.index[b]] if b in self.index else (0.0, 0.0, 0.0)
            total += math.dist(prev, cur)
            if not measure_hidden and self.hidden(b, hidden_roots):
                if extra <= 0:
                    break
                extra -= 1
            prev = cur
        return total
