"""Game-file patches (not save edits), each fully undoable and independent of the others.

The containers are IoStore (.utoc/.ucas, unsigned, unencrypted). A patch builds new bytes for whole chunks
(packages, the container header) from the PRISTINE game data; applying writes them as new uncompressed blocks at
the end of the .ucas and repoints the chunk's offset/length entry in the .utoc at them (chunks are block-aligned,
so a moved chunk simply starts at the next free block of the container's virtual space). Every change of a switch
restores the pristine .utoc (backup in user_data_dir/gamepatch/), cuts the .ucas back to its old length and
re-applies every switch that is still on. A Steam 'verify files' or a game update also undoes all of it (then
simply switch them on again).

UTV: the game ships a finished side-by-side (BP_VehicleUTV, DA_VehicleConfig_UTV) that no menu hands out.
DA_VehicleConfigs.m_vehicleConfigs = [Offroad03 (the truck), UTV, Offroad03_Demo], and every caller asks for
config 0: GA_RecallVehicle (parking spots) and WBP_UiPage_Nexus (Nexus 'Garage' tile) both run
RecallVehicleServer(IntConst 0) -> BP_VehicleManagement 'Recall Vehicle BP' -> LoadVehicleConfig(id) ->
m_vehicleConfigs[id]. The save keeps only where the vehicle is parked, never which one, so the only switch is
the order of that array: swapping its first two import indices makes every recall bring the UTV.

MENU RARES: the title screen is a living level (MainMenu01) whose animals are never saved - the herd system rolls
them fresh on every start. Which coat an animal gets comes from the level's BP_HerdManagement_<Level>_WS class
default: mAnimalSubspeciesToRarityData = map subspecies tag -> {RarityToFurDistribution: map ERarity ->
{Weight, MaleAnimalConfigs[], FemaleAnimalConfigs[]}}; the game rolls a rarity by weight (Map01: Common 98000,
Rare 100, VeryRare 10) and then picks one config of that rarity at random. The menu's class sets no table at all
(plain animals only). The patch gives it one, for every species of the menu ecosystem that New Laurentia's table
knows (moose, mule deer, grizzly), with ALL of that species' rare coats in every rarity slot - whatever the roll,
the animal comes out albino / leucistic / melanistic / piebald, picked at random. The config references are hard
imports, so the menu package gets the extra imports and its store entry in the container header the extra
imported packages.
"""
import json, os, shutil, struct
import hostos

import nrgs, woth2_paks as paks, zenpkg

def _state_dir():
    import trainer_core
    d = os.path.join(trainer_core.user_data_dir(), "gamepatch")
    os.makedirs(d, exist_ok=True)
    return d

def _record_path(container):
    return os.path.join(_state_dir(), container + ".json")

def _records():
    out = {}
    try:
        d = _state_dir()
    except OSError:
        return out
    for f in os.listdir(d):
        if f.endswith(".json"):
            try:
                r = json.load(open(os.path.join(d, f)))
                r.setdefault("patches", ["utv"])          # records from before the multi-patch rework = UTV only
                out[r["container"]] = r
            except (OSError, ValueError, KeyError):
                pass
    return out

def drop_stale(pd):
    """Forget patches a game update or Steam 'verify files' already replaced: the live container is not the size
    our patch left it, so its saved .utoc copy is from an older game and must never be put back over the new one."""
    for c, r in _records().items():
        utoc = os.path.join(pd, c + ".utoc"); ucas = os.path.join(pd, c + ".ucas")
        try:
            stale = os.path.getsize(ucas) != r["patched_ucas_size"] or ("patched_utoc_size" in r and os.path.getsize(utoc) != r["patched_utoc_size"])
        except OSError:
            stale = True                                   # container gone (game moved / uninstalled)
        if stale:
            for f in (r.get("utoc_backup", ""), _record_path(c)):
                try: os.remove(f)
                except OSError: pass

def patched_sizes():
    """{ucas basename: size before our appended blocks} for containers we grew (woth2_paks.game_build uses it,
    so a patch does not look like a game update and the map caches stay valid)."""
    out = {}
    for c, r in _records().items():
        out[c + ".ucas"] = (r["ucas_size"], r["patched_ucas_size"])
        if "utoc_size" in r:                               # the .utoc grows by the appended block entries
            out[c + ".utoc"] = (r["utoc_size"], r["patched_utoc_size"])
    return out

def enabled_patches():
    return sorted({p for r in _records().values() for p in r["patches"]})

# ---------------------------------------------------------------- pristine game data
class _Ctx:
    """Pristine view of every container (the .utoc backup when we patched it) + the chunk bytes built so far."""
    def __init__(self, pd, records):
        self.pd, self.tocs, self.new = pd, {}, {}
        for utoc in sorted(f for f in os.listdir(pd) if f.startswith("pakchunk") and f.endswith("-Windows.utoc")):
            c = utoc[:-5]
            live = os.path.join(pd, utoc)
            src = records[c]["utoc_backup"] if c in records else live
            self.tocs[c] = paks.Toc(src, ucas=live[:-5] + ".ucas")

    def find(self, basename):
        for c, t in self.tocs.items():
            for path, idx in t.files.items():
                if path.endswith("/" + basename):
                    return c, idx
        raise FileNotFoundError(basename + " not found in the game files")

    def read(self, c, idx):
        return self.new.get((c, idx)) or self.tocs[c].read(idx)

    def chunk_type_index(self, c, ctype):
        b = open(self.tocs[c].path, "rb").read()
        hdr, ecount = struct.unpack_from("<II", b, 20)
        for i in range(ecount):
            if b[hdr + 12 * i + 11] == ctype:
                return i
        raise ValueError("no chunk of type %d in %s" % (ctype, c))

# ---------------------------------------------------------------- UTV
VEHICLES = "DA_VehicleConfigs.uasset"
TRUCK_FIRST = struct.pack("<ii", -7, -8)       # [Offroad03, UTV, ...]: the shipped order
UTV_FIRST = struct.pack("<ii", -8, -7)          # [UTV, Offroad03, ...]
HEAD = b"\x00\x03\x03\x00\x00\x00"               # unversioned header (1 property) + array count 3

def _vehicle_array(data):
    names = (b"DA_VehicleConfig_Offroad03_Demo", b"DA_VehicleConfig_UTV", b"DA_VehicleConfig_Offroad03\x00")
    if not all(n in data for n in names):
        raise ValueError("DA_VehicleConfigs does not list the truck and the UTV any more (game updated?)")
    hits = [i for i in range(len(data)) if data.startswith(HEAD, i) and data[i + 6:i + 14] in (TRUCK_FIRST, UTV_FIRST)
            and data[i + 14:i + 18] == struct.pack("<i", -6)]
    if len(hits) != 1:
        raise ValueError("could not find the vehicle list in DA_VehicleConfigs (game updated?)")
    return hits[0] + 6

def _build_utv(ctx):
    c, idx = ctx.find(VEHICLES)
    data = bytearray(ctx.read(c, idx))
    at = _vehicle_array(data)
    data[at:at + 8] = UTV_FIRST
    return {(c, idx): bytes(data)}

def _utv_live(pd):
    data = paks.find_package(pd, VEHICLES)
    data = data[0].read(data[1])
    at = _vehicle_array(data)
    return data[at:at + 8] == UTV_FIRST

# ---------------------------------------------------------------- MENU RARES
MENU_HERD = "BP_HerdManagement_MainMenu01_WS.uasset"
MENU_ECOSYSTEM = "DA_HerdEcosystem_MainMenu01_Land01.uasset"
RARITY_SOURCE = "BP_HerdManagement_Map01_WS.uasset"     # New Laurentia: same species as the menu
MENU_CDO_HEAD = b"\x01\x02\x90\x03\x01"                  # props 1 (ecosystems) + 18 (zero) - the shipped menu default
RARITIES = ("ERarity::Common", "ERarity::Rare", "ERarity::VeryRare")
CONTAINER_HEADER = 6                                     # EIoChunkType::ContainerHeader

def rarity_table(z):
    """Decode a herd class default -> (prop1 bytes, {tag: [(rarity, weight, [male import idx], [female])]})."""
    c = z.export_data[-1]
    if c[:4] == b"\x01\x02\x08\x03":                     # props 1 + 10 (the hunting maps)
        p = 4
    elif c[:7] == b"\x01\x02\x08\x02\x87\x03\x01":         # props 1 + 10 + 18 (zero): the patched menu
        p = 7
    else:
        raise ValueError("unexpected herd management default layout (game updated?)")
    n, = struct.unpack_from("<i", c, p + 4); p1 = c[p:p + 8 + 4 * n]; p += 8 + 4 * n
    n, = struct.unpack_from("<i", c, p + 4); p += 8
    out = {}
    def fname(p):
        i, num = struct.unpack_from("<II", c, p)
        return z.name(i) + ("_%d" % (num - 1) if num else "")
    for _ in range(n):
        if c[p:p + 2] != b"\0\3":
            raise ValueError("unexpected rarity table layout")
        tag = fname(p + 2); p += 10
        if c[p:p + 2] != b"\0\3":
            raise ValueError("unexpected rarity table layout")
        m, = struct.unpack_from("<i", c, p + 6); p += 10
        rows = []
        for _ in range(m):
            r = fname(p); p += 8
            if c[p:p + 2] != b"\0\7":
                raise ValueError("unexpected rarity entry layout")
            w, = struct.unpack_from("<i", c, p + 2); p += 6
            lists = []
            for _ in range(2):
                k, = struct.unpack_from("<i", c, p); p += 4
                lists.append([-x - 1 for x in struct.unpack_from("<%di" % k, c, p)]); p += 4 * k
            rows.append((r, w, lists[0], lists[1]))
        out[tag] = rows
    if c[p:] != b"\0\0\0\0":
        raise ValueError("rarity table not fully read")
    return p1, out

def _import_ref(z, k):
    """import index -> (package name, package name hash, package number, public export hash)"""
    sp = zenpkg.split_import(z.imports[k])
    if not sp:
        raise ValueError("animal config is not a package import")
    pk, hi = sp
    nm, h = z.package_names[pk][:2]
    return nm, h, z.package_numbers[pk], z.imported_hashes[hi]

def menu_rare_plan(ctx):
    """-> {tag: (male refs, female refs)}: every rare config of each menu species (from New Laurentia's table)."""
    src = zenpkg.ZenPackage(ctx.read(*ctx.find(RARITY_SOURCE)))
    _p1, table = rarity_table(src)
    eco = paks.package_names(ctx.read(*ctx.find(MENU_ECOSYSTEM)))
    plan = {}
    for tag, rows in table.items():
        if tag not in eco:
            continue
        males, females = [], []
        for r, _w, ms, fs in rows:
            if r == "ERarity::Common":
                continue
            males += [_import_ref(src, k) for k in ms if _import_ref(src, k) not in males]
            females += [_import_ref(src, k) for k in fs if _import_ref(src, k) not in females]
        if males and females:
            plan[tag] = (males, females)
    if not plan:
        raise ValueError("no menu species with rare coats found (game updated?)")
    return plan

def _build_menu_rares(ctx):
    c, idx = ctx.find(MENU_HERD)
    z = zenpkg.ZenPackage(ctx.read(c, idx))
    cdo = z.export_data[-1]
    if not cdo.startswith(MENU_CDO_HEAD) or cdo[-4:] != b"\0\0\0\0" or len(cdo) != len(MENU_CDO_HEAD) + 12 + 4:
        raise ValueError("the menu's herd management is not the one this patch knows (game updated?)")
    prop1 = cdo[len(MENU_CDO_HEAD):-4]
    plan = menu_rare_plan(ctx)
    ch_idx = ctx.chunk_type_index(c, CONTAINER_HEADER)
    ch = zenpkg.ContainerHeader(ctx.read(c, ch_idx))
    pid = zenpkg.package_id(z.name(z.name_index & 0xFFFFFFFF))
    old_ids = [zenpkg.package_id(n[0]) for n in z.package_names]
    if ch.imports_of(pid) != old_ids:
        raise ValueError("menu herd package does not match its container entry")

    # names: subspecies tags + rarity enum values
    def name(s):
        try:
            return z.name_idx(s)
        except ValueError:
            z.names.append((s, zenpkg.name_hash(s)))
            return len(z.names) - 1
    # imported packages (kept sorted by package id, like the cooker) + the new imports
    refs = []
    for ms, fs in plan.values():
        refs += [r for r in ms + fs if r not in refs]
    old_pk = list(z.package_names)
    pk_entries = [(n[0], n[1], num) for n, num in zip(old_pk, z.package_numbers)]
    for nm, h, num, _eh in refs:
        if all(e[0] != nm for e in pk_entries):
            pk_entries.append((nm, h, num))
    pk_entries.sort(key=lambda e: zenpkg.package_id(e[0]))
    pos = {e[0]: i for i, e in enumerate(pk_entries)}
    remap = {i: pos[n[0]] for i, n in enumerate(old_pk)}
    for k, v in enumerate(z.imports):
        sp = zenpkg.split_import(v)
        if sp:
            z.imports[k] = zenpkg.package_import(remap[sp[0]], sp[1])
    z.package_names = [(e[0], e[1]) for e in pk_entries]
    z.package_numbers = [e[2] for e in pk_entries]
    ref_index = {}
    for r in refs:
        z.imported_hashes.append(r[3])
        z.imports.append(zenpkg.package_import(pos[r[0]], len(z.imported_hashes) - 1))
        ref_index[r] = len(z.imports) - 1

    # class default: props 1 (ecosystems, unchanged), 10 (rarity table), 18 (zero, unchanged)
    def arr(rs):
        return struct.pack("<i", len(rs)) + b"".join(struct.pack("<i", -ref_index[r] - 1) for r in rs)
    body = struct.pack("<ii", 0, len(plan))
    for tag, (ms, fs) in plan.items():
        body += b"\0\3" + struct.pack("<II", name(tag), 0)
        body += b"\0\3" + struct.pack("<ii", 0, len(RARITIES))
        for r, w in zip(RARITIES, (98000, 100, 10)):
            body += struct.pack("<II", name(r), 0) + b"\0\7" + struct.pack("<i", w) + arr(ms) + arr(fs)
    z.export_data[-1] = struct.pack("<HHHB", 0x0201, 0x0208, 0x0387, 1) + prop1 + body + b"\0\0\0\0"

    # the class default must not be serialized before the configs it points at exist (serialize-before-create)
    hdr = z.dep_headers[-1]
    at = hdr[0] + hdr[1] + hdr[2] + hdr[3]
    new_deps = [-ref_index[r] - 1 for r in refs]
    z.dep_entries[at:at] = new_deps
    hdr[3] += len(new_deps)
    for h in z.dep_headers:
        if h is not hdr and h[0] >= at:
            h[0] += len(new_deps)

    pkg = z.build()
    ch.set_imports(pid, [zenpkg.package_id(e[0]) for e in pk_entries])
    # read back
    z2 = zenpkg.ZenPackage(pkg)
    _p, t2 = rarity_table(z2)
    if set(t2) != set(plan):
        raise RuntimeError("menu rarity table did not read back")
    return {(c, idx): pkg, (c, ch_idx): ch.build()}

def _menu_rares_live(pd):
    t, idx = paks.find_package(pd, MENU_HERD)
    z = zenpkg.ZenPackage(t.read(idx))
    return len(z.export_data[-1]) > len(MENU_CDO_HEAD) + 16

def menu_animals(save_path=None):
    """-> [{species tag, males: [config names], females: [...]}] that the patch puts on the title screen."""
    pd = paks.find_paks_dir(save_path)
    ctx = _Ctx(pd, _records())
    try:
        names = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "names_en.json")))
    except (OSError, ValueError):
        names = {}
    out = []
    for tag, (ms, fs) in menu_rare_plan(ctx).items():
        sp = tag.split(".")[-1]
        coats = []
        for r in ms + fs:
            c = r[0].rsplit("_", 1)[1].replace("Leucisitc", "Leucistic").lower()
            if c not in coats:
                coats.append(c)
        out.append({"species": sp, "label": names.get("KEY_ANIMALS_SUBSPECIES_%s_NAME" % sp.upper(), sp), "coats": coats})
    return out

# ---------------------------------------------------------------- RARE HERDS
# Every map's herd table rolls Common 98000 : Rare 100 : VeryRare 10 per subspecies. Common 1 / VeryRare 100 makes
# ~99.5 % of the animals of those species roll a rare coat, half of them VeryRare, whenever the game builds a
# population (after a herd reset).
# Same-size edit of the i32 weights -> patched in place. Species outside a map's table (hares, birds...) stay normal.
RARE_HERD_MAPS = ("Map01", "Map02", "Hub")
RARE_COMMON_WEIGHT = 1
RARE_VERYRARE_WEIGHT = 100                                 # = Rare: half of the rares come out VeryRare (game: 10 -> 1 in 11)

def _weight_offsets(z):
    """-> [(byte offset in the class default, rarity, weight)] of every rarity weight in the herd table."""
    c = z.export_data[-1]
    p = 4 if c[:4] == b"\x01\x02\x08\x03" else None
    if p is None:
        raise ValueError("unexpected herd management default layout (game updated?)")
    n, = struct.unpack_from("<i", c, p + 4); p += 8 + 4 * n
    n, = struct.unpack_from("<i", c, p + 4); p += 8
    out = []
    for _ in range(n):
        p += 10
        m, = struct.unpack_from("<i", c, p + 6); p += 10
        for _ in range(m):
            r = z.name(struct.unpack_from("<I", c, p)[0]); p += 8 + 2
            out.append((p, r, struct.unpack_from("<i", c, p)[0])); p += 4
            for _ in range(2):
                k, = struct.unpack_from("<i", c, p); p += 4 + 4 * k
    return out

def _build_rare_herds(ctx):
    out = {}
    for m in RARE_HERD_MAPS:
        c, idx = ctx.find(f"BP_HerdManagement_{m}_WS.uasset")
        data = ctx.read(c, idx)
        z = zenpkg.ZenPackage(data)
        rarity_table(z)                                    # layout check
        cdo = bytearray(z.export_data[-1])
        for at, r, w in _weight_offsets(z):
            if r == "ERarity::Common":
                struct.pack_into("<i", cdo, at, RARE_COMMON_WEIGHT)
            elif r == "ERarity::VeryRare":
                struct.pack_into("<i", cdo, at, RARE_VERYRARE_WEIGHT)
        z.export_data[-1] = bytes(cdo)
        new = z.build()
        if len(new) != len(data):
            raise RuntimeError("rare herds patch changed the package size")
        out[(c, idx)] = new
    return out

def _rare_herds_live(pd):
    """on when ANY map's herd table carries the patched weights (all three are checked, not just New Laurentia)"""
    for m in RARE_HERD_MAPS:
        t, idx = paks.find_package(pd, f"BP_HerdManagement_{m}_WS.uasset")
        z = zenpkg.ZenPackage(t.read(idx))
        if any(r == "ERarity::Common" and w == RARE_COMMON_WEIGHT for _a, r, w in _weight_offsets(z)):
            return True
    return False

def rare_herds_status(save_path=None):
    return status("rare_herds", save_path)

def set_rare_herds(on, save_path=None, force=False):
    """Make new herds roll (almost) only rare coats (on) or the game's normal odds (off). -> notes"""
    was = switch("rare_herds", on, save_path, force)
    if not on:
        return ["rare herds off: the game is back to its normal rare odds"] if was else ["the game already uses its normal rare odds"]
    if was:
        return ["rare herds are already switched on"]
    return ["rare herds on: the next time a map builds new herds about 99 % of its moose, deer, elk, bison, wolves, bears, lions, buffalo, wildebeest, kudu and crocodiles roll a rare coat, about half of them very rare ones",
            "now reset the herds of the maps you want (Map page) and load them in the game once",
            "switch it off again afterwards - the rares that were rolled stay"]

PATCHES = {
    "utv": (_build_utv, _utv_live),
    "menu_rares": (_build_menu_rares, _menu_rares_live),
    "rare_herds": (_build_rare_herds, _rare_herds_live),
}

# ---------------------------------------------------------------- apply
def _block_table_offset(b):
    ver, hdr, ecount, cbcount = struct.unpack_from("<BxxxIII", b, 16)
    phs, _psize, nph = struct.unpack_from("<IQI", b, 84)
    p = hdr + 12 * ecount + 10 * ecount
    if ver >= 4:
        p += 4 * phs
    if ver >= 5:
        p += 4 * nph
    return p, cbcount

def _write_container(pd, container, rec, chunks, patches, toc):
    """Restore the pristine container, then (if chunks) write them and repoint the .utoc. -> new record or None
    A chunk that keeps its size is patched IN PLACE: only its changed compression blocks are appended (uncompressed)
    and their 12-byte block entries repointed - the .utoc keeps its layout (the method the UTV switch used while the
    game ran fine, 2026-10-05). Only a chunk that changes size is moved to new blocks at the end of the container's
    virtual space (that method was live when the title screen lost its animals - still unproven either way)."""
    utoc = os.path.join(pd, container + ".utoc")
    ucas = utoc[:-5] + ".ucas"
    if rec:
        shutil.copyfile(rec["utoc_backup"], utoc)
        with hostos.open_big(ucas, "r+b") as f:
            f.truncate(rec["ucas_size"])
    if not chunks:
        if rec:
            os.remove(rec["utoc_backup"]); os.remove(_record_path(container))
        return None
    b = bytearray(open(utoc, "rb").read())
    utoc_size = len(b)
    ver, hdr, ecount = struct.unpack_from("<BxxxII", b, 16)
    cbs, = struct.unpack_from("<I", b, 44)
    table, cbcount = _block_table_offset(b)
    ucas_size = os.path.getsize(ucas)
    pcount, psize = struct.unpack_from("<I", b, 52)[0], struct.unpack_from("<Q", b, 88)[0]
    total = sum(len(v) for v in chunks.values()) + 16 * len(chunks) + 16
    if pcount > 1 or ucas_size + total > psize:          # one .ucas, no size cap (the game: 1, 0xFFFF...)
        raise RuntimeError("this game build splits its containers, the patch cannot be applied safely")
    backup = os.path.join(_state_dir(), container + ".utoc.orig")
    if not rec:
        shutil.copyfile(utoc, backup)
    end = (ucas_size + 15) // 16 * 16                    # appended blocks 16-byte aligned like the game's own
    entries = b""
    nblocks = cbcount
    with hostos.open_big(ucas, "r+b") as f:
        f.seek(ucas_size); f.write(b"\0" * (end - ucas_size))
        for idx in sorted(chunks):
            data = chunks[idx]
            off, ln = toc.ol[idx]
            if ln == len(data):                              # same size: patch only the blocks that changed
                if off % cbs:
                    raise RuntimeError("chunk is not block-aligned")
                for bi in range(off // cbs, (off + ln - 1) // cbs + 1):
                    bo, cs, us, m = toc.blocks[bi]
                    f.seek(bo); raw = f.read(cs)
                    old = raw if m == 0 else nrgs.oodle_decompress(raw, us)
                    lo = bi * cbs - off
                    part = data[lo:lo + us]
                    new_blk = part + old[len(part):]                # a chunk's last block may carry padding past its end
                    if new_blk == old:
                        continue
                    f.seek(end); f.write(new_blk)
                    e = table + 12 * bi
                    b[e:e + 12] = end.to_bytes(5, "little") + len(new_blk).to_bytes(3, "little") + len(new_blk).to_bytes(3, "little") + b"\0"
                    end += len(new_blk)
                continue
            f.seek(end)
            vstart = nblocks * cbs
            for k in range(0, len(data), cbs):
                blk = data[k:k + cbs]
                f.write(blk)
                entries += end.to_bytes(5, "little") + len(blk).to_bytes(3, "little") + len(blk).to_bytes(3, "little") + b"\0"
                end += len(blk); nblocks += 1
            ol = hdr + 12 * ecount + 10 * idx
            b[ol:ol + 10] = vstart.to_bytes(5, "big") + len(data).to_bytes(5, "big")
    if entries:
        b[table + 12 * cbcount:table + 12 * cbcount] = entries
        struct.pack_into("<I", b, 28, nblocks)
    with open(utoc + ".tmp", "wb") as f:
        f.write(b)
    os.replace(utoc + ".tmp", utoc)
    new = {"container": container, "ucas_size": ucas_size, "patched_ucas_size": end, "utoc_backup": backup,
           "utoc_size": utoc_size, "patched_utoc_size": len(b),
           "patches": sorted(patches)}
    json.dump(new, open(_record_path(container), "w"))
    return new

def apply(wanted, save_path=None):
    """Make the game files carry exactly the patches in `wanted` (names from PATCHES)."""
    pd = paks.find_paks_dir(save_path)
    if not pd:
        raise FileNotFoundError("game files not found")
    drop_stale(pd)
    records = _records()
    ctx = _Ctx(pd, records)
    by_container, owners = {}, {}
    for name in sorted(wanted):
        for (c, idx), data in PATCHES[name][0](ctx).items():   # everything is built before any file is touched
            ctx.new[(c, idx)] = data
            by_container.setdefault(c, {})[idx] = data
            owners.setdefault(c, set()).add(name)
    for c in sorted(set(records) | set(by_container)):
        _write_container(pd, c, records.get(c), by_container.get(c), owners.get(c, ()), ctx.tocs[c])
    paks._toc_cache.clear()

def status(name, save_path=None):
    """-> {"available": bool, "on": bool, "error": str}"""
    try:
        pd = paks.find_paks_dir(save_path)
        if not pd:
            return {"available": False, "on": False, "error": "game files not found"}
        paks._toc_cache.clear()
        return {"available": True, "on": bool(PATCHES[name][1](pd)), "error": ""}
    except Exception as e:
        return {"available": False, "on": False, "error": str(e)}

def switch(name, on, save_path=None, force=False):
    import trainer_core
    if trainer_core.game_running() and not force:
        raise RuntimeError("The game is running. Close it first.")
    pd = paks.find_paks_dir(save_path)
    if pd: drop_stale(pd)                                  # after a game update the old switches are off, not stale
    before = set(enabled_patches())
    was = name in before
    wanted = before | {name} if on else before - {name}
    apply(wanted, save_path)
    pd = paks.find_paks_dir(save_path)
    if any(bool(PATCHES[p][1](pd)) != (p in wanted) for p in PATCHES):
        apply(before, save_path)
        raise RuntimeError("patch did not read back, game files put back as they were")
    return was

# ---------------------------------------------------------------- switches the app calls
def utv_status(save_path=None):
    return status("utv", save_path)

def set_utv(on, save_path=None, force=False):
    """Make every vehicle recall bring the UTV (on) or the truck again (off). -> notes"""
    was = switch("utv", on, save_path, force)
    if not on:
        return ["the truck is already the vehicle you get"] if not was else \
               ["game files restored: vehicle recalls bring the truck again"]
    if was:
        return ["the UTV is already switched on"]
    return ["UTV switched on: recalling your vehicle (parking spot or Nexus > Garage) now brings the UTV",
            "a vehicle that is already parked in the world stays a truck until you recall it",
            "Steam 'verify files' or a game update puts the truck back - just switch it on again"]

def menu_rares_status(save_path=None):
    return status("menu_rares", save_path)

def set_menu_rares(on, save_path=None, force=False):
    """Fill the title screen with nothing but rare-coat animals (on) or the game's normal ones (off). -> notes"""
    was = switch("menu_rares", on, save_path, force)
    if not on:
        return ["title screen animals are back to normal"] if was else ["the title screen already has normal animals"]
    if was:
        return ["the title screen already shows only rare animals"]
    kinds = menu_animals(save_path)
    sp = ", ".join(k["label"] for k in kinds)
    return ["title screen now rolls only rare coats - a new random mix every time the game starts (" + sp + ")",
            "snowshoe hares have no rare coats in this game, they stay normal",
            "Steam 'verify files' or a game update puts the normal animals back - just switch it on again"]
