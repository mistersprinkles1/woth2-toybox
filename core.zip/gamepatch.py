"""Game-file patches (not save edits), each fully undoable and independent of the others.

The containers are IoStore (.utoc/.ucas, unsigned, unencrypted). A patch builds new bytes for whole chunks
(packages, the container header) from the PRISTINE game data; applying writes them as new uncompressed blocks at
the end of the .ucas and repoints the chunk's offset/length entry in the .utoc at them (chunks are block-aligned,
so a moved chunk simply starts at the next free block of the container's virtual space). Every change of a switch
restores the pristine .utoc (backup in user_data_dir/gamepatch/), cuts the .ucas back to its old length and
re-applies every switch that is still on. A Steam 'verify files' or a game update also undoes all of it (then
simply switch them on again).

UTV: the game ships a finished side-by-side (BP_VehicleUTV, DA_VehicleConfig_UTV) that no menu hands out.
DA_VehicleConfigs.m_vehicleConfigs = [Offroad03 (the truck), UTV, Offroad03_Demo], and every caller asks for
config 0: GA_RecallVehicle (parking spots) and WBP_UiPage_Nexus (Nexus 'Garage' tile) both run
RecallVehicleServer(IntConst 0) -> BP_VehicleManagement 'Recall Vehicle BP' -> LoadVehicleConfig(id) ->
m_vehicleConfigs[id]. The save keeps only where the vehicle is parked, never which one, so the only switch is
the order of that array: swapping its first two import indices makes every recall bring the UTV.
"""
import json, os, shutil, struct
import hostos

import nrgs, woth2_paks as paks, zenpkg

def _state_dir():
    import trainer_core
    d = os.path.join(trainer_core.user_data_dir(), "gamepatch")
    os.makedirs(d, exist_ok=True)
    return d

def _record_path(container):
    return os.path.join(_state_dir(), container + ".json")

def _records():
    out = {}
    try:
        d = _state_dir()
    except OSError:
        return out
    for f in os.listdir(d):
        if f.endswith(".json"):
            try:
                r = json.load(open(os.path.join(d, f)))
                r.setdefault("patches", ["utv"])          # records from before the multi-patch rework = UTV only
                out[r["container"]] = r
            except (OSError, ValueError, KeyError):
                pass
    return out

def drop_stale(pd):
    """Forget patches a game update or Steam 'verify files' already replaced: the live container is not the size
    our patch left it, so its saved .utoc copy is from an older game and must never be put back over the new one."""
    for c, r in _records().items():
        utoc = os.path.join(pd, c + ".utoc"); ucas = os.path.join(pd, c + ".ucas")
        try:
            stale = os.path.getsize(ucas) != r["patched_ucas_size"] or ("patched_utoc_size" in r and os.path.getsize(utoc) != r["patched_utoc_size"])
        except OSError:
            stale = True                                   # container gone (game moved / uninstalled)
        if stale:
            for f in (r.get("utoc_backup", ""), _record_path(c)):
                try: os.remove(f)
                except OSError: pass

def patched_sizes():
    """{ucas basename: size before our appended blocks} for containers we grew (woth2_paks.game_build uses it,
    so a patch does not look like a game update and the map caches stay valid)."""
    out = {}
    for c, r in _records().items():
        out[c + ".ucas"] = (r["ucas_size"], r["patched_ucas_size"])
        if "utoc_size" in r:                               # the .utoc grows by the appended block entries
            out[c + ".utoc"] = (r["utoc_size"], r["patched_utoc_size"])
    return out

RETIRED = {"menu_rares"}       # switches taken out of the app (title-screen rares broke the game): undone when seen

def enabled_patches():
    return sorted({p for r in _records().values() for p in r["patches"]} - RETIRED)

def _undo_retired(save_path=None):
    """A switch that was taken out of the app but is still in someone's game files: put those files back."""
    import trainer_core
    if not ({p for r in _records().values() for p in r["patches"]} & RETIRED) or trainer_core.game_running():
        return
    apply(set(enabled_patches()), save_path)

# ---------------------------------------------------------------- pristine game data
class _Ctx:
    """Pristine view of every container (the .utoc backup when we patched it) + the chunk bytes built so far."""
    def __init__(self, pd, records):
        self.pd, self.tocs, self.new = pd, {}, {}
        for utoc in sorted(f for f in os.listdir(pd) if f.startswith("pakchunk") and f.endswith("-Windows.utoc")):
            c = utoc[:-5]
            live = os.path.join(pd, utoc)
            src = records[c]["utoc_backup"] if c in records else live
            self.tocs[c] = paks.Toc(src, ucas=live[:-5] + ".ucas")

    def find(self, basename):
        for c, t in self.tocs.items():
            for path, idx in t.files.items():
                if path.endswith("/" + basename):
                    return c, idx
        raise FileNotFoundError(basename + " not found in the game files")

    def read(self, c, idx):
        return self.new.get((c, idx)) or self.tocs[c].read(idx)

# ---------------------------------------------------------------- UTV
VEHICLES = "DA_VehicleConfigs.uasset"
TRUCK_FIRST = struct.pack("<ii", -7, -8)       # [Offroad03, UTV, ...]: the shipped order
UTV_FIRST = struct.pack("<ii", -8, -7)          # [UTV, Offroad03, ...]
HEAD = b"\x00\x03\x03\x00\x00\x00"               # unversioned header (1 property) + array count 3

def _vehicle_array(data):
    names = (b"DA_VehicleConfig_Offroad03_Demo", b"DA_VehicleConfig_UTV", b"DA_VehicleConfig_Offroad03\x00")
    if not all(n in data for n in names):
        raise ValueError("DA_VehicleConfigs does not list the truck and the UTV any more (game updated?)")
    hits = [i for i in range(len(data)) if data.startswith(HEAD, i) and data[i + 6:i + 14] in (TRUCK_FIRST, UTV_FIRST)
            and data[i + 14:i + 18] == struct.pack("<i", -6)]
    if len(hits) != 1:
        raise ValueError("could not find the vehicle list in DA_VehicleConfigs (game updated?)")
    return hits[0] + 6

def _build_utv(ctx):
    c, idx = ctx.find(VEHICLES)
    data = bytearray(ctx.read(c, idx))
    at = _vehicle_array(data)
    data[at:at + 8] = UTV_FIRST
    return {(c, idx): bytes(data)}

def _utv_live(pd):
    data = paks.find_package(pd, VEHICLES)
    data = data[0].read(data[1])
    at = _vehicle_array(data)
    return data[at:at + 8] == UTV_FIRST

# ---------------------------------------------------------------- herd rarity tables (rare herds)
def rarity_table(z):
    """Decode a herd class default -> (prop1 bytes, {tag: [(rarity, weight, [male import idx], [female])]})."""
    c = z.export_data[-1]
    if c[:4] == b"\x01\x02\x08\x03":                     # props 1 + 10 (the hunting maps)
        p = 4
    else:
        raise ValueError("unexpected herd management default layout (game updated?)")
    n, = struct.unpack_from("<i", c, p + 4); p1 = c[p:p + 8 + 4 * n]; p += 8 + 4 * n
    n, = struct.unpack_from("<i", c, p + 4); p += 8
    out = {}
    def fname(p):
        i, num = struct.unpack_from("<II", c, p)
        return z.name(i) + ("_%d" % (num - 1) if num else "")
    for _ in range(n):
        if c[p:p + 2] != b"\0\3":
            raise ValueError("unexpected rarity table layout")
        tag = fname(p + 2); p += 10
        if c[p:p + 2] != b"\0\3":
            raise ValueError("unexpected rarity table layout")
        m, = struct.unpack_from("<i", c, p + 6); p += 10
        rows = []
        for _ in range(m):
            r = fname(p); p += 8
            if c[p:p + 2] != b"\0\7":
                raise ValueError("unexpected rarity entry layout")
            w, = struct.unpack_from("<i", c, p + 2); p += 6
            lists = []
            for _ in range(2):
                k, = struct.unpack_from("<i", c, p); p += 4
                lists.append([-x - 1 for x in struct.unpack_from("<%di" % k, c, p)]); p += 4 * k
            rows.append((r, w, lists[0], lists[1]))
        out[tag] = rows
    if c[p:] != b"\0\0\0\0":
        raise ValueError("rarity table not fully read")
    return p1, out

# ---------------------------------------------------------------- RARE HERDS
# Every map's herd table rolls Common 98000 : Rare 100 : VeryRare 10 per subspecies. Common 1 / VeryRare 100 makes
# ~99.5 % of the animals of those species roll a rare coat, half of them VeryRare, whenever the game builds a
# population (after a herd reset).
# Same-size edit of the i32 weights -> patched in place. Species outside a map's table (hares, birds...) stay normal.
RARE_HERD_MAPS = ("Map01", "Map02", "Hub")
RARE_COMMON_WEIGHT = 1
RARE_VERYRARE_WEIGHT = 100                                 # = Rare: half of the rares come out VeryRare (game: 10 -> 1 in 11)

def _weight_offsets(z):
    """-> [(byte offset in the class default, rarity, weight)] of every rarity weight in the herd table."""
    c = z.export_data[-1]
    p = 4 if c[:4] == b"\x01\x02\x08\x03" else None
    if p is None:
        raise ValueError("unexpected herd management default layout (game updated?)")
    n, = struct.unpack_from("<i", c, p + 4); p += 8 + 4 * n
    n, = struct.unpack_from("<i", c, p + 4); p += 8
    out = []
    for _ in range(n):
        p += 10
        m, = struct.unpack_from("<i", c, p + 6); p += 10
        for _ in range(m):
            r = z.name(struct.unpack_from("<I", c, p)[0]); p += 8 + 2
            out.append((p, r, struct.unpack_from("<i", c, p)[0])); p += 4
            for _ in range(2):
                k, = struct.unpack_from("<i", c, p); p += 4 + 4 * k
    return out

def _build_rare_herds(ctx):
    out = {}
    for m in RARE_HERD_MAPS:
        c, idx = ctx.find(f"BP_HerdManagement_{m}_WS.uasset")
        data = ctx.read(c, idx)
        z = zenpkg.ZenPackage(data)
        rarity_table(z)                                    # layout check
        cdo = bytearray(z.export_data[-1])
        for at, r, w in _weight_offsets(z):
            if r == "ERarity::Common":
                struct.pack_into("<i", cdo, at, RARE_COMMON_WEIGHT)
            elif r == "ERarity::VeryRare":
                struct.pack_into("<i", cdo, at, RARE_VERYRARE_WEIGHT)
        z.export_data[-1] = bytes(cdo)
        new = z.build()
        if len(new) != len(data):
            raise RuntimeError("rare herds patch changed the package size")
        out[(c, idx)] = new
    return out

def _rare_herds_live(pd):
    """on when ANY map's herd table carries the patched weights (all three are checked, not just New Laurentia)"""
    for m in RARE_HERD_MAPS:
        t, idx = paks.find_package(pd, f"BP_HerdManagement_{m}_WS.uasset")
        z = zenpkg.ZenPackage(t.read(idx))
        if any(r == "ERarity::Common" and w == RARE_COMMON_WEIGHT for _a, r, w in _weight_offsets(z)):
            return True
    return False

def rare_herds_status(save_path=None):
    return status("rare_herds", save_path)

def set_rare_herds(on, save_path=None, force=False):
    """Make new herds roll (almost) only rare coats (on) or the game's normal odds (off). -> notes"""
    was = switch("rare_herds", on, save_path, force)
    if not on:
        return ["rare herds off: the game is back to its normal rare odds"] if was else ["the game already uses its normal rare odds"]
    if was:
        return ["rare herds are already switched on"]
    return ["rare herds on: the next time a map builds new herds about 99 % of its moose, deer, elk, bison, wolves, bears, lions, buffalo, wildebeest, kudu and crocodiles roll a rare coat, about half of them very rare ones",
            "now reset the herds of the maps you want (Map page) and load them in the game once",
            "switch it off again afterwards - the rares that were rolled stay"]

PATCHES = {
    "utv": (_build_utv, _utv_live),
    "rare_herds": (_build_rare_herds, _rare_herds_live),
}

# ---------------------------------------------------------------- apply
def _block_table_offset(b):
    ver, hdr, ecount, cbcount = struct.unpack_from("<BxxxIII", b, 16)
    phs, _psize, nph = struct.unpack_from("<IQI", b, 84)
    p = hdr + 12 * ecount + 10 * ecount
    if ver >= 4:
        p += 4 * phs
    if ver >= 5:
        p += 4 * nph
    return p, cbcount

def _write_container(pd, container, rec, chunks, patches, toc):
    """Restore the pristine container, then (if chunks) write them and repoint the .utoc. -> new record or None
    A chunk that keeps its size is patched IN PLACE: only its changed compression blocks are appended (uncompressed)
    and their 12-byte block entries repointed - the .utoc keeps its layout (the method the UTV switch used while the
    game ran fine, 2026-10-05). Only a chunk that changes size is moved to new blocks at the end of the container's
    virtual space (that method was live when the title screen lost its animals - still unproven either way)."""
    utoc = os.path.join(pd, container + ".utoc")
    ucas = utoc[:-5] + ".ucas"
    if rec:
        shutil.copyfile(rec["utoc_backup"], utoc)
        with hostos.open_big(ucas, "r+b") as f:
            f.truncate(rec["ucas_size"])
    if not chunks:
        if rec:
            os.remove(rec["utoc_backup"]); os.remove(_record_path(container))
        return None
    b = bytearray(open(utoc, "rb").read())
    utoc_size = len(b)
    ver, hdr, ecount = struct.unpack_from("<BxxxII", b, 16)
    cbs, = struct.unpack_from("<I", b, 44)
    table, cbcount = _block_table_offset(b)
    ucas_size = os.path.getsize(ucas)
    pcount, psize = struct.unpack_from("<I", b, 52)[0], struct.unpack_from("<Q", b, 88)[0]
    total = sum(len(v) for v in chunks.values()) + 16 * len(chunks) + 16
    if pcount > 1 or ucas_size + total > psize:          # one .ucas, no size cap (the game: 1, 0xFFFF...)
        raise RuntimeError("this game build splits its containers, the patch cannot be applied safely")
    backup = os.path.join(_state_dir(), container + ".utoc.orig")
    if not rec:
        shutil.copyfile(utoc, backup)
    end = (ucas_size + 15) // 16 * 16                    # appended blocks 16-byte aligned like the game's own
    entries = b""
    nblocks = cbcount
    with hostos.open_big(ucas, "r+b") as f:
        f.seek(ucas_size); f.write(b"\0" * (end - ucas_size))
        for idx in sorted(chunks):
            data = chunks[idx]
            off, ln = toc.ol[idx]
            if ln == len(data):                              # same size: patch only the blocks that changed
                if off % cbs:
                    raise RuntimeError("chunk is not block-aligned")
                for bi in range(off // cbs, (off + ln - 1) // cbs + 1):
                    bo, cs, us, m = toc.blocks[bi]
                    f.seek(bo); raw = f.read(cs)
                    old = raw if m == 0 else nrgs.oodle_decompress(raw, us)
                    lo = bi * cbs - off
                    part = data[lo:lo + us]
                    new_blk = part + old[len(part):]                # a chunk's last block may carry padding past its end
                    if new_blk == old:
                        continue
                    f.seek(end); f.write(new_blk)
                    e = table + 12 * bi
                    b[e:e + 12] = end.to_bytes(5, "little") + len(new_blk).to_bytes(3, "little") + len(new_blk).to_bytes(3, "little") + b"\0"
                    end += len(new_blk)
                continue
            f.seek(end)
            vstart = nblocks * cbs
            for k in range(0, len(data), cbs):
                blk = data[k:k + cbs]
                f.write(blk)
                entries += end.to_bytes(5, "little") + len(blk).to_bytes(3, "little") + len(blk).to_bytes(3, "little") + b"\0"
                end += len(blk); nblocks += 1
            ol = hdr + 12 * ecount + 10 * idx
            b[ol:ol + 10] = vstart.to_bytes(5, "big") + len(data).to_bytes(5, "big")
    if entries:
        b[table + 12 * cbcount:table + 12 * cbcount] = entries
        struct.pack_into("<I", b, 28, nblocks)
    with open(utoc + ".tmp", "wb") as f:
        f.write(b)
    os.replace(utoc + ".tmp", utoc)
    new = {"container": container, "ucas_size": ucas_size, "patched_ucas_size": end, "utoc_backup": backup,
           "utoc_size": utoc_size, "patched_utoc_size": len(b),
           "patches": sorted(patches)}
    json.dump(new, open(_record_path(container), "w"))
    return new

def apply(wanted, save_path=None):
    """Make the game files carry exactly the patches in `wanted` (names from PATCHES)."""
    pd = paks.find_paks_dir(save_path)
    if not pd:
        raise FileNotFoundError("game files not found")
    drop_stale(pd)
    records = _records()
    ctx = _Ctx(pd, records)
    by_container, owners = {}, {}
    for name in sorted(wanted):
        for (c, idx), data in PATCHES[name][0](ctx).items():   # everything is built before any file is touched
            ctx.new[(c, idx)] = data
            by_container.setdefault(c, {})[idx] = data
            owners.setdefault(c, set()).add(name)
    for c in sorted(set(records) | set(by_container)):
        _write_container(pd, c, records.get(c), by_container.get(c), owners.get(c, ()), ctx.tocs[c])
    paks._toc_cache.clear()

def status(name, save_path=None):
    """-> {"available": bool, "on": bool, "error": str}"""
    try:
        _undo_retired(save_path)
        pd = paks.find_paks_dir(save_path)
        if not pd:
            return {"available": False, "on": False, "error": "game files not found"}
        paks._toc_cache.clear()
        return {"available": True, "on": bool(PATCHES[name][1](pd)), "error": ""}
    except Exception as e:
        return {"available": False, "on": False, "error": str(e)}

def switch(name, on, save_path=None, force=False):
    import trainer_core
    if trainer_core.game_running() and not force:
        raise RuntimeError("The game is running. Close it first.")
    pd = paks.find_paks_dir(save_path)
    if pd: drop_stale(pd)                                  # after a game update the old switches are off, not stale
    before = set(enabled_patches())
    was = name in before
    wanted = before | {name} if on else before - {name}
    apply(wanted, save_path)
    pd = paks.find_paks_dir(save_path)
    if any(bool(PATCHES[p][1](pd)) != (p in wanted) for p in PATCHES):
        apply(before, save_path)
        raise RuntimeError("patch did not read back, game files put back as they were")
    return was
