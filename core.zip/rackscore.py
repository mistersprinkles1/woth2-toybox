"""Exact trophy scores for GROWN racks (antlers / horns / tusks) from the rack DNA the save keeps, by rebuilding
the 3D trophy offline the way the game does (rack/engine.py; verified against the game's own harvest records).
score(species, sex, age, fitness, blob) -> {"score": int, "values": {tag: float}} or None (rack not grown, a
measurement kind the engine does not rebuild, or no game files)."""
import hashlib, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "rack"))

_engine = None; _files = None; _lib = None; _species = {}; _world = None; _cache = None; _dirty = False
UNSUPPORTED = {"Base_Shovel"}
WORLD = ("GreatestSpread", "DistanceSockets", "TipToTipLength", "Shovel_Length", "Base_Shovel_Width", "ShovelGreatestSpread")
VERSION = 10      # 2026-10-09: moose palm racks - no base pose when the save has none, unsaved layers at the ABP defaults

def _cache_path():
    try:
        import trainer_core
        return os.path.join(trainer_core.user_data_dir(), "rack_scores.json")
    except Exception:
        return os.path.join(HERE, "rack_scores.json")

def _load():
    global _engine, _files, _lib, _world, _cache
    if _engine is None:
        import engine
        _engine = engine; _files = engine.Files(); _lib = engine.PoseLib(_files)
        try: _world = json.load(open(os.path.join(HERE, "rack", "world_scale.json")))
        except (OSError, ValueError): _world = {}
        try:
            _cache = json.load(open(_cache_path()))
            if _cache.get("_v") != VERSION: _cache = {"_v": VERSION}
        except (OSError, ValueError):
            _cache = {"_v": VERSION}
    return _engine

def save_cache():
    global _dirty
    if _cache is not None and _dirty:
        try:
            with open(_cache_path() + ".tmp", "w") as f: json.dump(_cache, f)
            os.replace(_cache_path() + ".tmp", _cache_path()); _dirty = False
        except OSError:
            pass

def sides_of(blob):
    import validate
    return validate.parse_sides(blob)

def score(species, sex, age, fitness, blob, max_age=None, weight=None, variant=""):
    global _dirty
    if not blob or len(blob) < 80:
        return None
    try:
        E = _load()
    except Exception:
        return None
    key = hashlib.sha1(blob).hexdigest()[:20] + f"|{age}|{round(fitness, 4)}|{round(weight or 0, 2)}|{variant}"
    if key in _cache:
        return _cache[key]
    out = None
    try:
        sides = sides_of(blob)
        cfg = f"DA_AnimalConfig_{species}_{sex}"
        if variant and _files.path_of(cfg + "_" + variant):
            cfg += "_" + variant                  # its own body config (the rare buffalo bulls' weigh 40-137 kg)
        if sides and _files.path_of(cfg):
            sp = _species.get(cfg) or _species.setdefault(cfg, E.Species(_files, cfg))
            if sp.meas and not any(m.kind in UNSUPPORTED for m in sp.meas):
                import trophy_score as ts
                t = ts.growth(age, fitness, max_age or 10)
                w = _world.get(f"{species}|{sex}")
                wr = getattr(sp, "weight_range", None)
                if weight and wr:                 # the game sizes the body by where its weight sits in the body's range
                    t = max(0.0, min(1.0, (weight - wr[0]) / (wr[1] - wr[0])))
                    w = None
                bscale = (w["a"] + w["b"] * t) if w else sp.scale_range[0] + (sp.scale_range[1] - sp.scale_range[0]) * t
                built = {s["tag"]: (E.build_side(_lib, s), s["hidden_names"], s["mesh"].rsplit("/", 1)[-1]) for s in sides}
                vals = {}
                for m in sp.meas:
                    v = E.measure(m, built, sp.socks, bscale if m.kind in WORLD else 1.0, sp.comps)
                    if v is None: raise ValueError(m.kind)
                    vals[m.tag] = round(float(v), 3)
                out = {"score": int(sum(int(v + 1e-4) for v in vals.values())), "values": vals}
    except Exception:
        out = None
    _cache[key] = out; _dirty = True
    return out
