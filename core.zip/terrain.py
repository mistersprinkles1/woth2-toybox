"""Exact ground height from the game's own landscape collision (what the hunter stands on / falls through).

Every map's landscape is split into LandscapeStreamingProxy actors that live in World Partition cells
(Content/BASE/Maps/<Map>/_Generated_/<cell>.umap). The proxy is named ..._<Q>_<i>_<j>: Q quads per proxy, grid
position i, j. Each cell holds the proxy's RootComponent (unversioned: prop 5 RelativeLocation, 7 RelativeScale3D,
doubles; Map01: (1020, 2040, 1) m, scale (100, 100, 399)) and its LandscapeHeightfieldCollisionComponents
(one per landscape component, e.g. 4 x 510 quads), each with:
  ... i32 SectionBaseX, i32 SectionBaseY, i32 CollisionSizeQuads (510), f32 CollisionScale (1), [i32
  SimpleCollisionSizeQuads - left out on Kilimaya / HQ], FGuid HeightfieldGuid, FBox CachedLocalBox (6 doubles: 0, 0, zmin, size, size, zmax) ...
  then the cooked heightfield: u32 (size+1)^2 + (size+1)^2 u16 heights NORMALISED to zmin..zmax (row = y, col = x).
World position of vertex (col, row): origin + (SectionBase + (col, row)) x scale, origin = proxy location - proxy
SectionBase x scale (Map01 origin = (-5100, -5100) m = the map corner). World height = location.z + scale.z x
(zmin + q / 65535 x (zmax - zmin))  (landscape units are 1/128 of the raw height, the box is already in them).
Checked against animals the game placed on the ground (2026-10-05).

The cell for a point is found through a per-map index (world rectangle of every landscape component -> cell
package) built once and cached next to the map cache (rebuilt when the game build changes). Proxy names do not
give the grid on every map (Kilimaya's are offset by -55 quads), so the index uses the components' own bases.
Rocks / cliffs are static meshes ON the landscape: animals standing on them are up to ~25 m above it.
"""
import json, os, re, struct
import hostos

import woth2_paks as paks

_PROXY = re.compile(r"^LandscapeStreamingProxy_[A-Za-z0-9]+_(\d+)_(-?\d+)_(-?\d+)$")
_cells = {}          # (map, package path) -> parsed components (keeps the last few in memory)

def _index_path(mapname):
    import mapdata
    return os.path.join(mapdata.CACHE_ROOT, mapname, "terrain_index.json")

def _read_head(toc, idx):
    """The package header (with its name map) without decompressing the whole package."""
    import nrgs
    off, ln = toc.ol[idx]
    first = off // toc.cbs
    out = bytearray()
    need = None
    with hostos.open_big(toc.ucas, "rb") as f:
        bi = first
        while bi <= (off + ln - 1) // toc.cbs:
            bo, cs, us, m = toc.blocks[bi]
            f.seek(bo); raw = f.read(cs)
            out += raw if m == 0 else nrgs.oodle_decompress(raw, us)
            start = off - first * toc.cbs
            if need is None and len(out) - start >= 8:
                need = struct.unpack_from("<I", out, start + 4)[0]          # header size
            if need is not None and len(out) - start >= need:
                break
            bi += 1
    return bytes(out[off - first * toc.cbs:])

def build_index(paks_dir, mapname):
    """{"game": build, "cells": [[x0, y0, x1, y1, package path], ...]} - the world rectangle (cm) of every
    landscape cell. Built once (reads the ~100 landscape cells of the map) and cached."""
    game = paks.game_build(paks_dir)
    p = _index_path(mapname)
    try:
        ix = json.load(open(p))
        if ix.get("game") == game and ix.get("cells") and ix.get("version") == 5:
            return ix
    except (OSError, ValueError):
        pass
    cells = []
    pre = f"/Maps/{mapname}/"                            # cells: Maps/<Map>/<Map>/_Generated_/<cell>.umap
    for t in paks.all_tocs(paks_dir):
        for path, idx in t.files.items():
            if pre not in path or "/_Generated_/" not in path or not path.endswith(".umap"):
                continue
            try:
                names = paks.package_names(_read_head(t, idx))
            except Exception:
                continue
            if not any(_PROXY.match(n) for n in names):
                continue
            try:
                cell = _load_cell(paks_dir, mapname, path, toc=t)
            except (ValueError, FileNotFoundError, struct.error):
                continue
            for part in cell["parts"]:
                ox, oy = part["origin"]; sx, sy, _sz = part["scale"]
                for c in part["comps"]:
                    cells.append([ox + c["sbx"] * sx, oy + c["sby"] * sy, ox + (c["sbx"] + c["size"]) * sx,
                                  oy + (c["sby"] + c["size"]) * sy, path])
    if not cells:
        raise RuntimeError(f"{mapname}: no landscape cells found in the game files")
    ix = {"version": 5, "game": game, "cells": cells}
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f:
        json.dump(ix, f)
    return ix

def _root_transform(data):
    """(location xyz, scale xyz) in cm from the cell's RootComponent export."""
    hdr = []
    p, idx = 0, 0
    while True:
        h, = struct.unpack_from("<H", data, p); p += 2
        idx += h & 0x7F
        for _ in range(h >> 9):
            hdr.append(idx); idx += 1
        if h & 0x80:
            raise ValueError("root component with zero mask")
        if h & 0x100:
            break
    vals = {}
    for i in hdr:
        vals[i] = struct.unpack_from("<3d", data, p); p += 24
    return vals.get(5, (0.0, 0.0, 0.0)), vals.get(7, (100.0, 100.0, 100.0))

def _components(data):
    """(candidates, size, zmin, zmax, heights bytes offset) from one LandscapeHeightfieldCollisionComponent.
    The properties are unversioned, so a SectionBase that is 0 is not written at all: candidates lists the
    possible (sbx, sby) - both written, only sbx written (sby 0), only sby written (sbx 0); _load_cell picks the
    one that fits the other components of the cell."""
    for m in re.finditer(rb"\x00{16}", data[:4096]):
        k = m.start()                                     # box: 0.0, 0.0, zmin, size, size, zmax
        try:
            x0, y0, zmin, x1, y1, zmax = struct.unpack_from("<6d", data, k)
        except struct.error:
            continue
        if x0 != 0 or y0 != 0 or x1 != y1 or not (16 <= x1 <= 4096) or x1 != int(x1):
            continue
        size = int(x1)
        for back in (24, 20):                              # CollisionScale with / without SimpleCollisionSizeQuads (Kilimaya, HQ)
            s = k - back
            if s >= 12 and struct.unpack_from("<f", data, s)[0] == 1.0 and struct.unpack_from("<i", data, s - 4)[0] == size:
                break
        else:
            continue
        a, b = struct.unpack_from("<ii", data, s - 12)
        cands = [(a, b), (b, 0), (0, b), (0, 0)]
        cnt = struct.pack("<I", (size + 1) ** 2)
        g = data.find(cnt, k + 48)
        if g < 0:
            continue
        return cands, size, zmin, zmax, g + 4
    return None

def _edge_mismatch(pos, comps):
    """Sum of height differences along the edges neighbouring components share (the same vertices: 0 when the
    layout is right)."""
    def hgt(c, col, row):
        n = c["size"]
        q = struct.unpack_from("<H", c["h"], 2 * (row * (n + 1) + col))[0]
        return c["zmin"] + q / 65535.0 * (c["zmax"] - c["zmin"])
    at = {p: c for p, c in zip(pos, comps)}
    err = 0.0
    for (x, y), c in at.items():
        n = c["size"]
        r = at.get((x + n, y))
        if r:
            err += sum(abs(hgt(c, n, k) - hgt(r, 0, k)) for k in range(0, n + 1, 15))
        t = at.get((x, y + n))
        if t:
            err += sum(abs(hgt(c, k, n) - hgt(t, k, 0)) for k in range(0, n + 1, 15))
    return err

def _pick_bases(raw, comps):
    """One (sbx, sby) per component: the choice that puts the components on one grid of their own size, side by
    side without overlapping (a proxy is a block of components), preferring values that were written out; when
    two components carry the same clues (one has x = 0, the other y = 0), the one whose shared edges match."""
    import itertools
    if len(raw) > 6:                                       # never seen (proxies hold 4); keep it cheap
        return [r[0][0] for r in raw]
    found = []
    for choice in itertools.product(range(4), repeat=len(raw)):
        pos = [r[0][c] for r, c in zip(raw, choice)]
        size = raw[0][1]
        if len(set(pos)) != len(pos):
            continue
        xs = sorted({p[0] for p in pos}); ys = sorted({p[1] for p in pos})
        if any(x % size != xs[0] % size for x in xs) or any(y % size != ys[0] % size for y in ys):
            continue
        found.append(((xs[-1] - xs[0]) // size + (ys[-1] - ys[0]) // size, pos))
    if not found:
        return [r[0][0] for r in raw]
    tight = min(f[0] for f in found)
    layouts = {tuple(pos) for sp, pos in found if sp == tight}
    return list(min(layouts, key=lambda pos: _edge_mismatch(pos, comps)))

def _load_cell(paks_dir, mapname, path, toc=None):
    """{"parts": [{"loc", "scale", "origin", "comps"}]} - one part per LandscapeStreamingProxy in the cell (HQ puts
    several landscapes' proxies in one cell, each with its own transform)."""
    key = (mapname, path)
    if key in _cells:
        return _cells[key]
    import zenpkg
    toc = toc or next((t for t in paks.all_tocs(paks_dir) if path in t.files), None)
    if toc is None:
        raise FileNotFoundError(path)
    z = zenpkg.ZenPackage(toc.read(toc.files[path]))
    proxies = {k for k, e in enumerate(z.exports) if z.name(e[2] & 0xFFFFFFFF).startswith("LandscapeStreamingProxy")}
    roots, comps, raw = {}, {}, {}
    for e, dat in zip(z.exports, z.export_data):
        name, outer = z.name(e[2] & 0xFFFFFFFF), e[3]
        if outer not in proxies:
            continue
        if name.startswith("RootComponent"):                         # the proxy's own root (cells hold other actors too)
            roots[outer] = _root_transform(dat)
        elif name == "LandscapeHeightfieldCollisionComponent":
            c = _components(dat)
            if c:
                raw.setdefault(outer, []).append(c)
                comps.setdefault(outer, []).append({"size": c[1], "zmin": c[2], "zmax": c[3],
                                                    "h": dat[c[4]:c[4] + 2 * (c[1] + 1) ** 2]})
    parts = []
    for px, cs in comps.items():
        if px not in roots:
            continue
        loc, scale = roots[px]
        for c, (sbx, sby) in zip(cs, _pick_bases(raw[px], cs)):
            c["sbx"], c["sby"] = sbx, sby
        base = min(c["sbx"] for c in cs), min(c["sby"] for c in cs)
        parts.append({"loc": loc, "scale": scale, "origin": (loc[0] - base[0] * scale[0], loc[1] - base[1] * scale[1]),
                      "comps": cs})
    if not parts:
        raise ValueError(f"{path}: no landscape collision in this cell")
    cell = {"parts": parts}
    if len(_cells) > 8:
        _cells.clear()
    _cells[key] = cell
    return cell

def ground_z(mapname, x, y, paks_dir=None):
    """World ground height (cm) of the game's landscape at (x, y) cm, or None (outside the landscape / no data)."""
    pd = paks_dir or paks.find_paks_dir()
    if not pd:
        return None
    ix = build_index(pd, mapname)
    best = None
    for r in ix["cells"]:                                 # pieces meeting at an edge: take the higher one
        if r[0] <= x <= r[2] and r[1] <= y <= r[3]:
            z = _sample(_load_cell(pd, mapname, r[4]), x, y)
            if z is not None and (best is None or z > best):
                best = z
    return best

def _sample(cell, x, y):
    for part in cell["parts"]:
        z = _sample_part(part, x, y)
        if z is not None:
            return z
    return None

def _sample_part(cell, x, y):
    ox, oy = cell["origin"]; sx, sy, szz = cell["scale"]
    gx, gy = (x - ox) / sx, (y - oy) / sy                 # landscape quads
    for c in cell["comps"]:
        u, v = gx - c["sbx"], gy - c["sby"]
        n = c["size"]
        if 0 <= u <= n and 0 <= v <= n:
            u0, v0 = min(int(u), n - 1), min(int(v), n - 1)
            fu, fv = u - u0, v - v0
            h = lambda cc, rr: struct.unpack_from("<H", c["h"], 2 * (rr * (n + 1) + cc))[0]
            qv = (h(u0, v0) * (1 - fu) * (1 - fv) + h(u0 + 1, v0) * fu * (1 - fv)
                  + h(u0, v0 + 1) * (1 - fu) * fv + h(u0 + 1, v0 + 1) * fu * fv)
            local = c["zmin"] + qv / 65535.0 * (c["zmax"] - c["zmin"])
            return cell["loc"][2] + szz * local
    return None
