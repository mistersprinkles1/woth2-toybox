"""Shared state + JSON views for the WOTH2 Toybox app: the loaded save, names, map models and the
dictionaries the Godot front end reads (woth2_core.py prints them). Formerly the web app's server module."""
import collections, io, json, math, os, re, sys, threading, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import trainer_core as core
import stats as statsmod
import i18n
import woth2_paks as paks
import mapdata

class State:
    def __init__(self, save_path=None):
        self.lock = threading.Lock()
        self.no_save = os.environ.get("WOTH2_NOSAVE") == "1" and not save_path     # console players: map from game data only
        try:
            self.save = None if self.no_save else (save_path or core.find_save())   # the logged-in Steam account's save when there are several
        except FileNotFoundError:
            self.save = core.save_target()                  # none yet (START FRESH): where the game will put it
        tbl, self.names_src = paks.english_names(self.save)
        self.names = statsmod.Names(tbl)
        try:
            self.guid_data, self.guid_src = paks.all_map_guids(self.save)
        except Exception as e:
            self.guid_data, self.guid_src = None, str(e)
        self.models = {}
        self.progress = {}
        self._max_ages = None
        self._rater = None

    def rater(self):
        """trophy_score.Rater for this save (game thresholds + what the save's measured trophies teach), cached."""
        if self._rater is None:
            import nrgs, trophy_score
            try:
                self._rater = trophy_score.Rater(paks.find_paks_dir(self.save), nrgs.SaveFile(self.save), self.max_ages())
            except Exception:
                self._rater = False
        return self._rater or None

    def max_ages(self):
        """{subspecies: oldest age in the save} (the divisor of the game's rack-size formula), cached."""
        if self._max_ages is None:
            import nrgs
            try:
                import animals                             # locked (vault.py): no ages without the code
                self._max_ages = animals.max_ages(nrgs.SaveFile(self.save), self.guid_data) if self.save and self.guid_data else {}
            except Exception:
                self._max_ages = {}
            for sp, v in game_facts().get("species", {}).items():      # species not in the save (or no animals read): the game's own cap
                if v.get("max_age") and sp not in self._max_ages:
                    self._max_ages[sp] = v["max_age"]
        return self._max_ages

    def _progress(self, m, stage):
        """Remember the build stage; with WOTH2_PROGRESS set (the app does) also write "step/steps stage" there
        so the loading screen can show a bar while the first launch reads the game files."""
        self.progress[m] = stage
        fn = os.environ.get("WOTH2_PROGRESS")
        if not fn:
            return
        stages = mapdata.BUILD_STAGES
        k = stages.index(stage) + 1 if stage in stages else 0
        try:
            with open(fn, "w") as f:
                f.write(f"{k}/{len(stages)} {mapdata.stage_text(stage)}")     # the bar counts the English stages, the words are shown
        except OSError:
            pass

    def model(self, m):
        with self.lock:
            if m not in self.models:
                self.models[m] = mapdata.load_map(m, self.save, progress=lambda s: self._progress(m, s))
            return self.models[m]

_GAME_FACTS = None
def game_facts():
    global _GAME_FACTS
    if _GAME_FACTS is None:
        try:
            with open(os.path.join(HERE, "game_facts.json"), encoding="utf-8") as f:
                _GAME_FACTS = json.load(f)
        except (OSError, ValueError):
            _GAME_FACTS = {}
    return _GAME_FACTS

# ---------------------------------------------------------------- JSON helpers
def harvest_json(h, names):
    if h is None:
        return None
    return {"species": names.subspecies(h.subspecies), "sex": h.sex, "weight": round(h.weight, 1), "distance": round(h.distance, 1),
            "weapon": names.gear_name(h.weapon), "ammo": names.caliber(h.ammo), "map": names.map(h.map), "when": h.when.isoformat() if h.when else None,
            "fitness": round(h.fitness, 3), "hunt": h.hunt_rating}

def group_json(entries, names):
    out = []
    for e in entries:
        out.append({"name": e["name"], "latin": e.get("latin", ""), "total": e["total"], "m": e["m"], "f": e["f"],
                    "heaviest": harvest_json(e["heaviest"], names), "longest": harvest_json(e["longest"], names),
                    "last": e["last"].isoformat() if e["last"] else None, "sub": e["sub"].most_common(6)})
    return out

LAYOUT_MSG = "This save is laid out in a way the Toybox doesn't know. Nothing was changed."

def _plain(e):
    """An exception as the app shows it (woth2_core.plain_error), logged in full; never raw save-format text."""
    try:
        import woth2_core
        woth2_core.log_error(e)
        return woth2_core.plain_error(e)
    except Exception:
        return i18n.t("This save is laid out in a way the Toybox doesn't know. Nothing was changed.")

def _oldest_for(sid, oldest):
    """The oldest age for a species id; animal configs sometimes use a shorter name than the subspecies
    (StruthioCamelus -> StruthioCamelusAustralis), so match by prefix (same rule as animals.oldest_for)."""
    if sid in oldest:
        return oldest[sid]
    return next((v for s, v in sorted(oldest.items()) if s.startswith(sid) or sid.startswith(s)), 0)

def progress_json(st):
    """Challenges + missions (done / in progress / not started) for the Stats page. No save: the full list, none started
    (the app keeps your own ticks)."""
    import missions, nrgs
    try:
        if st.no_save or not st.save:                     # the list shipped with the app: no game folder search (web, consoles)
            return missions.overview(None, missions.shipped_catalog())
        return missions.overview(nrgs.SaveFile(st.save), missions.catalog(st.save))
    except Exception as e:                        # never lose the hunting stats over this
        _plain(e)                                 # logged in full
        return {"challenges": [], "missions": [], "error": i18n.t("This save's challenges and missions could not be read.")}

def _weather_names(times, names):
    """Adds the game's names for the clock's weather ("Light fog", "Moderate snow") next to the tags."""
    for t in times:
        for k in ("weather", "weather_next"):
            if t.get(k): t[k + "_name"] = names.weather(t[k])

def _kills(save):
    try:
        import nrgs, trophy_score
        return trophy_score.kill_records(nrgs.SaveFile(save))
    except Exception:
        return []

def _same_species(a, b):
    """Animal configs sometimes use a shorter name than the subspecies (StruthioCamelus / StruthioCamelusAustralis,
    MellivoraCapensis...): match by prefix both ways."""
    return a == b or a.startswith(b) or b.startswith(a)

_MEASURED_INDEX = {}

def _measured_for(measured, sp, sex, age, fit):
    v = measured.get((sp, sex, age, fit))
    if v is not None:
        return v
    # the slow way only among kills of the same sex, age and fitness (indexed once per table: a big log asked this
    # for every harvest over every kill)
    idx = _MEASURED_INDEX.get(id(measured))
    if idx is None or idx[0] is not measured or idx[1] != len(measured):
        by = collections.defaultdict(list)
        for (s, x, a, f), sc in measured.items(): by[(x, a, f)].append((s, sc))
        idx = _MEASURED_INDEX[id(measured)] = (measured, len(measured), by)
    return next((sc for s, sc in idx[2].get((sex, age, fit), ()) if _same_species(s, sp)), None)

def _stars(sc, req):
    return 0 if sc < 1 else 1 + sum(1 for t in req if sc >= t)       # the game's rule

def rate_records(st, recs, kills):
    """Adds the trophy to every hunting-log entry: "stars" = the game's own stars (the log keeps them for every kill),
    "score" + "est". The score is the game's measurement when the save still holds it, else worked out from age,
    fitness and weight, and only kept when it gives the same stars. "est" = antlers or horns the game no longer has
    measurements of (most likely score). Non-typical racks (r["quality"] == "NonTypical") use their own star lines.
    A sold mule deer buck keeps no rack type: when only the non-typical lines give the game's stars, the non-typical
    score is used ("nt_guess": True), and when both fit "maybe_nt" is set."""
    measured = {}
    for k in kills:
        key = (k["species"], k["sex"], k["age"], round(k["fit"], 3))
        measured[key] = max(measured.get(key, 0), int(k["score"]))
    rater = st.rater()
    for r in recs:
        r["score"] = 0
        n = r.get("stars", 0)
        if not n or not rater:
            continue
        q = r.get("quality", "")
        typ = rater.thresholds_for(r["sp"], r["sex"])
        nt = _nt_lines(rater, r["sp"], r["sex"])
        if nt == typ:
            nt = None
        if q == "NonTypical":
            choices = [("NonTypical", nt)] if nt else []
        elif q or not nt:                                    # typical (or another kind the lines are the same for)
            choices = [("Typical", typ)] if typ else []
        else:                                                # no rack type kept (sold): try both
            choices = [x for x in (("Typical", typ), ("NonTypical", nt)) if x[1]]
        if not choices:
            continue
        ms = _measured_for(measured, r["sp"], r["sex"], r.get("age", 0), round(r["fitness"], 3))
        if ms is not None:
            fits = [k for k, req in choices if _stars(ms, req) == n]
            if fits:
                r.update(score=ms, est=False)
                if not q and nt:
                    if fits == ["NonTypical"]: r["nt_guess"] = True
                    elif len(fits) > 1: r["maybe_nt"] = True
                continue
        if not r.get("age"):
            continue
        hits = []
        for k, req in choices:
            try:
                e = rater.rate(r["sp"], r["sex"], r["age"], r["fitness"], 0, weight=r["kg"], variant=r["var"], quality=k)
            except Exception:
                e = None
            if e and _stars(e["score"], req) == n:
                hits.append((k, e))
        if not hits:
            continue
        k, e = hits[0]
        r.update(score=int(e["score"]), est=e["how"] != "exact")
        if not q and nt:
            if [h[0] for h in hits] == ["NonTypical"]: r["nt_guess"] = True
            elif len(hits) > 1: r["maybe_nt"] = True
    return recs

def _slot(sex, quality):
    """The MY TROPHIES slot: "M", "F", or "M_NT" for a non-typical rack (own star lines, own best)."""
    return sex + "_NT" if quality == "NonTypical" else sex

def best_scores(save, recs=()):
    """{subspecies: {"M": score, "F": score, "M_NT": score}}: the best trophy score of every kill in this save's hunting
    log: the game's own measurement when the save still has it, and every hunting-log kill whose score is known for
    sure (weight, skull and length trophies). Non-typical racks are kept apart ("M_NT")."""
    out = {}
    # only kills that are in this save's hunting log (the log entry tells the rack type)
    mine = {}
    for r in recs:
        k = (r["sp"], r["sex"], int(r.get("age", 0)), round(float(r["fitness"]), 3), round(float(r.get("kg", 0))))
        mine[k] = "NonTypical" if (r.get("quality") == "NonTypical" or r.get("nt_guess")) else "Typical"
    for r in _kills(save):              # same animal: species, sex, age, fitness and weight (kg) all match
        k = (r["species"], r["sex"], int(r["age"]), round(float(r["fit"]), 3), round(float(r.get("w") or 0)))
        hit = next((key for key in mine if key[1:] == k[1:] and _same_species(key[0], k[0])), None) if k not in mine else k
        if hit is None:
            continue
        d = out.setdefault(hit[0], {})
        sl = _slot(r["sex"], mine[hit])
        d[sl] = max(d.get(sl, 0), int(r["score"]))
    for r in recs:
        if r.get("score") and not r.get("est"):
            d = out.setdefault(r["sp"], {})
            sl = _slot(r["sex"], "NonTypical" if (r.get("quality") == "NonTypical" or r.get("nt_guess")) else "Typical")
            d[sl] = max(d.get(sl, 0), int(r["score"]))
    return out

def best_stars(recs):
    """{subspecies: {"M": stars, "M_NT": stars}}: the most stars the game gave any kill in the hunting log."""
    out = {}
    for r in recs:
        if r.get("stars"):
            d = out.setdefault(r["sp"], {})
            sl = _slot(r["sex"], "NonTypical" if (r.get("quality") == "NonTypical" or r.get("nt_guess")) else "Typical")
            d[sl] = max(d.get(sl, 0), int(r["stars"]))
    return out

def best_guesses(recs):
    """{subspecies: {"M": [score, stars_lo, stars_hi]}}: the best unmeasured antler/horn kill (most likely score)."""
    out = {}
    for r in recs:
        if r.get("score") and r.get("est"):
            d = out.setdefault(r["sp"], {})
            sl = _slot(r["sex"], "NonTypical" if (r.get("quality") == "NonTypical" or r.get("nt_guess")) else "Typical")
            if r["score"] > d.get(sl, [0])[0]:
                d[sl] = [r["score"], r["stars"], r["stars"]]
    return out

def nt_lines_json(st):
    """{subspecies: {"M": [4 star lines]}} for animals with a non-typical rack (own lines; 1.3: mule deer bucks).
    The MY TROPHIES page gives each one its own row."""
    out = {}
    try:
        rater = st.rater()
        if not rater or not getattr(rater, "req_nt", None):
            return out
        ids = set(game_facts().get("species", {})) | set(rater.max_ages or {})
        for sp in sorted(ids):
            for sx in ("M", "F"):
                nt = _nt_lines(rater, sp, sx)
                if nt and nt != rater.thresholds_for(sp, sx):
                    out.setdefault(sp, {})[sx] = list(nt)
    except Exception as e:
        _plain(e)
    return out

def skills_owned(save):
    """Numbers ("015") of the skills the save has unlocked."""
    try:
        import re
        return sorted({m.group(1) for n in core.read_skills(save) for m in [re.search(r"DA_CharacterSkill_(\d+)", n)] if m})
    except Exception:
        return None

NO_SAVE_MSG = "No save yet. Start the game once so it makes one."

def stats_json(st):
    if st.no_save or not st.save:
        return {"no_save": True, "progress": progress_json(st)}
    if not os.path.isfile(st.save):                       # START FRESH / never played: nothing to read yet
        return {"error": i18n.t("No save yet. Start the game once so it makes one.")}
    try:
        s, notes = statsmod.read_stats(st.save, st.names)
    except Exception as e:                                # the Stats page only reads: no "Nothing was changed" here
        msg = _plain(e)
        if msg == i18n.t(LAYOUT_MSG) != LAYOUT_MSG:       # (another language: its own line without "Nothing was changed.")
            return {"error": i18n.t("This save is laid out in a way the Toybox doesn't know.")}
        return {"error": msg.replace(" Nothing was changed.", "")}
    if not s["total"]:
        return {"total": 0, "notes": notes, "progress": progress_json(st), "best_scores": best_scores(st.save), "skills_owned": skills_owned(st.save),
                "nt_lines": nt_lines_json(st)}
    n = st.names
    pk = paks.find_paks_dir(st.save)
    recs = rate_records(st, [record_json(h, n, pk) for h in s["harvests"]], _kills(st.save))
    write_save_facts(st.save, recs, s)
    return {"progress": progress_json(st), "total": s["total"], "males": s["males"], "females": s["females"], "species_count": s["species_count"], "hunters": s["hunters"],
            "first": s["first"].isoformat() if s["first"] else None, "last": s["last"].isoformat() if s["last"] else None,
            "longest": harvest_json(s["longest"], n), "heaviest": harvest_json(s["heaviest"], n), "best_fitness": harvest_json(s["best_fitness"], n), "best_hunt": harvest_json(s["best_hunt"], n),
            "hours_in_hand": round(s["hours_in_hand"], 1), "vehicle_km": round(s["vehicle_km"], 1),
            "by_species": group_json(s["by_species"], n), "by_weapon": group_json(s["by_weapon"], n), "by_ammo": group_json(s["by_ammo"], n),
            "by_map": group_json(s["by_map"], n), "by_weather": group_json(s["by_weather"], n),
            "gear_overall": [(k, round(v, 1)) for k, v in s["gear_overall"] if v >= 0.05], "notes": notes,
            "gear_time": {m: {c: [(k, round(v, 2)) for k, v in items if v >= 0.05] for c, items in cats.items()} for m, cats in s["gear_time"].items()},
            "records": recs, "best_scores": best_scores(st.save, recs), "best_guesses": best_guesses(recs), "best_stars": best_stars(recs), "skills_owned": skills_owned(st.save),
            "nt_lines": nt_lines_json(st), "mod_challenges": _with_kill_zones(mod_challenges(st.save, recs, st.names), recs),
            "mods": mods_found(st.save)}

# UE4SS's own mods that change nothing in the game (the LogicMods loader: those paks are listed by themselves); the
# Stats mod only reads (modcheck.lua keeps the same list)
QUIET_UE4SS = {"ToyboxStats", "shared", "Keybinds", "BPModLoaderMod", "BPML_GenericFunctions"}

def _game_files():
    """The game's own pak files {name (lower): bytes} and the Steam build they are from (game_files.txt, made by the
    Stats mod's tools/game_files.sh from an untouched game)."""
    own, build = {}, ""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "game_files.txt"), encoding="utf-8") as f:
            for line in f:
                p = line.split()
                if len(p) == 2 and p[0] == "build": build = p[1]
                elif len(p) == 2 and p[1].isdigit(): own[p[0].lower()] = int(p[1])
    except OSError:
        pass
    return own, build

def save_flags(save, skills=None, values=None):
    """What the save shows a normal game can never make (sure ones only: each makes the player "modded" for good):
    more skill points spent and held than the hunter's level ever gave (points come only from levels: skill_costs.json,
    from the game). -> ["save:<what>", ...]"""
    out = []
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "skill_costs.json"), encoding="utf-8") as f:
            sc = json.load(f)
        skills = core.read_skills(save) if skills is None else skills
        values = core.read_values(save) if values is None else values
        level = core.rank_of(values["xp"][0])["level"]
        given = int(sc["points_at_level"].get(str(level), 0)) if level <= 35 else int(sc["points_at_level"]["35"])
        spent = sum(int(sc["costs"].get(n, 1)) for n in skills)          # (a skill it does not know: at least 1)
        held = max(0, int(values["skill_points"][0]))
        if spent + held > given:
            out.append(f"save:skill points {spent}+{held} of {given}")
    except Exception:
        pass
    return out

GAME_DLLS = {"tbb12.dll", "tbbmalloc.dll", "dwmapi.dll"}   # the game's own, and UE4SS's loader (its mods are listed)
# Graphics tools are no mod: ReShade (colors, sharpening), OptiScaler / DLSS Enabler / dlssg-to-fsr3 (upscaling and
# frame generation) and the Intel / AMD files they bring. One sits beside the game under one of these names, and the
# file has to say which tool it is inside (plain or wide text), so a cheat DLL renamed to one of them still counts.
# (Same as the mod's toybox_net.js GFX.)
_GFX_LOADER = ("ReShade", "OptiScaler", "dlssg_to_fsr3", "dlss-enabler")
GFX_DLLS = [
    (r"(dxgi|d3d11|d3d12|opengl32|reshade64|version|winmm|dbghelp|nvngx|wininet|winhttp)\.dll", _GFX_LOADER),
    (r"dlssg_to_fsr3\w*\.dll", ("dlssg_to_fsr3",)),
    (r"dlss-enabler[\w-]*\.dll", ("dlss-enabler",)),
    (r"(libxess\w*|libxell)\.dll", ("XeSS", "XeLL")),
    (r"amd_fidelityfx\w*\.dll", ("FidelityFX",)),
    (r"fakenvapi\.dll", ("fakenvapi",)),
]


def _is_graphics(win64, name):
    low = name.lower()
    marks = next((m for pat, m in GFX_DLLS if re.fullmatch(pat, low)), None)
    if not marks:
        return False
    try:
        with open(os.path.join(win64, name), "rb") as f:
            b = f.read(128 << 20)
    except OSError:
        return False
    return any(m.encode() in b or m.encode("utf-16-le") in b for m in marks)
    try:
        with open(os.path.join(win64, name), "rb") as f:
            return _RESHADE_MARK in f.read(64 << 20)
    except OSError:
        return False

def mods_found(save):
    """What else changes this game, for the normal / modded boards (the Stats mod's toybox_net.js looks the same
    way): any pak file in Content/Paks that is not the game's own (game_files.txt; a game file of another size = a
    patched game), UE4SS mods switched on, DLL loaders beside the game, the Toybox's game patches and its save edits.
    ["kind:name", ...] sorted, or None when the game folder can't be found (then nothing is sent and the server
    keeps what it had)."""
    try:
        pk = paks.find_paks_dir(save)
    except Exception:
        pk = None
    if not pk or not os.path.isdir(pk):
        return save_flags(save) or None                    # (no game folder here, e.g. the website: the save's own check)
    out = set(save_flags(save))
    own, own_build = _game_files()
    build = ""
    try:
        steamapps = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(pk))))   # .../steamapps/common/<game>/WOTH2/Content/Paks
        steamapps = os.path.dirname(steamapps)
        with open(os.path.join(steamapps, "appmanifest_2543830.acf"), encoding="utf-8", errors="replace") as f:
            m = re.search(r'"buildid"\s+"(\d+)"', f.read())
            build = m.group(1) if m else ""
    except OSError:
        pass
    for root, _dirs, files in os.walk(pk):
        top = os.path.abspath(root) == os.path.abspath(pk)
        for f in files:
            low = f.lower()
            if not re.search(r"\.(pak|utoc|ucas|sig)$", low):
                continue
            if top and not own and re.match(r"^(pakchunk\d+(optional)?-windows|global)\.(pak|utoc|ucas|sig)$", low):
                continue                                   # (no list of the game's files here: never count the game's own names)
            if top and low in own:                         # a game file: the same size as the game's?
                if build and build == own_build and os.path.getsize(os.path.join(root, f)) != own[low]:
                    out.add("changed:" + f)
            elif low.endswith(".pak") or re.sub(r"\.(utoc|ucas|sig)$", ".pak", low) not in own:
                name = re.sub(r"\.(utoc|ucas|sig)$", ".pak", f, flags=re.I)
                out.add("pak:" + (name if top else os.path.basename(root) + "\\" + name))
    win64 = os.path.join(os.path.dirname(os.path.dirname(pk)), "Binaries", "Win64")
    for mods in (os.path.join(win64, "ue4ss", "Mods"), os.path.join(win64, "Mods")):
        if not os.path.isdir(mods):
            continue
        on = set()
        try:
            with open(os.path.join(mods, "mods.txt"), encoding="utf-8", errors="replace") as f:
                for line in f:
                    m = re.match(r"^\s*([^;:]+?)\s*:\s*1\s*$", line)
                    if m: on.add(m.group(1))
        except OSError:
            pass
        on.update(d for d in os.listdir(mods) if os.path.isfile(os.path.join(mods, d, "enabled.txt")))
        out.update(f"ue4ss:{n}" for n in on if n not in QUIET_UE4SS and os.path.isdir(os.path.join(mods, n)))
    try:
        for f in os.listdir(win64):
            low = f.lower()
            if (low.endswith(".dll") and low not in GAME_DLLS and not _is_graphics(win64, f)) or low.endswith(".asi"):
                out.add("dll:" + f)
    except OSError:
        pass
    try:
        import gamepatch
        out.update(f"patch:{c}" for c in gamepatch._records())
    except Exception:
        pass
    if os.path.isfile(core.ORIGINAL_BACKUP):
        out.add("edit:Toybox save edits")
    return sorted(x[:60] for x in out)[:20]

def _with_kill_zones(mc, recs):
    """Where each killing shot went, as the Stats mod's shot tracker saw it (its file's kz, by "<log id>:<claim unix>"):
    put on the records as "kz" for the super elite's shot rules and the leaderboard upload."""
    import datetime
    kz = mc.pop("kz", {}) if isinstance(mc, dict) else {}
    if kz:
        for r in recs:
            try:
                u = int(datetime.datetime.fromisoformat(str(r.get("when"))).replace(tzinfo=datetime.timezone.utc).timestamp())
            except (TypeError, ValueError):
                continue
            z = kz.get("%d:%d" % (int(r["i"]), u))
            if z: r["kz"] = z
    return mc

def _lua_safe_name(s):
    # byte by byte, like the mod's util.safe_name (Lua's gsub works on bytes: "José" -> "Jos__")
    return re.sub(rb"[^A-Za-z0-9\-_]", b"_", (s or "hunter").encode("utf-8")).decode("ascii")

def _lua_safe_names(s):
    """Every file name the mod may use for this hunter. The game hands the mod the name in the PC's ANSI code page,
    not UTF-8 ("Gildão": the ã is one byte there, two here; an emoji comes out "?" or "??"), so the app writes its
    files under each and reads the mod's from whichever is there. The UTF-8 one first (the app's own)."""
    s = s or "hunter"
    out = [_lua_safe_name(s)]
    for one in (1, 2):                                       # ("?" per character, or per UTF-16 half for an emoji)
        b = b"".join((ch.encode("cp1252") if _cp1252(ch) else b"?" * (2 if one == 2 and ord(ch) > 0xFFFF else 1)) for ch in s)
        n = re.sub(rb"[^A-Za-z0-9\-_]", b"_", b).decode("ascii")
        if n not in out:
            out.append(n)
    return out

def _cp1252(ch):
    try:
        ch.encode("cp1252"); return True
    except UnicodeEncodeError:
        return False

def _lua_value(t, i=0):
    """One value of a table the Stats mod wrote (util.ser: tables, strings in %q, numbers, booleans) -> (value, end)"""
    def ws(i):
        while i < len(t) and t[i] in " \t\r\n,": i += 1
        return i
    i = ws(i)
    c = t[i]
    if c == "{":
        arr, obj, i = [], {}, i + 1
        while True:
            i = ws(i)
            if t[i] == "}": return (obj if obj else arr) if not (obj and arr) else {**{str(n + 1): v for n, v in enumerate(arr)}, **obj}, i + 1
            if t[i] == "[":
                k, i = _lua_value(t, i + 1)
                i = t.index("=", t.index("]", i)) + 1
                v, i = _lua_value(t, i)
                obj[str(k) if not isinstance(k, str) else k] = v
            else:
                v, i = _lua_value(t, i)
                arr.append(v)
    if c == '"':
        out, i = [], i + 1
        while t[i] != '"':
            if t[i] == "\\":
                n = t[i + 1]
                if n.isdigit():
                    j = i + 1
                    while j < len(t) and j < i + 4 and t[j].isdigit(): j += 1
                    out.append(chr(int(t[i + 1:j]))); i = j; continue
                out.append({"n": "\n", "t": "\t", "r": "\r", "\n": "\n"}.get(n, n)); i += 2; continue
            out.append(t[i]); i += 1
        return "".join(out), i + 1
    m = re.match(r"-?[0-9][0-9.eE+-]*|true|false|nil|-?inf|-?nan", t[i:])
    w = m.group(0)
    if w in ("true", "false"): return w == "true", i + len(w)
    if w == "nil": return None, i + len(w)
    try: return int(w), i + len(w)
    except ValueError: return float(w), i + len(w)

def _mod_done(t, names=None):
    """The challenges the Stats mod keeps as finished (its "done" table) -> {key: {c, h, unix, hs, t}}"""
    m = re.search(r'^  \["done"\] = ', t, re.M)
    if not m:
        return {}
    try:
        done, _ = _lua_value(t, m.end())
    except (ValueError, IndexError):
        return {}
    out = {}
    unix = lambda ticks: int(float(ticks or 0)) // 10000000 - 62135596800
    for k, r in (done.items() if isinstance(done, dict) else []):
        if isinstance(r, dict) and "c" in r and "h" in r and not (isinstance(r["c"], dict) and r["c"].get("test")):   # (a holiday test's: never)
            out[k] = {"c": r["c"], "h": r["h"], "unix": unix(r.get("ticks", 0)), "hs": r.get("hs", []), "t": r.get("t", 0)}
            # old saves: the save it was finished in (its first harvest's claim) and the note of its harvests, so it
            # still shows when another save is loaded (the mod's challenges.completed)
            if r.get("save") and isinstance(r.get("note"), list):
                try:
                    out[k]["save_unix"] = unix(r["save"])
                    out[k]["note"] = [_note_record(n, names) for n in r["note"] if isinstance(n, dict)]
                except (TypeError, ValueError):
                    pass
    return out

def _note_record(n, nm=None):
    """A harvest of an old save as the mod noted it -> the few fields of a log record the challenge pages show"""
    from datetime import datetime, timezone
    sp, w = str(n.get("species", "")), str(n.get("weapon", ""))
    when = None
    try:
        when = datetime.fromtimestamp(int(float(n.get("ticks", 0))) // 10000000 - 62135596800, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    except (TypeError, ValueError, OverflowError, OSError):
        pass
    name = gear = None
    try:
        name, gear = nm.subspecies(sp), nm.gear_name(w)
    except Exception:
        pass
    return {"i": int(n.get("id", 0) or 0), "sp": sp, "name": name or sp, "sex": n.get("sex", ""), "weapon": gear or w,
            "weapon_id": w, "map": n.get("map", ""), "when": when, "old": True}

def stats_mod_here(save):
    """Is the Toybox Stats mod installed next to the game? (cheap: one folder check)"""
    try:
        pk = paks.find_paks_dir(save)
        return bool(pk) and os.path.isdir(os.path.join(pk, "..", "..", "Binaries", "Win64", "ue4ss", "Mods", "ToyboxStats"))
    except Exception:
        return False

def _mod_text(f):
    """A Stats mod data file's text; when a crash left it empty or cut short, the copy the mod kept before its last
    write (<file>.bak). None when there is neither."""
    for g in (f, f + ".bak"):
        try:
            t = open(g, encoding="utf-8", errors="replace").read()
        except OSError:
            if g == f and not os.path.isfile(f):
                return None                                # removed on purpose: no copy brought back
            continue
        if t.rstrip().endswith("}"):
            return t
    return None

def mod_board_asks(save):
    """When each leaderboard answer asked in the game's ledger was given (unix times, any hunter): the app reads the
    whole hunting log after a save read only when one of them is new to it (cheap: small files, one pattern)"""
    newest = []
    try:
        pk = paks.find_paks_dir(save)
        d = os.path.join(pk, "..", "..", "Binaries", "Win64", "ue4ss", "Mods", "ToyboxStats", "challenges") if pk else ""
        for f in (os.listdir(d) if d and os.path.isdir(d) else []):
            if f.endswith(".lua") and not f.startswith("_"):
                t = _mod_text(os.path.join(d, f)) or ""
                m = re.search(r'^  \["board"\] = \{.*?\["t"\]\s*=\s*(\d+)', t, re.M | re.S)
                if m: newest.append(int(m.group(1)))
    except OSError:
        pass
    return newest

def write_board(save, text, hunter=""):
    """The leaderboard as the Toybox app last read it, for the Stats mod (challenges/_leaderboard_<hunter>.lua next
    to the game: one per hunter, so two hunters on one PC keep their own). Written only where the mod is installed;
    the mod never writes it."""
    try:
        pk = paks.find_paks_dir(save)
        d = os.path.join(pk, "..", "..", "Binaries", "Win64", "ue4ss", "Mods", "ToyboxStats") if pk else ""
        if not d or not os.path.isdir(d):
            return {"ok": False, "why": "no mod"}
        os.makedirs(os.path.join(d, "challenges"), exist_ok=True)
        for name in _lua_safe_names(hunter):               # (the mod's file name may be another: _lua_safe_names)
            f = os.path.join(d, "challenges", "_leaderboard_" + name + ".lua")
            with open(f + ".tmp", "w", encoding="utf-8") as fh:
                fh.write(str(text)[:4 << 20])               # (a full board is 400 KB+ now: 200000 cut it mid-row = unreadable)
            os.replace(f + ".tmp", f)
        return {"ok": True}
    except OSError as e:
        return {"ok": False, "why": str(e)}

def write_board_key(save, key):
    """The app's Steam sign-in for the leaderboards, for the Stats mod (board_key.txt next to the game, only where the
    mod is installed): the mod then sends the hunting log and takes the hunter off by itself, the app closed or not."""
    key = str(key or "")
    if not re.fullmatch(r"[0-9a-f]{64}", key):
        return {"ok": False, "why": "no key"}
    try:
        pk = paks.find_paks_dir(save)
        d = os.path.join(pk, "..", "..", "Binaries", "Win64", "ue4ss", "Mods", "ToyboxStats") if pk else ""
        if not d or not os.path.isdir(d):
            return {"ok": False, "why": "no mod"}
        f = os.path.join(d, "board_key.txt")
        try:
            if open(f, encoding="utf-8").read().strip() == key:
                return {"ok": True}
        except OSError:
            pass
        with open(f + ".tmp", "w", encoding="utf-8") as fh:
            fh.write(key)
        os.replace(f + ".tmp", f)
        return {"ok": True}
    except OSError as e:
        return {"ok": False, "why": str(e)}

def save_facts_json(st):
    """After the game saved (the app open): the Stats mod's save facts again (distance driven), on the boards or not"""
    if st.no_save or not st.save or not os.path.isfile(st.save) or not stats_mod_here(st.save):
        return {"ok": False}
    s, _ = statsmod.read_stats(st.save, st.names)
    pk = paks.find_paks_dir(st.save)
    recs = rate_records(st, [record_json(h, st.names, pk) for h in s["harvests"]], _kills(st.save)) if s["total"] else []
    write_save_facts(st.save, recs, s)
    return {"ok": True}

def write_save_facts(save, recs, s):
    """What the Stats mod can't read in the game but the save has (challenges/_save_<hunter>.lua, next to the game,
    only where the mod is installed): the game's own distance driven, and each harvest's trophy score (the game keeps
    measurements only for the latest harvests; the rest are worked out like the Stats page does), by log id, so the
    leaderboards get the same scores from the mod as from the app. Written at every read of the stats; the mod only
    reads it."""
    hunter = next((r["hunter"] for r in reversed(recs) if r.get("hunter")), "") or "hunter"
    try:
        pk = paks.find_paks_dir(save)
        d = os.path.join(pk, "..", "..", "Binaries", "Win64", "ue4ss", "Mods", "ToyboxStats") if pk else ""
        if not d or not os.path.isdir(d):
            return
        os.makedirs(os.path.join(d, "challenges"), exist_ok=True)
        sc = ", ".join("[%d] = %d" % (int(r["i"]), int(r["score"])) for r in recs if int(r.get("score") or 0) > 0)
        # sold mule deer bucks only the non-typical lines fit: sent as non-typical (their own trophy board)
        nt = ", ".join("[%d] = true" % int(r["i"]) for r in recs if r.get("nt_guess") and int(r.get("score") or 0) > 0)
        for name in _lua_safe_names(hunter):
            f = os.path.join(d, "challenges", "_save_" + name + ".lua")
            with open(f + ".tmp", "w", encoding="utf-8") as fh:
                fh.write("-- written by the Toybox app from the save; the Stats mod only reads it\nreturn {updated = %d, driven_km = %.3f, scores = {%s}, nt = {%s}}\n"
                         % (int(time.time()), float(s.get("vehicle_km") or 0.0), sc, nt))
            os.replace(f + ".tmp", f)
    except OSError:
        pass

def mod_challenges(save, recs, names=None):
    """What the Toybox Stats mod keeps for this hunter (challenges/<hunter>.lua next to the game): when challenges
    started counting, the in-game day each map was last seen on and the log id that day's visit started at, the picked looks. {} when the mod is not there."""
    hunter = next((r["hunter"] for r in reversed(recs) if r.get("hunter")), "") or "hunter"
    try:
        pk = paks.find_paks_dir(save)
        if not pk:
            return {}
        t = None
        for name in _lua_safe_names(hunter):                 # (the mod names it in the PC's code page: _lua_safe_names)
            f = os.path.join(pk, "..", "..", "Binaries", "Win64", "ue4ss", "Mods", "ToyboxStats", "challenges", name + ".lua")
            if os.path.isfile(f):
                t = _mod_text(f); break
        if t is None:
            return {}
    except OSError:
        return {}
    out = {}
    m = re.search(r'\["since"\]\s*=\s*(\d+)', t)
    if m:
        out["since"] = int(m.group(1))
    m = re.search(r'\["played"\]\s*=\s*\{([^}]*)\}', t)    # the real day each map was last played (dailies)
    if m:
        out["played"] = {k: int(v) for k, v in re.findall(r'\["(\w+)"\]\s*=\s*(\d+)', m.group(1))}
    out["done"] = _mod_done(t, names)
    m = re.search(r'^  \["board"\] = \{(.*?)^  \}', t, re.M | re.S)  # the leaderboard answer asked in the ledger
    if m:
        b = m.group(1)
        j = re.search(r'\["join"\]\s*=\s*(true|false)', b); n = re.search(r'\["name"\]\s*=\s*"((?:[^"\\]|\\.)*)"', b); tt = re.search(r'\["t"\]\s*=\s*(\d+)', b)
        if j:
            name = re.sub(r'\\(.)', r'\1', n.group(1)) if n else ""       # the mod's %q escapes undone
            out["board"] = {"join": j.group(1) == "true", "name": name, "t": int(tt.group(1)) if tt else 0,
                            "mod": re.search(r'\["mod"\]\s*=\s*true', b) is not None}     # the mod joined by itself (its own Steam sign-in)
    m = re.search(r'\["kz"\]\s*=\s*\{([^}]*)\}', t)        # where each killing shot went (the shot tracker)
    if m:
        out["kz"] = dict(re.findall(r'\["(\d+:-?\d+)"\]\s*=\s*"([a-z,]*)"', m.group(1)))
    m = re.search(r'\["look"\]\s*=\s*\{([^}]*)\}', t)
    if m:
        out["look"] = dict(re.findall(r'\["(\w+)"\]\s*=\s*"([^"]*)"', m.group(1)))
    return out

def weapon_class(wid):
    w = wid.lower()
    for key, label in (("crossbow", "Crossbow"), ("bow", "Bow"), ("shotgun", "Shotgun"), ("handgun", "Handgun"), ("pistol", "Handgun"), ("revolver", "Handgun"), ("rifle", "Rifle")):
        if key in w:
            return label
    return "Other"

COAT_FIX = {"Pieblad": "Piebald", "Leucisitc": "Leucistic", "Tutorial": ""}    # game typos; the tutorial animal is no coat

def record_json(h, names, pk=None):
    """One hunting-log entry, everything the Stats page charts. wbug: heavier than the game can make it (the May-June
    2026 game bug): no heaviest record counts it."""
    import trophy_score
    var = "_".join(w for w in (COAT_FIX.get(p, p) for p in (h.variant or "").split("_")) if w)
    return {"i": h.index, "sp": h.subspecies, "name": names.subspecies(h.subspecies), "sex": h.sex, "var": var, "age": h.age, "stars": h.stars,
            "quality": h.quality or "", "roadkill": bool(h.roadkill), "dog": bool(h.dog), "seen": bool(h.seen), "track": round(h.tracked or 0.0, 1),
            "fitness": round(h.fitness, 3), "hunt": h.hunt_rating, "kg": round(h.weight, 1), "m": round(h.distance, 1),
            "wbug": trophy_score.weight_bug(h.subspecies, h.sex, h.weight, pk),
            "weapon": names.gear_name(h.weapon), "wclass": weapon_class(h.weapon), "ammo": names.caliber(h.ammo), "ammo_id": h.ammo,
            "weather": names.weather(h.weather), "wx": names.weather_kind(h.weather), "ghour": round(int(h.game_hour * 60.0) / 60.0, 5), "gmin": int(h.game_hour * 60.0), "gday": h.game_day, "map": h.map, "mapname": names.map(h.map),
            "when": h.when.strftime("%Y-%m-%dT%H:%M:%S") if h.when else None,
            "hunter": h.hunter or "", "weapon_id": h.weapon or "", "tut": "Tutorial" in (h.map or "") or h.variant == "Tutorial",
            "raw": [h.distance, h.weight, h.tracked or 0.0, h.fitness, h.game_hour]}     # unrounded, for the challenge rules (as the Stats mod reads them)

def _nt_lines(rater, species, sex):
    import trophy_score as ts
    return ts._match(getattr(rater, "req_nt", {}), species, sex)

def state_json(st):
    out = {"save": st.save, "game_running": core.game_running(), "names_src": st.names_src, "maps": {}, "stats_mod": stats_mod_here(st.save), "mod_board_ts": mod_board_asks(st.save)}
    if st.no_save:                                        # no save on purpose: nothing to read, nothing to complain about
        out["no_save_mode"] = True; out["backups"] = backups_json(None)
        return out
    if not st.save or not os.path.exists(st.save):
        out["error"] = "No SaveData.nrgs found"
        out["backups"] = backups_json(None)                # the Saves page still works: load or import a save back
        return out
    vals = core.read_values(st.save)
    out["values"] = {k: {"current": v[0], "max": v[1], "label": core.field_label(k)} for k, v in vals.items()}
    if "xp" in vals:
        out["rank"] = core.rank_of(vals["xp"][0])
    try:
        skills = core.read_skills(st.save); out["skills"] = {"have": len([n for n in skills if n not in core.SKILLS_NOT_IN_GAME]), "total": len(core.SKILL_PATHS)}
    except Exception:
        out["skills"] = None
    try:
        out["hq"] = core.read_hub_level(st.save)
    except Exception:
        out["hq"] = None
    try:
        out["jobs"] = core.read_jobs(st.save)
    except Exception:
        out["jobs"] = None
    try:
        ms = core.read_map_status(st.save, st.guid_data)
        for m, v in ms.items():
            out["maps"][m] = {"label": core.MAP_LABELS.get(m, m), "explored": v["explored"], "territories": v["territories"], "zones": v["zones"], "jobs": v.get("jobs"), "board": v.get("board"), "habitat": v.get("habitat")}
    except Exception as e:
        out["maps_error"] = _plain(e)
    pend = reset_pending_maps(st)                         # RESET ANIMALS waiting for the game: animal edits there are refused
    for m, v in out["maps"].items():
        v["reset_pending"] = m in pend
    out["reset_pending"] = sorted(pend)
    try:
        import names as names_mod, nrgs
        out["names"] = names_mod.read_names(nrgs.SaveFile(st.save))
    except Exception as e:
        out["names"] = None; out["names_error"] = _plain(e)
    out["int_max"] = core.INT_MAX
    try:
        out["time"] = core.read_game_time(st.save)          # per-map in-game clock (day + time of day) + weather
        _weather_names(out["time"].values(), st.names)
    except Exception as e:
        out["time"] = {}; out["time_error"] = _plain(e)
    out["save_mtime"] = os.path.getmtime(st.save)
    out["backups"] = backups_json(st.save)
    out["history"] = core.history(st.save)[:40]
    out["rares"] = rares_json(st)
    return out

def reset_pending_maps(st):
    """{map names whose animals the game replaces on the next load} (a RESET ANIMALS not yet loaded in the game)."""
    try:
        import animals, nrgs
        sf = nrgs.SaveFile(st.save)
    except Exception:                                     # locked or no save: nothing to say
        return set()
    out = set()
    for m in core.MAPS:
        try:
            if animals.reset_pending(sf, m, st.guid_data[m][0]):
                out.add(m)
        except Exception:
            continue
    return out

def rares_json(st):
    """Rare-fur / unique / unusual-trophy animals on every map (fast: animal records only)."""
    import nrgs
    out = {}
    try:
        import animals
    except ImportError:                                   # locked
        return out
    if not st.save or not st.guid_data:
        return out
    try:
        sf = nrgs.SaveFile(st.save)
    except Exception:
        return out
    for m in core.MAPS:
        try:
            an = animals.read_animals(sf, m, st.guid_data[m][0])
        except Exception:
            continue
        lst = []
        for a in an:
            if (a["variant"] or a.get("quality", "Typical") != "Typical") and not a.get("harvested"):
                lst.append({"id": a["id"], "species": a["species"], "name": st.names.subspecies(a["species"]), "sex": a["sex"], "variant": a["variant"], "kind": a.get("kind", ""),
                            "quality": a.get("quality", "Typical"), "fitness": round(a["fitness"], 3), "hit": bool(a.get("harvested")), "wounded": bool(a.get("hit")) and not a.get("harvested") and not a.get("lost"), "lost": bool(a.get("lost")), "x": round(a["x"]), "y": round(a["y"]), "z": round(a["z"])})
        out[m] = {"label": core.MAP_LABELS.get(m, m), "animals": lst, "total": len(an)}
    return out

_GAME_OLDEST = []
def _game_oldest(save):
    """{species: oldest age} from the game files (cached; {} when the game is not here)."""
    if not _GAME_OLDEST:
        try:
            import trophy_score
            d = paks.find_paks_dir(save)
            _GAME_OLDEST.append(trophy_score.game_max_ages(d) if d else {})
        except Exception:
            _GAME_OLDEST.append({})
    return _GAME_OLDEST[0]

def backups_json(save=None):
    """The Saves page: every copy with its money / rank points, why it was made (label), whether the app made it by
    itself (auto) and whether it is the very save in the game right now (in_game)."""
    baks = core.list_backups()
    orig = os.path.exists(core.ORIGINAL_BACKUP)
    facts = core.backup_facts(baks + ([core.ORIGINAL_BACKUP] if orig else []))
    cur = core.file_hash(save) if save and os.path.isfile(save) else None
    labels = core.backup_labels()
    def one(b):
        f = facts.get(b, {})
        n = os.path.basename(b)
        return {"path": b, "name": n, "mtime": core.backup_time(b), "size": os.path.getsize(b), "money": f.get("money"), "xp": f.get("xp"),
                "rank": core.rank_of(f["xp"]) if f.get("xp") is not None else None,
                "auto": bool(core.AUTO_BACKUP_RE.match(n)), "label": labels.get(n, ""), "in_game": bool(cur) and f.get("hash") == cur}
    files = [one(b) for b in baks]
    oinfo = one(core.ORIGINAL_BACKUP) if orig else {}
    seen = False                                          # several identical copies: the newest gets the badge, the rest say "same"
    for f in files + ([oinfo] if oinfo else []):
        if f["in_game"]:
            f["same_as_game"] = seen; f["in_game"] = not seen; seen = True
    slot = core.loaded_slot()
    return {"original": orig, "original_info": oinfo, "dir": core.BACKUP_DIR, "files": files,
            "slot": os.path.basename(slot)[:-5] if slot else "", "slot_path": slot or ""}

def _herd_data(save, m):
    """(territory sizes, group sizes, ecosystems) for herd sizes (herds.py), kept on disk per game build: reading
    them goes through every game file index (~2.2 s per map load)."""
    key = (m, )
    if key not in _HERD_CACHE:
        try:
            import herds
            d = paks.find_paks_dir(save)
            if not d:
                _HERD_CACHE[key] = ({}, {}, {})
            else:
                build = paks.game_build(d); fp = paks._user_cache_file("herd_data_%s.json" % m)
                try:
                    with open(fp) as f:
                        j = json.load(f)
                    if j.get("game") != build: raise ValueError("other game build")
                    _HERD_CACHE[key] = tuple(j["data"])
                except (OSError, ValueError, KeyError, TypeError):
                    data = (herds.territory_sizes(d, m), herds.group_sizes(d), herds.ecosystems(d, m))
                    _HERD_CACHE[key] = tuple(json.loads(json.dumps(data)))     # the same shapes whether read or built
                    try:
                        os.makedirs(os.path.dirname(fp), exist_ok=True)
                        with open(fp + ".tmp", "w") as f:
                            f.write(json.dumps({"game": build, "data": data}))
                        os.replace(fp + ".tmp", fp)
                    except OSError:
                        pass
        except Exception:
            _HERD_CACHE[key] = ({}, {}, {})
    return _HERD_CACHE[key]
_HERD_CACHE = {}

def model_json(m, model, st):
    n = st.names
    hsizes, hgroups, heco = _herd_data(st.save, m)
    terrs = []
    hfit = getattr(model, "herd_fit", {})                 # herd fitness from the save (shown on hover and on the herd card)
    for t in model.territories.values():
        terrs.append({"guid": t["guid"], "species": t["species"], "name": n.subspecies(t["species"]) if t["species"] != "Unknown" else "Unknown",
                      "size": hsizes.get(t["guid"], ""), "now": getattr(model, "herd_n", {}).get(t["guid"]), **({"fit": hfit.get(t["guid"])} if hfit else {}),
                      "x": round(t["cx"]), "y": round(t["cy"]), "discovered": t["discovered"], "trails": t["trails"],
                      "zones": [{"guid": z["guid"], "x": round(z["x"]), "y": round(z["y"]), "z": round(z["z"]), "type": z["type"], "discovered": z["discovered"],
                                 "shape": z.get("shape"), "w": z.get("w"), "h": z.get("h"), "role": z.get("role")} for z in t["zones"]]})
    try:
        import animals as animals_mod
    except ImportError:                                   # locked: no individual animals at all
        animals_mod = None
    oldest = st.max_ages()
    sizes = animals_mod.rack_sizes(model.animals, oldest) if animals_mod else {}
    oldest = {**_game_oldest(st.save), **oldest}           # no save (web, console players): the game's own oldest ages
    species = {}
    for t in model.territories.values():
        sid = t["species"]
        if sid not in species:
            sched = model.schedule_for(sid)
            species[sid] = {"name": n.subspecies(sid) if sid != "Unknown" else "Unknown", "latin": n.latin(sid) if sid != "Unknown" else "",
                            "schedule": {k: [(a, b) for a, b in v] for k, v in sched.items()}, "herds": 0, "max_age": _oldest_for(sid, oldest),
                            "groups": hgroups.get(sid) or next((v for k, v in hgroups.items() if k.startswith(sid) or sid.startswith(k)), {})}
        species[sid]["herds"] += 1
    rater = st.rater() if animals_mod else None
    def trophy(a):
        """stars the way the game rates the animal (trophy_score), the old size estimate when it cannot"""
        size = sizes.get(a["id"], (0.0, False))[0]
        if rater and a.get("quality") == "NonTypical":     # own star lines and own rack (1.3)
            r = rater.rate(a["species"], a["sex"], a.get("age", 0), a["fitness"], size, blob=a.get("rack_blob"), weight=a.get("weight"),
                           variant=a.get("variant", ""), quality="NonTypical")
            if r:
                out = {"stars": r["stars"], "stars_lo": r["stars_lo"], "stars_hi": r["stars_hi"], "score": r["score"], "req": r["req"],
                       "score_how": r["how"], "nontypical": True}
                for k in ("p4", "p5", "pstars"):
                    if r.get(k) is not None: out[k] = r[k]
                return out
            req = _nt_lines(rater, a["species"], a["sex"])
            if req:
                return {"stars": 1, "stars_lo": 1, "stars_hi": 5, "req": req, "nontypical": True}
        r = rater.rate(a["species"], a["sex"], a.get("age", 0), a["fitness"], size, hidden=a.get("rack_hidden"), blob=a.get("rack_blob"),
                        weight=a.get("weight"), variant=a.get("variant", "")) if rater else None
        if not r:
            if rater:                                     # no trophy lines for it (e.g. does): no trophy rating
                return {"no_trophy": True}
            s = animals_mod.stars(size)
            return {"stars": s, "stars_lo": s, "stars_hi": s}
        out = {"stars": r["stars"], "stars_lo": r["stars_lo"], "stars_hi": r["stars_hi"], "score": r["score"], "req": r["req"], "score_how": r["how"]}
        if "p5" in r: out["p5"] = r["p5"]; out["p4"] = r["p4"]       # chance of 5 / 4+ stars when this year's rack grows
        if r.get("pstars"): out["pstars"] = r["pstars"]                # chance of each star rating
        return out
    animals = [dict({"id": a["id"], "species": a["species"], "sex": a["sex"], "variant": a["variant"], "kind": a.get("kind", ""), "quality": a.get("quality", "Typical"), "coat_wrong": bool(a.get("coat_wrong")),
                "fitness": round(a["fitness"], 3), "age": a.get("age", 0), "hit": bool(a.get("harvested")), "wounded": bool(a.get("hit")) and not a.get("harvested") and not a.get("lost"), "lost": bool(a.get("lost")), "x": round(a["x"]), "y": round(a["y"]), "z": round(a["z"]), "terr": a.get("terr"),
                "rack": bool(a.get("trophy_generated")), "size": round(sizes.get(a["id"], (0.0, False))[0], 3),
                "name": n.subspecies(a["species"]) if a["species"] != "Unknown" else "Unknown"}, **trophy(a)) for a in (model.animals if animals_mod else [])]
    try:
        import rackscore; rackscore.save_cache()
    except Exception:
        pass
    import stands, nrgs
    placed, markers, opps = [], [], []
    if st.no_save:
        opps = stands.opportunities(m, None)
    try:
        sf = nrgs.SaveFile(st.save)
        opps = stands.opportunities(m, sf)
        gear, mk = stands.read_placed(sf, m)
        placed = [{"cls": c, "kind": "tent" if "Tent" in c else ("tripod" if "Tripod" in c else ("blind" if "Blind" in c else "decoy")), "x": round(x), "y": round(y), "z": round(z)} for c, x, y, z in gear]
        lbls = stands.marker_labels(m)
        markers = [{"x": round(x), "y": round(y), "z": round(z), "type": t, "label": stands.label_for(lbls, x, y)} for x, y, z, t in mk]
    except Exception:
        pass
    try:
        gtime = core.read_game_time(st.save).get(m)
        if gtime: _weather_names([gtime], st.names)
    except Exception:
        gtime = None
    try:
        import animals as _am
        pending = bool(st.save) and _am.reset_pending(nrgs.SaveFile(st.save), m, st.guid_data[m][0])
    except Exception:
        pending = False
    return {"map": m, "label": core.MAP_LABELS.get(m, m), "L": model.L, "reset_pending": pending, "player": model.player, "height_fit": list(model.height_fit),
            "time": gtime, "save_mtime": os.path.getmtime(st.save) if st.save and os.path.exists(st.save) else 0, "no_save": st.no_save,
            "animals": animals, "variants": animal_options(), "placed": placed, "markers": markers, "stands": [s for s in stands.remembered(m)          # only stands still in this save (picked up / undone / other save = gone)
                       if any(g["kind"] == "tripod" and abs(g["x"] - s["x"]) < 300 and abs(g["y"] - s["y"]) < 300 for g in placed)],
            "facilities": [{"x": x, "y": y, "kind": k, "name": n} for x, y, k, n in stands.facilities(m)], "opportunities": opps, "marker_types": stands.MARKER_TYPES, "max_markers": stands.MAX_MARKERS,
            "has_2d": model.map2d is not None, "has_3d": model.satellite is not None, "has_height": model.height is not None,
            "territories": terrs, "species": species, "herd_eco": heco, "roads": model.roads, "rivers": model.rivers, "has_lakes": model.lakes is not None, "discovered_zones": sum(1 for z in model.zones if z["discovered"]), "zones": len(model.zones), "trails": len(model.splines)}

def animal_options():
    """{subspecies: {"M": [variants], "F": [variants]}} that the game has rare-fur configs for."""
    try:
        import animals
    except ImportError:
        return {}
    return animals.released_rare_fur()

def fow_png(model):
    from PIL import Image
    import numpy as np
    if not model.fow:
        return None
    b = np.frombuffer(model.fow, dtype=np.uint8)
    g = np.empty((1024, 1024), dtype=np.uint8); g[:, 0::2] = (b >> 4).reshape(1024, 512); g[:, 1::2] = (b & 15).reshape(1024, 512)
    buf = io.BytesIO(); Image.fromarray((g * 17).astype(np.uint8)).save(buf, "PNG"); return buf.getvalue()
