"""Shared state + JSON views for the WOTH2 Toybox app: the loaded save, names, map models and the
dictionaries the Godot front end reads (woth2_core.py prints them). Formerly the web app's server module."""
import io, json, math, os, sys, threading

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import trainer_core as core
import stats as statsmod
import woth2_paks as paks
import mapdata

class State:
    def __init__(self, save_path=None):
        self.lock = threading.Lock()
        self.no_save = os.environ.get("WOTH2_NOSAVE") == "1" and not save_path     # console players: map from game data only
        try:
            self.save = None if self.no_save else (save_path or core.find_save())   # the logged-in Steam account's save when there are several
        except FileNotFoundError:
            self.save = core.save_target()                  # none yet (START FRESH): where the game will put it
        tbl, self.names_src = paks.english_names(self.save)
        self.names = statsmod.Names(tbl)
        try:
            self.guid_data, self.guid_src = paks.all_map_guids(self.save)
        except Exception as e:
            self.guid_data, self.guid_src = None, str(e)
        self.models = {}
        self.progress = {}
        self._max_ages = None
        self._rater = None

    def rater(self):
        """trophy_score.Rater for this save (game thresholds + what the save's measured trophies teach), cached."""
        if self._rater is None:
            import nrgs, trophy_score
            try:
                self._rater = trophy_score.Rater(paks.find_paks_dir(self.save), nrgs.SaveFile(self.save), self.max_ages())
            except Exception:
                self._rater = False
        return self._rater or None

    def max_ages(self):
        """{subspecies: oldest age in the save} (the divisor of the game's rack-size formula), cached."""
        if self._max_ages is None:
            import nrgs
            try:
                import animals                             # locked (vault.py): no ages without the code
                self._max_ages = animals.max_ages(nrgs.SaveFile(self.save), self.guid_data) if self.save and self.guid_data else {}
            except Exception:
                self._max_ages = {}
            for sp, v in game_facts().get("species", {}).items():      # species not in the save (or no animals read): the game's own cap
                if v.get("max_age") and sp not in self._max_ages:
                    self._max_ages[sp] = v["max_age"]
        return self._max_ages

    def _progress(self, m, stage):
        """Remember the build stage; with WOTH2_PROGRESS set (the app does) also write "step/steps stage" there
        so the loading screen can show a bar while the first launch reads the game files."""
        self.progress[m] = stage
        fn = os.environ.get("WOTH2_PROGRESS")
        if not fn:
            return
        stages = mapdata.BUILD_STAGES
        k = stages.index(stage) + 1 if stage in stages else 0
        try:
            with open(fn, "w") as f:
                f.write(f"{k}/{len(stages)} {stage}")
        except OSError:
            pass

    def model(self, m):
        with self.lock:
            if m not in self.models:
                self.models[m] = mapdata.load_map(m, self.save, progress=lambda s: self._progress(m, s))
            return self.models[m]

    def invalidate(self):
        with self.lock:
            self.models = {}
            self._max_ages = None

_GAME_FACTS = None
def game_facts():
    global _GAME_FACTS
    if _GAME_FACTS is None:
        try:
            with open(os.path.join(HERE, "game_facts.json"), encoding="utf-8") as f:
                _GAME_FACTS = json.load(f)
        except (OSError, ValueError):
            _GAME_FACTS = {}
    return _GAME_FACTS

# ---------------------------------------------------------------- JSON helpers
def harvest_json(h, names):
    if h is None:
        return None
    return {"species": names.subspecies(h.subspecies), "sex": h.sex, "weight": round(h.weight, 1), "distance": round(h.distance, 1),
            "weapon": names.gear_name(h.weapon), "ammo": names.caliber(h.ammo), "map": names.map(h.map), "when": h.when.isoformat() if h.when else None,
            "fitness": round(h.fitness, 3), "hunt": h.hunt_rating}

def group_json(entries, names):
    out = []
    for e in entries:
        out.append({"name": e["name"], "latin": e.get("latin", ""), "total": e["total"], "m": e["m"], "f": e["f"],
                    "heaviest": harvest_json(e["heaviest"], names), "longest": harvest_json(e["longest"], names),
                    "last": e["last"].isoformat() if e["last"] else None, "sub": e["sub"].most_common(6)})
    return out

LAYOUT_MSG = "This save is laid out in a way the Toybox doesn't know. Nothing was changed."

def _plain(e):
    """An exception as the app shows it (woth2_core.plain_error), logged in full; never raw save-format text."""
    try:
        import woth2_core
        woth2_core.log_error(e)
        return woth2_core.plain_error(e)
    except Exception:
        return LAYOUT_MSG

def _oldest_for(sid, oldest):
    """The oldest age for a species id; animal configs sometimes use a shorter name than the subspecies
    (StruthioCamelus -> StruthioCamelusAustralis), so match by prefix (same rule as animals.oldest_for)."""
    if sid in oldest:
        return oldest[sid]
    return next((v for s, v in sorted(oldest.items()) if s.startswith(sid) or sid.startswith(s)), 0)

def progress_json(st):
    """Challenges + missions (done / in progress / not started) for the Stats page. No save: the full list, none started
    (the app keeps your own ticks)."""
    import missions, nrgs
    try:
        if st.no_save or not st.save:                     # the list shipped with the app: no game folder search (web, consoles)
            with open(missions.CATALOG_CACHE, encoding="utf-8") as f:
                return missions.overview(None, json.load(f))
        return missions.overview(nrgs.SaveFile(st.save), missions.catalog(st.save))
    except Exception as e:                        # never lose the hunting stats over this
        _plain(e)                                 # logged in full
        return {"challenges": [], "missions": [], "error": "This save's challenges and missions could not be read."}

def _weather_names(times, names):
    """Adds the game's names for the clock's weather ("Light fog", "Moderate snow") next to the tags."""
    for t in times:
        for k in ("weather", "weather_next"):
            if t.get(k): t[k + "_name"] = names.weather(t[k])

def _kills(save):
    try:
        import nrgs, trophy_score
        return trophy_score.kill_records(nrgs.SaveFile(save))
    except Exception:
        return []

def rate_records(st, recs, kills):
    """Adds the trophy to every hunting-log entry: "stars" = the game's own stars (the log keeps them for every kill),
    "score" + "est". The score is the game's measurement when the save still holds it, else worked out from age,
    fitness and weight, and only kept when it gives the same stars. "est" = antlers or horns the game no longer has
    measurements of (most likely score)."""
    measured = {}
    for k in kills:
        key = (k["species"], k["sex"], k["age"], round(k["fit"], 3))
        measured[key] = max(measured.get(key, 0), int(k["score"]))
    rater = st.rater()
    for r in recs:
        r["score"] = 0
        n = r.get("stars", 0)
        if not n:
            continue
        req = rater.thresholds_for(r["sp"], r["sex"]) if rater else None
        stars_of = lambda sc: 0 if sc < 1 else 1 + sum(1 for t in req if sc >= t)
        key = (r["sp"], r["sex"], r.get("age", 0), round(r["fitness"], 3))
        if req and key in measured and stars_of(measured[key]) == n:
            r.update(score=measured[key], est=False)
            continue
        if not req or not r.get("age"):
            continue
        try:
            q = rater.rate(r["sp"], r["sex"], r["age"], r["fitness"], 0, weight=r["kg"], variant=r["var"])
        except Exception:
            q = None
        if q and stars_of(q["score"]) == n:
            r.update(score=int(q["score"]), est=q["how"] != "exact")
    return recs

def best_scores(save, recs=()):
    """{subspecies: {"M": score, "F": score}}: the best trophy score of every kill the game measured (the save's own
    kill lists plus every one the app has kept from earlier reads) and of every hunting-log kill whose score is known
    for sure (weight, skull and length trophies)."""
    out = {}
    for r in _kills(save):
        d = out.setdefault(r["species"], {})
        d[r["sex"]] = max(d.get(r["sex"], 0), int(r["score"]))
    for r in recs:
        if r.get("score") and not r.get("est"):
            d = out.setdefault(r["sp"], {})
            d[r["sex"]] = max(d.get(r["sex"], 0), int(r["score"]))
    return out

def best_stars(recs):
    """{subspecies: {"M": stars}}: the most stars the game gave any kill in the hunting log."""
    out = {}
    for r in recs:
        if r.get("stars"):
            d = out.setdefault(r["sp"], {})
            d[r["sex"]] = max(d.get(r["sex"], 0), int(r["stars"]))
    return out

def best_guesses(recs):
    """{subspecies: {"M": [score, stars_lo, stars_hi]}}: the best unmeasured antler/horn kill (most likely score)."""
    out = {}
    for r in recs:
        if r.get("score") and r.get("est"):
            d = out.setdefault(r["sp"], {})
            if r["score"] > d.get(r["sex"], [0])[0]:
                d[r["sex"]] = [r["score"], r["stars"], r["stars"]]
    return out

def skills_owned(save):
    """Numbers ("015") of the skills the save has unlocked."""
    try:
        import re
        return sorted({m.group(1) for n in core.read_skills(save) for m in [re.search(r"DA_CharacterSkill_(\d+)", n)] if m})
    except Exception:
        return None

def stats_json(st):
    if st.no_save or not st.save:
        return {"no_save": True, "progress": progress_json(st)}
    s, notes = statsmod.read_stats(st.save, st.names)
    if not s["total"]:
        return {"total": 0, "notes": notes, "progress": progress_json(st), "best_scores": best_scores(st.save), "skills_owned": skills_owned(st.save)}
    n = st.names
    recs = rate_records(st, [record_json(h, n) for h in s["harvests"]], _kills(st.save))
    return {"progress": progress_json(st), "total": s["total"], "males": s["males"], "females": s["females"], "species_count": s["species_count"], "hunters": s["hunters"],
            "first": s["first"].isoformat() if s["first"] else None, "last": s["last"].isoformat() if s["last"] else None,
            "longest": harvest_json(s["longest"], n), "heaviest": harvest_json(s["heaviest"], n), "best_fitness": harvest_json(s["best_fitness"], n), "best_hunt": harvest_json(s["best_hunt"], n),
            "hours_in_hand": round(s["hours_in_hand"], 1), "vehicle_km": round(s["vehicle_km"], 1),
            "by_species": group_json(s["by_species"], n), "by_weapon": group_json(s["by_weapon"], n), "by_ammo": group_json(s["by_ammo"], n),
            "by_map": group_json(s["by_map"], n), "by_weather": group_json(s["by_weather"], n),
            "gear_overall": [(k, round(v, 1)) for k, v in s["gear_overall"] if v >= 0.05], "notes": notes,
            "gear_time": {m: {c: [(k, round(v, 2)) for k, v in items if v >= 0.05] for c, items in cats.items()} for m, cats in s["gear_time"].items()},
            "records": recs, "best_scores": best_scores(st.save, recs), "best_guesses": best_guesses(recs), "best_stars": best_stars(recs), "skills_owned": skills_owned(st.save)}

def weapon_class(wid):
    w = wid.lower()
    for key, label in (("crossbow", "Crossbow"), ("bow", "Bow"), ("shotgun", "Shotgun"), ("handgun", "Handgun"), ("pistol", "Handgun"), ("revolver", "Handgun"), ("rifle", "Rifle")):
        if key in w:
            return label
    return "Other"

COAT_FIX = {"Pieblad": "Piebald", "Leucisitc": "Leucistic", "Tutorial": ""}    # game typos; the tutorial animal is no coat

def record_json(h, names):
    """One hunting-log entry, everything the Stats page charts."""
    var = "_".join(w for w in (COAT_FIX.get(p, p) for p in (h.variant or "").split("_")) if w)
    return {"i": h.index, "sp": h.subspecies, "name": names.subspecies(h.subspecies), "sex": h.sex, "var": var, "age": h.age, "stars": h.stars,
            "fitness": round(h.fitness, 3), "hunt": h.hunt_rating, "kg": round(h.weight, 1), "m": round(h.distance, 1),
            "weapon": names.gear_name(h.weapon), "wclass": weapon_class(h.weapon), "ammo": names.caliber(h.ammo), "ammo_id": h.ammo,
            "weather": names.weather(h.weather), "wx": names.weather_kind(h.weather), "ghour": round(int(h.game_hour * 60.0) / 60.0, 5), "gmin": int(h.game_hour * 60.0), "gday": h.game_day, "map": h.map, "mapname": names.map(h.map),
            "when": h.when.strftime("%Y-%m-%dT%H:%M:%S") if h.when else None}

def _nt_lines(rater, species, sex):
    import trophy_score as ts
    return ts._match(getattr(rater, "req_nt", {}), species, sex)

def state_json(st):
    out = {"save": st.save, "game_running": core.game_running(), "names_src": st.names_src, "maps": {}}
    if st.no_save:                                        # no save on purpose: nothing to read, nothing to complain about
        out["no_save_mode"] = True; out["backups"] = backups_json(None)
        return out
    if not st.save or not os.path.exists(st.save):
        out["error"] = "No SaveData.nrgs found"
        out["backups"] = backups_json(None)                # the Saves page still works: load or import a save back
        return out
    vals = core.read_values(st.save)
    out["values"] = {k: {"current": v[0], "max": v[1], "label": core.FIELDS[k][1]} for k, v in vals.items()}
    if "xp" in vals:
        out["rank"] = core.rank_of(vals["xp"][0])
    try:
        skills = core.read_skills(st.save); out["skills"] = {"have": len([n for n in skills if n not in core.SKILLS_NOT_IN_GAME]), "total": len(core.SKILL_PATHS)}
    except Exception:
        out["skills"] = None
    try:
        out["hq"] = core.read_hub_level(st.save)
    except Exception:
        out["hq"] = None
    try:
        out["jobs"] = core.read_jobs(st.save)
    except Exception:
        out["jobs"] = None
    try:
        ms = core.read_map_status(st.save, st.guid_data)
        for m, v in ms.items():
            out["maps"][m] = {"label": core.MAP_LABELS.get(m, m), "explored": v["explored"], "territories": v["territories"], "zones": v["zones"]}
    except Exception as e:
        out["maps_error"] = _plain(e)
    try:
        import names as names_mod, nrgs
        out["names"] = names_mod.read_names(nrgs.SaveFile(st.save))
    except Exception as e:
        out["names"] = None; out["names_error"] = _plain(e)
    out["int_max"] = core.INT_MAX
    try:
        out["time"] = core.read_game_time(st.save)          # per-map in-game clock (day + time of day) + weather
        _weather_names(out["time"].values(), st.names)
    except Exception as e:
        out["time"] = {}; out["time_error"] = _plain(e)
    out["save_mtime"] = os.path.getmtime(st.save)
    out["backups"] = backups_json(st.save)
    out["history"] = core.history(st.save)[:40]
    out["rares"] = rares_json(st)
    return out

def rares_json(st):
    """Rare-fur / unique / unusual-trophy animals on every map (fast: animal records only)."""
    import nrgs
    out = {}
    try:
        import animals
    except ImportError:                                   # locked
        return out
    if not st.save or not st.guid_data:
        return out
    try:
        sf = nrgs.SaveFile(st.save)
    except Exception:
        return out
    for m in core.MAPS:
        try:
            an = animals.read_animals(sf, m, st.guid_data[m][0])
        except Exception:
            continue
        lst = []
        for a in an:
            if (a["variant"] or a.get("quality", "Typical") != "Typical") and not a.get("hit"):
                lst.append({"id": a["id"], "species": a["species"], "name": st.names.subspecies(a["species"]), "sex": a["sex"], "variant": a["variant"], "kind": a.get("kind", ""),
                            "quality": a.get("quality", "Typical"), "fitness": round(a["fitness"], 3), "hit": bool(a.get("hit")), "x": round(a["x"]), "y": round(a["y"]), "z": round(a["z"])})
        out[m] = {"label": core.MAP_LABELS.get(m, m), "animals": lst, "total": len(an)}
    return out

_GAME_OLDEST = []
def _game_oldest(save):
    """{species: oldest age} from the game files (cached; {} when the game is not here)."""
    if not _GAME_OLDEST:
        try:
            import trophy_score
            d = paks.find_paks_dir(save)
            _GAME_OLDEST.append(trophy_score.game_max_ages(d) if d else {})
        except Exception:
            _GAME_OLDEST.append({})
    return _GAME_OLDEST[0]

def backups_json(save=None):
    """The Saves page: every copy with its money / rank points, why it was made (label), whether the app made it by
    itself (auto) and whether it is the very save in the game right now (in_game)."""
    baks = core.list_backups()
    orig = os.path.exists(core.ORIGINAL_BACKUP)
    facts = core.backup_facts(baks + ([core.ORIGINAL_BACKUP] if orig else []))
    cur = core.file_hash(save) if save and os.path.isfile(save) else None
    labels = core.backup_labels()
    def one(b):
        f = facts.get(b, {})
        n = os.path.basename(b)
        return {"path": b, "name": n, "mtime": core.backup_time(b), "size": os.path.getsize(b), "money": f.get("money"), "xp": f.get("xp"),
                "rank": core.rank_of(f["xp"]) if f.get("xp") is not None else None,
                "auto": bool(core.AUTO_BACKUP_RE.match(n)), "label": labels.get(n, ""), "in_game": bool(cur) and f.get("hash") == cur}
    files = [one(b) for b in baks]
    oinfo = one(core.ORIGINAL_BACKUP) if orig else {}
    seen = False                                          # several identical copies: the newest gets the badge, the rest say "same"
    for f in files + ([oinfo] if oinfo else []):
        if f["in_game"]:
            f["same_as_game"] = seen; f["in_game"] = not seen; seen = True
    slot = core.loaded_slot()
    return {"original": orig, "original_info": oinfo, "dir": core.BACKUP_DIR, "files": files,
            "slot": os.path.basename(slot)[:-5] if slot else "", "slot_path": slot or ""}

def _herd_data(save, m):
    """(territory sizes, group sizes, ecosystems) for herd sizes (herds.py), cached per game build."""
    key = (m, )
    if key not in _HERD_CACHE:
        try:
            import herds
            d = paks.find_paks_dir(save)
            _HERD_CACHE[key] = (herds.territory_sizes(d, m), herds.group_sizes(d), herds.ecosystems(d, m)) if d else ({}, {}, {})
        except Exception:
            _HERD_CACHE[key] = ({}, {}, {})
    return _HERD_CACHE[key]
_HERD_CACHE = {}

def model_json(m, model, st):
    n = st.names
    hsizes, hgroups, heco = _herd_data(st.save, m)
    terrs = []
    for t in model.territories.values():
        terrs.append({"guid": t["guid"], "species": t["species"], "name": n.subspecies(t["species"]) if t["species"] != "Unknown" else "Unknown",
                      "size": hsizes.get(t["guid"], ""), "now": getattr(model, "herd_n", {}).get(t["guid"]), "fit": getattr(model, "herd_fit", {}).get(t["guid"]),
                      "x": round(t["cx"]), "y": round(t["cy"]), "discovered": t["discovered"], "trails": t["trails"],
                      "zones": [{"guid": z["guid"], "x": round(z["x"]), "y": round(z["y"]), "z": round(z["z"]), "type": z["type"], "discovered": z["discovered"],
                                 "shape": z.get("shape"), "w": z.get("w"), "h": z.get("h"), "role": z.get("role")} for z in t["zones"]]})
    try:
        import animals as animals_mod
    except ImportError:                                   # locked: no individual animals at all
        animals_mod = None
    oldest = st.max_ages()
    sizes = animals_mod.rack_sizes(model.animals, oldest) if animals_mod else {}
    oldest = {**_game_oldest(st.save), **oldest}           # no save (web, console players): the game's own oldest ages
    species = {}
    for t in model.territories.values():
        sid = t["species"]
        if sid not in species:
            sched = model.schedule_for(sid)
            species[sid] = {"name": n.subspecies(sid) if sid != "Unknown" else "Unknown", "latin": n.latin(sid) if sid != "Unknown" else "",
                            "schedule": {k: [(a, b) for a, b in v] for k, v in sched.items()}, "herds": 0, "max_age": _oldest_for(sid, oldest),
                            "groups": hgroups.get(sid) or next((v for k, v in hgroups.items() if k.startswith(sid) or sid.startswith(k)), {})}
        species[sid]["herds"] += 1
    rater = st.rater() if animals_mod else None
    def trophy(a):
        """stars the way the game rates the animal (trophy_score), the old size estimate when it cannot"""
        size = sizes.get(a["id"], (0.0, False))[0]
        if rater and a.get("quality") == "NonTypical":     # own star lines; the rack builder can't grow these racks yet
            req = _nt_lines(rater, a["species"], a["sex"])
            if req:
                return {"stars": 1, "stars_lo": 1, "stars_hi": 5, "req": req, "nontypical": True}
        r = rater.rate(a["species"], a["sex"], a.get("age", 0), a["fitness"], size, hidden=a.get("rack_hidden"), blob=a.get("rack_blob"),
                        weight=a.get("weight"), variant=a.get("variant", "")) if rater else None
        if not r:
            if rater:                                     # no trophy lines for it (e.g. does): no trophy rating
                return {"no_trophy": True}
            s = animals_mod.stars(size)
            return {"stars": s, "stars_lo": s, "stars_hi": s}
        out = {"stars": r["stars"], "stars_lo": r["stars_lo"], "stars_hi": r["stars_hi"], "score": r["score"], "req": r["req"], "score_how": r["how"]}
        if "p5" in r: out["p5"] = r["p5"]; out["p4"] = r["p4"]       # chance of 5 / 4+ stars when this year's rack grows
        if r.get("pstars"): out["pstars"] = r["pstars"]                # chance of each star rating
        return out
    animals = [dict({"id": a["id"], "species": a["species"], "sex": a["sex"], "variant": a["variant"], "kind": a.get("kind", ""), "quality": a.get("quality", "Typical"), "coat_wrong": bool(a.get("coat_wrong")),
                "fitness": round(a["fitness"], 3), "age": a.get("age", 0), "hit": bool(a.get("hit")), "x": round(a["x"]), "y": round(a["y"]), "z": round(a["z"]), "terr": a.get("terr"),
                "rack": bool(a.get("trophy_generated")), "size": round(sizes.get(a["id"], (0.0, False))[0], 3),
                "name": n.subspecies(a["species"]) if a["species"] != "Unknown" else "Unknown"}, **trophy(a)) for a in (model.animals if animals_mod else [])]
    try:
        import rackscore; rackscore.save_cache()
    except Exception:
        pass
    import stands, nrgs
    placed, markers, opps = [], [], []
    if st.no_save:
        opps = stands.opportunities(m, None)
    try:
        sf = nrgs.SaveFile(st.save)
        opps = stands.opportunities(m, sf)
        gear, mk = stands.read_placed(sf, m)
        placed = [{"cls": c, "kind": "tent" if "Tent" in c else ("tripod" if "Tripod" in c else ("blind" if "Blind" in c else "decoy")), "x": round(x), "y": round(y), "z": round(z)} for c, x, y, z in gear]
        lbls = stands.marker_labels(m)
        markers = [{"x": round(x), "y": round(y), "z": round(z), "type": t, "label": stands.label_for(lbls, x, y)} for x, y, z, t in mk]
    except Exception:
        pass
    try:
        gtime = core.read_game_time(st.save).get(m)
        if gtime: _weather_names([gtime], st.names)
    except Exception:
        gtime = None
    return {"map": m, "label": core.MAP_LABELS.get(m, m), "L": model.L, "player": model.player, "height_fit": list(model.height_fit),
            "time": gtime, "save_mtime": os.path.getmtime(st.save) if st.save and os.path.exists(st.save) else 0, "no_save": st.no_save,
            "animals": animals, "variants": animal_options(), "placed": placed, "markers": markers, "stands": [s for s in stands.remembered(m)          # only stands still in this save (picked up / undone / other save = gone)
                       if any(g["kind"] == "tripod" and abs(g["x"] - s["x"]) < 300 and abs(g["y"] - s["y"]) < 300 for g in placed)],
            "facilities": [{"x": x, "y": y, "kind": k, "name": n} for x, y, k, n in stands.facilities(m)], "opportunities": opps, "marker_types": stands.MARKER_TYPES, "max_markers": stands.MAX_MARKERS,
            "has_2d": model.map2d is not None, "has_3d": model.satellite is not None, "has_height": model.height is not None,
            "territories": terrs, "species": species, "herd_eco": heco, "roads": model.roads, "rivers": model.rivers, "has_lakes": model.lakes is not None, "discovered_zones": sum(1 for z in model.zones if z["discovered"]), "zones": len(model.zones), "trails": len(model.splines)}

def animal_options():
    """{subspecies: {"M": [variants], "F": [variants]}} that the game has rare-fur configs for."""
    try:
        import animals
    except ImportError:
        return {}
    return animals.released_rare_fur()

def fow_png(model):
    from PIL import Image
    import numpy as np
    if not model.fow:
        return None
    b = np.frombuffer(model.fow, dtype=np.uint8)
    g = np.empty((1024, 1024), dtype=np.uint8); g[:, 0::2] = (b >> 4).reshape(1024, 512); g[:, 1::2] = (b & 15).reshape(1024, 512)
    buf = io.BytesIO(); Image.fromarray((g * 17).astype(np.uint8)).save(buf, "PNG"); return buf.getvalue()
