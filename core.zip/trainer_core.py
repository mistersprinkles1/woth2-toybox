"""Shared logic for the CLI and GUI: locate the save, read/write values, backups."""
import datetime, glob, hashlib, json, os, re, shutil, struct, zlib

HERE = os.path.dirname(os.path.abspath(__file__))
import sys; sys.path.insert(0, HERE)
import nrgs
import hostos

SAVE_REL = "WOTH2/Saved/SaveGames/Account_*/SaveData.nrgs"           # under the Windows user's AppData/Local
PROTON_REL = "steamapps/compatdata/2543830/pfx/drive_c/users/steamuser/AppData/Local/" + SAVE_REL

def user_data_dir():
    """Where the app keeps its own files (backups) when it is not run from a source checkout."""
    if hostos.WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return os.path.join(base, "woth2-toybox")

def save_globs():
    """Every place a SaveData.nrgs can live: Windows AppData, Proton prefixes in every Steam library."""
    globs = []
    if hostos.WINDOWS:
        la = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local")
        globs.append(os.path.join(la, *SAVE_REL.split("/")))
    for root in ("~/.steam/steam", "~/.local/share/Steam", "~/.steam/root", "~/.var/app/com.valvesoftware.Steam/.local/share/Steam"):
        globs.append(os.path.join(os.path.expanduser(root), PROTON_REL))
    try:
        import woth2_paks
        for lib in woth2_paks.steam_libraries():
            globs.append(os.path.join(lib, PROTON_REL))
    except Exception:
        pass
    return globs

BACKUP_DIR = os.path.join(HERE, "backups") if os.path.isdir(os.path.join(HERE, "backups")) else os.path.join(user_data_dir(), "backups")
ORIGINAL_BACKUP = os.path.join(BACKUP_DIR, "SaveData-ORIGINAL.nrgs")
PART = "Game_0/GameData"
INT_MAX = 0x7FFFFFFF
SKILLS_SECTION = 0x5DC08F25          # section of GameData holding the unlocked-skill list
SKILL_DIR = "/Game/BASE/Game/CharacterProgression/CharacterSkills/Skills/"
# (folder, asset) for every skill referenced by the five skill trees (from the game's pak index)
SKILLS = [
    ("CharacterSkill001", "DA_CharacterSkill_001"), ("CharacterSkill002_ImproveBlinds", "DA_CharacterSkill_002"),
    ("CharacterSkill003_ImproveStands", "DA_CharacterSkill_003"), ("CharacterSkill004_ImproveScents", "DA_CharacterSkill_004_ImproveScents"),
    ("CharacterSkill005_ImproveCallers", "DA_CharacterSkill_005_ImproveCallers"), ("CharacterSkill006_ImproveDecoys", "DA_CharacterSkill_006_ImproveDecoys"),
    ("CharacterSkill007_DecreaseAnimalAttacks", "DA_CharacterSkill_007"), ("CharacterSkill008_ImproveDogFocus", "DA_CharacterSkill_008"),
    ("CharacterSkill009_UndetectableDog", "DA_CharacterSkill_009"), ("CharacterSkill010_HearMoreAnimals", "DA_CharacterSkill_010"),
    ("CharacterSkill011_DecreaseTaxidermyPrice", "DA_CharacterSkill_011"), ("CharacterSkill012_SellAtHigherPrices", "DA_CharacterSkill_012"),
    ("CharacterSkill013_SpeedUpAnalysis", "DA_CharacterSkill_013"), ("CharacterSkill014_LowerFallDamage", "DA_CharacterSkill_014"),
    ("CharacterSkill015_IncreaseHealth", "DA_CharacterSkill_015"), ("CharacterSkill016_ExpandAmunition", "DA_CharacterSkill_016"),
    ("CharacterSkill017_ExpandInventoryNoBackpack", "DA_CharacterSkill_017"), ("CharacterSkill018_IncreaseTentLimit", "DA_CharacterSkill_018"),
    ("CharacterSkill019", "DA_CharacterSkill_019"), ("CharacterSkill020", "DA_CharacterSkill_020"),
    ("CharacterSkill021", "DA_CharacterSkill_021"), ("CharacterSkill022", "DA_CharacterSkill_022"),
    ("CharacterSkill023_ImproveShootingSticks", "DA_CharacterSkill_023"), ("CharacterSkill024_ImproveSuppressors", "DA_CharacterSkill_024"),
    ("CharacterSkill025", "DA_CharacterSkill_025"), ("CharacterSkill026", "DA_CharacterSkill_026"),
    ("CharacterSkill028_CrouchSpeedBuff", "DA_CharacterSkill_028_CrouchSpeedBuff"), ("CharacterSkill029_ProneSpeedBuff", "DA_CharacterSkill_029"),
    ("CharacterSkill030_WalkSpeedBuff", "DA_CharacterSkill_030_WalkSpeedBuff"),
]
# 007-012 = a tree the game shows as "Coming soon" and does not have yet: never written, never counted
SKILLS_NOT_IN_GAME = {"DA_CharacterSkill_%03d" % n for n in range(7, 13)}
SKILL_PATHS = [(SKILL_DIR + folder + "/" + asset, asset) for folder, asset in SKILLS if asset not in SKILLS_NOT_IN_GAME]

# --- map / discovery (per-map world parts) ---
MAPS = ["Map01", "Map02", "Hub"]
MAP_LABELS = {"Map01": "New Laurentia", "Map02": "Kilimaya Reserve", "Hub": "Hearth & Hunt Headquarters"}

# GameTimeSubsystem section (name hash of "GameTimeSubsystem") in Game_0/World_0/<Map>: one u64 game clock per map
# world, counting 1/100000 s of game time: day = clock // 8.64e9, time of day = the rest. (Until 2026-10-08 this was
# read as day << 32 | fraction, which showed wrong hours; the hunting log stores the same clock per harvest.)
GAME_TIME_SECTION = 0x3931CF2A
GAME_TIME_TICKS_PER_DAY = 86400 * 100000   # the clock counts 1/100000 s: matched to the in-game clock 2026-10-08 (09:38, 09:39, sleep -> 08:11 next day)


# ---------------------------------------------------------------- weather
# WeatherSubsystem (crc name hash 0xAA34FA95) in Game_0/World_0/<map>: u32, u32 n, n weather blocks (the forecast, the
# CURRENT block first: checked against the weather the hunting log stores for each kill), each = u32 color, u32 color,
# u32 0, FString DA_WeatherDay_<day type> (or "Init"), u32 setting id, u32 duration, u32 0; then the gust timeline and the
# sky state. The setting id is the game's string crc (crc32 of the UTF-32 name) of the DA_WeatherSetting_* asset name, so it
# names the weather for sure; the debug color is the fallback only (some day types give two settings the same color:
# light rain/rain, thunderstorm/overcast).
WEATHER_SECTION = 0xAA34FA95
WEATHER_DAYS = {   # day type -> {debug color (RGB hex): DA_WeatherSetting_*}, from the game's DA_WeatherDay_* assets
    'cloudy': {'007c00': 'Cloudy', '00bc00': 'CloudyPartly', '00007c': 'RainLight'},
    'mostlycloudy': {'007c00': 'Cloudy', '6f7c6f': 'Cloudy_Foggy', '00bc00': 'CloudyPartly', '00007c': 'RainLight', 'aabcaa': 'CloudyPartly_Foggy'},
    'mostlysunny': {'00ff00': 'ClearSky', '00bc00': 'CloudyPartly', 'e7ffe7': 'ClearSky_Foggy'},
    'rainy': {'00007c': 'Rain', 'ffffff': 'Overcast', '007c00': 'Cloudy', '6f7c6f': 'Cloudy_Foggy'},
    'rainy_nofog': {'00007c': 'Rain', 'ffffff': 'Overcast', '007c00': 'Cloudy'},
    'rainysunny': {'00ff00': 'ClearSky', '00bc00': 'CloudyPartly', '00007c': 'RainLight'},
    'rainythunderstorm': {'00007c': 'Rain', 'ffffff': 'Overcast', '007c00': 'Cloudy', '6f7c6f': 'Cloudy_Foggy'},
    'snowy': {'a8a7a8': 'Snow', '9ba89b': 'SnowLight', '003200': 'Overcast', '007c00': 'Cloudy', '6f7c6f': 'Cloudy_Foggy'},
    'snowyblizzard': {'fffeff': 'SnowBlizzard', 'a8a7a8': 'Snow', '9ba89b': 'SnowLight', '003200': 'Overcast', '007c00': 'Cloudy', '6f7c6f': 'Cloudy_Foggy'},
    'snowysunny': {'00ff00': 'ClearSky', '00bc00': 'CloudyPartly', '9ba89b': 'SnowLight'},
    'sunny': {'00ff00': 'ClearSky', '00bc00': 'CloudyPartly'},
}
WEATHER_TAG = {   # DA_WeatherSetting_* -> its Weather.Settings.* tag (the hunting log uses the same tags)
    'ClearSky': 'Weather.Settings.Clear',
    'ClearSky_Foggy': 'Weather.Settings.Fog.Light',
    'Cloudy': 'Weather.Settings.Clouds.Mostly',
    'Cloudy_Foggy': 'Weather.Settings.Fog.Light',
    'CloudyPartly': 'Weather.Settings.Clouds.Partly',
    'CloudyPartly_Foggy': 'Weather.Settings.Fog.Moderate',
    'Overcast': 'Weather.Settings.Clouds.Overcast',
    'Rain': 'Weather.Settings.Rain.Heavy',
    'RainLight': 'Weather.Settings.Rain.Light',
    'RainThunderstorm': 'Weather.Settings.Thunderstorm.Severe',
    'Snow': 'Weather.Settings.Snowfall.Moderate',
    'SnowBlizzard': 'Weather.Settings.Snowfall.Blizzard',
    'SnowLight': 'Weather.Settings.Snowfall.Light',
}

def _weather_crc(name):
    return zlib.crc32(name.encode("utf-32-le")) & 0xFFFFFFFF
WEATHER_IDS = {_weather_crc("DA_WeatherSetting_" + k): k for k in WEATHER_TAG}

def read_weather_blocks(blob):
    """-> [Weather.Settings.* tag, ...] for the forecast blocks of a WeatherSubsystem section, current first."""
    n, = struct.unpack_from("<I", blob, 4); p = 8; out = []
    for _ in range(min(n, 200)):
        c1, = struct.unpack_from("<I", blob, p); p += 12
        ln, = struct.unpack_from("<i", blob, p); p += 4
        day = blob[p:p + ln - 1].decode("latin1").replace("DA_WeatherDay_", "").lower(); p += ln
        sid, = struct.unpack_from("<I", blob, p); p += 12
        setting = WEATHER_IDS.get(sid) or WEATHER_DAYS.get(day, {}).get("%06x" % (c1 & 0xFFFFFF))
        out.append(WEATHER_TAG.get(setting, ""))
    return out

def read_game_time(save_path, sf=None):
    """{map: {"ticks", "day", "hour" (0..24 float), "text" "HH:MM"}} for every map world in the save."""
    sf = sf or nrgs.SaveFile(save_path)
    out = {}
    for m in MAPS:
        try:
            part = sf.part(f"Game_0/World_0/{m}")
        except KeyError:
            continue
        wx = None
        for h, _v, b in nrgs.split_sections(part.data)[1]:
            if h == GAME_TIME_SECTION and len(b) == 8:
                t = struct.unpack("<Q", b)[0]
                day, frac = divmod(t, GAME_TIME_TICKS_PER_DAY)
                hour = frac / GAME_TIME_TICKS_PER_DAY * 24.0
                mins = int(hour * 60) % 1440                  # the game's clock shows whole minutes passed
                out[m] = {"ticks": t, "day": int(day), "hour": round(hour, 4), "text": "%02d:%02d" % (mins // 60, mins % 60)}
            elif h == WEATHER_SECTION:
                try: wx = read_weather_blocks(b)
                except (struct.error, UnicodeDecodeError): wx = None
        if m in out and wx:
            out[m]["weather"] = wx[0]; out[m]["weather_next"] = wx[1] if len(wx) > 1 else ""
    return out
HUNTINGMAP_SECTION = 0x9B3830FF      # BP_HuntingMap_WS_C in Game_0/World_0/<map>: fog-of-war texture
DISCOVERY_SECTION = 0x92BF6548       # BP_Discovery_WS_C in Game_0/WorldShared/<map>: discovered tags + GUIDs
FOW_SIZE = 1024                      # 1024x1024 texels, 4 bits each: 0 = fogged, 0xF = explored
FOW_BYTES = FOW_SIZE * FOW_SIZE // 2
FOW_HEADER = (b"\x01\x00\x00\x00\x01\x03", struct.pack("<III", FOW_SIZE, 1, FOW_BYTES))   # (section start, bytes right before the texels)
FOW_GRID_OFF = 0x39
HUB_PART = "Game_0/World_0/Hub"
HUB_SECTION = 0xAA393F2E             # BP_Hub_WS_C: u32 1 | 01 02 | u32 9 | 01 | u32 4 | i32 m_expansionCurrentIndex
HUB_HEADER = b"\x01\x00\x00\x00\x01\x02\x09\x00\x00\x00\x01\x04\x00\x00\x00"
HUB_EXPANSIONS = 3                   # DA_HubExpansion_01to02 / 02to03 / 03to04: index 3 = lodge level 4, nothing left to buy

FIELDS = {   # key -> (gameplay tag, label)
    "money":        (b"PlayerEconomy.Resources.SoftCurrency", "Money ($)"),
    "xp":           (b"PlayerEconomy.Resources.RankPoints",   "XP"),
    "skill_points": (b"PlayerEconomy.Resources.SkillPoints",  "Skill points (unspent)"),
}

def find_saves():
    hits = []
    for g in save_globs():
        hits += glob.glob(os.path.expanduser(g))
    return sorted(set(os.path.realpath(h) for h in hits))

def _steam_active_account():
    """Windows: the 64-bit id of the Steam account logged in right now (Steam keeps it in the registry), or None."""
    v = hostos.reg_value("HKCU", r"Software\Valve\Steam\ActiveProcess", "ActiveUser")
    try:
        v = int(str(v), 0)
    except (TypeError, ValueError):
        return None
    return 76561197960265728 + v if v else None

def save_target():
    """Where the game's save goes when there is none right now (after START FRESH): the logged-in account's save folder,
    else the newest one. -> path or None"""
    dirs = []
    for g in save_globs():
        dirs += glob.glob(os.path.dirname(os.path.expanduser(g)))
    dirs = sorted(set(os.path.realpath(d) for d in dirs if os.path.isdir(d)))
    if not dirs:
        return None
    acc = _steam_active_account()
    mine = [d for d in dirs if acc and os.path.basename(d) == f"Account_{acc}"]
    return os.path.join(mine[0] if mine else max(dirs, key=os.path.getmtime), "SaveData.nrgs")

def find_save(explicit=None):
    """The save the game will load: with several Account_* folders (more Steam accounts on one PC), the logged-in
    account's, else the one played last."""
    if explicit:
        return os.path.expanduser(explicit)
    picked = os.environ.get("WOTH2_SAVE", "")             # a save file picked by hand in the app (not where the game keeps it)
    if picked and os.path.isfile(picked):
        return picked
    hits = find_saves()
    if not hits:
        raise FileNotFoundError("No SaveData.nrgs found")
    acc = _steam_active_account()
    if acc:                                          # the logged-in account's save, never another account's
        mine = [h for h in hits if os.path.basename(os.path.dirname(h)) == f"Account_{acc}"]
        if not mine:
            raise FileNotFoundError("No SaveData.nrgs found for the Steam account logged in now")
        return mine[0]
    if len(hits) > 1:
        return max(hits, key=os.path.getmtime)
    return hits[0]

def game_running():
    """True if a WOTH2-Win64-Shipping.exe process exists (Windows: tasklist; Linux: /proc, ignoring ourselves)."""
    if hostos.WINDOWS:
        return "woth2-win64-shipping.exe" in hostos.tasklist("WOTH2-Win64-Shipping.exe").lower()
    if not os.path.isdir("/proc"):
        return False
    me = os.getpid()
    for pid in os.listdir("/proc"):
        if not pid.isdigit() or int(pid) == me:
            continue
        try:
            args = open(f"/proc/{pid}/cmdline", "rb").read().split(b"\0")
        except OSError:
            continue
        if any(os.path.basename(x.replace(b"\\", b"/")).lower() == b"woth2-win64-shipping.exe" for x in args if x):
            return True
    return False

# Hunter rank from rank points: DA_CharacterLevel_001..035 (total points to reach each level, the rank asset it belongs
# to) and ST_CharacterProgression KEY_METAGAME_PROGRESSION_RANK0NN_NAME. Levels past 35 do not exist in this build.
LEVEL_POINTS = [0, 100, 300, 600, 1000, 1500, 2100, 2800, 3600, 4500, 5550, 6750, 8100, 9600, 11250, 13050, 15000, 17100, 19350,
                21750, 24350, 27150, 30150, 33350, 36750, 40400, 44300, 48450, 52850, 57500, 62400, 67550, 72950, 78600, 84500]
LEVEL_RANK = [1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12]
RANK_NAMES = {1: "Not a Hunter Yet", 2: "Initiated Hunter", 3: "Hunter in Training", 4: "Rookie Hunter", 5: "Aspiring Hunter",
              6: "Promising Hunter", 7: "Rising Hunter", 8: "Competent Hunter", 9: "Capable Hunter", 10: "Proficient Hunter",
              11: "Experienced Hunter", 12: "Adept Hunter"}

def rank_of(points):
    """-> {"level": 1..35, "rank": name} for that many rank points."""
    level = sum(1 for p in LEVEL_POINTS if points >= p) or 1
    return {"level": level, "rank": RANK_NAMES[LEVEL_RANK[level - 1]]}

def read_values(path):
    """-> {key: (current, max)}"""
    sf = nrgs.SaveFile(path)
    data = sf.part(PART).data
    out = {}
    for key, (tag, label) in FIELDS.items():
        cur = nrgs.find_int_property(data, tag, b"CurrentValue_")
        mx = nrgs.find_int_property(data, tag, b"MaxValue_")
        out[key] = (struct.unpack_from("<i", data, cur)[0], struct.unpack_from("<i", data, mx)[0])
    return out

# ---------------------------------------------------------------- skills
def _skills_section(data):
    seed, secs = nrgs.split_sections(data)
    for i, (h, v, blob) in enumerate(secs):
        if h == SKILLS_SECTION:
            return seed, secs, i
    raise KeyError("skills section not found in GameData")

def parse_skills(blob):
    """Section layout: u32 1 | u8 1 | u8 2 | u32 len | u8 1 | u32 len | u32 count | count * (path, name, u32 0)."""
    if blob[:6] != b"\x01\0\0\0\x01\x02" or blob[10] != 1:
        raise ValueError("unexpected skills section header")
    n, = struct.unpack_from("<I", blob, 15)
    p = 19; out = []
    for _ in range(n):
        path, p = nrgs.read_fstring(blob, p)
        name, p = nrgs.read_fstring(blob, p)
        sub, p = nrgs.read_fstring(blob, p)
        out.append((path, name))
    return out


def read_skills_data(data):
    seed, secs, i = _skills_section(data)
    return [n for p, n in parse_skills(secs[i][2])]

def read_skills(path):
    """-> list of unlocked skill asset names."""
    data = nrgs.SaveFile(path).part(PART).data
    seed, secs, i = _skills_section(data)
    return [n for p, n in parse_skills(secs[i][2])]


# ---------------------------------------------------------------- map: fog of war
def _section(data, wanted):
    seed, secs = nrgs.split_sections(data)
    for i, (h, v, blob) in enumerate(secs):
        if h == wanted:
            return seed, secs, i
    raise KeyError(f"section {wanted:08x} not found")

def _fow_check(blob):
    """The hunting-map section starts with the texture: u32 1 | 01 03 len | 01 len | u32 1 | 01 01 len | 01 len | u32 1 |
    01 01 len | 02 len | u32 1024 | u32 1 | u32 524288 | texels.  Verify the bits we rely on."""
    if blob[:6] != FOW_HEADER[0] or blob[FOW_GRID_OFF - 12:FOW_GRID_OFF] != FOW_HEADER[1] or len(blob) < FOW_GRID_OFF + FOW_BYTES:
        raise ValueError("unexpected hunting-map section layout")

def fow_explored(blob):
    """-> fraction of map texels explored (0..1)."""
    _fow_check(blob)
    g = blob[FOW_GRID_OFF:FOW_GRID_OFF + FOW_BYTES]
    return sum(((b >> 4) + (b & 15)) for b in g) / (15.0 * 2 * len(g))


# ---------------------------------------------------------------- map: discovered territories / need zones
def _skip_tagged_struct(blob, p):
    """Unreal tagged-property struct: (FString name, FString type, i32 array index, i32 size, u8 has-guid, size bytes)* then 'None'."""
    while True:
        name, p = nrgs.read_fstring(blob, p)
        if name == "None":
            return p
        _type, p = nrgs.read_fstring(blob, p)
        size, = struct.unpack_from("<i", blob, p + 4)
        p += 9 + size

def parse_discovery(blob):
    """Discovery section: u32 1 | 01 02 len | 01 len | u32 n_tags | n_tags * tagged FGameplayTag struct | u32 n_guids | guids.
    -> (tags_region bytes (from n_tags up to the GUID count), [guid bytes...])."""
    if blob[:6] != b"\x01\x00\x00\x00\x01\x02":
        raise ValueError("unexpected discovery section header")
    l1, = struct.unpack_from("<I", blob, 6)
    l2, = struct.unpack_from("<I", blob, 11)
    if l1 != len(blob) - 10 or l2 != l1 - 5:
        raise ValueError("discovery section length mismatch")
    p = 15
    ntags, = struct.unpack_from("<I", blob, p); p += 4
    for _ in range(ntags):
        p = _skip_tagged_struct(blob, p)
    tags_region = blob[15:p]
    ng, = struct.unpack_from("<I", blob, p); p += 4
    if p + 16 * ng != len(blob):
        raise ValueError("discovery GUID list does not end the section")
    return tags_region, [blob[p + 16 * i:p + 16 * (i + 1)] for i in range(ng)]

def discovery_tags(tags_region):
    """-> the found gameplay tags (Facility.Opportunity.Shortcut.1, Facility.Tent.3, ...) of a discovery tags region."""
    out, p = [], 4
    for _ in range(struct.unpack_from("<I", tags_region, 0)[0]):
        q = p
        p = _skip_tagged_struct(tags_region, p)
        k = tags_region.find(b"NameProperty\0", q, p)
        if k >= 0:
            out.append(nrgs.read_fstring(tags_region, k + 13 + 9)[0])
    return out


def _map_parts(sf, mapname):
    return sf.part(f"Game_0/World_0/{mapname}"), sf.part(f"Game_0/WorldShared/{mapname}")

def read_map_status(path, guid_data=None):
    """-> {map: {"explored": 0..1, "territories": (found, total), "zones": (found, total)}}
    (totals are None when guid_data is not given)."""
    sf = nrgs.SaveFile(path)
    out = {}
    for m in MAPS:
        try:
            world, shared = _map_parts(sf, m)
        except KeyError:
            continue
        st = {}
        seed, secs, i = _section(world.data, HUNTINGMAP_SECTION)
        st["explored"] = fow_explored(secs[i][2])
        seed, secs, i = _section(shared.data, DISCOVERY_SECTION)
        tags_region, guids = parse_discovery(secs[i][2])
        have = set(guids)
        jobs = _find_list(m)                      # the "?" spots on the game map until the hunter finds them
        st["jobs"] = (len(set(discovery_tags(tags_region)) & set(jobs)), len(jobs))
        if guid_data and m in guid_data:
            terr, zones = guid_data[m]
            st["territories"] = (len(have & set(terr)), len(terr))
            st["zones"] = (len(have & set(zones)), len(zones))
        else:
            st["territories"] = (None, None); st["zones"] = (None, None)
        out[m] = st
    return out

def _maps_arg(v):
    """True -> every map; False/None -> none; else an iterable of map names (case-insensitive)."""
    if v is True:
        return set(MAPS)
    if not v:
        return set()
    out = set()
    for m in v:
        hit = [x for x in MAPS if x.lower() == str(m).lower()]
        if not hit:
            raise KeyError(f"unknown map {m!r}; choose from {', '.join(MAPS)}")
        out.add(hit[0])
    return out


# ---------------------------------------------------------------- Hearth & Hunt HQ (lodge expansions)
def _hub_section(sf):
    """-> (part, seed, secs, index of the BP_Hub_WS_C section); KeyError when the HQ world was never saved."""
    part = sf.part(HUB_PART)
    seed, secs = nrgs.split_sections(part.data)
    for i, (h, v, blob) in enumerate(secs):
        if h == HUB_SECTION:
            if blob[:len(HUB_HEADER)] != HUB_HEADER or len(blob) != len(HUB_HEADER) + 4:
                raise ValueError("unexpected BP_Hub_WS_C section layout")
            return part, seed, secs, i
    raise KeyError("HQ section not found")

def read_hub_level(path_or_sf):
    """-> {"index": bought expansions 0..3, "level": lodge level 1..4, "max": 4} or None when the save
    has no Hearth & Hunt HQ data yet (the game writes it the first time the HQ is visited)."""
    sf = path_or_sf if isinstance(path_or_sf, nrgs.SaveFile) else nrgs.SaveFile(path_or_sf)
    try:
        part, seed, secs, i = _hub_section(sf)
    except (KeyError, ValueError):
        return None
    idx = struct.unpack_from("<i", secs[i][2], len(HUB_HEADER))[0]
    return {"index": idx, "level": idx + 1, "max": HUB_EXPANSIONS + 1}


def _jobs_list(m):
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "opportunities.json"), encoding="utf-8") as f:
            return [o["tag"] for o in json.load(f).get(m, [])]
    except (OSError, ValueError):
        return []

def _find_list(m):
    """Every "?" spot of the map: its habitat jobs plus the camps, cabins, stations, lodge, range and parking spots
    the game's map marks (facility_tags.json, from the BP_Facility markers in Maps/<Map>/<Map>.umap)."""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "facility_tags.json"), encoding="utf-8") as f:
            places = json.load(f).get(m, [])
    except (OSError, ValueError):
        places = []
    return _jobs_list(m) + [t for t in places if not t.startswith("Facility.Opportunity.")]

def read_jobs(path_or_sf):
    """-> {"done": n, "total": n} over every map: habitat improvements, bridges, blocked roads, clean-ups, lookouts."""
    import stands
    sf = path_or_sf if isinstance(path_or_sf, nrgs.SaveFile) else nrgs.SaveFile(path_or_sf)
    done = total = 0
    for m in MAPS:
        tags = _jobs_list(m); total += len(tags)
        try:
            seed, secs, i = _section(sf.part(f"Game_0/WorldShared/{m}").data, nrgs.name_hash(f"BP_Opportunity_WS_{m}_C"))
            done += len(set(stands.parse_opp_done(secs[i][2])) & set(tags))
        except (KeyError, ValueError):
            pass
    return {"done": done, "total": total}

# ---------------------------------------------------------------- backups
def backup_time(b):
    """When a copy was made: the time in an automatic backup's name (older ones kept the save's file date), else the file date."""
    m = re.match(r"^SaveData-(\d{8}-\d{6})", os.path.basename(b))
    if m and os.path.basename(b) != os.path.basename(ORIGINAL_BACKUP):
        try:
            return datetime.datetime.strptime(m.group(1), "%Y%m%d-%H%M%S").timestamp()
        except ValueError:
            pass
    return os.path.getmtime(b)

def list_backups():
    """Every .nrgs in backups/ (renamed and added ones too), newest first; the ORIGINAL backup is excluded (see ORIGINAL_BACKUP)."""
    baks = [b for b in glob.glob(os.path.join(BACKUP_DIR, "*.nrgs")) if b != ORIGINAL_BACKUP]
    return sorted(baks, key=backup_time, reverse=True)

def ensure_original_backup(path):
    """Keep one untouched copy of the save from before the very first edit."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if not os.path.exists(ORIGINAL_BACKUP):
        shutil.copy2(path, ORIGINAL_BACKUP)
        return True
    return False

def make_backup(path):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    bak = os.path.join(BACKUP_DIR, f"SaveData-{stamp}.nrgs")
    if os.path.exists(bak):                       # two writes within a second
        bak = bak[:-5] + datetime.datetime.now().strftime("-%f") + ".nrgs"
    shutil.copyfile(path, bak)                    # dated now: the list shows when the copy was made
    return bak

def make_bak(path):
    """BACK UP NOW: a plain copy of the save in use, next to it, as SaveData.bak (SaveData (2).bak, ... when one is there).
    To use it again: rename it back to SaveData.nrgs. -> written path"""
    base = os.path.splitext(path)[0]
    bak, n = base + ".bak", 2
    while os.path.exists(bak):                    # never overwrite an earlier .bak
        bak = f"{base} ({n}).bak"; n += 1
    shutil.copyfile(path, bak)
    return bak

LOADED_SLOT = os.path.join(BACKUP_DIR, ".loaded")

def loaded_slot():
    """The named copy last LOADed into the game (BACK UP NOW saves back into it), or None."""
    try:
        f = open(LOADED_SLOT, encoding="utf-8").read().strip()
    except OSError:
        return None
    return f if f and os.path.isfile(f) else None

def set_loaded_slot(f):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if f:
        with open(LOADED_SLOT, "w", encoding="utf-8") as fh: fh.write(f)
    elif os.path.exists(LOADED_SLOT):
        os.remove(LOADED_SLOT)

def save_to_slot(path, slot):
    """BACK UP NOW with a loaded named copy: the game's save goes back into that copy (same name)."""
    nrgs.SaveFile(path)
    tmp = slot + ".tmp"
    shutil.copyfile(path, tmp)
    os.replace(tmp, slot)
    return slot

def save_as(path, name):
    """SAVE AS: the game's save as a named copy, which becomes the save slot BACK UP NOW writes to. -> path"""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    dst = os.path.join(BACKUP_DIR, _safe_name(name))
    if os.path.basename(dst).casefold() == os.path.basename(ORIGINAL_BACKUP).casefold():
        raise ValueError("that name is kept for the original save")
    if os.path.exists(dst):
        raise ValueError("a copy with that name already exists")
    nrgs.SaveFile(path)
    shutil.copyfile(path, dst)
    set_loaded_slot(dst)
    return dst

def restore_backup(bak, path):
    nrgs.SaveFile(bak)                            # refuse to restore something unreadable
    tmp = path + ".tmp"
    shutil.copyfile(bak, tmp)                     # the game's save is dated now, not when the copy was made
    os.replace(tmp, path)

# ---------------------------------------------------------------- edit history (undo)
# Every write the app makes is logged in BACKUP_DIR/edits.json: what it did, the backup taken just before it
# and the save's mtime right after it. Undo puts that backup back; when the save changed after the edit (the
# game saved since), undo says so first because it would also throw away that progress.
JOURNAL_MAX = 200

def _journal_path():
    return os.path.join(BACKUP_DIR, "edits.json")

def read_journal():
    try:
        with open(_journal_path()) as f:
            j = json.load(f)
        return j if isinstance(j, list) else []
    except (OSError, ValueError):
        return []

def _write_journal(j):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    tmp = _journal_path() + ".tmp"
    with open(tmp, "w") as f:
        json.dump(j[-JOURNAL_MAX:], f, indent=1)
    os.replace(tmp, _journal_path())

def _jkey(path):
    """A save's key in the edit journal: the path as Windows writes it there (the WebAssembly core on Windows sees
    C:\\ as /mnt/c), matched without case on Windows - old journals from the native core keep working."""
    k = hostos.host(os.path.realpath(path))
    return k.casefold() if hostos.WINDOWS else k

def _same_save(e, key):
    v = e.get("save") or ""
    return (hostos.host(v).casefold() if hostos.WINDOWS else v) == key

def log_edit(path, what, notes, backup):
    """Record one write (called by woth2_core after a command that changed the save)."""
    if not backup or not os.path.exists(backup):
        return
    j = read_journal()
    j.append({"time": datetime.datetime.now().timestamp(), "what": what, "notes": list(notes or [])[:12],
              "backup": hostos.host(backup), "save": hostos.host(os.path.realpath(path)), "mtime": os.path.getmtime(path),
              "hash": file_hash(path)})
    _write_journal(j)

def history(path):
    """The edits on this save, newest first, each with 'undoable' (its backup still exists) and
    'game_saved_since' (the save is not the file this edit wrote any more)."""
    key = _jkey(path)
    cur = os.path.getmtime(path) if os.path.exists(path) else 0
    cur_hash = None
    out = []
    j = [e for e in read_journal() if _same_save(e, key)]
    for k, e in enumerate(reversed(j)):
        e = dict(e)
        e["undoable"] = k == 0 and os.path.exists(hostos.p(e.get("backup", "")))
        if e.get("hash") and cur:                    # the file's content: an UNDO re-dates the save without changing it
            cur_hash = cur_hash or file_hash(path)
            e["game_saved_since"] = cur_hash != e["hash"]
        else:
            e["game_saved_since"] = abs(cur - float(e.get("mtime", 0))) > 1.0
        out.append(e)
    return out

def undo_last(path, force=False):
    """Put back the save from before the most recent edit. -> (backup of the current file, the undone entry)"""
    if game_running() and not force:
        raise RuntimeError("The game is running. Close it first so your edit is not overwritten.")
    key = _jkey(path)
    j = read_journal()
    idx = next((i for i in range(len(j) - 1, -1, -1) if _same_save(j[i], key)), None)
    if idx is None:
        raise ValueError("Nothing to undo: the app has not changed this save yet.")
    e = j[idx]
    if not os.path.exists(hostos.p(e.get("backup", ""))):
        raise ValueError("The backup from before that edit was deleted, so it cannot be undone.")
    bak = make_backup(path)
    restore_backup(hostos.p(e["backup"]), path)
    del j[idx]
    _write_journal(j)
    return bak, e

# ---------------------------------------------------------------- writing


# ---------------------------------------------------------------- animals (rare fur, trophy quality, fitness)









# ---------------------------------------------------------------- stands, tents, in-game markers
def replace_checked(path, data, check_map=None, guid_data=None):
    """Write `data` over the save only after it reads back cleanly (save file, values, the edited map's animals);
    a bad edit never reaches the game's save and leaves no stray file behind."""
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    try:
        sf = nrgs.SaveFile(tmp)
        read_values(tmp)
        if check_map and guid_data and check_map in guid_data:
            import animals
            animals.read_animals(sf, check_map, guid_data[check_map][0])
    except Exception as e:
        os.remove(tmp)
        print(f"read-back failed: {type(e).__name__}: {e}", file=sys.stderr)       # the raw detail: log only
        raise RuntimeError("The edit did not read back right, so your save was left as it was.")
    os.replace(tmp, path)

def _write_world(path, sf, backup=True):
    """Write the edited save (a backup first). -> the backup, or None when the edit changed nothing: then nothing
    is written, no backup is made and no UNDO entry is logged (woth2_core logs only edits with a backup)."""
    out = sf.build()
    if out == getattr(sf, "raw", None):
        return None
    bak = None
    if backup:
        ensure_original_backup(path)
        bak = make_backup(path)
    replace_checked(path, out)
    return bak





# ---------------------------------------------------------------- save file management
def _in_backup_dir(f):
    return os.path.isfile(f) and os.path.dirname(os.path.abspath(f)) == os.path.abspath(BACKUP_DIR)

def _safe_name(name):
    """A backup file name that works on Windows and Linux, always ending in lower-case .nrgs (the list only reads those)."""
    name = re.sub(r"[^A-Za-z0-9 ._()-]+", "_", str(name)).strip().strip(".")
    if name.lower().endswith(".nrgs"):
        name = name[:-5].rstrip().rstrip(".")
    if not name:
        raise ValueError("empty name")
    if re.fullmatch(r"(?i)(con|prn|aux|nul|com\d|lpt\d)", name):        # names Windows keeps for devices
        name += "_"
    return name + ".nrgs"

def rename_backup(f, new_name):
    """Rename a backup inside backups/. -> new path"""
    if not _in_backup_dir(f) or os.path.abspath(f) == os.path.abspath(ORIGINAL_BACKUP):
        raise ValueError("only timestamped backups can be renamed")
    dst = os.path.join(BACKUP_DIR, _safe_name(new_name))
    same = (lambda q: os.path.abspath(q).casefold()) if hostos.WINDOWS else (lambda q: os.path.normcase(os.path.abspath(q)))
    if os.path.exists(dst) and same(dst) != same(f):     # Windows ignores case: "abc" -> "ABC" is the same file
        raise ValueError("a backup with that name already exists")
    if os.path.basename(dst).casefold() == os.path.basename(ORIGINAL_BACKUP).casefold():
        raise ValueError("that name is kept for the original save")
    slot = loaded_slot()
    os.rename(f, dst)
    if slot and os.path.abspath(slot) == os.path.abspath(f): set_loaded_slot(dst)     # the save slot follows its new name
    old, new = os.path.basename(f), os.path.basename(dst)
    j = read_journal()                                   # UNDO and the labels follow the file
    hit = False
    for e in j:
        b = e.get("backup") or ""
        if os.path.basename(b.replace("\\", "/")) == old:
            e["backup"] = b[: len(b) - len(old)] + new; hit = True
    if hit:
        _write_journal(j)
    lab = read_labels()
    if old in lab:
        lab[new] = lab.pop(old)
        try:
            with open(_labels_path(), "w", encoding="utf-8") as fh:
                json.dump(lab, fh, indent=1)
        except OSError:
            pass
    return dst

def start_fresh(path, force=False):
    """Delete the game's save and the app's untouched original copy so the game starts a brand-new save.
    Timestamped backups stay (a way back). Only sticks when Steam Cloud is off for the game - otherwise Steam
    downloads the cloud copy again. -> notes"""
    if game_running() and not force:
        raise RuntimeError("The game is running. Close it first.")
    notes = []
    if path and os.path.isfile(path):
        os.remove(path); notes.append("deleted the game's save " + os.path.basename(path))
    else:
        notes.append("no save file to delete")
    if os.path.isfile(ORIGINAL_BACKUP):
        os.remove(ORIGINAL_BACKUP); notes.append("deleted the original backup")
    return notes

def delete_backup(f):
    if not _in_backup_dir(f) or os.path.abspath(f) == os.path.abspath(ORIGINAL_BACKUP):
        raise ValueError("only timestamped backups can be deleted")
    os.remove(f)

# ---------------------------------------------------------------- the Saves page: what each copy is
AUTO_BACKUP_RE = re.compile(r"^SaveData-\d{8}-\d{6}(-\d+)?\.nrgs$")      # timestamped copies the app makes by itself

def file_hash(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def _labels_path():
    return os.path.join(BACKUP_DIR, ".labels.json")

def read_labels():
    """{backup file name: why it was made} (see set_label)."""
    try:
        with open(_labels_path(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}

def set_label(backup, text):
    """Remember why a backup was made ("Backup you made", "Before loading ...") for the Saves page."""
    if not backup:
        return
    d = read_labels()
    have = {os.path.basename(b) for b in glob.glob(os.path.join(BACKUP_DIR, "*.nrgs"))}
    d = {k: v for k, v in d.items() if k in have}                # forget deleted backups
    d[os.path.basename(backup)] = text
    try:
        with open(_labels_path(), "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1)
    except OSError:
        pass

def backup_labels():
    """{backup file name: label}: set_label's notes, else the app edit the backup was taken before."""
    out = {}
    for e in read_journal():
        b = os.path.basename((e.get("backup") or "").replace("\\", "/"))
        if b and e.get("what"):
            out[b] = "Before: " + e["what"]
    out.update(read_labels())
    return out

def cleanup_backups(path, keep=20, dry_run=False):
    """Delete old automatic backups, keeping the newest `keep`. Never touches renamed / imported copies, the original,
    a copy identical to the game's save or the backup UNDO needs. -> [deleted paths]"""
    protect = set()
    j = [e for e in read_journal() if _same_save(e, _jkey(path))] if path and os.path.exists(path) else []
    if j:
        protect.add(os.path.basename((j[-1].get("backup") or "").replace("\\", "/")))
    cur = file_hash(path) if path and os.path.exists(path) else None
    auto = [b for b in list_backups() if AUTO_BACKUP_RE.match(os.path.basename(b))]
    gone = []
    for b in auto[keep:]:
        if os.path.basename(b) in protect:
            continue
        if cur and backup_facts([b]).get(b, {}).get("hash") == cur:
            continue
        gone.append(b)
        if not dry_run:
            os.remove(b)
    return gone

def backup_facts(paths):
    """{path: {"money", "xp", "hash"}} for the Saves page, cached per file (name + size + mtime) in backups/.facts.json."""
    cache_file = os.path.join(BACKUP_DIR, ".facts.json")
    try:
        with open(cache_file, encoding="utf-8") as f:
            cache = json.load(f)
    except (OSError, ValueError):
        cache = {}
    out, fresh = {}, {}
    for b in paths:
        try:
            key = f"{os.path.basename(b)}|{os.path.getsize(b)}|{os.path.getmtime(b)}"
        except OSError:
            continue
        facts = cache.get(key)
        if facts is None or "hash" not in facts:
            facts = {}
            try:
                vals = read_values(b)
                facts = {"money": vals["money"][0], "xp": vals["xp"][0]}
            except Exception:
                pass
            facts["hash"] = file_hash(b)
        fresh[key] = out[b] = facts
    fresh = dict(cache, **fresh) if len(paths) < 3 else fresh   # a lookup of one or two files keeps the rest
    if fresh != cache:
        try:
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(fresh, f)
        except OSError:
            pass
    return out

def export_save(src, dest):
    """Copy a save or backup to any folder or file path. -> written path"""
    nrgs.SaveFile(src)                                # refuse to export something unreadable
    if os.path.isdir(dest):
        dest = os.path.join(dest, os.path.basename(src))
        base, n = dest[:-5], 2
        while os.path.exists(dest):                        # several copies into one folder: never overwrite
            dest = f"{base} ({n}).nrgs"; n += 1
    os.makedirs(os.path.dirname(os.path.abspath(dest)) or ".", exist_ok=True)
    shutil.copyfile(src, dest)                        # the copy is dated when it was exported (the name says which save)
    return dest

def import_save(src, path, force=False):
    """Replace the game's save with another .nrgs file. No backup: the app tells the user to BACK UP NOW / EXPORT first."""
    if game_running() and not force:
        raise RuntimeError("The game is running. Close it first.")
    try:
        nrgs.SaveFile(src)                            # must be a valid save
    except Exception:
        raise ValueError(os.path.basename(src) + " is not a Way of the Hunter 2 save file")
    if not path:
        raise ValueError("No save folder found. Start the game once so it makes one, then try again.")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    shutil.copyfile(src, tmp)
    os.replace(tmp, path)

def save_info(f):
    """Quick facts about any .nrgs file for a picker: money, rank points, maps present, mtime."""
    out = {"path": f, "name": os.path.basename(f), "mtime": os.path.getmtime(f), "size": os.path.getsize(f)}
    try:
        vals = read_values(f)
        out["money"] = vals["money"][0]; out["xp"] = vals["xp"][0]; out["rank"] = rank_of(vals["xp"][0])
        sf = nrgs.SaveFile(f); maps = []
        for m in MAPS:
            try:
                sf.part(f"Game_0/World_0/{m}"); maps.append(m)
            except Exception:
                pass
        out["maps"] = maps
    except Exception as e:
        print(f"saveinfo {f}: {type(e).__name__}: {e}", file=sys.stderr)
        out["error"] = "Not a Way of the Hunter 2 save the Toybox can read."
    return out


# ---------------------------------------------------------------- in-game markers (free: no code needed)
def write_marker(path, mapname, x, y, z, mtype="Default", force=False):
    """Add one in-game custom map marker. -> (backup, notes)"""
    import stands
    if game_running() and not force:
        raise RuntimeError("The game is running. Close it first so your edit is not overwritten.")
    if mtype not in stands.MARKER_TYPES:
        raise ValueError(f"unknown marker type {mtype}")
    sf = nrgs.SaveFile(path)
    notes = []
    stands.add_marker(sf, mapname, float(x), float(y), _marker_z(mapname, float(x), float(y), float(z)), mtype, notes)
    bak = _write_world(path, sf)
    return bak, notes

def write_marker_list(path, mapname, points, force=False):
    """Replace the map's in-game custom markers with points [(x, y, z, type)] cm. -> (backup, notes)"""
    import stands
    if game_running() and not force:
        raise RuntimeError("The game is running. Close it first so your edit is not overwritten.")
    sf = nrgs.SaveFile(path)
    notes = []
    stands.set_markers(sf, mapname, [(float(x), float(y), _marker_z(mapname, float(x), float(y), float(z)), t) for x, y, z, t in points], notes)
    bak = _write_world(path, sf)
    return bak, notes

def write_names(path, hunter=None, dog=None, force=False):
    """Rename the hunter (on every harvest / trophy) and / or the dog. -> (backup, notes)"""
    import names
    if game_running() and not force:
        raise RuntimeError("The game is running. Close it first so your edit is not overwritten.")
    sf = nrgs.SaveFile(path)
    have = names.read_names(sf)
    notes = []
    if hunter:
        old = max(have["hunters"], key=have["hunters"].get) if have["hunters"] else None
        if not old:
            raise ValueError("No harvests yet: the game puts your hunter name on harvests, so there is nothing to rename.")
        if hunter.strip() != old:
            notes += names.rename_hunter(sf, old, hunter)
    if dog and dog.strip() != have["dog"]:
        notes += names.rename_dog(sf, dog)
    if not notes:
        return None, ["nothing to change"]
    after = names.read_names(sf)                     # the new names must read back on every record
    want = have["hunters"].get(hunter.strip(), 0) + have["hunters"][old] if hunter and hunter.strip() != old else None
    if want is not None and after["hunters"].get(hunter.strip(), 0) != want:     # the new name may already be on some
        raise RuntimeError("The rename did not read back right - nothing was written.")
    if dog and after["dog"] != dog.strip():
        raise RuntimeError("The dog rename did not read back right - nothing was written.")
    bak = _write_world(path, sf)
    return bak, notes

MARKER_Z_TRUST_CM = 2000

def _marker_z(mapname, x, y, z):
    """Height for a marker / stand: the one given when it is within 20 m of the real ground (markers the game
    placed sit on it), else the ground - a z of 0 came from animals the game had not placed yet."""
    zg = ground_at(mapname, x, y)
    if zg is None or (z != 0 and abs(z - zg) <= MARKER_Z_TRUST_CM):
        return z
    return zg

GROUND_MARGIN_CM = {"Map01": 400, "Map02": 600, "Hub": 1200}

def _model_ground(mapname, x, y):
    """Ground height (cm) of the app's map model at (x, y); None without a map cache."""
    try:
        import json, os, numpy as np, mapdata
        from PIL import Image
        cd = os.path.join(mapdata.CACHE_ROOT, mapname)
        a, b = json.load(open(os.path.join(cd, "meta.json")))["height_fit"]
        h = np.asarray(Image.open(os.path.join(cd, "height.png")).convert("L"), dtype=np.float32)
    except Exception:
        return None
    L = mapdata.BOUNDS[mapname]; n = h.shape[0]
    u = min(max((x + L) / (2 * L) * (n - 1), 0.0), n - 1.001); v = min(max((y + L) / (2 * L) * (n - 1), 0.0), n - 1.001)
    x0, y0 = int(u), int(v); fx, fy = u - x0, v - y0
    hv = (h[y0, x0] * (1 - fx) * (1 - fy) + h[y0, x0 + 1] * fx * (1 - fy) + h[y0 + 1, x0] * (1 - fx) * fy
          + h[y0 + 1, x0 + 1] * fx * fy)
    return float(a * hv + b)

def ground_at(mapname, x, y):
    """The game's real ground (terrain.py: landscape collision) at (x, y) cm; the app's height model when the
    terrain cannot be read; None when neither is there."""
    try:
        import terrain
        zt = terrain.ground_z(mapname, x, y)
        if zt is not None:
            return zt
    except Exception:
        pass
    zm = _model_ground(mapname, x, y)
    return None if zm is None else zm + GROUND_MARGIN_CM.get(mapname, 1200)


# ---------------------------------------------------------------- locked part
_LOCKED = ('build_skills', '_unlock_all_skills', '_reveal_fow', 'build_discovery', '_apply_map_edits', '_set_hub_level', '_complete_jobs', 'build_tag', '_find_jobs', 'write_values', 'write_animal_edits', 'spawn_rare', 'reset_animals', 'repair_trophies', 'complete_missions', 'write_stands', 'teleport_player', 'mark_wounded', 'pickup_stands', 'pickup_everything', 'max_dog')

def __getattr__(name):
    """The save-writing functions live in toybox_locked (encrypted in the released app, see vault.py)."""
    if name in _LOCKED:
        import vault
        return getattr(vault.locked("locked_trainer_core"), name)
    raise AttributeError(name)
