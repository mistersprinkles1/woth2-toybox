"""Per-map data for the interactive map: need zones, animal trails, textures, and the
per-save overlay (species per territory, discovered zones, fog of war, player position).

World space: Unreal centimeters. Each map's hunting-map textures (satellite, roads, fog of
war) cover the square [-L, L] x [-L, L] with texture u = (x + L) / 2L (column) and
v = (y + L) / 2L (row); L = 510000 on the big maps, 201600 on the Hub (verified by
correlating zone altitudes against the game's height texture, r = 0.999).

Game-file sources (read through woth2_paks):
  DA_TerritorySigns_<territory GUID>   one group of static animal signs per need zone
                                       (zone GUID + 63/39-byte sign records with world
                                       position); the zone centre is the mean sign position
  <Map>_SpawnData_All_generatedSplines animal travel paths (GUID, point count, FVector list)
  T_SatMap_<Map>_BC / T_SatMapHub_Small_BC   satellite background (DXT1 / BC7)
  T_HuntingMapInfrastructure_<Map>_KKK       roads overlay (BC7)
Save sources:
  BP_HerdManagement_<Map>_WS_C   habitat -> subspecies -> territory GUIDs
  BP_Discovery_WS_C              discovered GUIDs
  BP_HuntingMap_WS_C             fog-of-war texels
  AnimalSaveSystem               zone GUID followed by its EAnimalNeedZone (2 Watering,
                                 3 Eating, 4 Resting); the sign-kind mix of a zone maps
                                 1:1 onto that type, which is how zones the animals have
                                 not visited yet get typed.
  PlayerSaveWorldSubsystem       player position (3 doubles at offset 47)
Everything from the game files is cached under ~/.cache/woth2-save-editor/maps/<Map>/.
"""
import collections, json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import nrgs
import woth2_paks as paks
import i18n

import hostos
if hostos.WINDOWS:
    CACHE_ROOT = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local"), "woth2-toybox", "maps")
else:
    CACHE_ROOT = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "woth2-save-editor", "maps")
BOUNDS = {"Map01": 510000.0, "Map02": 510000.0, "Hub": 201600.0}
TEXTURES = {   # (satellite, roads)
    "Map01": ("T_SatMap_Map01_BC", "T_HuntingMapInfrastructure_Map01_KKK"),
    "Map02": ("T_SatMap_Map02_BC", "T_HuntingMapInfrastructure_Map02_KKK"),
    "Hub": ("T_SatelitHub_BC", "T_HuntinMap_Hub_KKK"),
}
# EAnimalNeedZone values seen next to zone GUIDs in AnimalSaveSystem (game enum: Resting = 2, Eating = 3,
# Watering = 4 - the same table as AREA_TYPES below)
ZONE_TYPES = {2: "Resting", 3: "Eating", 4: "Watering"}
ZONE_TYPES_VERSION = 2    # zone_types.json learnt with the old swapped table (1) is thrown away
TYPE_ORDER = ["Eating", "Watering", "Resting", "Unknown"]
SPLINE_MARK = b"\x00\x00\x00\x00\x02\x02\x05\x04\x02\x03"
CACHE_VERSION = 16   # 16: rebuild caches that an earlier bundle (no scipy) left without satellite/map2d
KKK_SHIFT = -0.022     # the infrastructure texture sits 2.2% of the map edge to the LEFT of the world (fitted against the game's own drinking zones on all three maps)
ICONS = {   # name in cache -> texture
    "drink": "T_UI_Needzone_Drinking", "eat": "T_UI_Needzone_Eating_new", "rest": "T_UI_Needzone_Resting_new",
    "unknown": "T_UI_Needzone_Undiscovered", "tracks": "T_UI_Needzone_Footprints_new", "player": "T_UI_Marker_General_Player",
    "animal": "T_UI_Marker_Custom_Animal", "lodge": "T_UI_Marker_Lodge", "camp": "T_UI_Marker_Camp", "tent": "T_UI_Marker_Tent",
    "stand": "T_UI_Marker_HuntingStand", "cabin": "T_UI_Marker_Cabin", "tripod": "T_UI_Marker_Placeable_TripodStand",
    "marker": "T_UI_Marker_Custom_Tracking", "blind": "T_UI_Marker_Placeable_Blind", "decoy": "T_UI_Marker_Placeable_Decoy",
    # in-game custom marker types -> the icon the game draws for them (DT_TagInterpreter_Misc)
    "marker_Default": "T_UI_Marker_Custom_Tracking", "marker_Animal": "T_UI_Marker_Custom_Animal", "marker_Blood": "T_UI_Marker_Custom_Like",
    "marker_Fitness": "T_UI_Marker_Custom_Favourite", "marker_Footprints": "T_UI_Marker_Custom_Crown", "marker_Nature": "T_UI_Marker_Custom_Trophy",
    "marker_Exploration": "T_UI_Marker_Custom_Exploration",
    # look-alike pin icons the notes no longer offer; older pins still draw with them
    "marker_Favourite": "T_UI_Marker_Custom_Favourite", "marker_Trophy": "T_UI_Marker_Custom_Trophy",
    "station": "T_UI_Marker_Station", "range": "T_UI_Marker_ShootingRange", "parking": "T_UI_Marker_Vehicle",
    # opportunities (habitat enhancements, bridges, ...): the game's own map markers (a lookout uses "stand")
    "opp_enhancement": "T_UI_Marker_Opportunity_Enhancement", "opp_obstacle": "T_UI_Marker_Opportunity_Obstacle",
    "opp_pollution": "T_UI_Marker_Opportunity_Pollution", "opp_bridge": "T_UI_Marker_Opportunity_Shortcut",
}
# hypsometric tint of the in-game 2D map (Curve_HuntingMap2D_Color: normalized height -> RGB)
MAP2D_RAMP = [(0.0, (0.231, 0.440, 0.027)), (0.2, (0.624, 0.799, 0.216)), (0.4, (0.847, 0.847, 0.250)),
              (0.6, (0.956, 0.644, 0.147)), (0.8, (0.888, 0.451, 0.262)), (0.9, (0.443, 0.218, 0.117)), (1.0, (0.443, 0.218, 0.117))]
WATER_2D = (0.166, 0.482, 0.628)     # M_HuntingMap "2D Water Color" (linear)
NONPLAYABLE_2D = (0.1, 0.1, 0.1)     # "Nonplayable Area Color" (linear)
def _srgb(c):
    return tuple(v ** (1 / 2.2) for v in c)
HEIGHT_TEXTURES = {"Map01": "T_HuntingMap_Map01_H", "Map02": "T_HuntingMap_Map02_H", "Hub": "T_HuntinMap_Hub_H"}
SCHEDULE_TYPES = {2: "Resting", 3: "Eating", 4: "Watering"}   # lifecycle schedules count 2 = rest, 4 = drink (the
# opposite of the save's need-zone numbers); matched against where thousands of animals stood at the saved hour
SCHEDULES_VERSION = 2

def load_schedules():
    """schedules.json from the cache; a file from before SCHEDULES_VERSION 2 had drinking and resting swapped."""
    path = os.path.join(CACHE_ROOT, "schedules.json")
    with open(path) as f:
        sched = json.load(f)
    if sched.get("version") != SCHEDULES_VERSION:
        sw = {"Watering": "Resting", "Resting": "Watering"}
        sched["families"] = {k: [(h, sw.get(t, t)) for h, t in v] for k, v in sched.get("families", {}).items()}
        sched["version"] = SCHEDULES_VERSION
        try:
            with open(path, "w") as f:
                json.dump(sched, f)
        except OSError:
            pass
    return sched
# lifecycle schedule family per subspecies (DA_LifeCycleSchedule_<family>); by taxonomy where the
# game files do not spell it out
SPECIES_FAMILY = {
    "AlcesAlcesAndersoni": "BigGameDeerLarge", "CervusCanadensisNelsoni": "BigGameDeerLarge",
    "OdocoileusHemionusHemionus": "BigGameDeerMedium", "OdocoileusVirginianusBorealis": "BigGameDeerMedium",
    "AntilocapraAmericana": "BigGameAntelopeMedium", "BisonBisonAthabascae": "BigGameBovid", "OvisDalliDalli": "BigGameCaprine",
    "SusScrofaScrofa": "BigGameSwine", "PhacochoerusAfricanusSundevallii": "BigGameSwine",
    "MeleagrisGallopavoSilvestris": "LandfowlGalliform", "LagopusLeucura": "LandfowlGalliform", "StruthioCamelusAustralis": "BigGameBovid",
    "CanisLupusOccidentalis": "PredatorCaniform", "UrsusArctosHorribilis": "PredatorCaniform", "CrocutaCrocuta": "PredatorCaniform",
    "PantheraLeoMelanochaita": "PredatorFelid", "CrocodylusNiloticus": "PredatorCrocodile",
    "GuloGuloLuscus": "SmallGameMustelid", "MellivoraCapensisCapensis": "SmallGameMustelid", "LepusAmericanusAmericanus": "SmallGameLeporid",
    "AnasPlatyrhynchos": "WaterfowlDuck", "AnasUndulataUndulata": "WaterfowlDuck",
    "HippopotamusAmphibiusAmphibius": "BigGameHippo", "SyncerusCafferCaffer": "BigGameBovid", "ConnochaetesTaurinusTaurinus": "BigGameAntelopeLarge",
    "TragelaphusStrepsicerosStrepsiceros": "BigGameAntelopeLarge", "EquusZebraZebra": "BigGameDeerLarge",
    "DamaliscusPygargusPhillipsi": "BigGameAntelopeMedium", "AepycerosMelampusMelampus": "BigGameAntelopeMedium",
}

# ---------------------------------------------------------------- game files: zones
def _parse_sign_record(ex, p):
    """Unversioned struct: u16 header (7-bit skip | zero-mask flag | last flag | 7-bit count),
    optional zero mask, then the non-zero fields (i32, FVector, FRotator, i32, i32, ?)."""
    h, = struct.unpack_from("<H", ex, p); p += 2
    if not (h >> 8) & 1 or h & 0x7F:
        raise ValueError(f"unexpected sign record header {h:04x}")
    mask = 0
    if (h >> 7) & 1:
        mask = ex[p]; p += 1
    pos = None; kind = 0
    for i, sz in enumerate((4, 24, 24, 4, 4, 4)[:h >> 9]):
        if mask >> i & 1:
            continue
        if i == 0:
            kind, = struct.unpack_from("<i", ex, p)
        elif i == 1:
            pos = struct.unpack_from("<ddd", ex, p)
        p += sz
    return pos, kind, p

def parse_territory_signs(ex):
    """-> [(zone guid hex, [(x, y, z)...], sorted sign kinds)]"""
    if ex[0] != 0 or ex[5] != 0:
        raise ValueError("bad territory-signs header")
    p = 10
    zones = []
    while p + 22 <= len(ex):
        if ex[p + 16] != 0 or ex[p + 17] != 3:
            raise ValueError(f"bad zone group header at {p}")
        guid = ex[p:p + 16].hex(); cnt, = struct.unpack_from("<I", ex, p + 18); p += 22
        pts = []; kinds = set()
        for _ in range(cnt):
            pos, kind, p = _parse_sign_record(ex, p)
            kinds.add(kind)
            if pos:
                pts.append(pos)
        zones.append((guid, pts, sorted(kinds)))
    return zones

def build_zones(paks_dir, mapname):
    """-> territories {guid: {"zones": [zone dicts]}}; zone dict: guid, x, y, z, n (signs), kinds (sign kind ids)"""
    toc, idx = paks.find_package(paks_dir, f"{mapname}_SpawnData_All_GeneratedAnimalSigns.uasset")
    names = paks.package_names(toc.read(idx))
    tids = sorted(set(re.findall(r"DA_TerritorySigns_([0-9A-F]{32})$", "\n".join(names), re.M)))
    index = {}
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            if "/DA_TerritorySigns_" in path and path.endswith(".uasset"):
                index[path.rsplit("/", 1)[1][18:-7]] = (t, i)
    terrs = {}
    for tid in tids:
        if tid not in index:
            continue
        t, i = index[tid]
        d = t.read(i); hdr, = struct.unpack_from("<I", d, 4)
        try:
            groups = parse_territory_signs(d[hdr:])
        except ValueError:
            continue
        zones = []
        for guid, pts, kinds in groups:
            if not pts:
                continue
            n = len(pts)
            zones.append({"guid": guid, "x": sum(p[0] for p in pts) / n, "y": sum(p[1] for p in pts) / n, "z": sum(p[2] for p in pts) / n, "n": n, "kinds": kinds})
        if zones:
            terrs[tid] = {"zones": zones}
    return terrs

# Where a need zone's signs are (beds, feeding and drinking spots): the game places all of them in every zone of a
# territory, used by the herd or not (StaticSignsManager / SignsStaticMassSpawner go through every zone of
# DA_TerritorySigns), and finding one of them (walking within about 5 m) discovers the zone. The Toybox draws a zone at
# the middle of its signs, which in a spread-out zone can be empty ground: these are the real spots, up to
# SIGNS_PER_ZONE of each zone spread over all of them. Cached as zone_signs.json {"version", zone guid: [x, y, ...] cm}.
SIGNS_VERSION = 1
SIGNS_PER_ZONE = 24
def zone_signs(mapname, paks_dir=None):
    cd = cache_dir(mapname); f = os.path.join(cd, "zone_signs.json")
    try:
        with open(f) as fh:
            d = json.load(fh)
        if d.get("version") == SIGNS_VERSION:
            return d
    except (OSError, ValueError):
        pass
    if not paks_dir:
        return {}
    toc, idx = paks.find_package(paks_dir, f"{mapname}_SpawnData_All_GeneratedAnimalSigns.uasset")
    tids = sorted(set(re.findall(r"DA_TerritorySigns_([0-9A-F]{32})$", "\n".join(paks.package_names(toc.read(idx))), re.M)))
    index = {}
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            if "/DA_TerritorySigns_" in path and path.endswith(".uasset"):
                index[path.rsplit("/", 1)[1][18:-7]] = (t, i)
    out = {"version": SIGNS_VERSION}
    for tid in tids:
        if tid not in index:
            continue
        t, i = index[tid]
        d = t.read(i); hdr, = struct.unpack_from("<I", d, 4)
        try:
            groups = parse_territory_signs(d[hdr:])
        except ValueError:
            continue
        for guid, pts, _kinds in groups:
            if not pts:
                continue
            step = max(1, -(-len(pts) // SIGNS_PER_ZONE))
            out[guid] = [v for p in pts[::step] for v in (round(p[0]), round(p[1]))]
    os.makedirs(cd, exist_ok=True)
    with open(f + ".tmp", "w") as fh:
        json.dump(out, fh, separators=(",", ":"))
    os.replace(f + ".tmp", f)
    return out

# ---------------------------------------------------------------- game files: splines
def build_splines(paks_dir, mapname, with_z=False):
    """-> list of (guid hex, [(x, y), ...]) in world cm; with_z also returns a sample of (x, y, z) points."""
    toc, idx = paks.find_package(paks_dir, f"{mapname}_SpawnData_All_generatedSplines.uasset")
    d = toc.read(idx); hdr, = struct.unpack_from("<I", d, 4); ex = d[hdr:]
    out = []; zs = []
    for m in re.finditer(re.escape(SPLINE_MARK) + rb"(.{4})", ex, re.S):
        cnt, = struct.unpack("<I", m.group(1))
        if not 2 <= cnt <= 5000:
            continue
        p = m.end()
        if p + 24 * cnt > len(ex):
            continue
        vals = struct.unpack_from(f"<{3 * cnt}d", ex, p)
        pts = [(vals[3 * k], vals[3 * k + 1]) for k in range(cnt)]
        if any(abs(x) > 2e6 or abs(y) > 2e6 for x, y in pts):
            continue
        out.append((ex[m.start() - 16:m.start()].hex(), pts))
        if with_z:
            zs += [(vals[3 * k], vals[3 * k + 1], vals[3 * k + 2]) for k in range(0, cnt, 3)]
    return (out, zs) if with_z else out

# ---------------------------------------------------------------- game files: textures
def _texture_info(d):
    hdr, = struct.unpack_from("<I", d, 4); ex = d[hdr:]
    i = ex.find(b"PF_")
    sx, sy = struct.unpack_from("<II", ex, i - 16)
    fmt = ex[i:ex.find(b"\0", i)].decode()
    _first, nmips = struct.unpack_from("<II", ex, i + len(fmt) + 1)
    return sx, sy, fmt, ex, nmips

BPP = {"PF_DXT1": 0.5, "PF_BC7": 1, "PF_DXT5": 1, "PF_BC6H": 1, "PF_B8G8R8A8": 4, "PF_FloatRGBA": 8, "PF_G16": 2, "PF_R16F": 2, "PF_G8": 1}
BCN = {"PF_DXT1": 1, "PF_DXT5": 3, "PF_BC7": 7, "PF_BC6H": 6}
MIN_BLOCK = {"PF_DXT1": 8, "PF_BC7": 16, "PF_DXT5": 16, "PF_BC6H": 16, "PF_B8G8R8A8": 4, "PF_FloatRGBA": 8, "PF_G16": 2, "PF_R16F": 2, "PF_G8": 1}

def height_array(paks_dir, mapname):
    """The map's height texture as float32 in 0..1 (sy, sx), whatever its pixel format; None if absent."""
    import numpy as np
    from PIL import Image
    tex = HEIGHT_TEXTURES.get(mapname)
    if not tex:
        return None
    toc, idx = paks.find_package(paks_dir, tex + ".uasset")
    d = toc.read(idx)
    sx, sy, fmt, ex, nmips = _texture_info(d)
    if fmt not in BPP:
        return None
    bulk_path = next((p for p in toc.files if p.endswith("/" + tex + ".ubulk")), None)
    size = int(sx * sy * BPP[fmt])
    if bulk_path:
        data = toc.read(toc.files[bulk_path])[:size]
    else:
        off = len(ex) - mip_chain_size(sx, sy, fmt, nmips) - 28
        data = ex[off:off + size]
    if fmt == "PF_BC6H":
        img = Image.frombytes("RGB", (sx, sy), data, "bcn", 6, "BC6H")
        return np.asarray(img, dtype=np.float32)[:, :, 0] / 255.0
    if fmt == "PF_FloatRGBA":
        a = np.frombuffer(data, dtype="<f2").reshape(sy, sx, 4)[:, :, 0].astype(np.float32)
    elif fmt == "PF_R16F":
        a = np.frombuffer(data, dtype="<f2").reshape(sy, sx).astype(np.float32)
    elif fmt == "PF_G16":
        a = np.frombuffer(data, dtype="<u2").reshape(sy, sx).astype(np.float32) / 65535.0
    else:
        a = np.frombuffer(data, dtype=np.uint8).reshape(sy, sx).astype(np.float32) / 255.0
    a = np.nan_to_num(a)
    lo, hi = float(a.min()), float(a.max())
    return (a - lo) / (hi - lo) if hi > lo else a

def mip_chain_size(w, h, fmt, nmips):
    """Bytes of the first nmips mips from w x h as UE stores them (block formats never go below one block)."""
    total = 0
    for _ in range(nmips):
        total += max(int(w * h * BPP[fmt]), MIN_BLOCK[fmt])
        w, h = max(1, w // 2), max(1, h // 2)
    return total

def decode_texture(paks_dir, name, max_size=4096):
    """-> PIL RGBA image of the largest available mip (<= max_size), or None."""
    from PIL import Image
    toc, idx = paks.find_package(paks_dir, name + ".uasset")
    d = toc.read(idx)
    sx, sy, fmt, ex, nmips = _texture_info(d)
    if fmt not in BPP:
        return None
    bpp = BPP[fmt]
    bulk_path = next((p for p in toc.files if p.endswith("/" + name + ".ubulk")), None)
    if bulk_path:
        bulk = toc.read(toc.files[bulk_path])
        w = sx
        while w * w * bpp > len(bulk):
            w //= 2
        data = bulk[:int(w * w * bpp)]
    else:
        # inline mip chain right before a 28-byte trailer (verified on 1024/2048/128 px textures)
        w, h = sx, sy; size = int(w * h * bpp)
        off = len(ex) - mip_chain_size(w, h, fmt, nmips) - 28
        if off < 0:
            return None
        data = ex[off:off + size]
        sy = h
    if fmt == "PF_B8G8R8A8":
        img = Image.frombytes("RGBA", (w, sy if not bulk_path else w), data, "raw", "BGRA")
    else:
        img = Image.frombytes("RGBA", (w, w if bulk_path else sy), data, "bcn", BCN[fmt])
    if max(img.size) > max_size:                          # keep its shape (the people portraits are 1040x1900)
        s = max_size / max(img.size)
        img = img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)
    return img

def render_map2d(paks_dir, mapname, roads_tex=None, size=2048):
    """The in-game 2D hunting map, rebuilt the way the game's map material does it: the height texture
    through the game's color palette, hillshade, contour lines, water (red channel of the
    infrastructure texture), roads by type (blue channel), a kilometer grid."""
    from PIL import Image
    import numpy as np
    ha = height_array(paks_dir, mapname)
    if ha is None:
        return None
    h = np.asarray(Image.fromarray(ha, "F").resize((size, size), Image.BICUBIC), dtype=np.float32)
    hs = h.copy()
    for _ in range(3):
        hs = (hs + np.roll(hs, 1, 0) + np.roll(hs, -1, 0) + np.roll(hs, 1, 1) + np.roll(hs, -1, 1)) / 5.0
    ramp = [(t, _srgb(c)) for t, c in MAP2D_RAMP]                  # curve colors are linear; display is sRGB
    col = np.zeros(hs.shape + (3,), dtype=np.float32)
    for (t0, c0), (t1, c1) in zip(ramp, ramp[1:]):
        m = (hs >= t0) & (hs < t1); f = ((hs - t0) / (t1 - t0))[m]
        for i in range(3):
            col[..., i][m] = c0[i] + (c1[i] - c0[i]) * f
    col[hs >= 1.0] = ramp[-1][1]
    lum = col @ np.array([0.3, 0.59, 0.11], dtype=np.float32)
    col = col * 0.8 + lum[..., None] * 0.2
    gy, gx = np.gradient(hs * 30.0)
    col *= np.clip(1.0 - 0.8 * gx - 0.3 * gy, 0.75, 1.12)[..., None]
    lev = (hs * 40.0) % 1.0
    col[(lev < 0.03) | (lev > 0.97)] *= 0.8                         # contour lines
    if roads_tex is not None:
        k = np.asarray(roads_tex.resize((size, size)), dtype=np.float32) / 255.0
        water = k[..., 0]; col = col * (1 - water[..., None]) + np.array(_srgb(WATER_2D), dtype=np.float32) * water[..., None]
    km = size / (2 * BOUNDS[mapname] / 100000.0)                   # pixels per kilometer
    yy, xx = np.mgrid[0:size, 0:size]
    g = ((xx % km) < 1.2) | ((yy % km) < 1.2)
    col[g] *= 0.88
    outside = h <= 0.002                                            # no terrain: outside the playable square
    col[outside] = col[outside] * 0.3 + np.array(_srgb(NONPLAYABLE_2D), dtype=np.float32) * 0.7
    return Image.fromarray(np.clip(col * 255, 0, 255).astype(np.uint8))

NORMAL_TEXTURES = {"Map01": "T_SatMap_Map01_NR", "Map02": "T_SatMap_Map02_NR", "Hub": "T_SateliteHub_NR"}

def light_satellite(paks_dir, mapname, sat_img, fit=None):
    """The in-game 3D map is the satellite texture on a lit terrain mesh: shade it with the game's normal map."""
    import numpy as np
    from PIL import Image
    tex = NORMAL_TEXTURES.get(mapname)
    if not tex:
        return sat_img
    nr_img = decode_texture(paks_dir, tex, sat_img.size[0])
    if nr_img is None:
        return sat_img
    if fit and (fit[0] != 1.0 or fit[1] or fit[2]):
        nr_img = resample_to_map(nr_img.resize(sat_img.size), *fit[:3])
    sat = np.asarray(sat_img.convert("RGB"), dtype=np.float32) / 255.0
    nr = np.asarray(nr_img.resize(sat_img.size), dtype=np.float32) / 255.0
    n = nr[..., :3] * 2 - 1
    nz = np.sqrt(np.clip(1 - n[..., 0] ** 2 - n[..., 1] ** 2, 0, 1))
    L = np.array([-0.5, -0.6, 0.62]); L /= np.linalg.norm(L)
    ndl = np.clip(n[..., 0] * L[0] + n[..., 1] * L[1] + nz * L[2], 0, 1)
    out = np.clip(sat * (0.45 + 0.75 * ndl)[..., None] * 1.05, 0, 1)
    return Image.fromarray((out * 255).astype(np.uint8))

def resample_to_map(img, scale, dx, dy):
    """Resample a satellite-space image so that it covers the hunting-map square."""
    from PIL import Image
    w = img.size[0]
    # map pixel (x, y) -> source pixel ((x - w/2) * scale + w/2 + dx * w, ...)
    a, c = scale, w / 2 - scale * w / 2 + dx * w
    e, f = scale, w / 2 - scale * w / 2 + dy * w
    return img.transform(img.size, Image.AFFINE, (a, 0, c, 0, e, f), Image.BILINEAR)

WARNINGS = []   # non-fatal problems of the last build, reported to the app by `prepare`

def _warn(msg, shown=None):
    """Non-fatal problems while building a map cache go to stderr (the app only reads the JSON line); `shown` is the
    same line in the app's language for WARNINGS (the log stays English)."""
    WARNINGS.append(str(msg if shown is None else shown))
    print("warning: " + str(msg), file=sys.stderr)

CACHE_FILES = ("zones.json", "splines.json", "height.png", "kkk.png", "lakes.png", "satellite.png", "map2d.png")

def cache_missing(cd):
    """Names of the files a finished map cache must have but this one lacks."""
    return [n for n in CACHE_FILES if not os.path.exists(os.path.join(cd, n))]

def fill_shifted_edge(img, dx):
    """resample_to_map leaves a blank band on one side when the texture is shifted (KKK_SHIFT), so the
    sea used to stop 2.2% short of the world edge. Continue the wide water (red channel) of the first
    valid column across the band; rivers that touch the edge are not extended."""
    import numpy as np
    from PIL import Image
    w = img.size[0]; pad = int(round(abs(dx) * w))
    if pad <= 0:
        return img
    a = np.array(img)
    edge = a[:, pad] if dx < 0 else a[:, w - 1 - pad]
    red = edge[:, 0] > 64
    er = red.copy()
    for k in range(1, 25):
        er &= np.roll(red, k) & np.roll(red, -k)
    keep = er.copy()
    for k in range(1, 26):
        keep |= np.roll(er, k) | np.roll(er, -k)
    keep &= red                                            # runs taller than ~48 px (of 2048): the sea, not river mouths
    cl = keep.copy()                                       # close sandbar gaps of up to ~12 rows in the sea
    for k in range(1, 7):
        cl |= np.roll(keep, k) | np.roll(keep, -k)
    keep = cl.copy()
    for k in range(1, 7):
        keep &= np.roll(cl, k) & np.roll(cl, -k)
    band = np.zeros((a.shape[0], pad, a.shape[2]), np.uint8)
    band[keep, :, 0] = 255
    if dx < 0:
        a[:, :pad] = band
    else:
        a[:, w - pad:] = band
    return Image.fromarray(a)

def _thin(mask):
    """Zhang-Suen thinning -> 1 px skeleton (numpy)."""
    import numpy as np
    img = mask.astype(np.uint8).copy()
    def nb(a):
        P = [np.roll(a, (1, 0), (0, 1)), np.roll(a, (1, -1), (0, 1)), np.roll(a, (0, -1), (0, 1)), np.roll(a, (-1, -1), (0, 1)),
             np.roll(a, (-1, 0), (0, 1)), np.roll(a, (-1, 1), (0, 1)), np.roll(a, (0, 1), (0, 1)), np.roll(a, (1, 1), (0, 1))]
        return P   # P2..P9 clockwise starting north
    for _ in range(60):
        changed = False
        for step in (0, 1):
            P2, P3, P4, P5, P6, P7, P8, P9 = nb(img)
            B = P2 + P3 + P4 + P5 + P6 + P7 + P8 + P9
            seq = [P2, P3, P4, P5, P6, P7, P8, P9, P2]
            A = sum(((seq[i] == 0) & (seq[i + 1] == 1)).astype(np.uint8) for i in range(8))
            if step == 0:
                c1 = (P2 * P4 * P6) == 0; c2 = (P4 * P6 * P8) == 0
            else:
                c1 = (P2 * P4 * P8) == 0; c2 = (P2 * P6 * P8) == 0
            rem = (img == 1) & (B >= 2) & (B <= 6) & (A == 1) & c1 & c2
            if rem.any():
                img[rem] = 0; changed = True
        if not changed:
            break
    return img.astype(bool)

def _trace(skel):
    """Skeleton -> list of pixel polylines (8-connected walks between junctions/endpoints)."""
    import numpy as np
    H, W = skel.shape
    pts = set((int(y), int(x)) for y, x in zip(*np.nonzero(skel)))
    def nbrs(p):
        y, x = p
        return [(y + dy, x + dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1) if (dy or dx) and (y + dy, x + dx) in pts]
    deg = {p: len(nbrs(p)) for p in pts}
    used = set(); lines = []
    def walk(start, nxt):
        line = [start, nxt]; used.add((start, nxt)); used.add((nxt, start))
        cur, prev = nxt, start
        while deg.get(cur, 0) == 2:
            n = [q for q in nbrs(cur) if q != prev]
            if not n: break
            q = n[0]
            if (cur, q) in used: break
            used.add((cur, q)); used.add((q, cur)); line.append(q); prev, cur = cur, q
        return line
    order = sorted(pts)                               # fixed order: a set's order differs between 64- and 32-bit Python
    for p in order:
        if deg[p] != 2:
            for q in nbrs(p):
                if (p, q) not in used:
                    lines.append(walk(p, q))
    for p in order:                                   # closed loops without junctions
        for q in nbrs(p):
            if (p, q) not in used:
                lines.append(walk(p, q))
    return lines

def _simplify(line, tol=1.2):
    """Douglas-Peucker."""
    if len(line) < 3:
        return line
    (y0, x0), (y1, x1) = line[0], line[-1]
    dx, dy = x1 - x0, y1 - y0; L = (dx * dx + dy * dy) ** 0.5 or 1.0
    best, bi = 0.0, 0
    for i, (y, x) in enumerate(line[1:-1], 1):
        d = abs(dy * (x - x0) - dx * (y - y0)) / L
        if d > best: best, bi = d, i
    if best > tol:
        return _simplify(line[:bi + 1], tol)[:-1] + _simplify(line[bi:], tol)
    return [line[0], line[-1]]

def _erode(m, k=1):
    import numpy as np
    for _ in range(k):
        m = m & np.roll(m, 1, 0) & np.roll(m, -1, 0) & np.roll(m, 1, 1) & np.roll(m, -1, 1)
    return m

def _dilate(m, k=1):
    import numpy as np
    for _ in range(k):
        m = m | np.roll(m, 1, 0) | np.roll(m, -1, 0) | np.roll(m, 1, 1) | np.roll(m, -1, 1)
    return m

WATER_VERSION = 6

def vectorize_water(roads_tex, size=2048):
    """Red channel of the infrastructure texture: wide water (lakes, sea, wide rivers, compact ponds)
    -> filled mask, everything narrower -> one centreline per channel (no bank outlines).
    -> (lakes mask bool array, [[(u, v), ...], ...])"""
    import numpy as np
    from scipy import ndimage
    k = np.asarray(roads_tex.resize((size, size)), dtype=np.float32)[:, :, 0] / 255.0
    mask = k > 0.25
    big = _dilate(_erode(mask, 8), 9) & mask                    # wider than ~16 texels: lakes, sea
    lab, n = ndimage.label(mask & ~big)
    small = np.zeros_like(mask)
    if n:
        areas = ndimage.sum(mask & ~big, lab, range(1, n + 1))
        objs = ndimage.find_objects(lab)
        for i, sl in enumerate(objs):
            h = sl[0].stop - sl[0].start; w = sl[1].stop - sl[1].start
            a = areas[i]
            if 12 <= a <= 3000 and a / float(h * w) > 0.45 and max(h, w) < 4 * min(h, w):
                small[sl] |= (lab[sl] == i + 1)                 # compact pond, not a channel
    lakes = big | small
    rivers = mask & ~_dilate(big, 2) & ~small
    skel = _thin(rivers)
    near_lake = _dilate(big, 5)
    lines = []
    for line in _trace(skel):
        if len(line) < 12:
            continue
        if sum(1 for y, x in line if near_lake[y, x]) / len(line) > 0.8:
            continue                                            # shoreline sliver, not a river
        lines.append([(x / size, y / size) for y, x in _simplify(line, 0.5)])
    return lakes, lines

INFRA_SIZE = 4096
INFRA_RANGE = 48.0        # texels of distance encoded in one 8-bit channel

def infra_fields(roads_tex, size=INFRA_SIZE):
    """Distance fields for the map lines, so the terrain shader can draw constant-width strokes:
    R = distance to the nearest road centreline (texels / INFRA_RANGE), G = that road's class
    (1 main road, 0.5 track), B = distance to the nearest river centreline. Centrelines come from
    the traced, smoothed vectors, so they are continuous and never bank outlines."""
    import numpy as np
    from PIL import Image, ImageDraw
    from scipy import ndimage
    def chaikin(pts, passes=2):
        for _ in range(passes):
            if len(pts) < 3:
                break
            out = [pts[0]]
            for a, b in zip(pts, pts[1:]):
                out.append((0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1])); out.append((0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]))
            out.append(pts[-1]); pts = out
        return pts
    def field(lines_with_class):
        mask = Image.new("L", (size, size), 0); cls = Image.new("L", (size, size), 0)
        dm, dc = ImageDraw.Draw(mask), ImageDraw.Draw(cls)
        for c, pts in lines_with_class:
            if len(pts) < 2:
                continue
            xy = [(u * size, v * size) for u, v in chaikin(pts)]
            dm.line(xy, fill=255, width=1); dc.line(xy, fill=int(c * 255), width=3)
        m = np.asarray(mask) > 0
        dist, (iy, ix) = ndimage.distance_transform_edt(~m, return_indices=True)
        cl = np.asarray(cls, dtype=np.float32)[iy, ix] / 255.0
        return np.clip(dist / INFRA_RANGE, 0, 1), cl
    roads = vectorize_roads(roads_tex)
    _lakes, rivers = vectorize_water(roads_tex)
    rd, rc = field([(1.0 if major else 0.5, pts) for major, pts in roads])
    wd, _ = field([(1.0, pts) for pts in rivers])
    out = np.zeros((size, size, 4), dtype=np.uint8)
    out[..., 0] = (rd * 255).astype(np.uint8); out[..., 1] = (rc * 255).astype(np.uint8); out[..., 2] = (wd * 255).astype(np.uint8); out[..., 3] = 255
    return Image.fromarray(out, "RGBA")

def rebuild_water(mapname, paks_dir, cd):
    """Regenerate lakes.png / water.json / infra.png of a cached map with the current vectoriser."""
    from PIL import Image
    sat, roads = TEXTURES[mapname]
    if not roads:
        return False
    roads_img = decode_texture(paks_dir, roads, 2048)
    if roads_img is None:
        return False
    roads_img = fill_shifted_edge(resample_to_map(roads_img.convert("RGB"), 1.0, KKK_SHIFT, 0.0), KKK_SHIFT)
    roads_img.save(os.path.join(cd, "kkk.png"))
    infra_fields(roads_img).save(os.path.join(cd, "infra.png"))
    lakes, rivers = vectorize_water(roads_img)
    lk = Image.new("RGBA", (lakes.shape[1], lakes.shape[0]), (79, 147, 208, 0)); lk.putalpha(Image.fromarray((lakes * 255).astype("uint8")))
    lk.save(os.path.join(cd, "lakes.png"))
    with open(os.path.join(cd, "water.json"), "w") as f:
        json.dump(rivers, f)
    try:
        m2 = render_map2d(paks_dir, mapname, roads_img)
        if m2 is not None:
            m2.save(os.path.join(cd, "map2d.png"))
    except Exception as e:
        _warn("2D map: %r" % (e,), i18n.t("2D map: {problem}").format(problem=repr(e)))
    return True

def vectorize_roads(roads_tex, size=2048):
    """Blue channel of the infrastructure texture -> [(major: bool, [(u, v), ...]), ...]"""
    import numpy as np
    k = np.asarray(roads_tex.resize((size, size)), dtype=np.float32)[:, :, 2] / 255.0
    mask = k > 0.18
    skel = _thin(mask)
    out = []
    for line in _trace(skel):
        if len(line) < 4:
            continue
        strength = float(np.mean([k[y, x] for y, x in line[::max(1, len(line) // 12)]]))
        pts = [(x / size, y / size) for y, x in _simplify(line, 0.5)]
        out.append((strength > 0.5, pts))
    return out

def export_height(paks_dir, mapname, cd):
    """Height texture -> <cache>/height.png (8-bit) for the 3D terrain."""
    from PIL import Image
    import numpy as np
    ha = height_array(paks_dir, mapname)
    if ha is None:
        return None
    img = Image.fromarray(np.clip(ha * 255 + 0.5, 0, 255).astype(np.uint8), "L")
    img.save(os.path.join(cd, "height.png"))
    return img

def synth_height(terrs, splines_z, L, cd, n=256):
    """No height texture (Hub): rasterize the altitudes of paths and zones into a grid, fill gaps."""
    import numpy as np
    from PIL import Image
    acc = np.zeros((n, n), np.float64); cnt = np.zeros((n, n), np.float64)
    def add(x, y, z):
        u = (x + L) / (2 * L); v = (y + L) / (2 * L)
        if 0 <= u < 1 and 0 <= v < 1:
            acc[int(v * n), int(u * n)] += z; cnt[int(v * n), int(u * n)] += 1
    for x, y, z in splines_z:
        add(x, y, z)
    for tr in terrs.values():
        for zz in tr["zones"]:
            add(zz["x"], zz["y"], zz["z"])
    known = cnt > 0
    h0 = np.where(known, acc / np.maximum(cnt, 1), 0.0)
    S = h0.copy(); W = known.astype(np.float64)
    blur = lambda a: (a + np.roll(a, 1, 0) + np.roll(a, -1, 0) + np.roll(a, 1, 1) + np.roll(a, -1, 1)) / 5
    for _ in range(120):                                     # normalized diffusion into the gaps
        S = blur(S); W = blur(W)
        S[known] = h0[known]; W[known] = 1.0
    mean = float(h0[known].mean()) if known.any() else 0.0
    h = np.where(W > 1e-4, S / np.maximum(W, 1e-4), mean)
    for _ in range(3):
        h = blur(h)
    lo, hi = float(h.min()), float(h.max())
    img = Image.fromarray(((h - lo) / max(1.0, hi - lo) * 255).astype(np.uint8)).resize((1024, 1024), Image.BICUBIC)
    img.save(os.path.join(cd, "height.png"))
    return ((hi - lo) / 255.0, lo)

def fit_height(height_img, terrs, L):
    """Linear fit world z (cm) = a * H(0..255) + b from the zones' known altitudes."""
    import numpy as np
    h = np.asarray(height_img, dtype=np.float32)
    n = h.shape[0]
    xs, ys, zs = [], [], []
    for tr in terrs.values():
        for z in tr["zones"]:
            u = (z["x"] + L) / (2 * L); v = (z["y"] + L) / (2 * L)
            ix, iy = int(u * (n - 0.001)), int(v * (n - 0.001))
            if 0 <= ix < n and 0 <= iy < n:
                xs.append(h[iy, ix]); zs.append(z["z"])
    if len(xs) < 10:
        return 100.0, 0.0
    a, b = np.polyfit(np.array(xs), np.array(zs), 1)
    return float(a), float(b)

ICONS_VERSION = 6      # bump when ICONS changes so an existing cache re-exports (v2: station / range / parking, refreshed species; v3: one icon per marker type; v4: opportunities; v5: crisp 256 px animal silhouettes; v6: impala (1.4))

def icons_ready(cd=None):
    """True when the shared icon folder is complete for this ICONS_VERSION."""
    icons = os.path.join(cd or CACHE_ROOT, "icons")
    try:
        with open(os.path.join(icons, "VERSION")) as f:
            if f.read().strip() != str(ICONS_VERSION):
                return False
    except OSError:
        return False
    return all(os.path.exists(os.path.join(icons, n + ".png")) for n in ICONS)

def ensure_icons(paks_dir, cd=None):
    """Export the icons unless the cache already has the current set (cheap check, called on every map load)."""
    if not icons_ready(cd):
        export_icons(paks_dir, cd or CACHE_ROOT)

def crisp_silhouette(img, out=256):
    """The game's animal icons are 128 px with a soft, grainy edge and a dark shadow ring (no bigger copy ships).
    Rebuild them as a clean white silhouette: coverage = how white AND how opaque a pixel is (so the shadow ring is
    dropped), upscaled 4x, a hard edge at half coverage (a smooth band of about one output pixel), shrunk to `out`."""
    from PIL import Image
    import numpy as np
    rgba = np.asarray(img.convert("RGBA"), dtype=np.float32) / 255.0
    lum = rgba[..., :3].mean(axis=2)
    cov = np.clip(rgba[..., 3] * (lum - 0.25) / 0.6, 0.0, 1.0)            # white & opaque = animal, dark ring = 0
    up = Image.fromarray((cov * 255).astype(np.uint8), "L").resize((img.width * 4, img.height * 4), Image.LANCZOS)
    x = np.asarray(up, dtype=np.float32) / 255.0
    t = np.clip((x - 0.42) / 0.16, 0.0, 1.0); t = t * t * (3 - 2 * t)
    big = Image.fromarray((t * 255).astype(np.uint8), "L").resize((out, out), Image.LANCZOS)
    res = Image.new("RGBA", (out, out), (255, 255, 255, 0)); res.putalpha(big)
    return res

def export_icons(paks_dir, cd):
    """Game UI icons (need zones, markers, species) -> <cache>/icons/<name>.png"""
    icons = os.path.join(cd, "icons"); os.makedirs(icons, exist_ok=True)
    wanted = dict(ICONS)
    for t in paks.all_tocs(paks_dir):
        for path in t.files:
            b = path.rsplit("/", 1)[1]
            if b.startswith("T_UI_AnimalSubspecies_") and b.endswith(".uasset") \
                    and (paks.released_species(b[len("T_UI_AnimalSubspecies_"):-7]) or b == "T_UI_AnimalSubspecies_Unknown.uasset"):
                wanted["species_" + b[len("T_UI_AnimalSubspecies_"):-7]] = b[:-7]       # only animals in the game
    for name, tex in wanted.items():
        try:
            img = decode_texture(paks_dir, tex, 256)
            if img is not None:
                if name.startswith("species_"):
                    img = crisp_silhouette(img)
                img.save(os.path.join(icons, name + ".png"))
        except Exception:
            pass
    with open(os.path.join(icons, "VERSION"), "w") as f:
        f.write(str(ICONS_VERSION))

def build_schedules(paks_dir):
    """{family: [(hour, type), ...]} from DA_LifeCycleSchedule_* (unversioned: hour f32 and type u8, zero fields omitted)."""
    out = {}
    for t in paks.all_tocs(paks_dir):
        for path, idx in t.files.items():
            b = path.rsplit("/", 1)[1]
            if not (b.startswith("DA_LifeCycleSchedule_") and b.endswith(".uasset")):
                continue
            d = t.read(idx); hdr, = struct.unpack_from("<I", d, 4); ex = d[hdr:]
            try:
                n, = struct.unpack_from("<I", ex, 2); p = 6; ents = []
                for _ in range(n):
                    if ex[p] != 0x80 or ex[p + 1] != 0x07:
                        raise ValueError
                    mask = ex[p + 2]; p += 3; hour = 0.0; tp = 0
                    if not mask & 1:
                        hour, = struct.unpack_from("<f", ex, p); p += 4
                    if not mask & 2:
                        tp = ex[p]; p += 1
                    if not mask & 4:
                        p += 4
                    ents.append((hour, SCHEDULE_TYPES.get(tp, "?")))
                out[b[len("DA_LifeCycleSchedule_"):-7]] = sorted(ents)
            except (ValueError, struct.error):
                continue
    return out

def released_schedules(families, species):
    """schedules.json: only animals that are in the game, and only the schedule families they use."""
    species = {k: v for k, v in species.items() if paks.released_species(k)}
    used = set(species.values()) | {v for k, v in SPECIES_FAMILY.items()}
    return {"families": {k: v for k, v in families.items() if k in used}, "species": species, "version": SCHEDULES_VERSION}

def build_species_families(paks_dir):
    """{subspecies: schedule family} from the lifecycle class each species' AI difficulty config names."""
    out = {}
    for t in paks.all_tocs(paks_dir):
        for path, idx in t.files.items():
            b = path.rsplit("/", 1)[1]
            m = re.match(r"BP_GroupAiDifficultyConfig_(\w+)\.uasset$", b) or re.match(r"BP_(\w+)_AIGroup_DifficultyMapping\.uasset$", b)
            if not m:
                continue
            refs = re.findall(rb"BP_GroupAiLifeCycle_(\w+?)_Default", t.read(idx))
            if refs:
                out[m.group(1)] = refs[0].decode()
    return out

def schedule_windows(ents):
    """[(hour, type)] -> {type: [(start, end), ...]} over a 24 h day."""
    win = collections.defaultdict(list)
    if not ents:
        return win
    for i, (h, t) in enumerate(ents):
        end = ents[i + 1][0] if i + 1 < len(ents) else ents[0][0] + 24
        win[t].append((h, end))
    # merge touching segments, then the wrap-around one
    for t, segs in win.items():
        segs.sort()
        merged = []
        for a, b in segs:
            if merged and abs(merged[-1][1] - a) < 1e-6:
                merged[-1] = (merged[-1][0], b)
            else:
                merged.append((a, b))
        segs[:] = merged
        if len(segs) > 1 and segs[-1][1] >= 24 and segs[0][0] == 0:
            first = segs.pop(0); last = segs.pop()
            segs.append((last[0], first[1] + 24))
    return win

# ---------------------------------------------------------------- cache
def cache_dir(mapname):
    return os.path.join(CACHE_ROOT, mapname)

def stage_text(stage):
    """A build stage (BUILD_STAGES) as the loading screen shows it: in the app's language."""
    return {"Reading the need zones": i18n.t("Reading the need zones"), "Reading the animal trails": i18n.t("Reading the animal trails"),
            "Reading roads": i18n.t("Reading roads"), "Drawing roads": i18n.t("Drawing roads"), "Drawing rivers and lakes": i18n.t("Drawing rivers and lakes"),
            "Redrawing rivers and lakes": i18n.t("Redrawing rivers and lakes"), "Reading the map picture": i18n.t("Reading the map picture"),
            "Building the 3D map": i18n.t("Building the 3D map"), "Drawing the map": i18n.t("Drawing the map"),
            "Getting the map icons": i18n.t("Getting the map icons"), "Reading hills and valleys": i18n.t("Reading hills and valleys")}.get(stage, stage)

BUILD_STAGES = ["Reading the need zones", "Reading the animal trails", "Reading roads", "Drawing roads", "Drawing rivers and lakes", "Reading the map picture",
                "Building the 3D map", "Drawing the map", "Getting the map icons", "Reading hills and valleys"]

PACK_FILES = ("meta.json", "zones.json", "height.png", "kkk.png", "lakes.png", "map2d.png", "lands.json", "lands.png", "fog.png",
              "spawn_areas.json", "zone_types.json", "terrain_index.json", "zone_signs.json")

def pack_problems(mapname, paks_dir=None):
    """What is out of date in a map's cache for shipping it in the map pack: [] when every cached file is the current
    version (and, with the game here, the current game build). A stale file in the pack is thrown away by an app with
    no game files (console players, the website), so the map would come up with zones missing or typed wrong."""
    import lands
    cd = cache_dir(mapname); game = paks.game_build(paks_dir) if paks_dir else None
    def j(n):
        try:
            with open(os.path.join(cd, n)) as f: return json.load(f)
        except (OSError, ValueError): return None
    out = []
    for n in ("satellite.png", "zones.json", "lands.png"):
        if not os.path.exists(os.path.join(cd, n)): out.append(n + " missing")
    for n, key, want in (("meta.json", "version", CACHE_VERSION), ("spawn_areas.json", "version", AREAS_VERSION),
                         ("lands.json", "version", lands.VERSION), ("zone_types.json", "_version", ZONE_TYPES_VERSION)):
        d = j(n)
        if d is None: out.append(n + " missing"); continue
        if d.get(key) != want: out.append(f"{n} {key} {d.get(key)} (wants {want})")
        if game and n != "zone_types.json" and d.get("game") != game: out.append(f"{n} game build {d.get('game')} (game is {game})")
    sa = j("spawn_areas.json") or {}
    if not sa.get("areas") or sa.get("territories") is None: out.append("spawn_areas.json has no areas / territory lists")
    if not (j("lands.json") or {}).get("territories"): out.append("lands.json has no herd lands")
    return out

def build_pack(dest):
    """The map files the app needs to work with no game files at all (console players): every map's finished cache, the
    satellite as JPEG, no animal trails. Built at release time from a full cache (build_dist.sh). A map whose cache is
    out of date is rebuilt from the game first; with no game files to rebuild from, nothing stale is shipped (error)."""
    from PIL import Image
    import shutil, lands
    pd = paks.find_paks_dir()
    for m in BOUNDS:
        cd, out = cache_dir(m), os.path.join(dest, m)
        if pack_problems(m, pd) and pd:                   # refresh: map cache, need zones + their types, lands
            model = load_map(m, None)
            tp = os.path.join(cd, "zone_types.json")
            try: zt = json.load(open(tp))
            except (OSError, ValueError): zt = {}
            if zt.get("_version") != ZONE_TYPES_VERSION:
                with open(tp, "w") as f: json.dump({**model.types_table, "_version": ZONE_TYPES_VERSION}, f)
            lands.ensure_cache(cd, pd, m, paks.english_names()[0])
        if pd: zone_signs(m, pd)                          # (the sign spots of every need zone, for the website too)
        bad = pack_problems(m, pd)
        if bad:
            raise RuntimeError(f"map pack: {m} cache is out of date and could not be rebuilt: " + "; ".join(bad))
        os.makedirs(out, exist_ok=True)
        for n in PACK_FILES:
            if os.path.exists(os.path.join(cd, n)): shutil.copyfile(os.path.join(cd, n), os.path.join(out, n))
        with open(os.path.join(out, "meta.json")) as f: mm = json.load(f)
        mm["paks"] = ""                                    # the build PC's game folder (a home path) stays out of what ships
        with open(os.path.join(out, "meta.json"), "w") as f: json.dump(mm, f)
        Image.open(os.path.join(cd, "satellite.png")).convert("RGB").save(os.path.join(out, "satellite.jpg"), quality=88)
    if pd: ensure_icons(pd)                               # re-export when the cache's icons are an older ICONS_VERSION
    shutil.copytree(os.path.join(CACHE_ROOT, "icons"), os.path.join(dest, "icons"), dirs_exist_ok=True,
                    ignore=lambda _d, fs: [f for f in fs if f.startswith("species_") and f != "species_Unknown.png"
                                           and not paks.released_species(f[8:-4])])
    sched = load_schedules()                     # only the animals that are in the game go into the pack
    with open(os.path.join(dest, "schedules.json"), "w") as f:
        json.dump(released_schedules(sched.get("families", {}), sched.get("species", {})), f)

def seed_from_pack(mapname):
    """No game files on this PC: fill the map cache from the pack shipped with the app (when there is one)."""
    pack = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mappack")
    if not os.path.isdir(os.path.join(pack, mapname)):
        return False
    import shutil
    cd = cache_dir(mapname); os.makedirs(cd, exist_ok=True)
    src = os.path.join(pack, mapname)
    for n in os.listdir(src):
        if n == "satellite.jpg":
            if not os.path.exists(os.path.join(cd, "satellite.png")):
                from PIL import Image
                Image.open(os.path.join(src, n)).save(os.path.join(cd, "satellite.png"))
        elif not os.path.exists(os.path.join(cd, n)):
            shutil.copyfile(os.path.join(src, n), os.path.join(cd, n))
    if not os.path.exists(os.path.join(cd, "splines.json")):
        with open(os.path.join(cd, "splines.json"), "w") as f: f.write("[]")
    if not icons_ready():
        shutil.copytree(os.path.join(pack, "icons"), os.path.join(CACHE_ROOT, "icons"), dirs_exist_ok=True)
    if not os.path.exists(os.path.join(CACHE_ROOT, "schedules.json")):
        shutil.copyfile(os.path.join(pack, "schedules.json"), os.path.join(CACHE_ROOT, "schedules.json"))
    return True

def load_or_build(mapname, paks_dir, progress=None):
    """Zones, splines and textures for a map, cached. -> dict or raises."""
    cd = cache_dir(mapname)
    meta = os.path.join(cd, "meta.json")
    try:
        with open(meta) as f:
            m = json.load(f)
        stale_game = bool(paks_dir) and m.get("game") != paks.game_build(paks_dir)   # the game was patched since
        if m.get("version") == CACHE_VERSION and not cache_missing(cd) and not stale_game:   # a partial cache (a failed stage) is rebuilt
            height_fit = m.get("height_fit", (0.0, 0.0))
            with open(os.path.join(cd, "zones.json")) as f:
                terrs = json.load(f)
            with open(os.path.join(cd, "splines.json")) as f:
                splines = json.load(f)
            sched = load_schedules()
            if m.get("water_version") != WATER_VERSION and paks_dir:
                try:
                    if progress: progress("Redrawing rivers and lakes")
                    if rebuild_water(mapname, paks_dir, cd):
                        m["water_version"] = WATER_VERSION
                        with open(meta, "w") as f:
                            json.dump(m, f)
                except Exception:
                    pass
            return {"territories": terrs, "splines": splines, "dir": cd, "L": BOUNDS[mapname], "schedules": sched, "height_fit": height_fit}
    except (OSError, ValueError):
        pass
    if not paks_dir:
        looked = "; ".join(paks.LOOKED) or "no Steam library found"
        raise RuntimeError(f"game files not found and no cached map data (looked in: {looked})")
    os.makedirs(cd, exist_ok=True)
    del WARNINGS[:]
    if progress: progress("Reading the need zones")
    terrs = build_zones(paks_dir, mapname)
    if progress: progress("Reading the animal trails")
    splines, spline_points_z = build_splines(paks_dir, mapname, with_z=True)
    sat, roads = TEXTURES[mapname]
    fit = (1.0, 0.0, 0.0, 0.0)
    roads_img = None
    if roads:
        try:
            if progress: progress("Reading roads")
            roads_img = decode_texture(paks_dir, roads, 2048)
            if roads_img is not None:
                roads_img = fill_shifted_edge(resample_to_map(roads_img.convert("RGB"), 1.0, KKK_SHIFT, 0.0), KKK_SHIFT)   # into the world frame
                roads_img.save(os.path.join(cd, "kkk.png"))
        except Exception as e:
            _warn("roads texture: %r" % (e,), i18n.t("roads texture: {problem}").format(problem=repr(e))); roads_img = None
    if roads_img is not None:
        try:
            if progress: progress("Drawing roads")
            with open(os.path.join(cd, "roads.json"), "w") as f:
                json.dump(vectorize_roads(roads_img), f)
        except Exception as e:
            _warn("roads: %r" % (e,), i18n.t("roads: {problem}").format(problem=repr(e)))
        try:
            if progress: progress("Drawing rivers and lakes")
            lakes, rivers = vectorize_water(roads_img)
            from PIL import Image
            lk = Image.new("RGBA", (lakes.shape[1], lakes.shape[0]), (79, 147, 208, 0)); lk.putalpha(Image.fromarray((lakes * 255).astype("uint8")))
            lk.save(os.path.join(cd, "lakes.png"))
            with open(os.path.join(cd, "water.json"), "w") as f:
                json.dump(rivers, f)
        except Exception as e:
            _warn("water: %r" % (e,), i18n.t("water: {problem}").format(problem=repr(e)))
    try:
        if progress: progress("Reading the map picture")
        img = decode_texture(paks_dir, sat)
        if img is not None:
            if progress: progress("Building the 3D map")
            try:
                img = light_satellite(paks_dir, mapname, img, fit)
            except Exception as e:
                _warn("lighting: %r" % (e,), i18n.t("lighting: {problem}").format(problem=repr(e)))
            img.convert("RGB").save(os.path.join(cd, "satellite.png"))
        else:
            _warn("satellite texture %s not decodable" % sat, i18n.t("satellite texture {name} not decodable").format(name=sat))
    except Exception as e:
        _warn("satellite: %r" % (e,), i18n.t("satellite: {problem}").format(problem=repr(e)))
    try:
        if progress: progress("Drawing the map")
        m2 = render_map2d(paks_dir, mapname, roads_img)
        if m2 is not None:
            m2.save(os.path.join(cd, "map2d.png"))
    except Exception as e:
        _warn("2D map: %r" % (e,), i18n.t("2D map: {problem}").format(problem=repr(e)))
    try:
        if progress: progress("Getting the map icons")
        export_icons(paks_dir, os.path.join(CACHE_ROOT))
    except Exception as e:
        _warn("icons: %r" % (e,), i18n.t("icons: {problem}").format(problem=repr(e)))
    sched = released_schedules(build_schedules(paks_dir), build_species_families(paks_dir))
    with open(os.path.join(CACHE_ROOT, "schedules.json"), "w") as f:
        json.dump(sched, f)
    with open(os.path.join(cd, "zones.json"), "w") as f:
        json.dump(terrs, f)
    with open(os.path.join(cd, "splines.json"), "w") as f:
        json.dump([(g, [(round(x), round(y)) for x, y in pts]) for g, pts in splines], f)
    hfit = (0.0, 0.0)
    try:
        if progress: progress("Reading hills and valleys")
        him = export_height(paks_dir, mapname, cd)
        if him is not None:
            hfit = fit_height(him, terrs, BOUNDS[mapname])
        else:
            hfit = synth_height(terrs, spline_points_z, BOUNDS[mapname], cd)
    except Exception as e:
        _warn("height: %r" % (e,), i18n.t("height: {problem}").format(problem=repr(e)))
    with open(meta, "w") as f:
        json.dump({"version": CACHE_VERSION, "paks": paks_dir, "game": paks.game_build(paks_dir), "water_version": WATER_VERSION,
                   "satellite_fit": fit, "height_fit": hfit}, f)
    return {"territories": terrs, "splines": splines, "dir": cd, "L": BOUNDS[mapname], "schedules": sched, "height_fit": hfit}

# ---------------------------------------------------------------- save overlay
RARE_VARIANTS = {"Albino": "Albino", "Melanistic": "Melanistic", "Leucistic": "Leucistic", "Piebald": "Piebald"}

def _asset_table(asv):
    """The AnimalSaveSystem section ends with its asset table: (path, name) string pairs; records
    index into it 0-based by pair. -> [name, ...]"""
    i = asv.find(b"/Game/BASE/Animals")
    if i < 4:
        return []
    p = i - 4; strs = []
    while p < len(asv) - 4:
        n, = struct.unpack_from("<i", asv, p)
        if 0 < n < 400 and asv[p + 4 + n - 1:p + 4 + n] == b"\x00":
            strs.append(asv[p + 4:p + 4 + n - 1].decode("latin-1")); p += 4 + n
        else:
            break
    return [strs[k + 1] for k in range(0, len(strs) - 1, 2) if strs[k].startswith("/")]

def _ue_guid(g):
    a, b, c, d = struct.unpack("<IIII", g); return f"{a:08X}{b:08X}{c:08X}{d:08X}"

def save_overlay(sf, mapname, terrs, extra_zone_guids=None):
    """Read everything per-save for one map. -> dict(species {terr: species}, discovered set,
    fow bytes, player (x, y, z) or None, zone_types {zone guid: type})"""
    try:
        world = nrgs.split_sections(sf.part(f"Game_0/World_0/{mapname}").data)[1]
        shared = nrgs.split_sections(sf.part(f"Game_0/WorldShared/{mapname}").data)[1]
    except KeyError:                                     # a map this save has never been to (a new game): as with no save
        return static_overlay(mapname)
    sec = {h: b for h, v, b in world}
    ssec = {h: b for h, v, b in shared}
    out = {"species": {}, "discovered": set(), "fow": None, "player": None, "zone_types": {}, "animals": [], "herd_zones": {}}
    hm = sec.get(nrgs.name_hash(f"BP_HerdManagement_{mapname}_WS_C"))
    if hm:
        for m in re.finditer(rb"Animals\.Subspecies\.([A-Za-z]+)\x00\x01\x00\x00\x00\x01\x02(.{4})\x01(.{4})", hm, re.S):
            l2, = struct.unpack("<I", m.group(3)); pay = hm[m.end():m.end() + l2]
            for i in range((len(pay) - 9) // 16):
                out["species"][_ue_guid(pay[9 + 16 * i:25 + 16 * i])] = m.group(1).decode()
    disc = ssec.get(nrgs.name_hash("BP_Discovery_WS_C"))
    if disc:
        import trainer_core
        out["discovered"] = {g.hex() for g in trainer_core.parse_discovery(disc)[1]}
    fow = sec.get(nrgs.name_hash("BP_HuntingMap_WS_C"))
    if fow:
        import trainer_core
        out["fow"] = fow[trainer_core.FOW_GRID_OFF:trainer_core.FOW_GRID_OFF + trainer_core.FOW_BYTES]
    pl = sec.get(nrgs.name_hash("PlayerSaveWorldSubsystem"))
    if pl and len(pl) >= 71:
        x, y, z = struct.unpack_from("<ddd", pl, 47)
        if abs(x) < 5e6 and abs(y) < 5e6:
            out["player"] = (x, y, z)
    asv = sec.get(nrgs.name_hash("AnimalSaveSystem"))
    if asv:
        try:
            import animals as animals_mod
            out["animals"] = animals_mod.read_animals(sf, mapname, [paks.guid_from_text(t) for t in terrs])
        except Exception:
            out["animals"] = []
        allz = {z["guid"] for tr in terrs.values() for z in tr["zones"]} | set(extra_zone_guids or ())
        where = guid_positions(asv, [bytes.fromhex(z) for z in allz])   # one pass over the save for every zone
        for tr in terrs.values():
            for z in tr["zones"]:
                g = bytes.fromhex(z["guid"]); votes = collections.Counter(); last = -16
                for i in where.get(g, ()):
                    if i < last + 16: continue                 # (as the find loop: the next look starts 16 bytes on)
                    last = i
                    if i + 20 > len(asv): continue
                    v, = struct.unpack_from("<I", asv, i + 16)
                    if v in ZONE_TYPES:
                        votes[v] += 1
                if votes:
                    out["zone_types"][z["guid"]] = ZONE_TYPES[votes.most_common(1)[0][0]]
        try:                                              # animals in each herd now (herds.py: the save's herd member lists)
            import herds
            out["herd_members"] = herds.herd_members(asv, [paks.guid_from_text(t) for t in terrs])
            out["herd_n"] = {t: len(ids) for t, ids in out["herd_members"].items()}
            hm = sec.get(nrgs.name_hash(f"BP_HerdManagement_{mapname}_WS_C"))
            out["herd_fit"] = herds.herd_fitness(hm, [paks.guid_from_text(t) for t in terrs]) if hm else {}
        except Exception:
            out["herd_members"] = {}; out["herd_n"] = {}; out["herd_fit"] = {}
        try:                                              # each herd's own need groups: exact types + its full zone list
            out["herd_zones"] = herd_records(asv, set(terrs), allz, where)
        except Exception:
            out["herd_zones"] = {}
    return out

def static_overlay(mapname):
    """The overlay without a save: herd species and zone types from static_maps.json (the game fixes them; tools/
    build_static.py), nothing discovered, no hunter, no animals."""
    out = {"species": {}, "discovered": set(), "fow": None, "player": None, "zone_types": {}, "animals": [], "herd_zones": {}}
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "static_maps.json")) as f:
            m = json.load(f)["maps"].get(mapname, {})
        out["species"] = m.get("species", {}); out["zone_types"] = m.get("zone_types", {})
    except (OSError, ValueError):
        pass
    return out

def _guid_text(b):
    return "".join("%08X" % struct.unpack_from("<I", b, k)[0] for k in range(0, 16, 4))

def guid_positions(buf, guids):
    """{guid: [every offset where it is in buf], sorted} for many 16-byte GUIDs in one pass: the first 8 bytes of
    the buffer at every offset are matched against all GUIDs at once (numpy), then the whole 16 are checked.
    (A find loop per GUID scanned the save thousands of times: ~1.7 s on New Laurentia.)"""
    import numpy as np
    out = {g: [] for g in guids}
    heads = {}
    for g in guids:
        heads.setdefault(g[:8], []).append(g)
    if not heads:
        return out
    vals = np.array([int.from_bytes(k, "little") for k in heads], dtype=np.uint64)
    n = len(buf)
    for k in range(8):
        m = (n - k) // 8
        if m <= 0:
            continue
        arr = np.frombuffer(buf, dtype="<u8", count=m, offset=k)
        for h in np.nonzero(np.isin(arr, vals))[0]:
            pos = k + 8 * int(h)
            for g in heads[bytes(buf[pos:pos + 8])]:
                if buf[pos:pos + 16] == g:
                    out[g].append(pos)
    for g in out:
        out[g].sort()
    return out

def herd_records(asv, terr_ids, zone_guids, where=None):
    """{territory id: [{"type", "pref", "zones": [guid hex, ...]}, ...]} - every herd's zone choice from
    AnimalSaveSystem (Ghidra 2026-10-08: NRGMassGroupZoneSelectionDataFragment.preferredZones, built by FUN_1456d5440
    at herd creation from a timer-seeded random order of the territory's zones, up to 3 per need). Layout:
    u32 ?, u32 need count, then per need: u8 EAnimalNeedZone, i32 tag, i32 preferredIndex, i32 secondaryCounter,
    u32 n, n zone GUIDs; then u32, territory GUID. The herd only goes to zones[preferredIndex] ("main"); the others are
    backups it switches to when hunting pressure on the main one passes the difficulty's zone threshold."""
    zb = {bytes.fromhex(z) for z in zone_guids}
    out = {}; L = len(asv)
    if where is None:
        where = guid_positions(asv, list(zb))
    for z in zb:
        for q in where.get(z, ()):
            s0 = q - 17
            if s0 >= 8:
                cnt, = struct.unpack_from("<I", asv, s0 - 4)
                if 1 <= cnt <= 6 and asv[s0] in AREA_TYPES:
                    p = s0; groups = []; ok = True
                    for _ in range(cnt):
                        if p + 17 > L or asv[p] not in AREA_TYPES: ok = False; break
                        t = asv[p]; tag, pref, sc, n = struct.unpack_from("<iiiI", asv, p + 1); p += 17
                        if not 1 <= n <= 6 or p + 16 * n > L: ok = False; break
                        zs = [asv[p + 16 * j:p + 16 * j + 16] for j in range(n)]
                        if not all(x in zb for x in zs): ok = False; break
                        groups.append({"type": AREA_TYPES[t], "pref": pref if 0 <= pref < n else 0, "zones": [x.hex() for x in zs]})
                        p += 16 * n
                    if ok and p + 20 <= L:
                        tid = _guid_text(asv[p + 4:p + 20])
                        if tid in terr_ids:
                            out[tid] = groups
    return out

AREA_TYPES = {2: "Resting", 3: "Eating", 4: "Watering", 5: "Transition"}   # EAnimalNeedZone (exe enum table)

def _uv_header(d, p):
    """UE unversioned-property header at p -> ([property indices present], [indices that are zero], data start)."""
    present = []; i = 0; frags = []
    while True:
        h, = struct.unpack_from("<H", d, p); p += 2
        i += h & 0x7f; num = h >> 9
        frags.append((i, num, bool(h & 0x80)))
        i += num
        if h & 0x100: break
    nz = sum(num for _, num, z in frags if z)
    zeros = set()
    if nz:
        nb = (nz + 7) // 8; bits = int.from_bytes(d[p:p + nb], "little"); p += nb; k = 0
        for st, num, z in frags:
            if not z: continue
            for j in range(num):
                if bits >> k & 1: zeros.add(st + j)
                k += 1
    for st, num, z in frags:
        present += [st + j for j in range(num)]
    return present, zeros, p

def spawn_areas(paks_dir, mapname):
    """Every need zone as the game defines it (SpawnAreaData in SD_<Map>_* / <Map>_SpawnData_*, 2026-10-08):
    {zone guid hex: {"x", "y" cm, "type" (m_areaType = what the game's GetNeedZoneType returns), "shape" "circle" |
    "rect", "w", "h" meters (circle: radius in both)}}. Property order (exe reflection): 0 m_center, 1 m_originShift,
    2 m_name, 3 m_areaColor, 4 m_areaType, 5 m_fadeout, 6 m_fadeoutLength, 7 m_territoryID, 8 m_areaShape (object),
    9 m_transitions, 10 m_TEHController, 11 m_signsCountCoef, 12 m_TEHTerritoryController, 17 territory ref, 18 GUID.
    The types match the zones' own signs (beds = Resting, grazing = Eating, drinking = Watering) on every zone."""
    import zenpkg
    out = {}
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            nm = path.rsplit("/", 1)[-1]
            if not ((nm.startswith(f"SD_{mapname}_") or nm.startswith(f"{mapname}_SpawnData")) and nm.endswith(".uasset")) \
                    or "GeneratedAnimalSigns" in nm or "plines" in nm:
                continue
            try:
                z = zenpkg.ZenPackage(t.read(i))
            except Exception:
                continue
            names = [n[0] if isinstance(n, tuple) else n for n in z.names]
            cls = lambda e: names[e[2] & 0xffffffff] if (e[2] & 0xffffffff) < len(names) else ""
            shapes = {}
            for k, (e, d) in enumerate(zip(z.exports, z.export_data)):
                c = cls(e)
                if c not in ("SpawnAreaShapeCircle", "SpawnAreaShapeRectangle"):
                    continue
                try:
                    pres, zero, p = _uv_header(d, 0)
                    vals = {}
                    for ix in pres:
                        if ix in zero: vals[ix] = 0.0; continue
                        if ix in (0, 1): vals[ix], = struct.unpack_from("<f", d, p); p += 4
                        else: break
                    if c == "SpawnAreaShapeCircle":
                        rr = vals.get(0, 0.0) / 100.0; shapes[k] = ("circle", rr, rr)
                    else:
                        shapes[k] = ("rect", vals.get(0, 0.0) / 100.0, vals.get(1, 0.0) / 100.0)
                except Exception:
                    pass
            for k, (e, d) in enumerate(zip(z.exports, z.export_data)):
                if cls(e) != "SpawnAreaData":
                    continue
                try:
                    pres, zero, p = _uv_header(d, 0)
                    rec = {}
                    for ix in pres:
                        if ix in zero: continue
                        if ix == 0: rec["x"], rec["y"] = struct.unpack_from("<dd", d, p); p += 16
                        elif ix == 1: p += 16
                        elif ix == 2: n, = struct.unpack_from("<i", d, p); p += 4 + (n if n > 0 else -2 * n)
                        elif ix == 3: p += 4
                        elif ix == 4: rec["type"] = AREA_TYPES.get(d[p], "Unknown"); p += 1
                        elif ix in (5, 6, 7, 10, 11, 12): p += 4
                        elif ix == 8: sr, = struct.unpack_from("<i", d, p); p += 4; rec["shape_ref"] = sr
                        elif ix == 9: n, = struct.unpack_from("<i", d, p); p += 4 + 4 * n
                        elif ix == 17: p += 4
                        elif ix == 18: rec["guid"] = d[p:p + 16].hex(); p += 16
                        else: break
                    g = rec.pop("guid", None)
                    if not g or "x" not in rec:
                        continue
                    sh = shapes.get(rec.pop("shape_ref", 0) - 1)
                    if sh:
                        rec["shape"], rec["w"], rec["h"] = sh[0], round(sh[1], 1), round(sh[2], 1)
                    rec.setdefault("type", "Unknown")
                    out[g] = rec
                except Exception:
                    pass
    return out

AREAS_VERSION = 3       # 2: + territory zone lists; 3: full lists (a ref equal to a count cut 4 Map01 lists short)

def territory_zones(paks_dir, mapname):
    """{territory id (zones.json key): [zone guid hex, ...]} - each herd territory's own need zones as the level data
    lists them (TerritoryData: ..., array of SpawnAreaData object refs, u32, territory GUID, u32 0)."""
    import zenpkg
    out = {}
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            nm = path.rsplit("/", 1)[-1]
            if not ((nm.startswith(f"SD_{mapname}_") or nm.startswith(f"{mapname}_SpawnData")) and nm.endswith(".uasset")) \
                    or "GeneratedAnimalSigns" in nm or "plines" in nm:
                continue
            try:
                z = zenpkg.ZenPackage(t.read(i))
            except Exception:
                continue
            names = [n[0] if isinstance(n, tuple) else n for n in z.names]
            cls = lambda e: names[e[2] & 0xffffffff] if (e[2] & 0xffffffff) < len(names) else ""
            area_guid = {}
            for k, (e, d) in enumerate(zip(z.exports, z.export_data)):
                if cls(e) == "SpawnAreaData" and len(d) >= 20:
                    try:
                        pres, zero, p = _uv_header(d, 0)
                        # the GUID is the last property: 16 bytes before the 4-byte tail
                        area_guid[k + 1] = d[-20:-4].hex() if d[-4:] == b"\0\0\0\0" else d[-16:].hex()
                    except Exception:
                        pass
            for k, (e, d) in enumerate(zip(z.exports, z.export_data)):
                if cls(e) != "TerritoryData" or len(d) < 28:
                    continue
                g = len(d) - 20                               # territory GUID, then u32 0
                tid = "".join("%08X" % struct.unpack_from("<I", d, g + j)[0] for j in range(0, 16, 4))
                end = g - 4                                   # u32 before the GUID
                # walk back for the array count; a zone ref can itself equal a smaller count (e.g. ref 9 nine
                # slots back), so keep the LONGEST list whose count matches and whose refs are all zones
                best = None
                for n in range(1, 64):
                    q = end - 4 * n - 4
                    if q < 0: break
                    if struct.unpack_from("<I", d, q)[0] == n:
                        refs = struct.unpack_from("<%di" % n, d, q + 4)
                        if all(r in area_guid for r in refs):
                            best = [area_guid[r] for r in refs]
                if best:
                    out[tid] = best
    return out

def shown_territories(paks_dir, mapname):
    """The herd territories the map draws (the ones with animal signs: zones.json), from the map cache when it is
    current, else straight from the game files. Animals that are not in the game, test herds and the empty mission
    herds have none."""
    cd = cache_dir(mapname)
    try:
        with open(os.path.join(cd, "meta.json")) as f: m = json.load(f)
        if m.get("version") == CACHE_VERSION and m.get("game") == paks.game_build(paks_dir):
            with open(os.path.join(cd, "zones.json")) as f: return set(json.load(f))
    except (OSError, ValueError):
        pass
    return set(build_zones(paks_dir, mapname))

def level_guids(paks_dir, mapname, shown_only=True):
    """-> (territory GUIDs, need-zone GUIDs) as sorted lists of 16-byte values (the save's byte order), from the level
    data: every TerritoryData and the zones it lists (m_children). The sign packages list zones and herds no level
    uses (Map01: 2,012 zones) and miss some (Map02: 5 zones), so "discover all zones" should take these. shown_only:
    only the herds the map draws (shown_territories) and their zones - what the Hunter page counts and "discover all"
    writes."""
    tz = territory_zones(paks_dir, mapname)
    if not tz:
        raise ValueError(f"no territories found in {mapname} level data")
    if shown_only:
        shown = shown_territories(paks_dir, mapname)
        if shown:
            tz = {t: v for t, v in tz.items() if t in shown}
    return sorted(paks.guid_from_text(t) for t in tz), sorted({bytes.fromhex(z) for v in tz.values() for z in v})

# ---------------------------------------------------------------- assembled map model
class MapModel:
    """Everything the map view draws, in world coordinates."""
    def __init__(self, mapname, data, overlay, types_table=None):
        self.map = mapname
        self.L = data["L"]
        self.dir = data["dir"]
        self.territories = {}           # guid -> dict(species, zones[list of zone dict], cx, cy)
        self.zones = []                 # dict(guid, terr, species, type, x, y, z, discovered, n)
        self.zone_by_guid = {}
        # zone type: the animals' own records first; otherwise the sign-kind mix, which maps 1:1
        # onto the type (learnt from the typed zones of this map, remembered in the types table)
        table = dict(types_table or {})
        votes = collections.defaultdict(collections.Counter)
        # a herd the save does not have yet (one a game update added, a map not played since): the game's own species
        # for it (static_maps.json), never a question mark
        fixed = static_overlay(mapname)["species"] if any(t not in overlay["species"] for t in data["territories"]) else {}
        species_of = lambda tid: overlay["species"].get(tid) or fixed.get(tid, "Unknown")
        for tid, tr in data["territories"].items():
            sp = species_of(tid)
            for z in tr["zones"]:
                t = overlay["zone_types"].get(z["guid"])
                if t:
                    k = ",".join(map(str, z["kinds"]))
                    votes[k][t] += 1; votes[f"{sp}|{k}"][t] += 1; votes[f"{sp}|{k}|{z['n']}"][t] += 1
        for key, c in votes.items():                     # the sign mix means different needs for different species:
            table["signs:" + key] = c.most_common(1)[0][0]   # species + mix (+ sign count) is right 98.5 % of the time
        self.types_table = table
        for tid, tr in data["territories"].items():
            sp = species_of(tid)
            zs = []
            signs = {z["guid"]: z for z in tr["zones"] + data.get("extra_zones", {}).get(tid, [])}
            lst = data.get("terr_zones", {}).get(tid)
            if lst and all(g in data.get("areas", {}) for g in lst):   # the level data's own list for this herd
                z0 = sum(z["z"] for z in tr["zones"]) / len(tr["zones"])
                zl = []
                for g in lst:
                    a = data["areas"][g]; sz = signs.get(g, {})
                    zl.append({"guid": g, "x": a["x"], "y": a["y"], "z": sz.get("z", z0), "n": sz.get("n", 0), "kinds": sz.get("kinds", [])})
            else:
                zl = list(signs.values())
            for z in zl:
                k = ",".join(map(str, z["kinds"]))
                ar = data.get("areas", {}).get(z["guid"]) or {}
                zt = ar.get("type") if ar.get("type") in ("Eating", "Watering", "Resting") else None
                zt = zt or (overlay["zone_types"].get(z["guid"]) or table.get(f"signs:{sp}|{k}|{z['n']}") or table.get(f"signs:{sp}|{k}")
                            or table.get("signs:" + k) or _type_heuristic(z["kinds"]))
                zd = dict(z, terr=tid, species=sp, type=zt, discovered=z["guid"] in overlay["discovered"],
                          shape=ar.get("shape"), w=ar.get("w"), h=ar.get("h"), role=data.get("zone_roles", {}).get((tid, z["guid"])))
                zs.append(zd); self.zones.append(zd); self.zone_by_guid[z["guid"]] = zd
            self.territories[tid] = {"guid": tid, "species": sp, "zones": zs, "cx": sum(z["x"] for z in zs) / len(zs), "cy": sum(z["y"] for z in zs) / len(zs),
                                     "discovered": paks.guid_from_text(tid).hex() in overlay["discovered"]}
        self.splines = []               # dict(species, terr, pts, start, end)
        near = _ZoneIndex(self.zones)
        for guid, pts in data["splines"]:
            # a path belongs to the ONE herd with need zones at both of its ends (herds of different species
            # overlap, so the plain nearest zone at each end put ~1 in 5 paths on a neighbouring herd)
            ea = near.by_herd(pts[0][0], pts[0][1]); eb = near.by_herd(pts[-1][0], pts[-1][1])
            both = set(ea) & set(eb)
            if both:
                t = min(both, key=lambda t: ea[t][0] + eb[t][0]); a, b = ea[t][1], eb[t][1]
            else:
                a = near.nearest(pts[0][0], pts[0][1]); b = near.nearest(pts[-1][0], pts[-1][1])
            terr = (a or b or {}).get("terr")
            self.splines.append({"pts": pts, "terr": terr, "species": (a or b or {}).get("species", "Unknown"), "start": a["guid"] if a else None, "end": b["guid"] if b else None})
        self.species = collections.Counter(z["species"] for z in self.zones)
        # individual animals (from the save): each goes in the herd whose member list (save) holds it; the nearest
        # herd of its species only for the odd one in no list
        self.animals = overlay.get("animals", [])
        herd_of = {i: t for t, ids in overlay.get("herd_members", {}).items() for i in ids}
        self.herd_n = overlay.get("herd_n", {})
        self.herd_fit = overlay.get("herd_fit", {})
        by_sp = collections.defaultdict(list)
        for z in self.zones:
            by_sp[z["species"]].append(z)
        idx = {sp: _ZoneIndex(zs) for sp, zs in by_sp.items()}
        for a in self.animals:
            sp = a["species"]
            if sp not in idx:                             # config name vs subspecies id spelling (StruthioCamelus vs ...Australis)
                sp = next((k for k in idx if k.startswith(sp) or sp.startswith(k)), None)
            t = herd_of.get(a.get("id"))
            if t in self.territories:
                a["terr"] = t
            else:
                z = idx[sp].nearest(a["x"], a["y"], maxd=60000) if sp else None
                a["terr"] = z["terr"] if z else None
            a["species"] = sp or a["species"]
        self.fow = overlay["fow"]
        self.player = overlay["player"]
        self.discovered = overlay["discovered"]
        self.satellite = os.path.join(self.dir, "satellite.png") if os.path.exists(os.path.join(self.dir, "satellite.png")) else None
        self.roads = []; self.rivers = []
        try:
            with open(os.path.join(self.dir, "roads.json")) as f:
                self.roads = json.load(f)
            with open(os.path.join(self.dir, "water.json")) as f:
                self.rivers = json.load(f)
        except (OSError, ValueError):
            pass
        self.lakes = os.path.join(self.dir, "lakes.png") if os.path.exists(os.path.join(self.dir, "lakes.png")) else None
        self.map2d = os.path.join(self.dir, "map2d.png") if os.path.exists(os.path.join(self.dir, "map2d.png")) else None
        self.height = os.path.join(self.dir, "height.png") if os.path.exists(os.path.join(self.dir, "height.png")) else None
        self.height_fit = data.get("height_fit", (0.0, 0.0))
        self.icons_dir = os.path.join(CACHE_ROOT, "icons")
        self.schedules = data.get("schedules", {})
        for t in self.territories.values():
            t["trails"] = 0
        for s in self.splines:
            if s["terr"] in self.territories:
                self.territories[s["terr"]]["trails"] += 1

    def schedule_for(self, species):
        """{type: [(start, end)]} for a species, or {} when unknown."""
        game = self.schedules.get("species", {})
        fams = self.schedules.get("families", {})
        # the game's own table first, also by name prefix (StruthioCamelusAustralis vs config named StruthioCamelus);
        # the hand table only when the game files did not name one
        fam = game.get(species) or next((v for k, v in game.items() if species.startswith(k) or k.startswith(species)), None)
        if fam not in fams:
            fam = SPECIES_FAMILY.get(species)
        return schedule_windows(fams.get(fam, [])) if fam else {}

    def to_uv(self, x, y):
        return (x + self.L) / (2 * self.L), (y + self.L) / (2 * self.L)

def _type_heuristic(kinds):
    """Fallback when a sign mix was never seen typed: kinds -5/-6 go with drinking, -7..-9 with resting, -2/-3 with feeding."""
    ks = set(kinds)
    if ks & {-5, -6}:
        return "Watering"
    if ks & {-7, -8, -9}:
        return "Resting"
    if ks & {-2, -3}:
        return "Eating"
    return "Unknown"

class _ZoneIndex:
    def __init__(self, zones, cell=20000):
        self.cell = cell; self.grid = collections.defaultdict(list)
        for z in zones:
            self.grid[(int(z["x"] // cell), int(z["y"] // cell))].append(z)
    def nearest(self, x, y, maxd=6000):
        cx, cy = int(x // self.cell), int(y // self.cell); best = (maxd * maxd, None)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for z in self.grid.get((cx + dx, cy + dy), ()):
                    d = (z["x"] - x) ** 2 + (z["y"] - y) ** 2
                    if d < best[0]:
                        best = (d, z)
        return best[1]
    def by_herd(self, x, y, maxd=15000):
        """{herd guid: (distance², its nearest zone)} for every herd with a need zone within maxd."""
        cx, cy = int(x // self.cell), int(y // self.cell); out = {}
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for z in self.grid.get((cx + dx, cy + dy), ()):
                    d = (z["x"] - x) ** 2 + (z["y"] - y) ** 2
                    if d <= maxd * maxd and (z["terr"] not in out or d < out[z["terr"]][0]):
                        out[z["terr"]] = (d, z)
        return out

def load_map(mapname, save_path, progress=None):
    """-> MapModel (raises RuntimeError with a readable message)."""
    paks_dir = paks.find_paks_dir(save_path)
    if not paks_dir and cache_missing(cache_dir(mapname)):
        seed_from_pack(mapname)                       # no game on this PC (console player): the map files shipped with the app
    data = load_or_build(mapname, paks_dir, progress)
    sf = nrgs.SaveFile(save_path) if save_path else None      # None: no save (console players, or none picked)
    # every need zone as the game defines it: its own type (GetNeedZoneType), spot and size (spawn_areas)
    ap = os.path.join(data["dir"], "spawn_areas.json")
    areas = None
    srcs = [ap]
    if not paks_dir:                                  # no game: an older cache can be refreshed from the shipped pack
        srcs.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "mappack", mapname, "spawn_areas.json"))
    for src in srcs:
        try:
            with open(src) as f: j = json.load(f)
            if j.get("version") == AREAS_VERSION and (not paks_dir or j.get("game") == paks.game_build(paks_dir)):
                areas = j["areas"]
                if src != ap:
                    import shutil; shutil.copyfile(src, ap)
                break
        except (OSError, ValueError):
            pass
    tzones = None
    try:
        if areas is not None: tzones = j.get("territories")
    except NameError:
        pass
    if (areas is None or tzones is None) and paks_dir:
        areas = spawn_areas(paks_dir, mapname); tzones = territory_zones(paks_dir, mapname)
        try:
            with open(ap, "w") as f:
                json.dump({"version": AREAS_VERSION, "game": paks.game_build(paks_dir), "areas": areas, "territories": tzones}, f)
        except OSError:
            pass
    data["areas"] = areas or {}
    data["terr_zones"] = tzones or {}
    overlay = save_overlay(sf, mapname, data["territories"], data["areas"].keys()) if sf else static_overlay(mapname)
    # each herd's zone choice (save): main = the one it goes to, backup = used after hunting pressure, unused = the
    # territory's zones the herd never picked (it keeps at most 3 per need)
    roles = {}
    for tid, groups in overlay["herd_zones"].items():
        for gp in groups:
            for k, g in enumerate(gp["zones"]):
                roles[(tid, g)] = "main" if k == gp["pref"] else "backup"
        for g in (data["terr_zones"].get(tid) or []):
            roles.setdefault((tid, g), "unused")
    data["zone_roles"] = roles
    have = {z["guid"] for tr in data["territories"].values() for z in tr["zones"]}
    data["extra_zones"] = {}
    known = {g: (a["x"], a["y"]) for g, a in data["areas"].items()}
    if True:                                          # zones a herd uses that have no static signs (Kilimaya hippos...)
        for tid, groups in overlay["herd_zones"].items():
            tr = data["territories"].get(tid)
            if not tr: continue
            z0 = sum(z["z"] for z in tr["zones"]) / len(tr["zones"])
            for gp in groups:
                for g in gp["zones"]:
                    if g not in have and known.get(g):
                        data["extra_zones"].setdefault(tid, []).append({"guid": g, "x": known[g][0], "y": known[g][1], "z": z0, "n": 0, "kinds": []})
    types_path = os.path.join(data["dir"], "zone_types.json")
    try:
        with open(types_path) as f:
            table = json.load(f)
    except (OSError, ValueError):
        table = {}
    if table.get("_version") != ZONE_TYPES_VERSION:   # learnt from the old swapped need numbers
        table = {"_version": ZONE_TYPES_VERSION}
    model = MapModel(mapname, data, overlay, table)
    if model.types_table != table:                    # remember sign-mix types learnt from this save
        try:
            with open(types_path, "w") as f:
                json.dump(model.types_table, f)
        except OSError:
            pass
    return model

if __name__ == "__main__":
    import time, trainer_core
    save = trainer_core.find_save()
    for m in sys.argv[1:] or BOUNDS:
        t = time.time()
        mm = load_map(m, save, progress=lambda s: print("  ", s))
        typed = collections.Counter(z["type"] for z in mm.zones)
        print(f"{m}: territories {len(mm.territories)} zones {len(mm.zones)} {dict(typed)} splines {len(mm.splines)} species {len(mm.species)} player {mm.player} sat {mm.satellite is not None} {time.time() - t:.1f}s")
