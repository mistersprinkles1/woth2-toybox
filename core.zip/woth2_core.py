#!/usr/bin/env python3
"""Command-line core used by the standalone app: everything comes out as JSON / files.

  woth2_core.py state                    -> JSON: save path, values, skills, per-map status, backups
  woth2_core.py stats                    -> JSON: hunting statistics
  woth2_core.py prepare <Map> [--force]  -> builds the map cache and writes
                                            <cache>/<Map>/model.json, fow.png, paths/<territory>.json
                                            prints JSON {"dir": ..., "model": ...}
  woth2_core.py apply '<json>'           -> applies edits (JSON body from the app: money/xp/skill_points/unlock_all_skills/reveal/discover/upgrade_hq)
  woth2_core.py spawn '<json>'           -> {"map","species","sex","variant","quality","fitness","fitness_range","age","rack","target","animal_id"}
  woth2_core.py reset-animals '{"map"}'    -> the game regenerates the map's whole population on load
  woth2_core.py complete '<json>'        -> {"ids": [DA_ asset, ...]} marks challenges / missions finished
  woth2_core.py repair '<json>'          -> {"maps": [...]}  reset trophy tags the game cannot show back to Typical
  woth2_core.py plan '<json>'            -> {"map","species"?,"per_species","tents","camp_radius_m","marker_type","markers"} -> {"spots": [...]}
  woth2_core.py stands '<json>'          -> {"map","spots","markers","marker_type"} writes them into the save
  woth2_core.py marker '<json>'          -> {"map","x","y","z","type"} adds one in-game custom marker
  woth2_core.py set-markers '<json>'     -> {"map","markers":[{"x","y","z","type","label"?}]} the map's whole marker list
  woth2_core.py mark-wounded '<json>'   -> {"map"} a star marker (named in the app) on every wounded animal
  woth2_core.py teleport '<json>'       -> {"map","x","y","z"} game cm: the hunter starts there on the next load
                                            (add / move / retype / delete; labels are kept by the app only)
  woth2_core.py max-dog                  -> bonding + the three hunting skills to the top level (hidden traits kept)
  woth2_core.py restore <file|original>  -> restores a backup
  woth2_core.py undo                     -> puts back the save from before the app's most recent edit
  woth2_core.py rename '<json>'          -> {"file","name"} renames a backup
  woth2_core.py delete '<json>'          -> {"file"} deletes a backup
  woth2_core.py export '<json>'          -> {"file"|omitted (= the game's save),"dest"} copies it anywhere
  woth2_core.py import '<json>'          -> {"file"} replaces the game's save with that .nrgs (NO backup)
  woth2_core.py saveinfo '<json>'        -> {"file"} quick facts about any .nrgs
  woth2_core.py backup                   -> makes a backup now
  woth2_core.py cleanup '<json>'         -> {"keep": 20, "dry_run"} deletes old automatic backups -> {"count"}
  woth2_core.py start-fresh '<json>'     -> {"confirm": "START FRESH"} deletes the game's save + the original backup
  woth2_core.py vault                    -> {"unlocked", "has_vault"} for the key in WOTH2_KEY
  woth2_core.py unlock '<json>'          -> {"code", "new"?} -> {"key"}: opens the lock (and changes the code)
Options: --save PATH selects another save file.
"""
import datetime, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import i18n

WRITE_CMDS = {"apply", "spawn", "rare-herds", "reset-animals", "complete", "repair", "stands", "marker",
              "mark-wounded", "teleport", "set-markers", "set-names", "max-dog", "pickup", "pickup-everything", "rename", "delete", "start-fresh", "import",
              "restore", "undo", "backup", "cleanup", "save-as"}

def main(argv):
    """Commands that change the save or the backups run one at a time (each one reads the save, changes it and writes
    it back: two at once - a marker and a hunter move clicked quickly - would lose one of them)."""
    cmd = next((a for a in argv if not a.startswith("--") and (argv.index(a) == 0 or argv[argv.index(a) - 1] != "--save")), "state")
    if cmd not in WRITE_CMDS:
        return _main(argv)
    import time, trainer_core
    lock = os.path.join(trainer_core.BACKUP_DIR, ".write.lock")
    os.makedirs(trainer_core.BACKUP_DIR, exist_ok=True)
    deadline = time.time() + 120
    while True:
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY); os.write(fd, str(os.getpid()).encode()); os.close(fd); break
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock) > 300 or _lock_owner_gone(lock):     # left by a crashed run
                    os.remove(lock); continue
            except OSError:
                continue
            if time.time() > deadline:
                json.dump({"error": i18n.t("Another change is still being written, try again in a moment.")}, sys.stdout); print(); return
            time.sleep(0.2)
    try:
        return _main(argv)
    finally:
        try: os.remove(lock)
        except OSError: pass

def _lock_owner_gone(lock):
    """The run that made the write lock is not there any more (the app was closed mid-write): no 5 minute wait.
    Only where one program can ask about another (not in the Windows bundle's sandboxed Python)."""
    if sys.platform not in ("linux", "darwin"):
        return False
    try:
        pid = int(open(lock).read().strip() or 0)
    except (OSError, ValueError):
        return False
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    except OSError:
        return False
    return False

def _main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8")           # Windows pipes default to the console code page
    except Exception:
        pass
    save = None
    if "--save" in argv:
        i = argv.index("--save"); save = argv[i + 1]; del argv[i:i + 2]
    force = "--force" in argv; argv = [a for a in argv if a != "--force"]
    cmd = argv[0] if argv else "state"
    if len(argv) > 1 and argv[1].startswith("@"):        # JSON body handed over in a file (the app does this)
        with open(argv[1][1:]) as f:
            argv[1] = f.read()
    import vault                                          # first: it guards the locked modules (see vault.py)
    if cmd == "vault":                                    # is the lock open for the key the app handed over?
        json.dump({"unlocked": vault.unlocked(), "has_vault": vault.has_vault()}, sys.stdout); print(); return
    if cmd == "unlock":                                   # {"code", "new"?} -> {"key"} (the content key, hex)
        body = json.loads(argv[1])
        key = vault.change_code(body["code"], body["new"]) if body.get("new") else vault.unlock(body["code"])
        json.dump({"ok": True, "key": key}, sys.stdout); print(); return
    if cmd in LOCKED_CMDS and EDITION == "toybox":      # the basic app has no save editing at all
        json.dump({"error": i18n.t("Not in this app.")}, sys.stdout); print(); return
    if cmd == "check-save":                              # {"file"}: is this a Way of the Hunter 2 save? (picked by hand)
        import nrgs
        try:
            nrgs.SaveFile(json.loads(argv[1])["file"]); json.dump({"ok": True}, sys.stdout)
        except Exception as e:
            log_error(e)
            json.dump({"error": i18n.t("That is not a Way of the Hunter 2 save file.")}, sys.stdout)
        print(); return
    if cmd in LOCKED_CMDS and not vault.unlocked():
        json.dump({"error": i18n.t(vault.LOCKED_MSG)}, sys.stdout); print(); return
    if cmd == "encyclopedia":                            # the game's codex + trophy / herd chapters (no save needed)
        import encyclopedia
        json.dump(encyclopedia.load(force=force), sys.stdout, ensure_ascii=True); print(); return     # (plain ASCII: the app reads the output in chunks, and an accented letter split between two came out broken)
    if cmd == "running":                                 # cheap poll from the app: no save parsing
        import trainer_core
        out = {"game_running": trainer_core.game_running()}
        try: out["save_mtime"] = os.path.getmtime(trainer_core.find_save(save))     # the app lights REFRESH when the game saved
        except Exception: pass
        json.dump(out, sys.stdout); print(); return
    if cmd == "set-game-dir":                            # {"dir"}: the game folder picked by hand (game not found)
        import woth2_paks
        try:
            d = woth2_paks.set_game_dir(json.loads(argv[1])["dir"])
            json.dump({"ok": True, "paks": d}, sys.stdout)
        except ValueError as e:
            json.dump({"error": str(e)}, sys.stdout)
        print(); return
    import appstate as server, trainer_core as core, mapdata
    st = server.State(save)
    out = {}
    if cmd == "state":
        out = server.state_json(st)
    elif cmd == "killshare":                              # measured kills for "Help make trophy ratings better"
        import trophy_score as ts, nrgs as _nrgs, woth2_paks as _wp
        sf = _nrgs.SaveFile(st.save) if st.save and os.path.isfile(st.save) else None
        out = {"build": (_wp.game_build(_wp.find_paks_dir(st.save)) or "") if sf else "", "kills": ts.share_records(sf) if sf else []}
    elif cmd == "savepack":                               # a copy of the save with every hunter name taken out (savepack.py)
        import savepack
        out = savepack.pack(st.save) if st.save and os.path.isfile(st.save) else {"error": "no save"}
    elif cmd == "zone-signs":                             # {"map", "zone"}: where that need zone's signs are (x, y pairs, cm)
        import woth2_paks
        a = json.loads(argv[1]) if len(argv) > 1 else {}
        try: pd = woth2_paks.find_paks_dir(st.save)
        except Exception: pd = None
        out = {"zone": a.get("zone", ""), "pts": mapdata.zone_signs(str(a.get("map", "")), pd).get(str(a.get("zone", "")), [])}
    elif cmd == "stats":
        out = server.stats_json(st)
    elif cmd == "board-file":                             # {"text"}: the leaderboard for the Stats mod's ledger (only if the mod is there)
        body = json.loads(argv[1]); out = server.write_board(st.save, body["text"], body.get("hunter", ""))
    elif cmd == "save-facts":                             # the game saved: distance driven for the Stats mod (only if the mod is there)
        out = server.save_facts_json(st)
    elif cmd == "board-key":                              # {"key"}: the Steam sign-in for the Stats mod (only if the mod is there)
        out = server.write_board_key(st.save, json.loads(argv[1]).get("key", ""))
    elif cmd == "prepare":
        m = argv[1]
        if not st.no_save and (not st.save or not os.path.isfile(st.save)):
            raise FileNotFoundError(i18n.t("No save found. Start the game once so it makes one, then try again."))
        if force:
            import shutil; shutil.rmtree(mapdata.cache_dir(m), ignore_errors=True)
        model = st.model(m)
        mj = server.model_json(m, model, st)
        cd = model.dir
        try:                                              # the game's Lands: border overlay + names (lands.py)
            import lands, woth2_paks
            mj["lands"] = lands.ensure_cache(cd, woth2_paks.find_paks_dir(st.save), m, getattr(st.names, "t", None))
            mj["land_borders"] = lands.borders(cd)
            mj["herd_land"] = lands.herd_lands(woth2_paks.find_paks_dir(st.save), m, [(t["guid"], t["x"], t["y"]) for t in mj["territories"]])
        except Exception as e:
            print("warning: lands:", e, file=sys.stderr); mj["lands"] = []
        try:                                              # the game's fog-of-war smudge texture (drifting mist over unexplored land)
            fp = os.path.join(cd, "fog.png")
            if not os.path.exists(fp):
                import woth2_paks
                img = mapdata.decode_texture(woth2_paks.find_paks_dir(st.save), "T_Smudges_02_K")
                if img is not None:
                    img.convert("L").save(fp)
        except Exception as e:
            print("warning: fog texture:", e, file=sys.stderr)
        mp = os.path.join(cd, "model.json")
        with open(mp + ".tmp", "w") as f:                # whole file or nothing: the app may be reading it right now
            f.write(json.dumps(mj))                       # (dumps: json.dump to a file skips the fast C encoder)
        os.replace(mp + ".tmp", mp)
        fow = server.fow_png(model)
        if fow:
            with open(os.path.join(cd, "fow.png"), "wb") as f:
                f.write(fow)
        pd = os.path.join(cd, "paths")
        if vault.unlocked():                              # herd paths are behind the code
            # they only change when the map cache is rebuilt: written again only then (659 files on Map01)
            try:
                with open(os.path.join(cd, "meta.json")) as f:
                    stamp = json.dumps(json.load(f), sort_keys=True) + str(len(model.splines))
            except (OSError, ValueError):
                stamp = ""
            sp = os.path.join(pd, ".stamp")
            try:
                with open(sp) as f:
                    same = stamp != "" and f.read() == stamp
            except OSError:
                same = False
            if not same:
                os.makedirs(pd, exist_ok=True)
                by = {}
                for s in model.splines:
                    if s["terr"]:
                        by.setdefault(s["terr"], []).append(s["pts"])
                for terr, lst in by.items():
                    with open(os.path.join(pd, terr + ".json"), "w") as f:
                        f.write(json.dumps(lst))
                with open(sp, "w") as f:
                    f.write(stamp)
        else:
            import shutil; shutil.rmtree(pd, ignore_errors=True)
        try:                                      # keep the shared icon set current (facility icons were added after the first export)
            import woth2_paks
            mapdata.ensure_icons(woth2_paks.find_paks_dir(st.save))
        except Exception:
            pass
        out = {"dir": cd, "icons": os.path.join(mapdata.CACHE_ROOT, "icons"), "territories": len(mj["territories"]), "zones": mj["zones"], "paths": mj["trails"],
               "warnings": list(mapdata.WARNINGS), "missing": mapdata.cache_missing(cd)}
    elif cmd == "apply":
        body = json.loads(argv[1])
        edits = {k: int(body[k]) for k in ("money", "xp", "skill_points") if body.get(k) is not None}
        bak, values, notes = core.write_values(st.save, edits, unlock_all_skills=bool(body.get("unlock_all_skills")),
                                               reveal_map=body.get("reveal") or [], discover_zones=body.get("discover") or [],
                                               guid_data=st.guid_data, force=bool(body.get("force")), upgrade_hq=bool(body.get("upgrade_hq")),
                                               complete_jobs=body.get("complete_jobs") or [], find_jobs=body.get("find_jobs") or [],
                                               board_jobs=body.get("board_jobs") or [])
        out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "spawn":
        body = json.loads(argv[1])
        bak, notes, aid = core.spawn_rare(st.save, body["map"], body.get("species", ""), body.get("sex", ""), body.get("variant", ""),
                                          body.get("quality", ""), body.get("fitness"), body.get("target", "best"), body.get("animal_id"),
                                          guid_data=st.guid_data, force=bool(body.get("force")), fitness_range=body.get("fitness_range"), age=body.get("age"),
                                          rack=body.get("rack", ""), names=st.names)
        out = {"ok": True, "backup": bak, "notes": notes, "animal_id": aid}
    elif cmd == "rare-herds-status":
        import gamepatch
        out = gamepatch.rare_herds_status(st.save)
    elif cmd == "rare-herds":
        import gamepatch
        body = json.loads(argv[1])
        on = bool(body.get("on"))
        notes = gamepatch.set_rare_herds(on, st.save, force=bool(body.get("force")))
        out = {"ok": True, "notes": notes}
        if body.get("reset"):                           # roll the maps right away: every map builds new herds on load (rare or normal)
            first = None
            for m in ("Map01", "Map02", "Hub"):
                try:
                    bak, n2, _n = core.reset_animals(st.save, m, guid_data=st.guid_data, force=bool(body.get("force")))
                except (ValueError, KeyError):           # a map never played: nothing to roll there yet
                    notes.append(i18n.t("{map}: no animals yet (play it once), skipped").format(map=i18n.t(core.MAP_LABELS.get(m, m)))); continue
                first = first or bak; notes += n2
            out["backup"] = first
            notes.append(i18n.t("load each map in the game once - the new rare herds are rolled on the way in") if on else
                         i18n.t("load each map in the game once - the new normal herds are rolled on the way in"))
    elif cmd == "reset-animals":                         # {"map": Map01 | Map02 | Hub | "all"}
        body = json.loads(argv[1])
        maps = ("Map01", "Map02", "Hub") if body["map"] == "all" else (body["map"],)
        first, notes, n = None, [], 0
        for m in maps:
            try:
                bak, nt, k = core.reset_animals(st.save, m, guid_data=st.guid_data, force=bool(body.get("force")))
            except (ValueError, KeyError):
                if len(maps) == 1: raise
                notes.append(i18n.t("{map}: no animals yet (play it once), skipped").format(map=i18n.t(core.MAP_LABELS.get(m, m)))); continue
            first = first or bak; notes += nt; n += k
        if len(maps) > 1:
            notes.append(i18n.t("load each map in the game once - the new herds are rolled on the way in"))
        out = {"ok": True, "backup": first, "notes": notes, "count": n}
    elif cmd == "complete":
        body = json.loads(argv[1])
        bak, notes, n = core.complete_missions(st.save, body["ids"], force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes, "count": n}
    elif cmd == "repair":
        body = json.loads(argv[1]) if len(argv) > 1 else {}
        bak, notes, fixed = core.repair_trophies(st.save, body.get("maps"), force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes, "fixed": fixed}
    elif cmd == "plan":
        import stands, nrgs
        body = json.loads(argv[1]); m = body["map"]
        model = st.model(m)
        try:
            gear, _mk = stands.read_placed(nrgs.SaveFile(st.save), m)
        except Exception:
            gear = []
        sp = body.get("species") or None
        out = {"spots": stands.plan(model, st.names, species=[sp] if isinstance(sp, str) else sp, per_species=int(body.get("per_species", 1)),
                                    tents=bool(body.get("tents", True)), camp_radius=float(body.get("camp_radius_m", 400)) * 100,
                                    marker_type=body.get("marker_type", "Animal"), markers=bool(body.get("markers", True)),
                                    existing=[(x, y) for c, x, y, z in gear if "Tent" in c], mapname=m)}
        try:
            out["owned"] = stands.owned_gear(nrgs.SaveFile(st.save))      # the dialog says what the inventory holds
        except Exception as e:
            out["owned_error"] = str(e)
    elif cmd == "pickup":                                # {"map", "spots": [{"x","y"}] | "all": true}
        import stands
        body = json.loads(argv[1]); m = body["map"]
        mine = stands.remembered(m)
        want = mine if body.get("all") else [o for o in mine if any(abs(o["x"] - q["x"]) < 100 and abs(o["y"] - q["y"]) < 100 for q in body.get("spots", []))]
        if not want:
            raise ValueError(i18n.t("No Toybox stands to pick up there."))
        bak, notes = core.pickup_stands(st.save, m, want, force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "pickup-everything":                     # {"map": "Map01" | "all"}: every tent / tripod / blind / decoy back into the inventory
        body = json.loads(argv[1])
        maps = list(core.MAP_LABELS) if body.get("map") == "all" else [body["map"]]
        bak, notes = core.pickup_everything(st.save, [m for m in maps if m in ("Map01", "Map02", "Hub")], force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "stands":
        body = json.loads(argv[1])
        bak, notes = core.write_stands(st.save, body["map"], body["spots"], markers=bool(body.get("markers", True)), marker_type=body.get("marker_type", "Animal"), force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "marker":
        body = json.loads(argv[1])
        bak, notes = core.write_marker(st.save, body["map"], body["x"], body["y"], body.get("z", 0), body.get("type", "Default"), force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "mark-wounded":                          # {"map"}: a named star on every shot animal still on the map
        body = json.loads(argv[1])
        bak, notes, n = core.mark_wounded(st.save, body["map"], force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes, "count": n}
    elif cmd == "teleport":
        body = json.loads(argv[1])
        bak, notes = core.teleport_player(st.save, body["map"], body["x"], body["y"], body.get("z", 0), force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "set-markers":
        import stands, nrgs
        body = json.loads(argv[1]); m = body["map"]; want = body["markers"]
        pts = [(round(float(q["x"])), round(float(q["y"])), round(float(q.get("z", 0))), q.get("type", "Default")) for q in want]
        _gear, have = stands.read_placed(nrgs.SaveFile(st.save), m)
        same = len(have) == len(pts) and all(abs(a[0] - b[0]) < 1 and abs(a[1] - b[1]) < 1 and abs(a[2] - b[2]) < 1 and a[3] == b[3]
                                             for a, b in zip([(round(x), round(y), round(z), t) for x, y, z, t in have], pts))
        if same:                                       # only names changed: nothing to write into the save
            stands.save_marker_labels(m, want)
            out = {"ok": True, "notes": [i18n.t("marker names saved (the game shows no names, the Toybox map does)")]}
        else:
            bak, notes = core.write_marker_list(st.save, m, pts, force=bool(body.get("force")))
            try:
                stands.save_marker_labels(m, want)
            except OSError as e:                        # the save is written: report, keep the UNDO entry
                print("marker names:", e, file=sys.stderr)
                notes = list(notes) + [i18n.t("marker names not kept (the names file could not be written)")]
            out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "set-names":
        body = json.loads(argv[1])
        bak, notes = core.write_names(st.save, body.get("hunter"), body.get("dog"), force=bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "max-dog":                               # bonding + the three hunting skills to the top level
        body = json.loads(argv[1]) if len(argv) > 1 and argv[1][:1] == "{" else {}
        bak, notes = core.max_dog(st.save, force=force or bool(body.get("force")))
        out = {"ok": True, "backup": bak, "notes": notes}
    elif cmd == "rename":
        body = json.loads(argv[1]); out = {"ok": True, "path": core.rename_backup(body["file"], body["name"]), "backups": server.backups_json(st.save)}
    elif cmd == "delete":
        body = json.loads(argv[1])
        for f in body.get("files") or [body["file"]]: core.delete_backup(f)     # "files": several at once (checkmarks)
        out = {"ok": True, "backups": server.backups_json(st.save)}
    elif cmd == "start-fresh":                           # deletes the save + the original backup (the app asks twice)
        body = json.loads(argv[1]) if len(argv) > 1 else {}
        if body.get("confirm") != "START FRESH":
            raise ValueError(i18n.t("not confirmed"))
        out = {"ok": True, "notes": core.start_fresh(st.save, force=bool(body.get("force")))}
    elif cmd == "export":
        body = json.loads(argv[1])
        if body.get("files"):                             # several backups into one folder
            if not os.path.isdir(body["dest"]): raise ValueError(i18n.t("pick a folder to export into"))
            out = {"ok": True, "paths": [core.export_save(core.ORIGINAL_BACKUP if f == "original" else f, body["dest"]) for f in body["files"]]}
        else:
            src = body.get("file") or st.save
            src = core.ORIGINAL_BACKUP if src == "original" else src
            if not src or not os.path.isfile(src):
                raise ValueError(i18n.t("There is no save in the game to export yet."))
            out = {"ok": True, "path": core.export_save(src, body["dest"])}
    elif cmd == "import":
        body = json.loads(argv[1]); core.import_save(body["file"], st.save, force=bool(body.get("force"))); core.set_loaded_slot(None); out = {"ok": True}
    elif cmd == "saveinfo":
        body = json.loads(argv[1]); out = core.save_info(body["file"])
    elif cmd == "restore":
        f = argv[1]
        f = core.ORIGINAL_BACKUP if f == "original" else f
        if core.game_running() and not force:
            raise RuntimeError(i18n.t("The game is running. Close it first so your edit is not overwritten."))
        if not os.path.isfile(f):
            raise ValueError(i18n.t("That saved copy is gone."))
        import nrgs
        try:
            nrgs.SaveFile(f)                                # check the copy before anything is touched
        except Exception:
            raise ValueError(i18n.t("{file} is not a readable save").format(file=os.path.basename(f)))
        if not st.save:
            raise ValueError(i18n.t("No save folder found. Start the game once so it makes one, then try again."))
        bak = core.make_backup(st.save) if os.path.isfile(st.save) else None     # nothing to keep after START FRESH
        os.makedirs(os.path.dirname(st.save), exist_ok=True)
        core.restore_backup(f, st.save)
        if bak: core.set_label(bak, "Before loading " + ("the original save" if f == core.ORIGINAL_BACKUP else
                       "the copy from " + datetime.datetime.fromtimestamp(core.backup_time(f)).strftime("%b %d %H:%M") if core.AUTO_BACKUP_RE.match(os.path.basename(f))
                       else "\u201c" + os.path.basename(f)[:-5] + "\u201d"))
        # a copy you named becomes the save slot BACK UP NOW writes to; automatic copies and the original do not
        slot_before = core.loaded_slot() or ""              # (UNDO of this load puts the slot back too)
        core.set_loaded_slot(f if f != core.ORIGINAL_BACKUP and not core.AUTO_BACKUP_RE.match(os.path.basename(f)) else None)
        out = {"ok": True, "backup": bak, "slot_before": slot_before, "notes": [i18n.t("restored the original save") if f == core.ORIGINAL_BACKUP else i18n.t("restored {file}").format(file=os.path.basename(f))]}
    elif cmd == "undo":
        bak, e = core.undo_last(st.save)
        # a LOAD undone: the game's save is not that copy any more, so SAVE TO must not write over it (it did:
        # the button still named the copy, and the main save went into it)
        if "slot" in e:
            core.set_loaded_slot(e["slot"] if e["slot"] and os.path.isfile(e["slot"]) else None)
        core.set_label(bak, "Before undo of: " + e.get("what", "an edit"))
        out = {"ok": True, "undone": e, "notes": [i18n.t("undid: {what}").format(what=e.get("what", "edit"))]}
    elif cmd == "backup":
        if not st.save or not os.path.isfile(st.save):
            raise ValueError(i18n.t("There is no save in the game to back up yet."))
        slot = core.loaded_slot()
        if slot:                                          # a named copy is loaded: save back into it (same name)
            out = {"ok": True, "path": core.save_to_slot(st.save, slot), "slot": os.path.basename(slot)[:-5]}
        else:
            out = {"ok": True, "path": core.make_bak(st.save)}  # a .bak next to the save, not a hidden app copy
    elif cmd == "save-as":                               # {"name"}: the game's save as a named copy (the new save slot)
        if not st.save or not os.path.isfile(st.save):
            raise ValueError(i18n.t("There is no save in the game to copy yet."))
        p = core.save_as(st.save, json.loads(argv[1])["name"])
        out = {"ok": True, "path": p, "slot": os.path.basename(p)[:-5]}
    elif cmd == "cleanup":                               # old automatic backups (the Saves page CLEAN UP); {"keep", "dry_run"}
        body = json.loads(argv[1]) if len(argv) > 1 else {}
        gone = core.cleanup_backups(st.save, keep=int(body.get("keep", 20)), dry_run=bool(body.get("dry_run")))
        out = {"ok": True, "count": len(gone), "backups": server.backups_json(st.save)}
    else:
        out = {"error": i18n.t("unknown command {cmd}").format(cmd=cmd)}
    if out.get("ok") and out.get("backup") and cmd in EDIT_LABELS:     # the edit history behind UNDO
        body = json.loads(argv[1]) if len(argv) > 1 and argv[1][:1] == "{" else {}
        what = EDIT_LABELS[cmd]
        if body.get("map"):
            what += " · " + MAP_LABELS.get(body["map"], body["map"])
        try:
            core.log_edit(st.save, what, out.get("notes"), out["backup"], slot=out.get("slot_before"))
        except OSError:
            pass
    json.dump(out, sys.stdout); print()

EDITION = (open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "EDITION")).read().strip()
           if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), "EDITION")) else "hackbox")
LOCKED_CMDS = {"rare-herds", "rare-herds-status", "apply", "spawn", "reset-animals", "complete", "repair", "plan", "stands", "teleport",
               "marker", "set-markers", "mark-wounded", "set-names", "max-dog", "pickup", "pickup-everything"}     # everything that writes the save (backups stay free)
EDIT_LABELS = {"rare-herds": "Rare herds switch + all maps reset", "apply": "Hunter values", "spawn": "Animal edit", "reset-animals": "Reset all animals", "complete": "Completed challenges / missions",
               "repair": "Repaired trophy tags", "stands": "Placed stands & tents", "pickup": "Picked up stands & tents", "pickup-everything": "Picked up all placed gear", "marker": "In-game marker", "markers": "In-game markers", "mark-wounded": "Marked wounded animals", "set-markers": "Edited in-game markers", "teleport": "Moved the hunter", "set-names": "Renamed hunter / dog", "max-dog": "Maxed out the dog",
               "import": "Imported a save", "restore": "Restored a backup"}
MAP_LABELS = {"all": "all maps", "Map01": "New Laurentia", "Map02": "Kilimaya Reserve", "Hub": "Hearth & Hunt Headquarters", "Map03": "Parvata Raj"}

# Errors from reading the save's insides (a layout the Toybox does not know, e.g. after a game update) are not for the
# player: they get one plain line, the raw text goes to stderr and core_errors.log next to the map cache.
LAYOUT_MSG = "This save is laid out in a way the Toybox doesn't know. Nothing was changed."
_RAW = __import__("re").compile(r"CRC|NRGS|section|header|framing|trailing bytes|laid out|layout|length mismatch|unexpected|GUID list|"
                                r"where expected|Property|unpack|buffer|asset table|records not found|herd territories|fstring|offset|struct|codec|decode", __import__("re").I)

def layout_msg():
    """LAYOUT_MSG in the app's language."""
    return i18n.t("This save is laid out in a way the Toybox doesn't know. Nothing was changed.")

def log_error(e):
    import traceback
    raw = "".join(traceback.format_exception(type(e), e, e.__traceback__))
    print(raw, file=sys.stderr)
    try:
        import mapdata
        d = os.path.dirname(mapdata.CACHE_ROOT); os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "core_errors.log"), "a", encoding="utf-8") as f:
            f.write(datetime.datetime.now().isoformat(timespec="seconds") + " " + " ".join(sys.argv[1:2]) + "\n" + raw + "\n")
    except Exception:
        pass

def plain_error(e):
    """The message the app shows for an exception: our own plain sentences pass through, save-layout errors don't."""
    import errno, struct
    msg = str(e)
    if isinstance(e, OSError) and (e.errno is not None or e.filename or getattr(e, "winerror", None)):
        # the system's own text has paths and error numbers ("[Errno 2] No such file...", "[WinError 32] ...")
        if isinstance(e, FileNotFoundError):
            return i18n.t("A file the Toybox needs is not there. If the game has no save yet, start it once so it makes one, then try again.")
        if isinstance(e, PermissionError) or getattr(e, "winerror", None) in (5, 32, 33):
            return i18n.t("A file the Toybox needs is in use or locked. Close the game (and anything else that has the save open), then try again.")
        if e.errno == errno.ENOSPC or getattr(e, "winerror", None) == 112:
            return i18n.t("The disk is full. Free some space, then try again.")
        return i18n.t("A file could not be read or written. Close the game, then try again.")
    if isinstance(e, (struct.error, IndexError, UnicodeDecodeError, KeyError, AttributeError, TypeError, ZeroDivisionError)):
        return layout_msg()
    if isinstance(e, (ValueError, RuntimeError)) and _RAW.search(msg):
        return layout_msg()
    return msg

if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception as e:
        log_error(e)
        json.dump({"error": plain_error(e)}, sys.stdout); print(); sys.exit(1)
