"""The game's Lands and Domains (the named regions of a map: "Thunderbird Muskeg", "Kaggen Karoo" ...) read
from LA_Infrastructure_<Map> (BP_LandInfrastructureArea_DataAsset).

Layout of that asset's one export (unversioned properties):
  area table  : TMap<u8 key, struct{..., gameplay tag LevelAreas.<Map>.Lands.<Land>[.DomainNN], FColor, ...}>
  bounds      : FBox2D as 4 doubles (min x, min y, max x, max y) in cm
  grid        : u8 valid, i32 count, then `count` run-length structs {u8 area, i32 run, bool last}
                over ONE 1024 x 1024 picture of the map. The runs walk the picture row by row with the
                ROW = world x and the COLUMN = world y (transposed against our textures). Area n is the
                tag at name-table index n + 1 (index 0 = outside every land). Every pixel holds a Domain;
                its Land is the tag's parent.
Checked 2026-10-08: on New Laurentia all 659 herd territories fall in the Land the game's per-land
spawn data (SD_Map01_Land*) puts them in.
-> grid(paks_dir, map) = (box, picture[row=y][col=x] of area index, {area index: tag})."""
import os, re, struct
import numpy as np

MAP_KEYS = {"Map01": "MAP01", "Map02": "MAP02", "Hub": "MAPHUB"}
VERSION = 9       # 3: dotted borders baked into lands.png (drawn by the terrain shader like the roads); 9: + each herd's land
                  #    from the spawn data ("territories")

def _asset(paks_dir, mapname):
    import woth2_paks as paks, zenpkg
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            if re.search(rf"/LA_Infrastructure_{mapname}\.uasset$", path):
                return zenpkg.ZenPackage(t.read(i))
    return None

def grid(paks_dir, mapname):
    z = _asset(paks_dir, mapname)
    if z is None:
        return None
    d = z.export_data[0]
    names = [n[0] if isinstance(n, tuple) else n for n in z.names]
    # the bounds: the first 4 doubles that form a centred square box before the grid
    p = None
    for o in range(0, len(d) - 37):
        x0, y0, x1, y1 = struct.unpack_from("<4d", d, o)
        if x0 < 0 and abs(x0 + x1) < 1 and abs(y0 + y1) < 1 and abs(x1 - y1) < 1 and 1e4 < x1 < 1e7:
            fl, cnt = struct.unpack_from("<BI", d, o + 32)
            if fl == 1 and 0 < cnt < 10 ** 7:
                p = o; break
    if p is None:
        return None
    box = struct.unpack_from("<4d", d, p); q = p + 37
    runs = []
    for _ in range(struct.unpack_from("<I", d, p + 33)[0]):
        q += 2; mask = d[q]; q += 1; idx = ln = 0
        if not mask & 1: idx = d[q]; q += 1
        if not mask & 2: ln, = struct.unpack_from("<i", d, q); q += 4
        if not mask & 4: q += 1
        runs.append((idx, ln))
    total = sum(ln for _, ln in runs)
    n = int(round(total ** 0.5))
    if n * n != total:
        return None
    flat = np.zeros(total, np.uint8); k = 0
    for idx, ln in runs:
        flat[k:k + ln] = idx; k += ln
    pic = flat.reshape(n, n).T.copy()                     # -> row = y, column = x
    areas = {i: names[i + 1] for i in np.unique(pic).tolist() if i and i + 1 < len(names)}
    return box, pic, areas

def land_of(tag):
    """LevelAreas.Map01.Lands.LandPrivate01.Domain02 -> LandPrivate01"""
    m = re.search(r"\.Lands\.(Land\w+?)(?:\.|$)", tag)
    return m.group(1) if m else None

def land_names(tables, mapname):
    """{LandPrivate01: 'Thunderbird Muskeg', ...} from the game's ST_Levels string table."""
    L = tables.get("ST_Levels", {}) if tables else {}
    mk = MAP_KEYS.get(mapname, mapname.upper())
    out = {}
    for k, v in L.items():
        m = re.match(rf"KEY_ENVIRONMENT_{mk}_(LAND(?:PRIVATE|PUBLIC)\d\d)_NAME$", k)
        if m:
            out[_land_key(m.group(1))] = v
    return out

def _land_key(raw):   # LANDPRIVATE01 -> LandPrivate01
    return "Land" + raw[4:-2].capitalize() + raw[-2:]

def summary(paks_dir, mapname, names=None):
    """{"box", "lands": [{"key", "name", "x", "y" (label spot, cm), "km2", "where" (north-east ...)}],
    "land_pic": picture of land numbers (1..) row = y, "land_keys": [key by number]} or None."""
    g = grid(paks_dir, mapname)
    if g is None:
        return None
    box, pic, areas = g
    keys = sorted({land_of(t) for t in areas.values() if land_of(t)})
    num = {k: i + 1 for i, k in enumerate(keys)}
    lut = np.zeros(256, np.uint8)
    for i, t in areas.items():
        if land_of(t): lut[i] = num[land_of(t)]
    lp = lut[pic]
    n = pic.shape[0]; cell = (box[2] - box[0]) / n
    from scipy import ndimage
    out = []
    for k in keys:
        m = lp == num[k]
        if not m.any(): continue
        dist = ndimage.distance_transform_edt(np.pad(m, 1))[1:-1, 1:-1]   # label at the spot deepest inside the land
                                                          # (padded: the map edge counts as its border too)
        r, c = np.unravel_index(int(dist.argmax()), dist.shape)
        x = box[0] + (c + 0.5) * cell; y = box[1] + (r + 0.5) * cell
        out.append({"key": k, "name": (names or {}).get(k, k), "x": int(round(x)), "y": int(round(y)),
                    "km2": round(float(m.sum()) * cell * cell / 1e10, 1), "where": where(x, y, box)})
    return {"box": box, "lands": out, "land_pic": lp, "land_keys": keys, "domain_pic": pic}

_LAND_RE = re.compile(rb"Land(?:Private|Public)\d\d")

def territory_lands(paks_dir, mapname):
    """{territory id: land key} the way the game files them: every herd territory (TerritoryData) is a child of one
    HabitatData in the map's spawn data, and the habitat is named after its land ("LandPublic01Habitat01Domain0203",
    New Laurentia; "LandPrivate03", Kilimaya). A habitat with no name takes the land in its package name
    (SD_Map01_LandPublic01); a map with only one land (the HQ) puts every herd there."""
    import woth2_paks as paks, zenpkg
    out = {}; unnamed = []
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            nm = path.rsplit("/", 1)[-1]
            if not ((nm.startswith(f"SD_{mapname}_") or nm.startswith(f"{mapname}_SpawnData")) and nm.endswith(".uasset")) \
                    or "Signs" in nm or "plines" in nm or "SubAreas" in nm or "_editor" in nm:
                continue
            try:
                z = zenpkg.ZenPackage(t.read(i))
            except Exception:
                continue
            names = [n[0] if isinstance(n, tuple) else n for n in z.names]
            cls = lambda e: names[e[2] & 0xffffffff] if (e[2] & 0xffffffff) < len(names) else ""
            terr = {}
            for k, (e, d) in enumerate(zip(z.exports, z.export_data)):
                if cls(e) == "TerritoryData" and len(d) >= 28:
                    g = len(d) - 20
                    terr[k + 1] = "".join("%08X" % struct.unpack_from("<I", d, g + j)[0] for j in range(0, 16, 4))
            if not terr:
                continue
            pm = _LAND_RE.search(nm.encode())
            for e, d in zip(z.exports, z.export_data):
                if cls(e) != "HabitatData":
                    continue
                kids = None                                   # m_children: the longest array of territory refs
                for q in range(0, len(d) - 7):
                    n, = struct.unpack_from("<I", d, q)
                    if 1 <= n <= 1000 and q + 4 + 4 * n <= len(d) and (kids is None or n > len(kids)):
                        refs = struct.unpack_from("<%di" % n, d, q + 4)
                        if all(r in terr for r in refs):
                            kids = refs
                if not kids:
                    continue
                m = _LAND_RE.search(d) or pm
                land = m.group(0).decode() if m else None
                for r in kids:
                    if land: out[terr[r]] = land
                    else: unnamed.append(terr[r])
    if unnamed:
        g = grid(paks_dir, mapname)
        keys = sorted({land_of(v) for v in g[2].values() if land_of(v)}) if g else []
        if len(keys) == 1:
            for tid in unnamed: out.setdefault(tid, keys[0])
    return out

def herd_lands(paks_dir, mapname, spots):
    """{guid: land key} for herds [(guid, x cm, y cm)]: the land the game files each herd under (territory_lands,
    kept in the map cache's lands.json so it works without the game files too); the land picture under the herd's
    centre only for a herd the spawn data does not list."""
    import json, mapdata
    tl = {}
    try:
        tl = json.load(open(os.path.join(mapdata.cache_dir(mapname), "lands.json"))).get("territories") or {}
    except (OSError, ValueError):
        pass
    if not tl and paks_dir:
        tl = territory_lands(paks_dir, mapname)
    out = {g: tl[g] for g, x, y in spots if g in tl}
    rest = [s for s in spots if s[0] not in out]
    if rest and paks_dir:
        s = summary(paks_dir, mapname)
        if s:
            box, lp, keys = s["box"], s["land_pic"], s["land_keys"]
            n = lp.shape[0]
            for g, x, y in rest:
                c = int((x - box[0]) / (box[2] - box[0]) * n); r = int((y - box[1]) / (box[3] - box[1]) * n)
                if 0 <= r < n and 0 <= c < n and lp[r, c]:
                    out[g] = keys[lp[r, c] - 1]
                elif len(keys) == 1:
                    out[g] = keys[0]
    return out

def where(x, y, box):
    """A rough compass spot on the map for (x, y): 'north-east', 'centre' ... (game maps: -y is north)."""
    u = (x - box[0]) / (box[2] - box[0]); v = (y - box[1]) / (box[3] - box[1])
    ns = "north" if v < 1 / 3 else ("south" if v > 2 / 3 else "")
    ew = "west" if u < 1 / 3 else ("east" if u > 2 / 3 else "")
    return (ns + "-" + ew if ns and ew else ns or ew) or "centre"

def border_png(s, size=2048):
    """RGBA overlay in map-texture space (u = x, v = y): R = land border, G = domain border, A = 255."""
    from PIL import Image
    from scipy import ndimage
    lp, dp = s["land_pic"], s["domain_pic"]
    def edges(a):
        e = np.zeros(a.shape, bool)
        e[:-1, :] |= a[:-1, :] != a[1:, :]; e[1:, :] |= a[:-1, :] != a[1:, :]
        e[:, :-1] |= a[:, :-1] != a[:, 1:]; e[:, 1:] |= a[:, :-1] != a[:, 1:]
        return e
    le = np.zeros(lp.shape, bool)                         # only where two different lands meet, not the map edge
    for a, b in ((lp[:-1, :], lp[1:, :]), (lp[:, :-1], lp[:, 1:])):
        e = (a != b) & (a > 0) & (b > 0)
        if a.shape[0] < lp.shape[0]: le[:-1, :] |= e; le[1:, :] |= e
        else: le[:, :-1] |= e; le[:, 1:] |= e
    de = edges(dp) & ~le & (dp > 0)
    img = np.zeros(lp.shape + (4,), np.uint8)
    img[..., 0] = le * 255; img[..., 1] = de * 255; img[..., 3] = 255
    im = Image.fromarray(img, "RGBA").resize((size, size), Image.BILINEAR)
    return im

def ensure_cache(cache_dir, paks_dir, mapname, names_table=None):
    """lands.png (border overlay) + lands.json (labels) in the map cache, rebuilt on a new game build or VERSION.
    -> [{"key", "name", "x", "y", "km2", "where"}] (empty when the map has no land data)."""
    import json, woth2_paks as paks
    jp = os.path.join(cache_dir, "lands.json"); pp = os.path.join(cache_dir, "lands.png")
    game = paks.game_build(paks_dir) if paks_dir else None
    try:
        j = json.load(open(jp))
        if j.get("version") == VERSION and (game is None or j.get("game") == game) and os.path.exists(pp):
            return j["lands"]
    except (OSError, ValueError):
        pass
    if not paks_dir:                                      # no game: an older cache is refreshed from the pack shipped with the app
        src = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mappack", mapname)
        try:
            j = json.load(open(os.path.join(src, "lands.json")))
            if j.get("version") == VERSION and os.path.exists(os.path.join(src, "lands.png")):
                import shutil
                os.makedirs(cache_dir, exist_ok=True)
                shutil.copyfile(os.path.join(src, "lands.png"), pp); shutil.copyfile(os.path.join(src, "lands.json"), jp)
                return j["lands"]
        except (OSError, ValueError):
            pass
        return []
    mk = MAP_KEYS.get(mapname, mapname.upper())
    names = {_land_key(k[len(f"KEY_ENVIRONMENT_{mk}_"):-5]): v for k, v in (names_table or {}).items()
             if k.startswith(f"KEY_ENVIRONMENT_{mk}_LAND") and k.endswith("_NAME")}
    s = summary(paks_dir, mapname, names)
    if not s:
        return []
    dotted_png(s, border_lines(s)).save(pp)
    with open(jp + ".tmp", "w") as f:
        json.dump({"version": VERSION, "game": game, "lands": s["lands"], "borders": border_lines(s),
                   "territories": territory_lands(paks_dir, mapname)}, f)
    os.replace(jp + ".tmp", jp)
    return s["lands"]

def borders(cache_dir):
    """The cached border polylines (cm) of a map, [] when there are none."""
    import json
    try: return json.load(open(os.path.join(cache_dir, "lands.json"))).get("borders", [])
    except (OSError, ValueError): return []

def border_lines(s, tol_px=0.8):
    """The borders between neighbouring lands as polylines [[x, y], ...] in cm (pixel-corner tracing of the
    land picture, chained, then Douglas-Peucker simplified to ~tol_px pixels)."""
    lp = s["land_pic"]; box = s["box"]; n = lp.shape[0]; cell = (box[2] - box[0]) / n
    # border edges between two different non-zero lands, on the pixel grid corners
    edges = {}
    def add(a, b):
        edges.setdefault(a, []).append(b); edges.setdefault(b, []).append(a)
    h = (lp[:, :-1] != lp[:, 1:]) & (lp[:, :-1] > 0) & (lp[:, 1:] > 0)      # vertical edge at x = c + 1
    for r, c in zip(*np.nonzero(h)):
        add((r, c + 1), (r + 1, c + 1))
    v = (lp[:-1, :] != lp[1:, :]) & (lp[:-1, :] > 0) & (lp[1:, :] > 0)      # horizontal edge at y = r + 1
    for r, c in zip(*np.nonzero(v)):
        add((r + 1, c), (r + 1, c + 1))
    used = set(); lines = []
    def key(a, b): return (a, b) if a < b else (b, a)
    starts = [p for p, nb in edges.items() if len(nb) != 2] + list(edges)
    for p0 in starts:
        for q in edges[p0]:
            if key(p0, q) in used: continue
            line = [p0, q]; used.add(key(p0, q)); cur = q
            while len(edges[cur]) == 2:
                nxt = next((w for w in edges[cur] if key(cur, w) not in used), None)
                if nxt is None: break
                used.add(key(cur, nxt)); line.append(nxt); cur = nxt
            lines.append(line)
    def rdp(pts):
        if len(pts) < 3: return pts
        a = np.array(pts[0], float); b = np.array(pts[-1], float); ab = b - a; L2 = float(ab @ ab)
        P = np.array(pts, float)
        if L2 == 0: d = np.hypot(*(P - a).T)
        else: d = np.abs(ab[0] * (P[:, 1] - a[1]) - ab[1] * (P[:, 0] - a[0])) / L2 ** 0.5
        i = int(d.argmax())
        if d[i] <= tol_px: return [pts[0], pts[-1]]
        return rdp(pts[:i + 1])[:-1] + rdp(pts[i:])
    out = []
    for ln in lines:
        if len(ln) < 2: continue
        pts = rdp(ln)
        out.append([[int(round(box[0] + c * cell)), int(round(box[1] + r * cell))] for r, c in pts])
    return out

DOTS = ((30.0, 5.0), (120.0, 20.0))     # (spacing m, radius m): close-up dots, then the ones seen zoomed out
TEX = 4096
def _dots(s, lines, spacing_m, radius_m):
    box = s["box"]; scale = TEX / (box[2] - box[0])          # px per cm
    step = spacing_m * 100 * scale; R = 2 * radius_m * 100 * scale
    img = np.zeros((TEX, TEX), np.float32)
    k = int(np.ceil(R)) + 1; yy, xx = np.mgrid[-k:k + 1, -k:k + 1]
    for ln in lines:
        pts = [((x - box[0]) * scale, (y - box[1]) * scale) for x, y in ln]
        carry = step * 0.5
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            seg = ((bx - ax) ** 2 + (by - ay) ** 2) ** 0.5
            t = carry
            while t < seg:
                cx = ax + (bx - ax) * t / seg; cy = ay + (by - ay) * t / seg
                ix, iy = int(round(cx)), int(round(cy))
                if k <= ix < TEX - k and k <= iy < TEX - k:
                    d = np.hypot(xx + ix - cx, yy + iy - cy)
                    win = img[iy - k:iy + k + 1, ix - k:ix + k + 1]
                    np.maximum(win, np.clip(1.0 - d / R, 0.0, 1.0), out=win)
                t += step
            carry = t - seg
    return (img * 255).astype(np.uint8)

def dotted_png(s, lines):
    """LA8 texture in map-texture space (u = x, v = y), baked once so the terrain shader draws the land borders for
    free, as dots like the game's own hunting map: L = close-up dots, A = bigger, wider-spaced dots for zoomed-out
    views. Each dot is a soft cone (255 centre, 128 at its radius, 0 at twice that): the shader cuts a crisp round dot
    at 0.5 and its outline below that, at any zoom."""
    from PIL import Image
    return Image.fromarray(np.dstack([_dots(s, lines, *DOTS[0]), _dots(s, lines, *DOTS[1])]), "LA")
