"""Automatic hunting spots: for every species on a map pick its two best herds, find where each herd's
paths and need zones converge, and plan a tripod stand (plus a tent when no camp / fast-travel spot
is near) with the herd's best time. Writes them into the save as placed gear
(`BP_ObjectPlacement_WS_C`) and optional in-game custom markers (`BP_UserMarkerSystem_C`).

Save formats (verified against the user's saves):

* BP_ObjectPlacement_WS_C: u32 1, 01 01 u32 len, 01 u32 len, u32 count, entries
  (01 01 u32 len, FString blueprint path, FString class name, u32 0, FTransform (quat xyzw, xyz cm,
  scale 1 1 1 as doubles), u32 1, metadata blob). Tents / stands use the metadata
  "01 01 39 00 00 00 01 34 00 00 00 FString('/Script/WOTH2.PlacedObjectMetaData') 09 00 00 00 FString('None')".
* BP_UserMarkerSystem_C: u32 1, 01 01 u32 len, 01 u32 len, u32 count, entries
  (u32 1, 01 03 u32 70, 01 u32 24, xyz doubles, 01 u32 36, FString("Gameplay.Markers.Custom.<Type>")).
  Types the game cycles through: Default, Animal, Blood, Fitness, Footprints, Nature, plus Exploration
  (tag "Gameplay.Markers.Exploration", no ".Custom"; the map's marker widget and DT_TagInterpreter_Misc
  list it with the six and give it the T_UI_Marker_Custom_Exploration icon).
  Only custom markers are saved: binocular tracking markers (BP_TrackingMarker / BP_AnimalTrackingMarker /
  BP_AnimalGroupTrackingMarker) have no archive code and never appear in a save, so they cannot be written.
"""
import json, math, os, re, struct

import nrgs
import i18n

MAP_NAMES = {"Map01": "New Laurentia", "Map02": "Kilimaya Reserve", "Hub": "Hearth & Hunt Headquarters", "Map03": "Parvata Raj"}
def map_name(mapname):
    return MAP_NAMES.get(mapname, mapname)

def _map(mapname):
    """map_name for a sentence, in the app's language."""
    return i18n.t(map_name(mapname))

HERE = os.path.dirname(os.path.abspath(__file__))
PLACEMENT_SECTION = nrgs.name_hash("BP_ObjectPlacement_WS_C")
MARKER_SECTION = nrgs.name_hash("BP_UserMarkerSystem_C")
TENT = ("/Game/BASE/Gear/Equipment/Tent01/BP_Tent01_World", "BP_Tent01_World_C")
TRIPOD = ("/Game/BASE/Gear/Equipment/TripodStand01/BP_TripodStand01_World", "BP_TripodStand01_World_C")
GEAR_META = (b"\x01\x01\x39\x00\x00\x00\x01\x34\x00\x00\x00" + nrgs.fstring("/Script/WOTH2.PlacedObjectMetaData") + struct.pack("<I", 9) + nrgs.fstring("None"))
MARKER_TYPES = ["Default", "Animal", "Blood", "Fitness", "Footprints", "Nature", "Exploration"]
MARKER_NAMES = {"Default": "Pin", "Animal": "Paw", "Blood": "Heart", "Fitness": "Star", "Footprints": "Crown", "Nature": "Trophy",
                "Exploration": "Outline pin"}          # what the app calls them: the icon each one shows on the game's map

def marker_tag(mtype):
    return "Gameplay.Markers.Exploration" if mtype == "Exploration" else "Gameplay.Markers.Custom." + mtype
TYPE_LABEL = {"Eating": "feeding", "Watering": "drinking", "Resting": "resting", "Unknown": "unknown"}
STAND_OFFSET_CM = 4500          # tripod 45 m from the zone centre
TENT_OFFSET_CM = 9000           # tent 90 m behind the stand
CAMP_RADIUS_CM = 40000          # no tent when a camp / fast-travel spot is within 400 m
MAX_MARKERS = 16                # BP_UserMarkerSystem default m_maximumSingleplayerMarkerCount

# ---------------------------------------------------------------- opportunities
def opportunities(mapname, sf=None):
    """[{tag, kind, name, desc, land, species, x, y, z, done}] habitat enhancements, damaged bridges, blocked roads,
    pollution and hunting stand / watchtower spots from opportunities.json (opportunities_scan.py); done = the save's
    BP_Opportunity_WS_<map>_C list of fulfilled tags (the game's own pre-built ones are in it too)."""
    try:
        with open(os.path.join(HERE, "opportunities.json"), encoding="utf-8") as f:
            lst = json.load(f).get(mapname, [])
    except (OSError, ValueError):
        return []
    done = set()
    if sf is not None:
        try:
            secs = nrgs.split_sections(sf.part(f"Game_0/WorldShared/{mapname}").data)[1]
            h = nrgs.name_hash(f"BP_Opportunity_WS_{mapname}_C")
            for hh, _v, b in secs:
                if hh == h:
                    done = {t.decode() for t in re.findall(rb"Facility\.Opportunity\.[A-Za-z]+\.\d+", b)}
        except Exception:
            pass
    if i18n.lang():                                       # the job's text in the app's language (the game's own words when it is here)
        lst = [dict(o, desc=game_line(o["desc"])) if o.get("desc") else o for o in lst]
    return [dict(o, done=o["tag"] in done) for o in lst]

_GAME_LINES = {}
def game_line(en):
    """A game text (English, as opportunities.json keeps it) in the app's language: the game's own translation
    when the game files are here, else the app's catalog."""
    if "lines" not in _GAME_LINES:
        try:
            import woth2_paks
            _GAME_LINES["lines"] = woth2_paks.game_lines(["ProductsRelease"], i18n.lang())
        except Exception:
            _GAME_LINES["lines"] = {}
    return _GAME_LINES["lines"].get(en) or i18n.t(en)

OPP_HEAD = b"\x01\x00\x00\x00\x01\x02"

def parse_opp_done(blob):
    """Tags in a BP_Opportunity_WS_<map>_C section: 01000000 0102 u32 len 01 u32 len u32 count, then per done job
    a tagged FGameplayTag struct (TagName NameProperty FString, "None")."""
    if not blob.startswith(OPP_HEAD):
        raise ValueError("This save's habitat jobs are laid out in a way the Toybox doesn't know. Nothing was changed.")
    n = struct.unpack_from("<I", blob, 15)[0]
    tags = [t.decode() for t in re.findall(rb"Facility\.Opportunity\.[A-Za-z]+\.\d+", blob)]
    if len(tags) != n or build_opp_done(tags) != blob:
        raise ValueError("This save's habitat jobs are laid out in a way the Toybox doesn't know. Nothing was changed.")
    return tags

def build_opp_done(tags):
    body = b""
    for t in tags:
        v = t.encode() + b"\x00"
        body += (b"\x08\x00\x00\x00TagName\x00\x0d\x00\x00\x00NameProperty\x00\x00\x00\x00\x00" + struct.pack("<I", 4 + len(v)) + b"\x00"
                 + struct.pack("<I", len(v)) + v + b"\x05\x00\x00\x00None\x00")
    inner = struct.pack("<I", len(tags)) + body
    return OPP_HEAD + struct.pack("<I", 1 + 4 + len(inner)) + b"\x01" + struct.pack("<I", len(inner)) + inner

# ---------------------------------------------------------------- facilities
def facilities(mapname):
    """[(x, y, kind, label)] campsites / lodge / cabins / stations / hunting stands / shooting ranges / parking
    spots from facilities.json (facilities_scan.py: actor positions from the game's streamed cells)."""
    try:
        with open(os.path.join(HERE, "facilities.json")) as f:
            lst = json.load(f).get(mapname, [])
    except (OSError, ValueError):
        return []
    lst = [a for a in lst if a.get("x") is not None]
    # the game draws one icon per facility (with a P for its parking); keep parking spots only where they
    # stand alone, more than 80 m from any building
    bld = [a for a in lst if a["kind"] in ("camp", "lodge", "cabin", "station", "range")]
    out = []
    for a in lst:
        if a["kind"] == "parking" and any((b["x"] - a["x"]) ** 2 + (b["y"] - a["y"]) ** 2 < 8000 ** 2 for b in bld):
            continue
        out.append((a["x"], a["y"], a["kind"], a.get("label") or a["name"]))
    return out

# ---------------------------------------------------------------- planning
def _hh(x):
    x = x % 24
    return "%02d:%02d" % (int(x), int(round((x - int(x)) * 60)))

# ---------------------------------------------------------------- save writing


def _wrap(count, entries):
    inner = struct.pack("<I", count) + entries
    return struct.pack("<I", 1) + b"\x01\x01" + struct.pack("<I", len(inner) + 5) + b"\x01" + struct.pack("<I", len(inner)) + inner

class Placement:
    """The BP_ObjectPlacement_WS_C section: existing entries kept byte for byte, new ones appended."""
    def __init__(self, blob=None):
        self.entries = []
        if blob and len(blob) >= 19:
            v0, t1, t2, l1, t3, l2, cnt = struct.unpack_from("<IBBIBII", blob, 0)
            if (v0, t1, t2, t3) != (1, 1, 1, 1) or l1 != len(blob) - 10 or l2 != len(blob) - 15:
                raise ValueError("placement section: unexpected framing")
            p = 19
            for _ in range(cnt):
                a, b, ln = struct.unpack_from("<BBI", blob, p)
                if (a, b) != (1, 1):
                    raise ValueError("placement section: bad entry")
                self.entries.append(bytes(blob[p:p + 6 + ln])); p += 6 + ln
            if p != len(blob):
                raise ValueError("placement section: trailing bytes")

    def positions(self):
        out = []
        for e in self.entries:
            q = 6; path, q = nrgs.read_fstring(e, q); cls, q = nrgs.read_fstring(e, q); q += 4 + 32
            x, y, z = struct.unpack_from("<3d", e, q)
            out.append((cls, x, y, z))
        return out


    def build(self):
        return _wrap(len(self.entries), b"".join(self.entries))

class Markers:
    """The BP_UserMarkerSystem_C section."""
    def __init__(self, blob=None):
        self.entries = []
        if blob and len(blob) >= 19:
            v0, t1, t2, l1, t3, l2, cnt = struct.unpack_from("<IBBIBII", blob, 0)
            if (v0, t1, t2, t3) != (1, 1, 1, 1) or l1 != len(blob) - 10 or l2 != len(blob) - 15:
                raise ValueError("marker section: unexpected framing")
            p = 19
            for _ in range(cnt):
                one, a, b, ln = struct.unpack_from("<IBBI", blob, p)
                if (a, b) != (1, 3):
                    raise ValueError("marker section: bad entry")
                self.entries.append(bytes(blob[p:p + 10 + ln])); p += 10 + ln
            if p != len(blob):
                raise ValueError("marker section: trailing bytes")

    def positions(self):
        out = []
        for e in self.entries:
            x, y, z = struct.unpack_from("<3d", e, 15)
            tag, _ = nrgs.read_fstring(e, 44)
            out.append((x, y, z, tag.split(".")[-1]))
        return out

    def add(self, x, y, z, mtype="Default"):
        tag = nrgs.fstring(marker_tag(mtype))
        body = b"\x01" + struct.pack("<I", 24) + struct.pack("<3d", x, y, z) + b"\x01" + struct.pack("<I", len(tag)) + tag
        self.entries.append(struct.pack("<I", 1) + b"\x01\x03" + struct.pack("<I", len(body)) + body)

    def build(self):
        return _wrap(len(self.entries), b"".join(self.entries))

def _sections(sf, mapname):
    part = sf.part(f"Game_0/World_0/{mapname}")
    seed, secs = nrgs.split_sections(part.data)[:2]
    return part, seed, secs

def read_placed(sf, mapname):
    """-> (gear [(class, x, y, z)], markers [(x, y, z, type)])"""
    part, seed, secs = _sections(sf, mapname)
    d = {h: b for h, v, b in secs}
    gear = Placement(d.get(PLACEMENT_SECTION)).positions() if PLACEMENT_SECTION in d else []
    mk = Markers(d.get(MARKER_SECTION)).positions() if MARKER_SECTION in d else []
    return gear, mk



def stands_dir():
    """The app's own notes on markers / stands: next to the backups (the project folder in a checkout, the user's
    data folder in a release - never inside the app folder, which an update replaces)."""
    import trainer_core
    return os.path.join(os.path.dirname(trainer_core.BACKUP_DIR), "stands")

# ---------------------------------------------------------------- the hunter's inventory (GameData)
# One section lists every owned item: u32 1, 01 01 <u32 len to end>, 02 <u32 len to end>, u32 count, then per item
# GUID, 01 02 <u32 len>, GUID, u32 0, "ItemDefinition", "DA_Item_<thing>", 00 00 00 00 01 00 00. A tent or tripod is
# one item each. After the list comes what is packed where (backpack slots), by item GUID.
INVENTORY_SECTION = 0xf8cb0e95
TENT_ITEM, TRIPOD_ITEM = "DA_Item_Tent01", "DA_Item_TripodStand01"

def _inventory(sf):
    """-> (seed, secs, index of the inventory section, [(offset, length, item name, guid)], end of the item list)"""
    seed, secs = nrgs.split_sections(sf.part("Game_0/GameData").data)
    k = next((i for i, (h, v, b) in enumerate(secs) if h == INVENTORY_SECTION), None)
    if k is None:
        raise ValueError(i18n.t("no inventory in this save yet (play a little first)"))
    b = secs[k][2]
    if b[:4] != b"\x01\x00\x00\x00" or b[4:6] != b"\x01\x01" or b[10] != 2 \
            or struct.unpack_from("<I", b, 6)[0] != len(b) - 10 or struct.unpack_from("<I", b, 11)[0] != len(b) - 15:
        raise ValueError("This save's inventory is laid out in a way the Toybox doesn't know. Nothing was changed.")
    n = struct.unpack_from("<I", b, 15)[0]; p = 19; items = []
    for _ in range(n):
        g = b[p:p + 16]
        if b[p + 16:p + 18] != b"\x01\x02" or b[p + 22:p + 38] != g:
            raise ValueError("This save's inventory is laid out in a way the Toybox doesn't know. Nothing was changed.")
        ln = struct.unpack_from("<I", b, p + 18)[0]
        name, _q = nrgs.read_fstring(b, p + 42 + 19) if b[p + 42:p + 61] == b"\x0f\x00\x00\x00ItemDefinition\x00" else ("?", 0)
        items.append((p, 22 + ln, name, g)); p += 22 + ln
    return seed, secs, k, items, p

def owned_gear(sf):
    """{"tents": n, "tripods": n} in the inventory (gear standing out on a map is not in it)."""
    _s, _x, _k, items, _e = _inventory(sf)
    names = [it[2] for it in items]
    return {"tents": names.count(TENT_ITEM), "tripods": names.count(TRIPOD_ITEM)}

def plans_file(mapname):
    return os.path.join(stands_dir(), f"{mapname}.json")


def labels_file(mapname):
    return os.path.join(stands_dir(), f"{mapname}_labels.json")

def marker_labels(mapname):
    """[{"x", "y", "label"}] the app's own names for in-game markers (the game stores no text)."""
    try:
        with open(labels_file(mapname)) as f:
            return [q for q in json.load(f) if q.get("label")]
    except (OSError, ValueError):
        return []

def label_for(labels, x, y):
    """The label of the marker at (x, y) cm: the nearest one within 2 m."""
    best, bd = "", 200.0 ** 2
    for q in labels:
        d = (q["x"] - x) ** 2 + (q["y"] - y) ** 2
        if d <= bd:
            best, bd = q["label"], d
    return best

def save_marker_labels(mapname, markers):
    """markers: [{"x", "y", "label"}] -> keep the non-empty labels."""
    os.makedirs(stands_dir(), exist_ok=True)
    keep = [{"x": round(float(q["x"])), "y": round(float(q["y"])), "label": str(q["label"]).strip()[:60]} for q in markers if str(q.get("label") or "").strip()]
    tmp = labels_file(mapname) + ".tmp"
    with open(tmp, "w") as f:
        json.dump(keep, f, indent=1)
    os.replace(tmp, labels_file(mapname))

def picked_file(mapname):
    """Stands the Toybox placed and later picked up (or lost from the list): kept so that after an UNDO / LOAD that
    brings them back into the save, the map still knows them as Toybox stands and PICK UP still works."""
    return os.path.join(stands_dir(), f"{mapname}_picked.json")

def _read_list(fn):
    try:
        with open(fn) as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except (OSError, ValueError):
        return []

def remembered(mapname):
    """Every stand the Toybox has placed on this map: the current list plus the picked-up ones (newest first, one per
    spot). The list is per map, not per save, so callers keep only the ones whose tripod is in the save they read."""
    live = _read_list(plans_file(mapname))
    out = list(live)
    for o in _read_list(picked_file(mapname)):
        if not any(abs(o["x"] - q["x"]) < 100 and abs(o["y"] - q["y"]) < 100 for q in out):
            out.append(o)
    return out


# ---------------------------------------------------------------- in-game markers (free: no code needed)
def add_marker(sf, mapname, x, y, z, mtype, notes):
    part, seed, secs = _sections(sf, mapname)
    idx = {h: i for i, (h, v, b) in enumerate(secs)}
    if MARKER_SECTION not in idx:
        raise ValueError(i18n.t("{map}: the save has no markers for this map yet. Visit it in the game once, save, then try again.").format(map=_map(mapname)))
    mk = Markers(secs[idx[MARKER_SECTION]][2])
    if len(mk.entries) >= MAX_MARKERS:
        raise ValueError(i18n.t("the game allows {max} custom markers per map and this map already has {n}; remove some in the game first").format(max=MAX_MARKERS, n=len(mk.entries)))
    mk.add(x, y, z, mtype)
    h, v, _ = secs[idx[MARKER_SECTION]]; secs[idx[MARKER_SECTION]] = (h, v, mk.build())
    part.data = nrgs.build_sections(seed, secs)
    n = len(mk.entries)
    notes.append((i18n.t("{map}: {type} marker added at ({x}, {y}) m ({n} marker on this map now, the game allows {max})") if n == 1 else
                  i18n.t("{map}: {type} marker added at ({x}, {y}) m ({n} markers on this map now, the game allows {max})")).format(
        map=_map(mapname), type=i18n.t(MARKER_NAMES.get(mtype, mtype)).lower(), x=f"{x / 100:.0f}", y=f"{y / 100:.0f}", n=n, max=MAX_MARKERS))

def set_markers(sf, mapname, points, notes):
    """Make the map's custom markers exactly `points` [(x, y, z, type)] cm: add, move, retype, delete.
    Markers that stay as they were keep their original bytes."""
    part, seed, secs = _sections(sf, mapname)
    idx = {h: i for i, (h, v, b) in enumerate(secs)}
    if MARKER_SECTION not in idx:
        raise ValueError(i18n.t("{map}: the save has no markers for this map yet. Visit it in the game once, save, then try again.").format(map=_map(mapname)))
    if len(points) > MAX_MARKERS:
        raise ValueError(i18n.t("the game allows {max} custom markers per map, not {n}").format(max=MAX_MARKERS, n=len(points)))
    old = Markers(secs[idx[MARKER_SECTION]][2])
    was = list(zip(old.positions(), old.entries))
    new = Markers()
    for x, y, z, t in points:
        if t not in MARKER_TYPES:
            raise ValueError(i18n.t("unknown marker type {type}").format(type=t))
        keep = next((i for i, ((ox, oy, oz, ot), e) in enumerate(was) if ot == t and abs(ox - x) < 1 and abs(oy - y) < 1 and abs(oz - z) < 1), None)
        if keep is not None:
            new.entries.append(was.pop(keep)[1])
        else:
            new.add(float(x), float(y), float(z), t)
    h, v, _ = secs[idx[MARKER_SECTION]]; secs[idx[MARKER_SECTION]] = (h, v, new.build())
    part.data = nrgs.build_sections(seed, secs)
    notes.append(i18n.t("{map}: {n} of {max} in-game markers").format(map=_map(mapname), n=len(new.entries), max=MAX_MARKERS))


# ---------------------------------------------------------------- locked part
_LOCKED = ('herd_score', 'zone_convergence', 'pick_spot', 'ground_z', 'plan', '_quat_yaw', '_gear_entry', 'apply_plan', 'remember',
           'take_gear', 'give_gear', 'new_item_record', 'pickup', 'pickup_everything', 'forget', 'GEAR_ITEMS')

def __getattr__(name):
    """The save-writing functions live in toybox_locked (encrypted in the released app, see vault.py)."""
    if name in _LOCKED:
        import vault
        return getattr(vault.locked("locked_stands"), name)
    raise AttributeError(name)
