"""Read and rebuild a cooked (zen / IoStore) package of this game build (UE 5.7, unversioned, no bulk data).

Layout (all offsets in the 60-byte summary are from the start of the package):
  0  u32 has versioning info (0 here), 4 u32 header size, 8 FMappedName package name, 16 u32 package flags,
  20 u32 cooked header size, 24 imported public export hashes, 28 import map, 32 export map,
  36 export bundle entries, 40 dependency bundle headers, 44 dependency bundle entries, 48 imported package names,
  52 cell import map, 56 cell export map (both empty, = the export bundle offset)
  60 name map (name batch: u32 count, u32 string bytes, u64 hash version, u64 hashes, u16 BE headers, strings),
     padded to 8, then 16 bytes (empty bulk data map)
  imported public export hashes u64[], import map u64[] (FPackageObjectIndex: 0x8.. = package import with
  imported package index << 32 | hash index), export map 72-byte entries, bundle entries (u32 export, u32 cmd),
  dependency headers (i32 first entry, u32 counts[2][2]), dependency entries (i32 FPackageIndex),
  imported package names (name batch + u32 number each) = end of header.
After the header: the export data (export serial offsets are relative to the header end), then the u32 file tag.
The imported package ids themselves live in the container header's store entry for the package, in the same order
as the imported package names (sorted by id).
"""
import struct

class ZenPackage:
    def __init__(self, data):
        self.raw = data
        hasver, self.hsize = struct.unpack_from("<II", data, 0)
        if hasver:
            raise ValueError("versioned package not supported")
        self.name_index, self.flags, self.cooked_hsize = struct.unpack_from("<QII", data, 8)
        o = struct.unpack_from("<9i", data, 24)
        impH, imp, exp, bun, dh, de, ipn, cimp, cexp = o
        if not (cimp == cexp == bun):
            raise ValueError("package has verse cells")
        self.names, p = _read_batch(data, 60)
        p8 = (p + 7) // 8 * 8
        self.bulk_blob = data[p8:impH]                 # i64 size + bulk data map entries (kept as they are)
        self.imported_hashes = list(struct.unpack_from("<%dQ" % ((imp - impH) // 8), data, impH))
        self.imports = list(struct.unpack_from("<%dQ" % ((exp - imp) // 8), data, imp))
        self.exports = [list(struct.unpack_from("<QQQQQQQQII", data, x)) for x in range(exp, bun, 72)]
        self.bundles = [struct.unpack_from("<II", data, x) for x in range(bun, dh, 8)]
        self.dep_headers = [list(struct.unpack_from("<iIIII", data, x)) for x in range(dh, de, 20)]
        self.dep_entries = list(struct.unpack_from("<%di" % ((ipn - de) // 4), data, de))
        self.package_names, q = _read_batch(data, ipn)
        self.package_numbers = list(struct.unpack_from("<%dI" % len(self.package_names), data, q))
        if q + 4 * len(self.package_names) != self.hsize:
            raise ValueError("unexpected package header layout")
        end = max((e[0] + e[1] for e in self.exports), default=0)
        self.export_data = [data[self.hsize + e[0]:self.hsize + e[0] + e[1]] for e in self.exports]
        self.trailer = data[self.hsize + end:]

    def name(self, i):
        return self.names[i][0]

    def build(self):
        names = _write_batch(self.names)
        p = 60 + len(names)
        pad = (-p) % 8
        head = names + (bytes([pad]) + b"\0" * (pad - 1) if pad else b"") + self.bulk_blob   # the cooker writes the pad length
        p = 60 + len(head)
        impH = p; p += 8 * len(self.imported_hashes)
        imp = p; p += 8 * len(self.imports)
        exp = p; p += 72 * len(self.exports)
        bun = p; p += 8 * len(self.bundles)
        dh = p; p += 20 * len(self.dep_headers)
        de = p; p += 4 * len(self.dep_entries)
        ipn = p
        pk = _write_batch(self.package_names) + struct.pack("<%dI" % len(self.package_numbers), *self.package_numbers)
        hsize = ipn + len(pk)
        body, off = b"", 0
        exports = []
        for e, d in zip(self.exports, self.export_data):
            e = list(e); e[0], e[1] = off, len(d)
            exports.append(e); body += d; off += len(d)
        out = struct.pack("<IIQII9i", 0, hsize, self.name_index, self.flags, self.cooked_hsize,
                          impH, imp, exp, bun, dh, de, ipn, bun, bun)
        out += head
        out += struct.pack("<%dQ" % len(self.imported_hashes), *self.imported_hashes)
        out += struct.pack("<%dQ" % len(self.imports), *self.imports)
        out += b"".join(struct.pack("<QQQQQQQQII", *e) for e in exports)
        out += b"".join(struct.pack("<II", *x) for x in self.bundles)
        out += b"".join(struct.pack("<iIIII", *x) for x in self.dep_headers)
        out += struct.pack("<%di" % len(self.dep_entries), *self.dep_entries)
        out += pk
        assert len(out) == hsize
        return out + body + self.trailer

def split_import(v):
    """-> (imported package index, imported public export hash index) or None (script import / null)"""
    if v >> 62 != 2:
        return None
    return (v >> 32) & 0x3FFFFFFF, v & 0xFFFFFFFF

def _read_batch(b, p):
    if struct.unpack_from("<I", b, p)[0] == 0:            # an empty batch is just its count
        return [], p + 4
    cnt, nbytes, _hv = struct.unpack_from("<IIQ", b, p)
    p0 = p
    p += 16
    hashes = struct.unpack_from("<%dQ" % cnt, b, p); p += 8 * cnt
    hdrs = [struct.unpack_from(">H", b, p + 2 * i)[0] for i in range(cnt)]; p += 2 * cnt
    out = []
    for h, hd in zip(hashes, hdrs):
        ln = hd & 0x7FFF
        if hd & 0x8000:
            out.append((b[p:p + 2 * ln].decode("utf-16-le"), h, True)); p += 2 * ln
        else:
            out.append((b[p:p + ln].decode("latin-1"), h, False)); p += ln
    if p - p0 - 16 - 10 * cnt != nbytes:
        raise ValueError("name batch size mismatch")
    return [(s, h) if not wide else (s, h, True) for s, h, wide in out], p

def _write_batch(names):
    if not names:
        return struct.pack("<I", 0)
    strs, hdrs = b"", b""
    for n in names:
        s, wide = n[0], len(n) > 2 and n[2]
        if wide:
            strs += s.encode("utf-16-le"); hdrs += struct.pack(">H", 0x8000 | len(s))
        else:
            strs += s.encode("latin-1"); hdrs += struct.pack(">H", len(s))
    hashes = b"".join(struct.pack("<Q", n[1]) for n in names)
    return struct.pack("<IIQ", len(names), len(strs), 0xC1640000) + hashes + hdrs + strs

# ---------------------------------------------------------------- container header (EIoContainerHeaderVersion 5)
    a = ((u ^ v) * mul) & _M; a ^= a >> 47
    b = ((v ^ a) * mul) & _M; b ^= b >> 47
    return (b * mul) & _M

def _len0to16(s):
    n = len(s)
    if n >= 8:
        mul = (_K2 + n * 2) & _M
        a = (_f64(s, 0) + _K2) & _M
        b = _f64(s, n - 8)
        c = (_rot(b, 37) * mul + a) & _M
        d = ((_rot(a, 25) + b) * mul) & _M
        return _h16(c, d, mul)
    if n >= 4:
        mul = (_K2 + n * 2) & _M
        a = _f32(s, 0)
        return _h16((n + (a << 3)) & _M, _f32(s, n - 4), mul)
    if n > 0:
        a, b, c = s[0], s[n >> 1], s[n - 1]
        y = a + (b << 8); z = n + (c << 2)
        return (_smix(((y * _K2) ^ (z * _K0)) & _M) * _K2) & _M
    return _K2

def _len17to32(s):
    n = len(s); mul = (_K2 + n * 2) & _M
    a = (_f64(s, 0) * _K1) & _M; b = _f64(s, 8)
    c = (_f64(s, n - 8) * mul) & _M; d = (_f64(s, n - 16) * _K2) & _M
    return _h16((_rot((a + b) & _M, 43) + _rot(c, 30) + d) & _M, (a + _rot((b + _K2) & _M, 18) + c) & _M, mul)

def _weak(w, x, y, z, a, b):
    a = (a + w) & _M
    b = _rot((b + a + z) & _M, 21)
    c = a
    a = (a + x + y) & _M
    b = (b + _rot(a, 44)) & _M
    return (a + z) & _M, (b + c) & _M

def _weak_s(s, i, a, b):
    return _weak(_f64(s, i), _f64(s, i + 8), _f64(s, i + 16), _f64(s, i + 24), a, b)

def _len33to64(s):
    n = len(s); mul = (_K2 + n * 2) & _M
    a = (_f64(s, 0) * _K2) & _M; b = _f64(s, 8); c = _f64(s, n - 24); d = _f64(s, n - 32)
    e = (_f64(s, 16) * _K2) & _M; f = (_f64(s, 24) * 9) & _M; g = _f64(s, n - 8); h = (_f64(s, n - 16) * mul) & _M
    u = (_rot((a + g) & _M, 43) + (_rot(b, 30) + c) * 9) & _M
    v = (((a + g) ^ d) + f + 1) & _M
    w = ((((u + v) * mul) & _M) >> 0)
    w = int.from_bytes(((u + v) * mul & _M).to_bytes(8, "little")[::-1], "little") + h & _M
    x = (_rot((e + f) & _M, 42) + c) & _M
    y = (int.from_bytes((((v + w) * mul) & _M).to_bytes(8, "little")[::-1], "little") + g) * mul & _M
    z = (e + f + c) & _M
    a = (int.from_bytes((((x + z) * mul + y) & _M).to_bytes(8, "little")[::-1], "little") + b) & _M
    b = (_smix((z + a) * mul + d + h & _M) * mul) & _M
    return (b + x) & _M

def city_hash64(s):
    n = len(s)
    if n <= 32:
        return _len0to16(s) if n <= 16 else _len17to32(s)
    if n <= 64:
        return _len33to64(s)
    x = _f64(s, n - 40)
    y = (_f64(s, n - 16) + _f64(s, n - 56)) & _M
    z = _h16((_f64(s, n - 48) + n) & _M, _f64(s, n - 24))
    v = _weak_s(s, n - 64, n, z)
    w = _weak_s(s, n - 32, (y + _K1) & _M, x)
    x = (x * _K1 + _f64(s, 0)) & _M
    n2 = (n - 1) & ~63
    i = 0
    while True:
        x = (_rot((x + y + v[0] + _f64(s, i + 8)) & _M, 37) * _K1) & _M
        y = (_rot((y + v[1] + _f64(s, i + 48)) & _M, 42) * _K1) & _M
        x ^= w[1]
        y = (y + v[0] + _f64(s, i + 40)) & _M
        z = (_rot((z + w[0]) & _M, 33) * _K1) & _M
        v = _weak_s(s, i, (v[1] * _K1) & _M, (x + w[0]) & _M)
        w = _weak_s(s, i + 32, (z + w[1]) & _M, (y + _f64(s, i + 16)) & _M)
        z, x = x, z
        i += 64; n2 -= 64
        if n2 == 0:
            break
    return _h16((_h16(v[0], w[0]) + _smix(y) * _K1 + z) & _M, (_h16(v[1], w[1]) + x) & _M)

def name_hash(s):
    """Name-batch hash (hash version 0xC1640000) of an FName string."""
    return city_hash64(s.lower().encode("latin-1"))
