"""Read-only statistics from the save: the hunting log (one record per harvested animal) and
the Statistics subsystem (hours each piece of gear was in hand, per map; vehicle distance).

Hunting-log record (section BP_HuntingLog_GS_C of Game_0/GameData, each framed as
``u32 1 | 01 01 | u32 len``):
  u8 2 | u32 len | u32 harvest# | u32 ? | f32 rating(0..1) | u8 | f32 weight kg | u8 | u32 | u32 hash
  FString "AnimalConfigDataAsset" | FString DA_AnimalConfig_<Subspecies>_<M|F>[_Variant]
  FString "BP_AnimalSubspecies_DataAsset_C" | FString DA_AnimalSubspecies_<Subspecies>
  16-byte animal GUID | 8 bytes
  FString "ItemDefinition" | FString DA_Item_<weapon> | FString "ItemDefinition" | FString DA_Item_<ammo>
  f32 shot distance cm | f32 ? | FString weather tag
  u32 | u32 | u64 game clock at the animal's death = harvest screen TIME OF DEATH (same as GameTimeSubsystem: 1/100000 s, 8.64e9 per day) | u32 ?
  FString map ("Map01" / "Map02" / "Hub") | u32 0 | FString hunter name | u32 1 | i64 FDateTime ticks | u32
  [older records: detailed hit list follows]
The record is written when the animal is sold or taxidermied (FDateTime = that moment, your computer's clock).
"""
import collections, datetime, re, struct

HUNTINGLOG_SECTION = 0x49672E80     # BP_HuntingLog_GS_C
STATISTICS_SECTION = 0x4920707C     # Statistics

def _fs(b, p):
    n, = struct.unpack_from("<i", b, p); p += 4
    if n < 0:
        return b[p:p - 2 * n - 2].decode("utf-16-le"), p - 2 * n
    return b[p:p + n - 1].decode("utf-8", "replace"), p + n

class Harvest:
    __slots__ = ("index", "subspecies", "sex", "variant", "rating", "weight", "distance", "weapon", "ammo", "weather", "map", "hunter", "when", "game_day", "game_hour")
    def __init__(self, **kw):
        for k in self.__slots__:
            setattr(self, k, kw.get(k))

def parse_record(r):
    index, = struct.unpack_from("<I", r, 5)
    rating, = struct.unpack_from("<f", r, 13)
    weight, = struct.unpack_from("<f", r, 18)
    p = 31
    _, p = _fs(r, p); cfg, p = _fs(r, p); _, p = _fs(r, p); sub, p = _fs(r, p)
    p += 24
    _, p = _fs(r, p); weapon, p = _fs(r, p); _, p = _fs(r, p); ammo, p = _fs(r, p)
    dist, _e = struct.unpack_from("<ff", r, p); p += 8
    weather, p = _fs(r, p)
    _a, _b, clock, _c = struct.unpack_from("<IIQI", r, p); p += 20
    gday, gsec = divmod(clock, 8640000000); gsec /= 100000.0
    mp, p = _fs(r, p)
    p += 4
    hunter, p = _fs(r, p)
    _one, ticks = struct.unpack_from("<Iq", r, p)
    when = datetime.datetime(1, 1, 1) + datetime.timedelta(microseconds=ticks // 10) if 0 < ticks < 10**19 else None
    subspecies = sub[len("DA_AnimalSubspecies_"):] if sub.startswith("DA_AnimalSubspecies_") else sub
    m = re.search(r"_(M|F)(?:_(\w+))?$", cfg)           # DA_AnimalConfig_<id>_<M|F>[_Variant]
    sex = m.group(1) if m else "?"
    variant = (m.group(2) or "") if m else ""
    return Harvest(index=index, subspecies=subspecies, sex=sex, variant=variant, rating=rating, weight=weight, distance=dist / 100.0,
                   weapon=weapon[len("DA_Item_"):] if weapon.startswith("DA_Item_") else weapon,
                   ammo=ammo[len("DA_Item_"):] if ammo.startswith("DA_Item_") else ammo,
                   weather=weather, map=mp, hunter=hunter, when=when,
                   game_day=gday, game_hour=gsec / 3600.0)

def parse_hunting_log(blob):
    """-> ([Harvest], unparsed_count)"""
    if blob[:6] != b"\x01\x00\x00\x00\x01\x01":
        raise ValueError("unexpected hunting-log header")
    n, = struct.unpack_from("<I", blob, 0x19)
    p = 0x1D
    out, bad = [], 0
    for _ in range(n):
        v, = struct.unpack_from("<I", blob, p)
        f1, f2, ln = struct.unpack_from("<BBI", blob, p + 4)
        if v != 1 or f1 != 1 or f2 != 1:
            raise ValueError("hunting-log record framing broke")
        rec = blob[p + 10:p + 10 + ln]; p += 10 + ln
        try:
            out.append(parse_record(rec))
        except Exception:
            bad += 1
    return out, bad

def parse_statistics(blob):
    """-> {"vehicle_km": float, "levels": {level: {stat tag: {item class: seconds}}}}"""
    out = {"vehicle_km": 0.0, "levels": {}}
    ntot, = struct.unpack_from("<I", blob, 0); p = 4      # 0 in a new game (no vehicle driven yet)
    for _ in range(ntot):
        tag, p = _fs(blob, p)
        val, = struct.unpack_from("<d", blob, p + 1); p += 9
        if tag == "Stats.Vehicle.TotalDistance":
            out["vehicle_km"] = val
    nlev, = struct.unpack_from("<I", blob, p); p += 4
    for _ in range(nlev):
        lev, p = _fs(blob, p)
        nst, = struct.unpack_from("<I", blob, p); p += 4
        d = out["levels"].setdefault(lev, {})
        for _ in range(nst):
            tag, p = _fs(blob, p)
            cnt, = struct.unpack_from("<I", blob, p + 1); p += 5
            items = d.setdefault(tag, {})
            for _ in range(cnt):
                name, p = _fs(blob, p)
                val, = struct.unpack_from("<d", blob, p); p += 8
                items[name] = items.get(name, 0.0) + val
    return out

# ---------------------------------------------------------------- display names
MAP_NAMES = {"Map01": "New Laurentia", "Map02": "Kilimaya Reserve", "Hub": "Hearth & Hunt HQ", "Tutorial01": "Tutorial"}
GEAR_NS = ("WEAPONS", "OPTICS", "ATTACHMENTS", "CALLERS", "DECOYS", "TENTS", "BACKPACKS")

class Names:
    """Pretty names from the game's English string table (woth2_paks.english_names())."""
    def __init__(self, table):
        self.t = table or {}
        self.gear = {}                      # ID (upper) -> name, exact ids first, then variants
        for k, v in self.t.items():
            m = re.match(r"KEY_GEAR_(\w+?)_([A-Z0-9]+)(?:_(\w+?))?_NAME$", k)
            if m and m.group(1) in GEAR_NS:
                base, var = m.group(2), m.group(3)
                self.gear.setdefault(base, {})
                self.gear[base].setdefault(var or "", v)

    def _species_key(self, sid, suffix):
        k = f"KEY_ANIMALS_SUBSPECIES_{sid.upper()}{suffix}"
        if k in self.t:
            return k
        pre = f"KEY_ANIMALS_SUBSPECIES_{sid.upper()}"       # e.g. CrocodylusNiloticus -> ...NILOTICUSNILOTICUS
        return next((x for x in sorted(self.t) if x.startswith(pre) and x.endswith(suffix) and x[len(pre):len(pre) + 1] != "_"), None)

    def subspecies(self, sid):
        k = self._species_key(sid, "_NAME")
        return self.t[k] if k else _split_camel(sid)

    def latin(self, sid):
        k = self._species_key(sid, "_NAME_LATIN")
        return self.t[k] if k else ""

    def gear_name(self, gid):
        """'RifleBolt27_B14StdHMR', 'BP_Proxy_Scope12_1PV_C', 'BP_Firearm_RifleBolt09_Carbon01_C' -> display name."""
        g = re.sub(r"^BP_(Proxy_|Firearm_|Bow_|Crossbow_)?", "", gid)
        g = re.sub(r"_1PV|_C$", "", g)
        parts = g.split("_", 1)
        base, var = parts[0].upper(), (parts[1] if len(parts) > 1 else "")
        names = self.gear.get(base)
        if not names:
            return g.replace("_", " ")
        if var:
            key = var.upper().replace("_", "")
            for k, v in names.items():
                if k and (k == key or k == base + key):
                    return v
        name = names.get("") or next(iter(names.values()))
        if var:
            v = re.sub(r"\d+$", "", var.split("_")[-1])
            flat = re.sub(r"[^a-z0-9]", "", name.lower())
            tokens = [t for t in re.findall(r"[A-Z]+[a-z]*\d*|\d+", v) if t.lower() != "std"]
            if v and not all(t.lower() in flat for t in tokens):
                name += f" ({v})"
        return name

    def caliber(self, aid):
        m = re.match(r"Ammo(?:Bullet|Shell|Arrow|Bolt)(\d+(?:-\d+)?(?:ga|in)?)", aid, re.I)
        if m:
            key = m.group(1).upper()
            v = self.t.get(f"KEY_GEAR_AMMUNITION_CALIBERS_{key}_NAME")
            if v:
                return v
        return aid.replace("_", " ")

    def weather(self, tag):
        short = tag.replace("Weather.Settings.", "").replace("Snowfall.", "Snow.")     # Snowfall.Moderate -> SNOWMODERATE
        return (self.t.get(f"KEY_WEATHERFORECAST_PRESET_{short.replace('.', '').upper()}")
                or self.t.get(f"KEY_WEATHERFORECAST_PRESET_{short.split('.')[0].upper()}")    # Thunderstorm.Severe -> Thunderstorm
                or short.replace(".", " ").lower().capitalize())

    WEATHER_KINDS = ("Clear", "Cloudy", "Fog", "Rain", "Snow", "Thunderstorm")
    def weather_kind(self, tag):
        """The weather family of a tag: Weather.Settings.Snow.Light -> Snow (one of WEATHER_KINDS)."""
        f = tag.replace("Weather.Settings.", "").split(".")[0].lower()
        return {"clear": "Clear", "clouds": "Cloudy", "fog": "Fog", "foggy": "Fog", "rain": "Rain", "snow": "Snow", "snowfall": "Snow",
                "thunderstorm": "Thunderstorm"}.get(f, "Other")

    def map(self, mid):
        return MAP_NAMES.get(mid, mid)

def _split_camel(s):
    return re.sub(r"(?<=[a-z])(?=[A-Z])", " ", s)

# ---------------------------------------------------------------- aggregation
GEAR_CATEGORIES = {   # stat tag suffix -> label
    "Firearm.Rifle": "Rifles", "Firearm.Shotgun": "Shotguns", "Bow": "Bows", "Crossbow": "Crossbows",
    "Binocular": "Binoculars and monoculars", "Attachment.Sight.Optic": "Scopes and sights",
}

def summarize(harvests, statistics, names):
    """Aggregate everything the Stats page shows."""
    s = {"harvests": harvests, "total": len(harvests), "hunters": sorted({h.hunter for h in harvests if h.hunter})}
    s["males"] = sum(1 for h in harvests if h.sex == "M"); s["females"] = sum(1 for h in harvests if h.sex == "F")
    dated = [h for h in harvests if h.when]
    s["first"] = min((h.when for h in dated), default=None); s["last"] = max((h.when for h in dated), default=None)
    s["longest"] = max(harvests, key=lambda h: h.distance, default=None)
    s["heaviest"] = max(harvests, key=lambda h: h.weight, default=None)
    s["best_rated"] = max(harvests, key=lambda h: h.rating, default=None)

    def group(keyf, namef):
        g = collections.OrderedDict()
        for h in harvests:
            k = keyf(h)
            e = g.setdefault(k, {"id": k, "name": namef(k), "total": 0, "m": 0, "f": 0, "heaviest": None, "longest": None, "last": None, "sub": collections.Counter()})
            e["total"] += 1
            if h.sex == "M": e["m"] += 1
            if h.sex == "F": e["f"] += 1
            if e["heaviest"] is None or h.weight > e["heaviest"].weight: e["heaviest"] = h
            if e["longest"] is None or h.distance > e["longest"].distance: e["longest"] = h
            if h.when and (e["last"] is None or h.when > e["last"]): e["last"] = h.when
            yield_sub = getattr(group, "sub", None)
            if yield_sub: e["sub"][yield_sub(h)] += 1
        return sorted(g.values(), key=lambda e: -e["total"])

    group.sub = lambda h: names.map(h.map)
    s["by_species"] = group(lambda h: h.subspecies, names.subspecies)
    for e in s["by_species"]:
        e["latin"] = names.latin(e["id"])
    group.sub = lambda h: names.caliber(h.ammo)
    s["by_weapon"] = group(lambda h: h.weapon, names.gear_name)
    group.sub = lambda h: names.gear_name(h.weapon)
    s["by_ammo"] = group(lambda h: h.ammo, names.caliber)
    group.sub = lambda h: names.subspecies(h.subspecies)
    s["by_map"] = group(lambda h: h.map, names.map)
    group.sub = None
    s["by_weather"] = group(lambda h: h.weather, names.weather)
    s["species_count"] = len(s["by_species"])

    # gear time: {map: {category: [(name, hours)]}} and overall totals
    s["vehicle_km"] = statistics["vehicle_km"] if statistics else 0.0
    gear = {}
    overall = collections.defaultdict(float)
    for lev, stats in (statistics or {}).get("levels", {}).items():
        for tag, items in stats.items():
            if not tag.startswith("Stats.Inventory.TimeUsed."):
                continue
            cat = GEAR_CATEGORIES.get(tag[len("Stats.Inventory.TimeUsed."):], tag.split(".")[-1])
            acc = collections.defaultdict(float)
            for item, sec in items.items():
                acc[names.gear_name(item)] += sec / 3600.0
                if cat != "Scopes and sights":
                    overall[names.gear_name(item)] += sec / 3600.0
            gear.setdefault(names.map(lev), {})[cat] = sorted(acc.items(), key=lambda x: -x[1])
    s["gear_time"] = gear
    s["gear_overall"] = sorted(overall.items(), key=lambda x: -x[1])
    s["hours_in_hand"] = sum(v for v in overall.values())
    return s

def read_stats(path, names):
    """-> (summary dict, notes list)"""
    import nrgs
    sf = nrgs.SaveFile(path)
    secs = nrgs.split_sections(sf.part("Game_0/GameData").data)[1]
    notes = []
    harvests, bad = [], 0
    stats = None
    for h, v, blob in secs:
        if h == HUNTINGLOG_SECTION:
            harvests, bad = parse_hunting_log(blob)
        elif h == STATISTICS_SECTION:
            stats = parse_statistics(blob)
    if bad:
        notes.append(f"{bad} hunting-log records could not be read")
    return summarize(harvests, stats, names), notes

def text_report(s, names, top=15):
    """Plain-text version for the CLI."""
    L = []
    if not s["total"]:
        return "No harvests in the hunting log yet."
    hunters = ", ".join(s["hunters"]) or "-"
    span = f"{s['first']:%Y-%m-%d} to {s['last']:%Y-%m-%d}" if s["first"] else "-"
    L.append(f"Harvests: {s['total']:,}  ({s['males']} male, {s['females']} female)  species: {s['species_count']}  hunter: {hunters}  {span}")
    lo, he, br = s["longest"], s["heaviest"], s["best_rated"]
    L.append(f"Longest shot: {lo.distance:.0f} m ({names.subspecies(lo.subspecies)}, {names.gear_name(lo.weapon)})")
    L.append(f"Heaviest: {he.weight:,.0f} kg {names.subspecies(he.subspecies)}    Best rated: {br.rating:.0%} {names.subspecies(br.subspecies)}")
    L.append(f"Gear in hand: {s['hours_in_hand']:,.1f} in-game hours    Driven: {s['vehicle_km']:,.1f} km")
    L.append("\nBy species:")
    for e in s["by_species"][:top]:
        L.append(f"  {e['name']:<34} {e['total']:>4}  ({e['m']}m/{e['f']}f)  heaviest {e['heaviest'].weight:>7,.1f} kg  longest {e['longest'].distance:>5.0f} m")
    if len(s["by_species"]) > top:
        L.append(f"  ... and {len(s['by_species']) - top} more")
    L.append("\nBy weapon:")
    for e in s["by_weapon"]:
        L.append(f"  {e['name']:<34} {e['total']:>4}  longest {e['longest'].distance:>5.0f} m   {', '.join(f'{k} x{v}' for k, v in e['sub'].most_common(3))}")
    L.append("\nBy map:      " + ", ".join(f"{e['name']} {e['total']}" for e in s["by_map"]))
    L.append("By weather:  " + ", ".join(f"{e['name']} {e['total']}" for e in s["by_weather"]))
    L.append("\nGear time (in-game hours in hand, all maps):")
    for name, hrs in s["gear_overall"][:top]:
        L.append(f"  {name:<34} {hrs:>7.1f} h")
    return "\n".join(L)
