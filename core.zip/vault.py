"""The code lock for builds with no locked code at all (WOTH2 Toybox and the website): shipped as core/vault.py.

The real vault.py (decrypt + run the locked modules) only goes into Toybox Unlocked. This one has the same
names and is always locked, so the basic app and the web page carry no crypto and no exec at all.
"""
LOCKED_MODULES = ("animals", "locked_trainer_core", "locked_stands", "locked_missions")
LOCKED_MSG = "Not in this app."


class Locked(ImportError):
    pass

def has_vault():
    return False

def unlocked():
    return False

def unlock(code):
    raise ValueError("this build has no lock")

def change_code(code, new_code):
    raise ValueError("this build has no lock")

def locked(name):
    raise Locked(LOCKED_MSG)

def install():
    pass
