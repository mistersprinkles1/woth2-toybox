"""The code lock: the save-writing part of the core ships encrypted, and only the unlock code opens it.

Same design as a crypto-wallet keystore (e.g. Ethereum's v3 keystore):
  * a random 256-bit CONTENT KEY encrypts the locked modules (LOCKED_MODULES, sources zlib'd into vault.bin);
  * the unlock code never decrypts anything directly: scrypt (N = 2^18, r = 8, p = 1: 256 MB of memory and
    about a second per guess, on purpose) turns it into a key-encryption key that unwraps the content key;
  * cipher = BLAKE2b-512 keyed PRF in counter mode, integrity = keyed BLAKE2b-256 over nonce + ciphertext
    (encrypt-then-MAC, checked in constant time before anything is decrypted). Python stdlib only.
Without the code the locked modules are random bytes: there is nothing in the download to patch around,
only scrypt guesses at the code. Changing the code re-wraps the same content key into a keystore of
your own (user data dir, keystore.json), which then replaces the built-in one on that machine.

The app keeps the unwrapped content key (not the code) after a successful unlock and hands it to every
core run in WOTH2_KEY. In a source checkout the modules are also there as plain files; they are still
only importable with a valid key whenever a vault.bin exists, so the checkout behaves like the release.
"""
import base64, hashlib, hmac, importlib.abc, importlib.util, json, os, sys, zlib

HERE = os.path.dirname(os.path.abspath(__file__))
VAULT_FILE = os.path.join(HERE, "vault.bin")
LOCKED_MODULES = ("animals", "locked_trainer_core", "locked_stands", "locked_missions")
SCRYPT = {"n": 1 << 18, "r": 8, "p": 1}
MIN_CODE = 12


class Locked(ImportError):
    pass

LOCKED_MSG = "Locked: enter the code (UNLOCK, top right) to use this."

# ---------------------------------------------------------------- primitives
def _b64(b): return base64.b64encode(b).decode()
def _unb64(s): return base64.b64decode(s)

def _subkeys(key):
    enc = hashlib.blake2b(key, digest_size=64, person=b"toybox-enc-v1").digest()
    mac = hashlib.blake2b(key, digest_size=32, person=b"toybox-mac-v1").digest()
    return enc, mac

def _keystream(key, nonce, n):
    out = bytearray(); ctr = 0
    while len(out) < n:
        out += hashlib.blake2b(nonce + ctr.to_bytes(8, "little"), key=key, digest_size=64).digest(); ctr += 1
    return bytes(out[:n])

def _xor(a, b):
    return (int.from_bytes(a, "little") ^ int.from_bytes(b, "little")).to_bytes(len(a), "little")

def seal(key, data):
    """-> {"nonce", "ct", "tag"} (base64)"""
    enc, mac = _subkeys(key)
    nonce = os.urandom(24)
    ct = _xor(data, _keystream(enc, nonce, len(data))) if data else b""
    tag = hashlib.blake2b(nonce + ct, key=mac, digest_size=32).digest()
    return {"nonce": _b64(nonce), "ct": _b64(ct), "tag": _b64(tag)}

def unseal(key, box):
    """-> plaintext, or None when the key is wrong / the data was changed"""
    enc, mac = _subkeys(key)
    nonce, ct, tag = _unb64(box["nonce"]), _unb64(box["ct"]), _unb64(box["tag"])
    if not hmac.compare_digest(hashlib.blake2b(nonce + ct, key=mac, digest_size=32).digest(), tag):
        return None
    return _xor(ct, _keystream(enc, nonce, len(ct))) if ct else b""

def _kek(code, ks):
    if not hasattr(hashlib, "scrypt"):                # WebAssembly core (Windows release): the host's scrypt (Node crypto)
        import toybox_host
        out = toybox_host.scrypt(code.encode("utf-8"), _unb64(ks["salt"]), ks["n"], ks["r"], ks["p"], 32)
        return out.to_bytes() if hasattr(out, "to_bytes") else bytes(out)
    return hashlib.scrypt(code.encode("utf-8"), salt=_unb64(ks["salt"]), n=ks["n"], r=ks["r"], p=ks["p"], maxmem=1 << 30, dklen=32)

def make_keystore(code, content_key):
    salt = os.urandom(32)
    ks = {"kdf": "scrypt", "salt": _b64(salt), **SCRYPT}
    ks["wrapped"] = seal(_kek(code, ks), content_key)
    return ks

# ---------------------------------------------------------------- vault file
_vault = None
def _load_vault():
    global _vault
    if _vault is None:
        try:
            with open(VAULT_FILE) as f:
                _vault = json.load(f)
        except (OSError, ValueError):
            _vault = {}
    return _vault

def has_vault():
    return bool(_load_vault())

def _user_keystore_path():
    import trainer_core
    return os.path.join(trainer_core.user_data_dir(), "keystore.json")

def _keystore():
    """The code's keystore: your own after a code change on this machine, else the one built into the release."""
    try:
        with open(_user_keystore_path()) as f:
            ks = json.load(f)
        if ks.get("kdf") == "scrypt":
            return ks, True
    except (OSError, ValueError):
        pass
    return _load_vault().get("keystore"), False

_sources = None
def _open_payload(content_key):
    v = _load_vault()
    if not v or len(content_key) != 32:
        return None
    raw = unseal(content_key, v["payload"])
    return json.loads(zlib.decompress(raw)) if raw is not None else None

def _key_from_env():
    """The content key: from the app (WOTH2_KEY, after the code was typed) or built into this bundle (the
    "Toybox Unlocked" edition ships its key in CONTENT_KEY next to the core: no code, always open)."""
    try:
        k = bytes.fromhex(os.environ.get("WOTH2_KEY", ""))
        if len(k) == 32: return k
    except ValueError:
        pass
    try:
        with open(os.path.join(HERE, "CONTENT_KEY")) as f:
            k = bytes.fromhex(f.read().strip())
        return k if len(k) == 32 else None
    except (OSError, ValueError):
        return None

_unlocked = None
def unlocked():
    """True when this process may use the locked modules (a valid content key, or a checkout without vault)."""
    global _unlocked, _sources
    if _unlocked is None:
        if not has_vault():
            _unlocked = all(os.path.exists(os.path.join(HERE, m + ".py")) for m in LOCKED_MODULES)
        else:
            k = _key_from_env()
            _sources = _open_payload(k) if k else None
            _unlocked = _sources is not None
    return _unlocked

def unlock(code):
    """The unlock code -> content key (hex). Raises ValueError on a wrong code."""
    ks, own = _keystore()
    if not ks:
        raise ValueError("this build has no lock")
    ck = unseal(_kek(code.strip(), ks), ks["wrapped"])
    if (ck is None or _open_payload(ck) is None) and own:
        # a code changed on this machine wraps the key of an older release: the release's own code still opens a new one
        built_in = _load_vault().get("keystore")
        ck2 = unseal(_kek(code.strip(), built_in), built_in["wrapped"]) if built_in else None
        if ck2 is not None and _open_payload(ck2) is not None:
            if ck is not None:                             # the own keystore is for an old release: drop it
                try: os.remove(_user_keystore_path())
                except OSError: pass
            ck = ck2
    if ck is None or _open_payload(ck) is None:
        raise ValueError("Wrong code.")
    return ck.hex()

def change_code(code, new_code):
    """Re-wrap the content key under a new code (this machine only). -> content key (hex)"""
    new_code = new_code.strip()
    if len(new_code) < MIN_CODE:
        raise ValueError(f"Use at least {MIN_CODE} characters for the new code.")
    ck = bytes.fromhex(unlock(code))
    p = _user_keystore_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w") as f:
        json.dump(make_keystore(new_code, ck), f)
    os.replace(tmp, p)
    return ck.hex()

# ---------------------------------------------------------------- import hook
class _Finder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    """Serves the locked modules from the decrypted vault, and refuses them while locked (also in a checkout)."""
    def find_spec(self, name, path=None, target=None):
        if name not in LOCKED_MODULES:
            return None
        if not unlocked():
            raise Locked(LOCKED_MSG)
        if _sources is None or name not in _sources:
            return None                                    # checkout: the plain file
        return importlib.util.spec_from_loader(name, self, origin="vault:" + name)

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        module.__file__ = os.path.join(HERE, module.__name__ + ".py")
        exec(compile(_sources[module.__name__], "vault:" + module.__name__, "exec"), module.__dict__)

def install():
    if not any(isinstance(f, _Finder) for f in sys.meta_path):
        sys.meta_path.insert(0, _Finder())

def locked(name):
    """The locked module `name` (import it), or raise Locked."""
    install()
    if not unlocked():
        raise Locked(LOCKED_MSG)
    return importlib.import_module(name)

install()

# ---------------------------------------------------------------- building (release tool)
def build(code, content_key, out=VAULT_FILE, src_dir=HERE):
    """Encrypt LOCKED_MODULES from src_dir into vault.bin with a keystore for `code`."""
    srcs = {}
    for m in LOCKED_MODULES:
        with open(os.path.join(src_dir, m + ".py"), encoding="utf-8") as f:
            srcs[m] = f.read()
    payload = seal(content_key, zlib.compress(json.dumps(srcs).encode("utf-8"), 9))
    v = {"version": 1, "modules": list(LOCKED_MODULES), "keystore": make_keystore(code, content_key), "payload": payload}
    tmp = out + ".tmp"
    with open(tmp, "w") as f:
        json.dump(v, f)
    os.replace(tmp, out)
