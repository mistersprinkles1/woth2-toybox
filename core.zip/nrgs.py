"""Reader/writer for Nine Rocks Games ``.nrgs`` save containers (Way of the Hunter 2).

Layout (all little-endian):

  NRGS container  = 'NRGS' | u32 crc | u32 version | u32 size | u64 flags | body[size]
                    crc = crc32(version .. end of body)
  version 1 body  = u32 seed(0x3619636b) | u32 n | n * (u64 name_hash, u32 size, u32 offset) | data
                    name_hash = crc32(name, seed)
  version 2 body  = u32 crc32(payload) | u32 payload_size | Unreal SerializeCompressed V2 stream
                    (tag 0x222222229E2A83C1, chunk size, compressor byte, summary, per-chunk
                    sizes, Oodle Kraken blocks of <= 128 KiB each)

The top-level container is version 1 and holds one entry per named part
(Profile, Game_0/GameData, ...) plus a raw NUL-separated name table
(SaveFile::StringTable).  Each named part is itself a version 1 or 2 container.

Writing never needs an Oodle *encoder*: sub-chunks that did not change are
copied verbatim from the original file, and changed sub-chunks are emitted as
Oodle "uncompressed" blocks (header 0xCC 0x06), which the game's own encoder
also produces for incompressible data, so its decoder accepts them.
"""
import ctypes, os, struct, sys, zlib

SEED = 0x3619636B
V2_TAG = 0x222222229E2A83C1
NAME_TABLE = "SaveFile::StringTable"

_lib = None
def _ooz():
    global _lib
    if _lib is None:
        here = os.path.dirname(os.path.abspath(__file__))
        name = {"nt": "ooz.dll", "posix": "libooz.so"}.get(os.name, "libooz.so")
        if sys.platform == "darwin":
            name = "libooz.dylib"
        _lib = ctypes.CDLL(os.path.join(here, "ooz", name))
        fn = None
        for sym in ("_Z17Kraken_DecompressPKhmPhm", "_Z17Kraken_DecompressPKhyPhy", "Kraken_Decompress"):   # Itanium mangling: size_t = m on Linux, y on Windows
            fn = getattr(_lib, sym, None)
            if fn is not None:
                break
        fn.restype = ctypes.c_int
        fn.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p, ctypes.c_size_t]
        _lib._kraken = fn
    return _lib

def oodle_decompress(src: bytes, dst_len: int) -> bytes:
    if sys.platform == "emscripten":                  # Windows release: the decoder is WebAssembly in the host (wasm/ooz.mjs)
        import toybox_host
        out = toybox_host.ooz(src, dst_len)
        if out is None:
            raise ValueError("Oodle decompress failed")
        return bytes(out.to_py()) if hasattr(out, "to_py") else bytes(out)
    dst = ctypes.create_string_buffer(dst_len + 64)
    r = _ooz()._kraken(src, len(src), dst, dst_len)
    if r != dst_len:
        raise ValueError(f"Oodle decompress failed ({r} != {dst_len})")
    return dst.raw[:dst_len]

def name_hash(name: str) -> int:
    return zlib.crc32(name.encode(), SEED) & 0xFFFFFFFF

def crc(b: bytes) -> int:
    return zlib.crc32(b) & 0xFFFFFFFF

# ---------------------------------------------------------------- containers
def split_container(buf: bytes, off: int = 0):
    """Return (version, flags, body) of the NRGS container at ``off`` after checking its CRC."""
    magic, h, ver, size = struct.unpack_from("<4sIII", buf, off)
    if magic != b"NRGS":
        raise ValueError("not an NRGS container")
    flags, = struct.unpack_from("<Q", buf, off + 16)
    end = off + 24 + size
    if crc(buf[off + 8:end]) != h:
        raise ValueError("NRGS container CRC mismatch")
    return ver, flags, buf[off + 24:end]

def build_container(ver: int, body: bytes, flags: int = 0) -> bytes:
    tail = struct.pack("<IIQ", ver, len(body), flags) + body
    return b"NRGS" + struct.pack("<I", crc(tail)) + tail

def split_v1(body: bytes):
    seed, n = struct.unpack_from("<II", body, 0)
    ents = [struct.unpack_from("<QII", body, 8 + 16 * i) for i in range(n)]
    data = 8 + 16 * n
    return seed, [(h, body[data + o:data + o + s]) for h, s, o in ents]

def build_v1(entries, seed: int = SEED) -> bytes:
    table, data = b"", b""
    for h, blob in entries:
        data += b"\0" * ((-len(data)) % 8)           # entries are 8-byte aligned
        table += struct.pack("<QII", h, len(blob), len(data))
        data += blob
    return struct.pack("<II", seed, len(entries)) + table + data

class V2Part:
    """A version-2 (compressed) part: ``data`` is the decompressed payload."""
    def __init__(self, body: bytes):
        self.ucrc, self.usize = struct.unpack_from("<II", body, 0)
        p = 8
        tag, self.chunk_size = struct.unpack_from("<QQ", body, p); p += 16
        if tag != V2_TAG:
            raise ValueError("unexpected compressed-archive tag")
        self.compressor = body[p]; p += 1
        csum, usum = struct.unpack_from("<QQ", body, p); p += 16
        n = (usum + self.chunk_size - 1) // self.chunk_size if usum else 0
        infos = [struct.unpack_from("<QQ", body, p + 16 * i) for i in range(n)]; p += 16 * n
        self.blocks = []          # original (compressed_bytes, uncompressed_len)
        out = bytearray()
        for cs, us in infos:
            blk = body[p:p + cs]; p += cs
            self.blocks.append((blk, us))
            out += oodle_decompress(blk, us)
        if len(out) != usum or len(out) != self.usize or crc(out) != self.ucrc:
            raise ValueError("payload size/CRC mismatch")
        self.orig_data = bytes(out)
        self.data = bytes(out)

    def build(self) -> bytes:
        cs = self.chunk_size
        pieces = [self.data[i:i + cs] for i in range(0, len(self.data), cs)]
        orig_pieces = [self.orig_data[i:i + cs] for i in range(0, len(self.orig_data), cs)]
        blocks = []
        for i, piece in enumerate(pieces):
            if i < len(orig_pieces) and piece == orig_pieces[i]:
                blocks.append(self.blocks[i][0])          # verbatim reuse
            else:
                blocks.append(b"\xCC\x06" + piece)        # Oodle raw block
        csum = sum(len(b) for b in blocks)
        stream = struct.pack("<QQ", V2_TAG, cs) + bytes([self.compressor])
        stream += struct.pack("<QQ", csum, len(self.data))
        for b, piece in zip(blocks, pieces):
            stream += struct.pack("<QQ", len(b), len(piece))
        stream += b"".join(blocks)
        return struct.pack("<II", crc(self.data), len(self.data)) + stream

# ---------------------------------------------------------------- save file
class SaveFile:
    def __init__(self, path: str):
        self.path = path
        raw = open(path, "rb").read()
        self.raw = raw
        ver, self.flags, body = split_container(raw)
        if ver != 1:
            raise ValueError("unexpected top-level version")
        self.seed, ents = split_v1(body)
        names = {}
        for h, blob in ents:
            if blob[:4] != b"NRGS":
                for nm in blob.split(b"\0"):
                    if nm:
                        names[name_hash(nm.decode())] = nm.decode()
        self.entries = []   # (hash, name, kind, obj)  kind: 'v2' (V2Part) | 'other' (bytes)
        for h, blob in ents:
            name = names.get(h, f"unknown_{h:08x}")
            if blob[:4] == b"NRGS":
                v, fl, b = split_container(blob)
                if v == 2:
                    self.entries.append((h, name, "v2", V2Part(b), fl)); continue
            self.entries.append((h, name, "other", blob, 0))

    def part(self, name: str) -> V2Part:
        for h, nm, kind, obj, fl in self.entries:
            if nm == name and kind == "v2":
                return obj
        raise KeyError(name)

    def build(self) -> bytes:
        ents = []
        for h, nm, kind, obj, fl in self.entries:
            blob = build_container(2, obj.build(), fl) if kind == "v2" else obj
            ents.append((h, blob))
        out = build_container(1, build_v1(ents, self.seed), self.flags)
        pad = (-len(out)) % 4096
        return out + b"\0" * pad

# ---------------------------------------------------------------- GameData sections
def split_sections(data: bytes):
    """GameData payload: u32 seed | u32 n | n * (u32 hash, u32 version, u32 size, u32 offset) | data.
    Returns (seed, [(hash, version, bytes), ...]); offsets are relative to the end of the table."""
    seed, n = struct.unpack_from("<II", data, 0)
    hdr = 8 + 16 * n
    secs = [struct.unpack_from("<IIII", data, 8 + 16 * i) for i in range(n)]
    return seed, [(h, v, data[hdr + o:hdr + o + s]) for h, v, s, o in secs]

def build_sections(seed: int, sections) -> bytes:
    table, data = b"", b""
    for h, v, blob in sections:
        data += b"\0" * ((-len(data)) % 8)           # 8-byte aligned like the top level
        table += struct.pack("<IIII", h, v, len(blob), len(data))
        data += blob
    return struct.pack("<II", seed, len(sections)) + table + data

def fstring(s: str) -> bytes:
    """An FString the way Unreal writes it: plain ASCII as is, anything else UTF-16 with a negative length."""
    if s.isascii():
        b = s.encode() + b"\0"
        return struct.pack("<I", len(b)) + b
    b = s.encode("utf-16-le") + b"\0\0"
    return struct.pack("<i", -(len(b) // 2)) + b

def read_fstring(data: bytes, p: int):
    n, = struct.unpack_from("<i", data, p); p += 4
    if n < 0:
        return data[p:p - 2 * n - 2].decode("utf-16-le"), p - 2 * n
    return data[p:p + n - 1].decode(), p + n

def find_int_property(data: bytes, tag: bytes, prop_prefix: bytes, start: int = 0) -> int:
    """Return the offset of the 4-byte IntProperty value ``prop_prefix``* that follows gameplay tag ``tag``."""
    t = data.find(tag + b"\0", start)
    if t < 0:
        raise KeyError(tag.decode())
    p = data.find(prop_prefix, t)
    if p < 0:
        raise KeyError(prop_prefix.decode())
    ip = data.find(b"IntProperty\0", p)
    if ip < 0 or ip - p > 128:
        raise ValueError("IntProperty tag not where expected")
    q = ip + len(b"IntProperty\0")
    if data[q:q + 9] != b"\0\0\0\0\x04\0\0\0\0":
        raise ValueError("unexpected IntProperty header bytes")
    return q + 9
