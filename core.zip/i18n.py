"""The core's side of the app's languages: i18n.t("English line") -> that line in the app's language (WOTH2_LANG).

Same catalog as the app (app/assets/i18n/<lang>.json in a checkout, i18n_<lang>.json next to this file in a bundle).
A line with values in it is one template: i18n.t("herds start at {lo} fitness").format(lo=x). Lines with no
translation stay English. tools/i18n_extract.py collects every i18n.t("...") line for the translators."""
import json, os

_HERE = os.path.dirname(os.path.abspath(__file__))
_CATS = {}

def lang():
    return os.environ.get("WOTH2_LANG", "")

def _cat(l):
    if l not in _CATS:
        d = {}
        for p in (os.path.join(_HERE, f"i18n_{l}.json"), os.path.join(_HERE, "app", "assets", "i18n", f"{l}.json")):
            try:
                with open(p, encoding="utf-8") as f: d = json.load(f)
                break
            except (OSError, ValueError):
                continue
        _CATS[l] = d
    return _CATS[l]

def tc(ctx, s):
    """One English word that needs two translations: the catalog line "<ctx>|<English>", else t(s)."""
    l = lang()
    if not l: return s
    return _cat(l).get(ctx + "|" + s) or t(s)

def t(s):
    l = lang()
    if not l: return s
    return _cat(l).get(s) or s
