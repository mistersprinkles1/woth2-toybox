#!/usr/bin/env python3
"""Find every facility of each map (campsites, lodge, cabins, stations, observation towers, hunting
stands, shooting ranges and their vehicle parking spots) inside the streamed world-partition cell
packages (Maps/<Map>/<Map>/_Generated_/*.umap) and write facilities.json with their world positions
(cm). An actor counts as a facility when its class name matches PAT or it owns a
BP_FacilityRepresentation component (the thing the game's hunting map draws). The facility gameplay
tag (Facility.Camp.3, Facility.Parking.Lodge.1 ...) is read from the actor's property blob when the
package has one. Run: python3 facilities_scan.py"""
import json, os, re, struct, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import woth2_paks as paks, trainer_core

PAT = re.compile(r"^(BP_Campsite\w*|BP_Lodge\w*|BP_Station\w*|BP_ObservationStation\w*|BP_Cabin\w*|BP_HuntingStand\w*|BP_VehicleParking\w*|BP_ShootingRange\w*|BP_FacilityRepresentation)_C_UAID_")
TAG_RE = re.compile(r"^Facility\.(Camp|Cabin|Lodge|Station|Parking|Tent|ShootingRange|Opportunity)\b")
ROOT_NAMES = ("DefaultSceneRoot", "StaticMeshComponent0", "Root", "SceneRoot", "RootComponent", "Scene", "SceneComponent")
KINDS = [("BP_VehicleParking", "parking"), ("BP_Campsite", "camp"), ("BP_Lodge", "lodge"), ("BP_ObservationStation", "station"), ("BP_Station", "station"),
         ("BP_Cabin", "cabin"), ("BP_HuntingStand", "stand"), ("BP_ShootingRange", "range"), ("BP_FacilityRepresentation", "facility")]

def kind_of(cls, tag):
    if tag:
        t = tag.split(".")
        if t[1] == "Parking": return "parking"
        if t[1] == "Camp": return "camp"
        if t[1] == "Cabin": return "cabin"
        if t[1] == "Lodge": return "lodge"
        if t[1] == "Station": return "station"
    for k, v in KINDS:
        if cls.startswith(k): return v
    return "other"

def _exports(data):
    f = struct.unpack_from("<IIIIIIiiiiiii", data, 0); hdr = f[1]; off, end = f[8], f[9]; n = (end - off) // 72
    return hdr, [struct.unpack_from("<QQIIQQQQQIB", data, off + 72 * k) for k in range(n)]

def pick_pos(cands, ground):
    """Root location among the candidate doubles: the first one whose z sits on the terrain (height
    texture, 8-bit so about 3 m steps); the first candidate when there is no map cache."""
    if not cands: return None
    if ground is None: return cands[0][:3]
    # the location is the first triple of the root blob (RelativeLocation comes before the rotation and
    # every other double); the height texture (8-bit, 10 m per texel) only rejects wild misreads
    for c in cands:
        if c[3] and abs(c[2] - ground(c[0], c[1])) < 15000: return c[:3]
    for c in cands:
        if abs(c[2] - ground(c[0], c[1])) < 15000: return c[:3]
    for c in cands:
        if c[3]: return (c[0], c[1], ground(c[0], c[1]))
    return None

def terrain(mapname):
    """(x, y) -> ground z in cm from the map cache's height texture, or None when there is no cache."""
    try:
        import mapdata, json
        from PIL import Image
        import numpy as np
        cd = mapdata.cache_dir(mapname)
        meta = json.load(open(os.path.join(cd, "meta.json"))); a, b = meta["height_fit"]
        img = np.asarray(Image.open(os.path.join(cd, "height.png")).convert("L"), dtype=np.float32)
        x0, y0, x1, y1 = mapdata.BOUNDS[mapname]; h, w = img.shape
        def g(x, y):
            px = min(w - 1, max(0, int((x - x0) / (x1 - x0) * w))); py = min(h - 1, max(0, int((y - y0) / (y1 - y0) * h)))
            return a * float(img[py, px]) + b
        return g
    except Exception:
        return None

def actors_in(data, L, ground=None):
    names = paks.package_names(data)
    if not any(PAT.match(n) or n.startswith("BP_FacilityRepresentation") for n in names): return []
    hdr, exps = _exports(data)
    kids = {}
    for j, e in enumerate(exps): kids.setdefault(e[4], []).append(j)      # e[4] = OuterIndex (export index)
    tag_idx = {i: n for i, n in enumerate(names) if TAG_RE.match(n)}
    out = []
    for k, e in enumerate(exps):
        nm = names[e[2]] if e[2] < len(names) else ""
        own = [names[exps[j][2]] if exps[j][2] < len(names) else "" for j in kids.get(k, [])]
        is_fac = bool(PAT.match(nm)) or any(o.startswith("BP_FacilityRepresentation") or o.startswith("FacilityRepresentation") for o in own)
        if not is_fac or "_UAID_" not in nm: continue
        blobs = [data[hdr + e[0]: hdr + e[0] + e[1]]] + [data[hdr + exps[j][0]: hdr + exps[j][0] + exps[j][1]] for j in kids.get(k, [])]
        # the root scene component holds the world transform: RelativeLocation (3 doubles) followed by
        # RelativeRotation (3 doubles); other components (collision boxes, meshes) hold offsets and extents
        roots = [i + 1 for i, o in enumerate(own) if o in ROOT_NAMES]
        order = roots + [i + 1 for i in range(len(own)) if i + 1 not in roots]
        cands = []
        for r in order:
            blob = blobs[r]
            for q in range(0, max(0, len(blob) - 24)):
                v = struct.unpack_from("<3d", blob, q)
                if any(x != x for x in v) or not all(x == 0.0 or abs(x) >= 1e-3 for x in v): continue
                x, y, z = v
                if abs(x) < L and abs(y) < L and abs(z) < 120000 and abs(x) + abs(y) > 6000:    # < 60 m from the origin = a collision extent; Map01 lowlands are below -600 m
                    cands.append((x, y, z, r in roots))
        pos = pick_pos(cands, ground)
        tag = ""
        if tag_idx:
            for blob in blobs:
                for i, t in tag_idx.items():
                    if struct.pack("<II", i, 0) in blob:
                        tag = t; break
                if tag: break
        base = nm.split("_C_UAID")[0]
        # the actor's own label (an FString in its property blob) carries the facility number: BP_Campsite_07, BP_CabinH02 ...
        m = re.search(rb"BP_(Campsite|Camp|Cabin|Station|Lodge|HuntingStand|ShootingRange)[A-Za-z]*_?(\d+)\x00", blobs[0])
        if m:
            base = "BP_" + m.group(1).decode() + m.group(2).decode()
        if base.startswith("StaticMeshActor"):          # unnamed building actor: name it after its meshes
            base = building_name(own + [names[j] for j in range(len(names)) if names[j].startswith("SM_")])
        out.append({"name": base, "tag": tag, "kind": kind_of(base, tag), "x": round(pos[0]) if pos else None, "y": round(pos[1]) if pos else None, "z": round(pos[2]) if pos else None,
                    "children": own})
    return out

def building_name(names):
    s = " ".join(names)
    for key, nm in (("Lodge", "BP_Lodge"), ("Cabin", "BP_Cabin"), ("Station", "BP_Station"), ("Shed", "BP_Campsite"), ("Tent", "BP_Campsite"), ("Camp", "BP_Campsite")):
        if key in s: return nm
    return "BP_Facility"

def label(found):
    """Give unnamed camps / cabins / stations / lodges the number of the named parking spot next to them."""
    named = [a for a in found if a["kind"] == "parking" and re.search(r"\d", a["name"])]
    for a in found:
        if a["kind"] in ("camp", "cabin", "station", "lodge") and not re.search(r"\d", a["name"]):
            near = [(p, (p["x"] - a["x"]) ** 2 + (p["y"] - a["y"]) ** 2) for p in named]
            near = [p for p, d2 in near if d2 < 12000 ** 2]
            if near:                                  # the parking spot next door carries the facility's number
                p = min(near, key=lambda p: (p["x"] - a["x"]) ** 2 + (p["y"] - a["y"]) ** 2)
                a["name"] = "BP_" + p["name"].replace("BP_VehicleParking_", "")
    # one entry per spot (the Hub lodge is four level actors plus a streaming check on the same point)
    keep = []
    for a in found:
        if any(b["kind"] == a["kind"] and (b["x"] - a["x"]) ** 2 + (b["y"] - a["y"]) ** 2 < 3000 ** 2 for b in keep): continue
        keep.append(a)
    found[:] = keep
    for a in found:
        a["label"] = pretty(a["name"], a["kind"])

def pretty(name, kind):
    n = name.replace("BP_VehicleParking_", "").replace("BP_", "")
    n = re.sub(r"HubLevel\d", "", n)
    m = re.search(r"(?:Campsite|Camp|Cabin|Station|Lodge)[A-Za-z]*?(\d+)$", n); num = (" " + str(int(m.group(1)))) if m else ""
    if kind in ("lodge", "range", "stand"): num = ""
    base = {"parking": "Parking", "camp": "Camp", "lodge": "Lodge", "cabin": "Cabin", "station": "Station", "stand": "Hunting stand", "range": "Shooting range"}.get(kind, n)
    if kind == "parking":
        return "Parking · " + pretty("BP_" + n, "camp" if "Campsite" in n else "cabin" if "Cabin" in n else "station" if "Station" in n else "lodge" if "Lodge" in n else "other") if re.search(r"Campsite|Cabin|Station|Lodge", n) else "Parking"
    return base + num

def main():
    save = trainer_core.find_save(); pd = paks.find_paks_dir(save)
    tocs = paks.all_tocs(pd)
    out = {}
    for m in ["Hub", "Map02", "Map01"]:
        L = 201600 if m == "Hub" else 510000
        ground = terrain(m)
        cells = [(t, idx) for t in tocs for path, idx in t.files.items() if f"/Maps/{m}/{m}/_Generated_/" in path and path.endswith(".umap")]
        found = []; t0 = time.time()
        for i, (t, idx) in enumerate(cells):
            try: data = t.read(idx)
            except Exception: continue
            try: found += actors_in(data, L, ground)
            except Exception as e: print("cell error", e)
        for a in found:
            if a["x"] is None and a["kind"] != "other": print("  no position:", a["name"], a["children"][:12])
        found = [a for a in found if a["kind"] != "other" and a["x"] is not None]
        for a in found: a.pop("children", None)
        label(found)
        out[m] = found
        print(f"{m}: {len(cells)} cells, {len(found)} facilities, {time.time() - t0:.0f}s", flush=True)
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "facilities.json"), "w") as f:
        json.dump(out, f, indent=1)

if __name__ == "__main__":
    main()
