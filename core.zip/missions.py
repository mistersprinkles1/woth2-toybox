"""Challenges and missions: what the game's mission log says is finished, in progress or not started,
and completing any of them by hand.

Mission-log sections (MissionLogGameSystem 0xdb50a494 in Game_0/GameData = challenges, achievements,
codex unlocks; MissionLogWorldSubsystem 0xe1bddabd in Game_0/World_0/<Map> = that map's story missions):
  u32 1 | wrappers (``01 01 u32 len`` / ``01 u32 len`` / ``u32 1``; every len runs to the end of the section)
  u32 n | n x ACTIVE  entry: 01 01 len | FString class | FString asset | 01 01 len | FString class | FString asset | u32 len | state
  u32 m | m x FINISHED entry: 01 01 len | FString class | FString asset | FString "Mission.State.Finished.Completed"
Active state: the objectives' CappedInt32Counter (``01 01 09000000 01 04000000 i32 value``, the progress of the
CURRENT objective, it restarts at 0 for the next one) and one "Mission.Objective.<i>.Completed" tag per finished
objective. Challenge series = one mission whose objectives are the tiers; the tier targets are the last
``(05 03 | 04 05 01) i32 value 00000000`` run of the unversioned DA_MissionData_ChallengeSeries* asset.
Story missions come with a ``<asset>_Helper`` twin and each mini-story with a ``DA_<Map>_MissionFlow_MiniStoryXX_Helper``;
the game finishes them together, so complete() does the same.
Section 0xd3f5aacb in a map world = the mission currently tracked on that map.
"""
import json, os, re, struct

HERE = os.path.dirname(os.path.abspath(__file__))
CATALOG_CACHE = os.path.join(HERE, "missions_en.json")
CATALOG_VERSION = 3

LOG_SECTION = 0xDB50A494          # MissionLogGameSystem   (Game_0/GameData)
WORLD_LOG_SECTION = 0xE1BDDABD    # MissionLogWorldSubsystem (Game_0/World_0/<Map>)
FINISHED = "Mission.State.Finished.Completed"
CLASS_CHALLENGE = "BP_MissionData_ChallengeSeries_DataAsset_C"
CLASS_MISSION = "BP_MissionData_DataAsset_C"
MAPS = ("Map01", "Map02")

def _fs(b, p):
    n, = struct.unpack_from("<i", b, p); p += 4
    if n < 0:
        return b[p:p - 2 * n - 2].decode("utf-16-le"), p - 2 * n
    return b[p:p + n - 1].decode("utf-8", "replace"), p + n

def _fstring(s):
    e = s.encode() + b"\0"
    return struct.pack("<I", len(e)) + e

# ---------------------------------------------------------------- save side
class MissionLog:
    """One mission-log section. active: {asset: (class, raw entry bytes)}; finished: [(asset, class, raw entry)] in file
    order (the game logs some repeatable ones several times, keep every record as it is)."""
    def __init__(self, blob):
        self.blob = blob
        n = len(blob)
        if blob[:4] != b"\x01\x00\x00\x00":
            raise ValueError("The mission list in this save could not be read.")
        p, self.lens = 4, []                     # offsets of the length fields that span to the end
        def span(q):                             # a length field at q that runs to the end -> its size, else 0
            if blob[q:q + 2] == b"\x01\x01" and q + 6 <= n and struct.unpack_from("<I", blob, q + 2)[0] == n - q - 6:
                return 6
            if q + 5 <= n and blob[q] == 1 and struct.unpack_from("<I", blob, q + 1)[0] == n - q - 5:
                return 5
            return 0
        while True:
            k = span(p)
            if k:
                self.lens.append((p + k - 4, p + k)); p += k
            elif blob[p:p + 4] == b"\x01\x00\x00\x00" and span(p + 4):
                p += 4                           # a nested layer, only when a real length field follows (else this
            else:                                # is "1 active mission" whose entry starts 01 01)
                break
        self.head = blob[:p]
        self.active = {}
        cnt, = struct.unpack_from("<I", blob, p); p += 4
        for _ in range(cnt):
            ln, = struct.unpack_from("<I", blob, p + 2)
            cls, q = _fs(blob, p + 6); name, q = _fs(blob, q)
            self.active[name] = (cls, blob[p:p + 6 + ln])
            p += 6 + ln
        self.finished = []
        cnt, = struct.unpack_from("<I", blob, p); p += 4
        for _ in range(cnt):
            ln, = struct.unpack_from("<I", blob, p + 2)
            cls, q = _fs(blob, p + 6); name, q = _fs(blob, q)
            self.finished.append((name, cls, blob[p:p + 6 + ln]))
            p += 6 + ln
        self.done = {f[0] for f in self.finished}
        if p != n:
            raise ValueError("The mission list in this save could not be read.")

    def state(self, name):
        """-> dict(state='done'|'active'|'new', done_objectives, counter)"""
        if name in self.done:
            return {"state": "done"}
        if name in self.active:
            raw = self.active[name][1]
            i = raw.find(b"\x01\x01\x09\x00\x00\x00\x01\x04\x00\x00\x00")
            counter = struct.unpack_from("<i", raw, i + 11)[0] if i >= 0 else 0
            tags = sorted({int(t) for t in re.findall(rb"Mission\.Objective\.(\d+)\.Completed", raw)})
            return {"state": "active", "done_objectives": len(tags), "done_tags": tags, "counter": counter}
        return {"state": "new"}


    def build(self):
        body = bytearray(self.head)
        body += struct.pack("<I", len(self.active))
        for cls, raw in self.active.values():
            body += raw
        body += struct.pack("<I", len(self.finished))
        for _name, _cls, raw in self.finished:
            body += raw
        n = len(body)
        for at, after in self.lens:
            struct.pack_into("<I", body, at, n - after)
        return bytes(body)

def _sections(sf, part):
    import nrgs
    p = sf.part(part)
    seed, secs = nrgs.split_sections(p.data)
    return p, seed, secs

def read_logs(sf):
    """-> {"GameData": MissionLog, "Map01": MissionLog, ...}"""
    out = {}
    for key, part, h in [("GameData", "Game_0/GameData", LOG_SECTION)] + [(m, f"Game_0/World_0/{m}", WORLD_LOG_SECTION) for m in MAPS + ("Hub",)]:
        try:
            _p, _s, secs = _sections(sf, part)
        except KeyError:
            continue
        for sh, _v, blob in secs:
            if sh == h:
                out[key] = MissionLog(blob)
    return out

# camp mission boards: the 15 level missions per map (board_jobs.json, made by tools/board_jobs.py)
BOARD_CACHE = os.path.join(HERE, "board_jobs.json")
_MAP_WORDS = {"Map01": "New Laurentia", "Map02": "Kilimaya Reserve"}

def board_jobs():
    """-> {asset: {"map", "objectives": [[index, has counter]], "helpers": [[package, class]]}}"""
    try:
        with open(BOARD_CACHE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}

def board_status(logs):
    """-> {map: (camp jobs taken or finished, all camp jobs)} for the maps this save has been to."""
    jobs = board_jobs()
    out = {}
    for m in MAPS:
        if m in logs:
            mine = [k for k, j in jobs.items() if j["map"] == m]
            out[m] = (sum(1 for k in mine if k in logs[m].active or k in logs[m].done), len(mine))
    return out


# ---------------------------------------------------------------- game-file side
TARGETS_RE = re.compile(rb"((?:(?:\x05\x03|\x04\x05\x01).{4}\x00{4})+)\xc1\x83\x2a\x9e$", re.S)
MISSION_ASSET_RE = re.compile(r"^DA_(Map\d\d)(LevelMission\d+|MiniStory\w+?_Mission\d+(?:_\d+)?)$")

def _targets(data):
    m = TARGETS_RE.search(data)
    if not m:
        return []
    run = m.group(1); out = []; p = 0
    while p < len(run):
        p += 2 if run[p] == 5 else 3
        out.append(struct.unpack_from("<i", run, p)[0]); p += 8
    return out

PLACEHOLDERS = {"minMass": "the required weight", "minStar": "the required", "maxDistance": "the required distance", "minDistance": "the required distance"}

def _plain(s):
    """Objective text with the UI's {value}|displayAs(unit) placeholders turned into words (fallback when a value is unknown)."""
    s = re.sub(r"\{(\w+)\}\|\s*displayAs\(ratingStars\)", lambda m: "the required stars" if "Star" in m.group(1) else "the required rating", s)
    s = re.sub(r"\{(\w+)\}(?:\|\s*displayAs\(\w+\))?", lambda m: PLACEHOLDERS.get(m.group(1), "the required amount"), s)
    return re.sub(r"\s+", " ", s).strip()

def _fill(s, vals):
    """Objective text with the mission's own numbers in it: "400 m or more", "5 stars", "between 00:00 and 03:00"."""
    s = re.sub(r"\{(\w+)\}(?:\|\s*displayAs\(\w+\))?", lambda m: vals.get(m.group(1), m.group(0)), s)
    s = re.sub(r"between (\d\d:\d\d)-(\d\d:\d\d)", r"between \1 and \2", s)
    return _plain(s)

# Missions the game keeps off the map (their mission boards are hidden and their animals do not live in Kilimaya yet):
# never listed, counted or completed.
HIDDEN_MISSIONS = {"DA_Map02LevelMission10", "DA_Map02LevelMission15"}

# Missions with two endings: each list is one way through (objective numbers as the save tags them).
BRANCHES = {"DA_Map01MiniStory04_Mission05": [[0, 1, 4, 5], [0, 2, 3]]}

# What each mission asks, from the mission data (Maps/Map0x/Missions/*/DA_*): who gives it (mini stories), and per
# objective: its text key, the number the save tags it with when done, optional or not, and the numbers its text shows.
# The mission data did not change in 1.3; the text itself always comes from the game.
MISSION_RULES = {
    'DA_Map01LevelMission01': ('', [
        ('KEY_MAP01LEVELMISSION01_OBJECTIVE01', 0, False, {'maxFitness': '60%'}),
        ('KEY_MAP01LEVELMISSION01_OBJECTIVE02', 1, False, {'maxFitness': '60%'}),
    ]),
    'DA_Map01LevelMission02': ('', [
        ('KEY_MAP01LEVELMISSION02_OBJECTIVE01', 0, False, {'minMass': '1.3 kg'}),
    ]),
    'DA_Map01LevelMission03': ('', [
        ('KEY_MAP01LEVELMISSION03_OBJECTIVE01', 0, False, {'minStar': '5 stars'}),
        ('KEY_MAP01LEVELMISSION03_OBJECTIVE02', 1, False, {'minStar': '5 stars'}),
    ]),
    'DA_Map01LevelMission04': ('', [
        ('KEY_MAP01LEVELMISSION04_OBJECTIVE01', 0, False, {'minMass': '1.3 kg'}),
    ]),
    'DA_Map01LevelMission05': ('', [
        ('KEY_MAP01LEVELMISSION05_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01LevelMission06': ('', [
        ('KEY_MAP01LEVELMISSION06_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01LevelMission07': ('', [
        ('KEY_MAP01LEVELMISSION07_OBJECTIVE01', 0, False, {'minFitness': '80%', 'maxCallDistance': '100 m'}),
    ]),
    'DA_Map01LevelMission08': ('', [
        ('KEY_MAP01LEVELMISSION08_OBJECTIVE01', 0, False, {'minFitness': '60%'}),
        ('KEY_MAP01LEVELMISSION08_OBJECTIVE02', 1, False, {'minFitness': '60%'}),
    ]),
    'DA_Map01LevelMission09': ('', [
        ('KEY_MAP01LEVELMISSION09_OBJECTIVE01', 0, False, {'minStar': '5 stars'}),
    ]),
    'DA_Map01LevelMission10': ('', [
        ('KEY_MAP01LEVELMISSION10_OBJECTIVE01', 0, False, {'minFitness': '40%'}),
    ]),
    'DA_Map01LevelMission11': ('', [
        ('KEY_MAP01LEVELMISSION11_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01LevelMission12': ('', [
        ('KEY_MAP01LEVELMISSION12_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01LevelMission13': ('', [
        ('KEY_MAP01LEVELMISSION13_OBJECTIVE01', 0, False, {'minShotDistance': '400 m'}),
    ]),
    'DA_Map01LevelMission14': ('', [
        ('KEY_MAP01LEVELMISSION14_OBJECTIVE01', 0, False, {'timeFrom': '00:00', 'timeTo': '03:00'}),
    ]),
    'DA_Map01LevelMission15': ('', [
        ('KEY_MAP01LEVELMISSION15_OBJECTIVE01', 0, False, {'minFitness': '70%', 'minShotDistance': '200 m'}),
    ]),
    'DA_Map01MiniStory00_Mission01': ('Angel Hearth', [
        ('KEY_MAP01MINISTORY00_MISSION01_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01MiniStory00_Mission01_1': ('Angel Hearth', [
        ('KEY_MAP01MINISTORY00_MISSION01_1_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01MiniStory00_Mission01_2': ('Angel Hearth', [
        ('KEY_MAP01MINISTORY00_MISSION01_2_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP01MINISTORY00_MISSION01_2_OBJECTIVE02', 1, False, {}),
    ]),
    'DA_Map01MiniStory01_Mission01': ('Juniper', [
        ('KEY_MAP01MINISTORY01_MISSION01_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP01MINISTORY01_MISSION01_OBJECTIVE02', 1, False, {}),
    ]),
    'DA_Map01MiniStory01_Mission02': ('Juniper', [
        ('KEY_MAP01MINISTORY01_MISSION02_OBJECTIVE01', 0, False, {'timeFrom': '00:00', 'timeTo': '05:00'}),
    ]),
    'DA_Map01MiniStory01_Mission03': ('Juniper', [
        ('KEY_MAP01MINISTORY01_MISSION03_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01MiniStory01_Mission04': ('Juniper', [
        ('KEY_MAP01MINISTORY01_MISSION04_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01MiniStory03_Mission01': ('Patrick Harper', [
        ('KEY_MAP01MINISTORY03_MISSION01_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP01MINISTORY03_MISSION01_OBJECTIVE02', 1, False, {}),
        ('KEY_MAP01MINISTORY03_MISSION01_OBJECTIVE03', 2, False, {}),
    ]),
    'DA_Map01MiniStory03_Mission02': ('Patrick Harper', [
        ('KEY_MAP01MINISTORY03_MISSION02_OBJECTIVE02', 0, False, {'maxCallDistance': '100 m'}),
    ]),
    'DA_Map01MiniStory03_Mission03': ('Patrick Harper', [
        ('KEY_MAP01MINISTORY03_MISSION03_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP01MINISTORY03_MISSION03_OBJECTIVE02', 1, False, {}),
    ]),
    'DA_Map01MiniStory04_Mission01': ('Regina Harper', [
        ('KEY_MAP01MINISTORY04_MISSION01_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP01MINISTORY04_MISSION01_OBJECTIVE02', 1, False, {}),
    ]),
    'DA_Map01MiniStory04_Mission02': ('Regina Harper', [
        ('KEY_MAP01MINISTORY04_MISSION02_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP01MINISTORY04_MISSION02_OBJECTIVE02', 1, False, {}),
        ('KEY_MAP01MINISTORY04_MISSION02_OBJECTIVE03', 2, False, {'maxFitness': '60%'}),
    ]),
    'DA_Map01MiniStory04_Mission03': ('Regina Harper', [
        ('KEY_MAP01MINISTORY04_MISSION03_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01MiniStory04_Mission04': ('Regina Harper', [
        ('KEY_MAP01MINISTORY04_MISSION04_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01MiniStory04_Mission05': ('Regina Harper', [
        ('KEY_MAP01MINISTORY04_MISSION05_OBJECTIVE00', 0, False, {}),
        ('KEY_MAP01MINISTORY04_MISSION05_OBJECTIVE01', 1, False, {}),
        ('KEY_MAP01MINISTORY04_MISSION05_OBJECTIVE02', 2, False, {}),
        ('KEY_MAP01MINISTORY04_MISSION05_OBJECTIVE03', 3, False, {}),
        ('KEY_MAP01MINISTORY04_MISSION05_OBJECTIVE04', 4, False, {}),
        ('KEY_MAP01MINISTORY04_MISSION05_OBJECTIVE05', 5, False, {}),
    ]),
    'DA_Map01MiniStory05_Mission01': ('Mikael Anderson', [
        ('KEY_MAP01MINISTORY05_MISSION01_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP01MINISTORY05_MISSION01_OBJECTIVE02', 1, False, {}),
    ]),
    'DA_Map01MiniStory05_Mission02': ('Mikael Anderson', [
        ('KEY_MAP01MINISTORY05_MISSION02_OBJECTIVE01', 0, False, {'minFitness': '70%'}),
    ]),
    'DA_Map01MiniStory05_Mission03': ('Mikael Anderson', [
        ('KEY_MAP01MINISTORY05_MISSION03_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP01MINISTORY05_MISSION03_OBJECTIVE02', 1, False, {}),
        ('KEY_MAP01MINISTORY05_MISSION03_OBJECTIVE03', 2, True, {'maxCallDistance': '150 m'}),
    ]),
    'DA_Map01MiniStory05_Mission04': ('Mikael Anderson', [
        ('KEY_MAP01MINISTORY05_MISSION04_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map01MiniStoryEND_Mission01': ('Angel Hearth', [
        ('KEY_MAP01MINISTORYEND_MISSION01_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map02LevelMission01': ('', [
        ('KEY_MAP02LEVELMISSION01_OBJECTIVE01', 0, False, {'minEnergy': '205 J', 'maxEnergy': '230 J'}),
    ]),
    'DA_Map02LevelMission02': ('', [
        ('KEY_MAP02LEVELMISSION02_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP02LEVELMISSION02_OBJECTIVE02', 1, False, {}),
    ]),
    'DA_Map02LevelMission03': ('', [
        ('KEY_MAP02LEVELMISSION03_OBJECTIVE01', 0, False, {'timeFrom': '17:00', 'timeTo': '19:00'}),
        ('KEY_MAP02LEVELMISSION03_OBJECTIVE02', 1, False, {'timeFrom': '17:00', 'timeTo': '19:00'}),
    ]),
    'DA_Map02LevelMission04': ('', [
        ('KEY_MAP02LEVELMISSION04_OBJECTIVE01', 0, False, {'minStar': '5 stars'}),
    ]),
    'DA_Map02LevelMission05': ('', [
        ('KEY_MAP02LEVELMISSION05_OBJECTIVE01', 0, False, {'maxFitness': '50%'}),
    ]),
    'DA_Map02LevelMission06': ('', [
        ('KEY_MAP02LEVELMISSION06_OBJECTIVE01', 0, False, {'minStar': '4 stars'}),
    ]),
    'DA_Map02LevelMission07': ('', [
        ('KEY_MAP02LEVELMISSION07_OBJECTIVE01', 0, False, {'maxShotDistance': '200 m'}),
    ]),
    'DA_Map02LevelMission08': ('', [
        ('KEY_MAP02LEVELMISSION08_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP02LEVELMISSION08_OBJECTIVE02', 1, False, {}),
    ]),
    'DA_Map02LevelMission09': ('', [
        ('KEY_MAP02LEVELMISSION09_OBJECTIVE01', 0, False, {'timeFrom': '00:00', 'timeTo': '05:00'}),
        ('KEY_MAP02LEVELMISSION09_OBJECTIVE02', 1, False, {'timeFrom': '00:00', 'timeTo': '05:00'}),
        ('KEY_MAP02LEVELMISSION09_OBJECTIVE03', 2, False, {'timeFrom': '00:00', 'timeTo': '05:00'}),
    ]),
    'DA_Map02LevelMission10': ('', [
        ('KEY_MAP02LEVELMISSION10_OBJECTIVE01', 0, False, {'minShotDistance': '250 m'}),
    ]),
    'DA_Map02LevelMission11': ('', [
        ('KEY_MAP02LEVELMISSION11_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map02LevelMission12': ('', [
        ('KEY_MAP02LEVELMISSION12_OBJECTIVE01', 0, False, {'maxStar': '1 star'}),
    ]),
    'DA_Map02LevelMission13': ('', [
        ('KEY_MAP02LEVELMISSION13_OBJECTIVE01', 0, False, {'minFitness': '80%', 'maxFitness': '100%'}),
    ]),
    'DA_Map02LevelMission14': ('', [
        ('KEY_MAP02LEVELMISSION14_OBJECTIVE01', 0, False, {'minMass': '2,500 kg'}),
    ]),
    'DA_Map02LevelMission15': ('', [
        ('KEY_MAP02LEVELMISSION15_OBJECTIVE01', 0, False, {'minShotDistance': '150 m', 'timeFrom': '00:00', 'timeTo': '02:00'}),
    ]),
    'DA_Map02MiniStory00_Mission01': ('Angel Hearth', [
        ('KEY_MAP01MINISTORY00_MISSION01_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map02MiniStory01_Mission01': ('', [
        ('KEY_MAP02MINISTORY01_MISSION01_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP02MINISTORY01_MISSION01_OBJECTIVE02', 1, False, {'maxObjectInVicinityDistance': '300 m'}),
    ]),
    'DA_Map02MiniStory01_Mission02': ('Malachi Burnett', [
        ('KEY_MAP02MINISTORY01_MISSION02_OBJECTIVE01', 0, False, {'maxFitness': '60%'}),
        ('KEY_MAP02MINISTORY01_MISSION02_OBJECTIVE02', 1, False, {}),
        ('KEY_MAP02MINISTORY01_MISSION02_OBJECTIVE03', 2, True, {}),
    ]),
    'DA_Map02MiniStory01_Mission03': ('Malachi Burnett', [
        ('KEY_MAP02MINISTORY01_MISSION03_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map02MiniStory02_Mission01': ('Damian Underwood', [
        ('KEY_MAP02MINISTORY02_MISSION01_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP02MINISTORY02_MISSION01_OPTIONAL01', 1, True, {}),
        ('KEY_MAP02MINISTORY02_MISSION01_OPTIONAL02', 2, True, {'minShotDistance': '150 m'}),
    ]),
    'DA_Map02MiniStory02_Mission02': ('Damian Underwood', [
        ('KEY_MAP02MINISTORY02_MISSION02_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP02MINISTORY02_MISSION02_OBJECTIVE02', 1, False, {}),
        ('KEY_MAP02MINISTORY02_MISSION02_OBJECTIVE03', 2, False, {}),
        ('KEY_MAP02MINISTORY02_MISSION02_OPTIONAL01', 3, True, {'maxShotDistance': '50 m'}),
    ]),
    'DA_Map02MiniStory02_Mission03': ('Damian Underwood', [
        ('KEY_MAP02MINISTORY02_MISSION03_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP02MINISTORY02_MISSION03_OBJECTIVE02', 1, False, {'maxShotDistance': '50 m'}),
        ('KEY_MAP02MINISTORY02_MISSION03_OBJECTIVE03', 2, False, {}),
    ]),
    'DA_Map02MiniStory03_Mission01': ('Naomi Vess', [
        ('KEY_MAP02MINISTORY03_MISSION01_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP02MINISTORY03_MISSION01_OBJECTIVE02', 1, False, {}),
        ('KEY_MAP02MINISTORY03_MISSION01_OBJECTIVE03', 2, False, {}),
        ('KEY_MAP02MINISTORY03_MISSION01_OBJECTIVE04', 4, False, {}),
    ]),
    'DA_Map02MiniStory03_Mission02': ('Naomi Vess', [
        ('KEY_MAP02MINISTORY03_MISSION02_OBJECTIVE01', 0, False, {}),
    ]),
    'DA_Map02MiniStory03_Mission03': ('Naomi Vess', [
        ('KEY_MAP02MINISTORY03_MISSION03_OBJECTIVE01', 0, False, {}),
        ('KEY_MAP02MINISTORY03_MISSION03_OBJECTIVE02', 1, False, {}),
    ]),
    'DA_Map02MiniStoryEND_Mission01': ('Angel Hearth', [
        ('KEY_MAP02MINISTORYEND_MISSION01_OBJECTIVE01', 0, False, {}),
    ]),
}

def _story_key(asset):
    """Game order inside a mini story: Mission01_1, Mission01_2, Mission01, Mission02..."""
    m = re.search(r"_Mission(\d+)(?:_(\d+))?$", asset)
    return (int(m.group(1)), int(m.group(2)) if m.group(2) else 99) if m else (99, 99)

def _story_num(story):
    return 99 if story == "END" else int(story) if story.isdigit() else 98

def _order(missions):
    """Game order and groups: Missions first, then the Mini stories by the person who gives them."""
    owners = {}
    for m in missions:
        if m["story"] and m.get("owner"):
            owners.setdefault((m["map"], m["story"]), m["owner"])
    for m in missions:
        if m["story"]:
            m["owner"] = m.get("owner") or owners.get((m["map"], m["story"]), "")
    rank = {}
    for m in missions:
        if m["story"]:
            k = (m["map"], m["owner"])
            rank[k] = min(rank.get(k, 99), _story_num(m["story"]))
    def key(m):
        if not m["story"]:
            return (m["map"], 0, 0, 0, int(re.search(r"(\d+)$", m["asset"]).group(1)), 0)
        return (m["map"], 1, rank[(m["map"], m["owner"])], _story_num(m["story"])) + _story_key(m["asset"])
    missions.sort(key=key)
    for m in missions:
        m["group"] = "Mini stories · " + m["owner"] if m["story"] and m["owner"] else ("Mini stories" if m["story"] else "Missions")
    return missions

def build_catalog(paks):
    import woth2_paks as W
    pak = W.Pak(os.path.join(paks, "pakchunk0-Windows.pak"))
    text = {}
    for t in ("MissionsRelease", "MetagameRelease"):
        path = next((p for p in pak.files if p.endswith(f"/{t}/en-US/{t}.locres")), None)
        if path:
            for kv in W.parse_locres(pak.read(path)).values():
                text.update(kv)
    challenges, missions = [], []
    for toc in W.all_tocs(paks):
        for path, idx in toc.files.items():
            name = path.rsplit("/", 1)[-1]
            if not name.endswith(".uasset"):
                continue
            name = name[:-7]
            chal = "/Challenges/" in path and name.startswith("DA_MissionData_ChallengeSeries")
            mm = MISSION_ASSET_RE.match(name)
            if not (chal or mm):
                continue
            data = toc.read(idx)
            keys = sorted(set(k.decode() for k in re.findall(rb"KEY_[A-Z0-9_]+", data)))
            objectives = len(set(re.findall(rb"Mission\.Objective\.(\d+)\.Completed", data)))
            mp = re.search(r"(Map\d\d)", name)
            descs = [k for k in keys if k.endswith("_DESCRIPTION") and k in text]
            descs.sort(key=lambda k: not (mp and mp.group(1).upper() in k))      # the map's own text first
            desc = text[descs[0]] if descs else ""
            if chal:
                num = re.search(r"ChallengeSeries_?(\d+)", name).group(1)
                challenges.append({"asset": name, "num": int(num), "map": mp.group(1) if mp else "",
                                   "text": desc.rstrip("."), "tiers": _targets(data) or [1] * max(objectives, 1)})
            else:
                if name in HIDDEN_MISSIONS:
                    continue
                title = next((text[k] for k in keys if k.endswith("_NAME") and k in text), "")
                if not title:
                    continue                      # test / demo variants have no player-facing name
                kind = "Story" if "MiniStory" in name else "Map mission"
                story = re.search(r"MiniStory(\w+?)_Mission", name)
                owner, rules = MISSION_RULES.get(name, ("", None))
                if rules:                         # every objective in game order, with its numbers
                    olist = [{"text": _fill(text[k], vals), "tag": tag, "optional": opt} for k, tag, opt, vals in rules if k in text]
                    branches = BRANCHES.get(name) or [[o["tag"] for o in olist if not o["optional"]]]
                else:                             # a mission the table does not know (a new one after a patch)
                    olist = [{"text": _plain(text[k]), "tag": i, "optional": "_OPTIONAL" in k}
                             for i, k in enumerate(k for k in keys if re.search(r"_(OBJECTIVE|OPTIONAL)\d+$", k) and k in text)]
                    branches = [[o["tag"] for o in olist if not o["optional"]]] if olist else [[0]]
                missions.append({"asset": name, "map": mm.group(1), "kind": kind, "story": story.group(1) if story else "", "owner": owner,
                                 "title": title, "text": desc, "objectives": len(branches[0]) or 1, "branches": branches,
                                 "objective_list": olist, "objective_text": [o["text"] for o in olist if not o["optional"]]})
    challenges.sort(key=lambda c: (c["num"], c["map"]))
    return {"version": CATALOG_VERSION, "challenges": challenges, "missions": _order(missions)}

def catalog(save_path=None):
    """Challenge / mission list with names and tier targets: from the game files, cached in missions_en.json."""
    import woth2_paks as W
    paks = W.find_paks_dir(save_path)
    build = W.game_build(paks)
    try:
        with open(CATALOG_CACHE) as f:
            cat = json.load(f)
        if cat.get("version") == CATALOG_VERSION and (not build or cat.get("game") == build):   # a game patch rebuilds it
            return cat
    except (OSError, ValueError):
        cat = None
    if not paks:
        return cat or {"version": 0, "challenges": [], "missions": []}
    cat = build_catalog(paks)
    cat["game"] = build
    try:
        with open(CATALOG_CACHE, "w") as f:
            json.dump(cat, f, indent=0)
    except OSError:
        pass
    return cat

# ---------------------------------------------------------------- view
def overview(sf, cat):
    logs = read_logs(sf) if sf is not None else {}        # no save (console players): everything not started
    g = logs.get("GameData")
    chals = []
    for c in cat["challenges"]:
        st = g.state(c["asset"]) if g else {"state": "new"}
        tiers = sorted(c["tiers"])
        done = len(tiers) if st["state"] == "done" else st.get("done_objectives", 0)
        cur = min(done, len(tiers) - 1)
        chals.append({"id": c["asset"], "text": c["text"], "map": c["map"], "tiers": tiers, "tiers_done": done,
                      "state": st["state"], "progress": st.get("counter", 0) if st["state"] == "active" else (tiers[-1] if st["state"] == "done" else 0),
                      "target": tiers[cur]})
    mis = []
    for m in cat["missions"]:
        if m["asset"] in HIDDEN_MISSIONS:
            continue
        log = logs.get(m["map"])
        st = log.state(m["asset"]) if log else {"state": "new"}
        if st["state"] == "new" and log and m["asset"] + "_Helper" in log.active:
            st = {"state": "active", "done_objectives": 0}        # given by the NPC, not started yet
        olist = m.get("objective_list") or [{"text": t, "tag": i, "optional": False} for i, t in enumerate(m.get("objective_text", []))]
        branches = m.get("branches") or [[o["tag"] for o in olist if not o["optional"]] or [0]]
        done_tags = set(st.get("done_tags", range(st.get("done_objectives", 0))))
        # the way through the player is on (a mission with two endings): the one whose own objectives are done
        common = set.intersection(*(set(b) for b in branches))
        path = max(branches, key=lambda b: (len(done_tags & (set(b) - common)), -branches.index(b)))
        total = len(path) or 1
        n_done = total if st["state"] == "done" else min(len(done_tags & set(path)), total)
        nxt = next((o["text"] for o in olist if o["tag"] in path and o["tag"] not in done_tags), "")
        mis.append({"id": m["asset"], "map": m["map"], "kind": m["kind"], "story": m["story"], "owner": m.get("owner", ""),
                    "group": m.get("group") or ("Mini stories" if m["story"] else "Missions"), "title": m["title"], "text": m["text"],
                    "state": st["state"], "objectives": total, "objectives_done": n_done, "next": nxt if st["state"] != "done" else "",
                    "objective_text": [o["text"] for o in olist if o["tag"] in path],
                    "optional": [o["text"] for o in olist if o["optional"]]})
    return {"challenges": chals, "missions": mis}



# ---------------------------------------------------------------- locked part
_LOCKED = ('write_logs', 'complete', '_objective_state', '_board_entry', 'take_board_jobs')

def __getattr__(name):
    """The save-writing functions live in toybox_locked (encrypted in the released app, see vault.py)."""
    if name in _LOCKED:
        import vault
        return getattr(vault.locked("locked_missions"), name)
    raise AttributeError(name)
