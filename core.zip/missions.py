"""Challenges and missions: what the game's mission log says is finished, in progress or not started,
and completing any of them by hand.

Mission-log sections (MissionLogGameSystem 0xdb50a494 in Game_0/GameData = challenges, achievements,
codex unlocks; MissionLogWorldSubsystem 0xe1bddabd in Game_0/World_0/<Map> = that map's story missions):
  u32 1 | wrappers (``01 01 u32 len`` / ``01 u32 len`` / ``u32 1``; every len runs to the end of the section)
  u32 n | n x ACTIVE  entry: 01 01 len | FString class | FString asset | 01 01 len | FString class | FString asset | u32 len | state
  u32 m | m x FINISHED entry: 01 01 len | FString class | FString asset | FString "Mission.State.Finished.Completed"
Active state: the objectives' CappedInt32Counter (``01 01 09000000 01 04000000 i32 value``, the progress of the
CURRENT objective, it restarts at 0 for the next one) and one "Mission.Objective.<i>.Completed" tag per finished
objective. Challenge series = one mission whose objectives are the tiers; the tier targets are the last
``(05 03 | 04 05 01) i32 value 00000000`` run of the unversioned DA_MissionData_ChallengeSeries* asset.
Story missions come with a ``<asset>_Helper`` twin and each mini-story with a ``DA_<Map>_MissionFlow_MiniStoryXX_Helper``;
the game finishes them together, so complete() does the same.
Section 0xd3f5aacb in a map world = the mission currently tracked on that map.
"""
import json, os, re, struct

HERE = os.path.dirname(os.path.abspath(__file__))
CATALOG_CACHE = os.path.join(HERE, "missions_en.json")
CATALOG_VERSION = 2

LOG_SECTION = 0xDB50A494          # MissionLogGameSystem   (Game_0/GameData)
WORLD_LOG_SECTION = 0xE1BDDABD    # MissionLogWorldSubsystem (Game_0/World_0/<Map>)
FINISHED = "Mission.State.Finished.Completed"
CLASS_CHALLENGE = "BP_MissionData_ChallengeSeries_DataAsset_C"
CLASS_MISSION = "BP_MissionData_DataAsset_C"
MAPS = ("Map01", "Map02")

def _fs(b, p):
    n, = struct.unpack_from("<i", b, p); p += 4
    if n < 0:
        return b[p:p - 2 * n - 2].decode("utf-16-le"), p - 2 * n
    return b[p:p + n - 1].decode("utf-8", "replace"), p + n

def _fstring(s):
    e = s.encode() + b"\0"
    return struct.pack("<I", len(e)) + e

# ---------------------------------------------------------------- save side
class MissionLog:
    """One mission-log section. active: {asset: (class, raw entry bytes)}; finished: [(asset, class, raw entry)] in file
    order (the game logs some repeatable ones several times, keep every record as it is)."""
    def __init__(self, blob):
        self.blob = blob
        n = len(blob)
        if blob[:4] != b"\x01\x00\x00\x00":
            raise ValueError("unexpected mission-log header")
        p, self.lens = 4, []                     # offsets of the length fields that span to the end
        def span(q):                             # a length field at q that runs to the end -> its size, else 0
            if blob[q:q + 2] == b"\x01\x01" and q + 6 <= n and struct.unpack_from("<I", blob, q + 2)[0] == n - q - 6:
                return 6
            if q + 5 <= n and blob[q] == 1 and struct.unpack_from("<I", blob, q + 1)[0] == n - q - 5:
                return 5
            return 0
        while True:
            k = span(p)
            if k:
                self.lens.append((p + k - 4, p + k)); p += k
            elif blob[p:p + 4] == b"\x01\x00\x00\x00" and span(p + 4):
                p += 4                           # a nested layer, only when a real length field follows (else this
            else:                                # is "1 active mission" whose entry starts 01 01)
                break
        self.head = blob[:p]
        self.active = {}
        cnt, = struct.unpack_from("<I", blob, p); p += 4
        for _ in range(cnt):
            ln, = struct.unpack_from("<I", blob, p + 2)
            cls, q = _fs(blob, p + 6); name, q = _fs(blob, q)
            self.active[name] = (cls, blob[p:p + 6 + ln])
            p += 6 + ln
        self.finished = []
        cnt, = struct.unpack_from("<I", blob, p); p += 4
        for _ in range(cnt):
            ln, = struct.unpack_from("<I", blob, p + 2)
            cls, q = _fs(blob, p + 6); name, q = _fs(blob, q)
            self.finished.append((name, cls, blob[p:p + 6 + ln]))
            p += 6 + ln
        self.done = {f[0] for f in self.finished}
        if p != n:
            raise ValueError(f"mission log: {n - p} trailing bytes")

    def state(self, name):
        """-> dict(state='done'|'active'|'new', done_objectives, counter)"""
        if name in self.done:
            return {"state": "done"}
        if name in self.active:
            raw = self.active[name][1]
            i = raw.find(b"\x01\x01\x09\x00\x00\x00\x01\x04\x00\x00\x00")
            counter = struct.unpack_from("<i", raw, i + 11)[0] if i >= 0 else 0
            done = len(set(re.findall(rb"Mission\.Objective\.(\d+)\.Completed", raw)))
            return {"state": "active", "done_objectives": done, "counter": counter}
        return {"state": "new"}


    def build(self):
        body = bytearray(self.head)
        body += struct.pack("<I", len(self.active))
        for cls, raw in self.active.values():
            body += raw
        body += struct.pack("<I", len(self.finished))
        for _name, _cls, raw in self.finished:
            body += raw
        n = len(body)
        for at, after in self.lens:
            struct.pack_into("<I", body, at, n - after)
        return bytes(body)

def _sections(sf, part):
    import nrgs
    p = sf.part(part)
    seed, secs = nrgs.split_sections(p.data)
    return p, seed, secs

def read_logs(sf):
    """-> {"GameData": MissionLog, "Map01": MissionLog, ...}"""
    out = {}
    for key, part, h in [("GameData", "Game_0/GameData", LOG_SECTION)] + [(m, f"Game_0/World_0/{m}", WORLD_LOG_SECTION) for m in MAPS + ("Hub",)]:
        try:
            _p, _s, secs = _sections(sf, part)
        except KeyError:
            continue
        for sh, _v, blob in secs:
            if sh == h:
                out[key] = MissionLog(blob)
    return out


# ---------------------------------------------------------------- game-file side
TARGETS_RE = re.compile(rb"((?:(?:\x05\x03|\x04\x05\x01).{4}\x00{4})+)\xc1\x83\x2a\x9e$", re.S)
MISSION_ASSET_RE = re.compile(r"^DA_(Map\d\d)(LevelMission\d+|MiniStory\w+?_Mission\d+(?:_\d+)?)$")

def _targets(data):
    m = TARGETS_RE.search(data)
    if not m:
        return []
    run = m.group(1); out = []; p = 0
    while p < len(run):
        p += 2 if run[p] == 5 else 3
        out.append(struct.unpack_from("<i", run, p)[0]); p += 8
    return out

PLACEHOLDERS = {"minMass": "the required weight", "minStar": "the required", "maxDistance": "the required distance", "minDistance": "the required distance"}

def _plain(s):
    """Objective text with the UI's {value}|displayAs(unit) placeholders turned into words."""
    s = re.sub(r"\{(\w+)\}\|\s*displayAs\(ratingStars\)", lambda m: "the required stars" if "Star" in m.group(1) else "the required rating", s)
    s = re.sub(r"\{(\w+)\}(?:\|\s*displayAs\(\w+\))?", lambda m: PLACEHOLDERS.get(m.group(1), "the required amount"), s)
    return re.sub(r"\s+", " ", s).strip()

def build_catalog(paks):
    import woth2_paks as W
    pak = W.Pak(os.path.join(paks, "pakchunk0-Windows.pak"))
    text = {}
    for t in ("MissionsRelease", "MetagameRelease"):
        path = next((p for p in pak.files if p.endswith(f"/{t}/en-US/{t}.locres")), None)
        if path:
            for kv in W.parse_locres(pak.read(path)).values():
                text.update(kv)
    challenges, missions = [], []
    for toc in W.all_tocs(paks):
        for path, idx in toc.files.items():
            name = path.rsplit("/", 1)[-1]
            if not name.endswith(".uasset"):
                continue
            name = name[:-7]
            chal = "/Challenges/" in path and name.startswith("DA_MissionData_ChallengeSeries")
            mm = MISSION_ASSET_RE.match(name)
            if not (chal or mm):
                continue
            data = toc.read(idx)
            keys = sorted(set(k.decode() for k in re.findall(rb"KEY_[A-Z0-9_]+", data)))
            objectives = len(set(re.findall(rb"Mission\.Objective\.(\d+)\.Completed", data)))
            mp = re.search(r"(Map\d\d)", name)
            descs = [k for k in keys if k.endswith("_DESCRIPTION") and k in text]
            descs.sort(key=lambda k: not (mp and mp.group(1).upper() in k))      # the map's own text first
            desc = text[descs[0]] if descs else ""
            if chal:
                num = re.search(r"ChallengeSeries_?(\d+)", name).group(1)
                challenges.append({"asset": name, "num": int(num), "map": mp.group(1) if mp else "",
                                   "text": desc.rstrip("."), "tiers": _targets(data) or [1] * max(objectives, 1)})
            else:
                title = next((text[k] for k in keys if k.endswith("_NAME") and k in text), "")
                if not title:
                    continue                      # test / demo variants have no player-facing name
                kind = "Story" if "MiniStory" in name else "Map mission"
                story = re.search(r"MiniStory(\w+?)_Mission", name)
                objs = [_plain(text[k]) for k in keys if re.search(r"_OBJECTIVE\d+$", k) and k in text]
                missions.append({"asset": name, "map": mm.group(1), "kind": kind, "story": story.group(1) if story else "",
                                 "title": title, "text": desc, "objectives": max(objectives, 1), "objective_text": objs})
    challenges.sort(key=lambda c: (c["num"], c["map"]))
    missions.sort(key=lambda m: m["asset"])
    return {"version": CATALOG_VERSION, "challenges": challenges, "missions": missions}

def catalog(save_path=None):
    """Challenge / mission list with names and tier targets: from the game files, cached in missions_en.json."""
    import woth2_paks as W
    paks = W.find_paks_dir(save_path)
    build = W.game_build(paks)
    try:
        with open(CATALOG_CACHE) as f:
            cat = json.load(f)
        if cat.get("version") == CATALOG_VERSION and (not build or cat.get("game") == build):   # a game patch rebuilds it
            return cat
    except (OSError, ValueError):
        cat = None
    if not paks:
        return cat or {"version": 0, "challenges": [], "missions": []}
    cat = build_catalog(paks)
    cat["game"] = build
    try:
        with open(CATALOG_CACHE, "w") as f:
            json.dump(cat, f, indent=0)
    except OSError:
        pass
    return cat

# ---------------------------------------------------------------- view
def overview(sf, cat):
    logs = read_logs(sf)
    g = logs.get("GameData")
    chals = []
    for c in cat["challenges"]:
        st = g.state(c["asset"]) if g else {"state": "new"}
        tiers = sorted(c["tiers"])
        done = len(tiers) if st["state"] == "done" else st.get("done_objectives", 0)
        cur = min(done, len(tiers) - 1)
        chals.append({"id": c["asset"], "text": c["text"], "map": c["map"], "tiers": tiers, "tiers_done": done,
                      "state": st["state"], "progress": st.get("counter", 0) if st["state"] == "active" else (tiers[-1] if st["state"] == "done" else 0),
                      "target": tiers[cur]})
    mis = []
    for m in cat["missions"]:
        log = logs.get(m["map"])
        st = log.state(m["asset"]) if log else {"state": "new"}
        if st["state"] == "new" and log and m["asset"] + "_Helper" in log.active:
            st = {"state": "active", "done_objectives": 0}        # given by the NPC, not started yet
        mis.append({"id": m["asset"], "map": m["map"], "kind": m["kind"], "story": m["story"], "title": m["title"], "text": m["text"],
                    "state": st["state"], "objectives": m["objectives"], "objectives_done": m["objectives"] if st["state"] == "done" else st.get("done_objectives", 0),
                    "objective_text": m["objective_text"]})
    return {"challenges": chals, "missions": mis}



# ---------------------------------------------------------------- locked part
_LOCKED = ('write_logs', 'complete')

def __getattr__(name):
    """The save-writing functions live in toybox_locked (encrypted in the released app, see vault.py)."""
    if name in _LOCKED:
        import vault
        return getattr(vault.locked("locked_missions"), name)
    raise AttributeError(name)
