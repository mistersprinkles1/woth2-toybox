"""Where the core runs. Natively (CPython on Linux / Windows) everything is the plain os module. On Windows the
release runs the core as WebAssembly inside the signed Node runtime (wasm/host.mjs, Pyodide), so no unsigned
program file ever loads: there sys.platform is "emscripten", the Windows drives are mounted at /mnt/<letter>
and the few things Python can't do there (registry, process list, Oodle) come from the host's toybox_host module.
"""
import os, sys

EMSCRIPTEN = sys.platform == "emscripten"
WINDOWS = os.name == "nt" or (EMSCRIPTEN and os.environ.get("WOTH2_HOST_OS") == "windows")
_MOUNTED = EMSCRIPTEN and WINDOWS


def p(path):
    """A Windows path (C:\\x\\y or C:/x/y) -> a path this Python can open."""
    if _MOUNTED and isinstance(path, str) and len(path) >= 2 and path[1] == ":" and path[0].isalpha():
        return "/mnt/" + path[0].lower() + path[2:].replace("\\", "/")
    return path


def host(path):
    """A path this Python uses -> how Windows writes it (for paths shown in, or handed back to, the app)."""
    if _MOUNTED and isinstance(path, str) and path.startswith("/mnt/") and len(path) >= 6 and (len(path) == 6 or path[6] == "/"):
        return path[5].upper() + ":" + (path[6:] or "/").replace("/", "\\")
    return path


def reg_value(hive, key, name):
    """A Windows registry string value or None. hive: "HKCU" | "HKLM"."""
    if not WINDOWS:
        return None
    if _MOUNTED:
        import toybox_host
        v = toybox_host.reg_query(hive, key, name)
        return str(v) if v else None
    import winreg
    try:
        with winreg.OpenKey({"HKCU": winreg.HKEY_CURRENT_USER, "HKLM": winreg.HKEY_LOCAL_MACHINE}[hive], key) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return None


def tasklist(image):
    """Windows: tasklist output for one image name ("" when it can't be read)."""
    if _MOUNTED:
        import toybox_host
        return str(toybox_host.tasklist(image) or "")
    import subprocess
    try:
        return subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {image}", "/NH"], capture_output=True, text=True, timeout=10, creationflags=0x08000000).stdout
    except Exception:
        return ""


class _HostFile:
    """A file opened through the host (Node fs): no 2 GB limit (the WebAssembly Python's seek stops at 2^31)."""
    def __init__(self, path, mode):
        import toybox_host
        self._h = toybox_host
        self._fd = int(toybox_host.fopen(host(path) if WINDOWS else path, mode))
        self._pos = int(self._h.fsize(self._fd)) if "a" in mode else 0
        self.closed = False

    def seek(self, off, whence=0):
        self._pos = off if whence == 0 else self._pos + off if whence == 1 else int(self._h.fsize(self._fd)) + off
        return self._pos

    def tell(self):
        return self._pos

    def read(self, n=-1):
        if n is None or n < 0:
            n = max(0, int(self._h.fsize(self._fd)) - self._pos)
        out = self._h.fread(self._fd, self._pos, n)
        b = out.to_bytes() if hasattr(out, "to_bytes") else bytes(out)
        self._pos += len(b)
        return b

    def write(self, b):
        self._h.fwrite(self._fd, self._pos, bytes(b))
        self._pos += len(b)
        return len(b)

    def truncate(self, size=None):
        self._h.ftruncate(self._fd, self._pos if size is None else size)

    def close(self):
        if not self.closed:
            self._h.fclose(self._fd); self.closed = True

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


def open_big(path, mode="rb"):
    """open() for the game's multi-GB containers: the host's file access under WebAssembly."""
    if EMSCRIPTEN:
        return _HostFile(path, mode)
    return open(path, mode)
