"""Hunter + dog names in the save (free: no code needed).

The hunter's name is the Steam name the game stamped on every harvest (hunting log, GameData 0x49672E80) and on
every trophy / carcass record (World_0/<map> 0x197E791F) - the game keeps no separate "player name" setting, so
new harvests get the Steam name again. The dog's name is a field of the dog profile (GameData 0x3EEC2FCD).

Names are FStrings inside nested size-prefixed chunks ([u8 tag 1|2|3][u32 size], often in outer/inner pairs
where outer = inner + 5), so changing a name's length means fixing every chunk size around it. chunk_fields()
finds them: a u32 after [00 01 tag] whose span holds the name and pairs with an inner [tag size-5], ends exactly
where its parent ends, or is followed by sibling chunks that land on the parent's end (+ the inner of a pair).
"""
import re
import struct
import nrgs

HUNTINGLOG_SECTION = 0x49672E80
DOG_SECTION = 0x3EEC2FCD
TROPHY_SECTION = 0x197E791F
DOG_PROFILE = b"DogProfileConfigDataAsset\0"
MAX_LEN = 32

def _u32(b, o):
    return struct.unpack_from("<I", b, o)[0]

def _chain(b, q, end, hops=64):
    """True when sibling chunks starting at q ([u32 1] [u8 1][u8 tag][u32 size]) land exactly on end."""
    for _ in range(hops):
        if q == end:
            return True
        if q + 6 > end:
            return False
        if _u32(b, q) == 1 and q + 10 <= end:
            q += 4
        if b[q] == 1 and b[q + 1] in (1, 2, 3):
            q = q + 6 + _u32(b, q + 2)
            continue
        return False
    return False

def _candidates(b):
    """(offset, end) of every u32 right after a tag byte 1|2|3 whose span fits in b (numpy, once per blob)."""
    import numpy as np
    a = np.frombuffer(b, dtype=np.uint8)
    if len(a) < 6:
        return np.zeros(0, np.int64), np.zeros(0, np.int64)
    f = np.arange(2, len(a) - 3, dtype=np.int64)
    f = f[(a[f - 1] >= 1) & (a[f - 1] <= 3)]
    v = a[f].astype(np.int64) | a[f + 1].astype(np.int64) << 8 | a[f + 2].astype(np.int64) << 16 | a[f + 3].astype(np.int64) << 24
    end = f + 4 + v
    keep = end <= len(a)
    return f[keep], end[keep]

def chunk_fields(b, o, n, cands=None):
    """Offsets of the chunk-size u32s whose chunks hold b[o:o+n], outermost first."""
    import numpy as np
    cf, ce = cands if cands is not None else _candidates(b)
    sel = (cf < o - 3) & (ce >= o + n)
    acc = [(None, len(b))]
    for f, end in zip(cf[sel].tolist(), ce[sel].tolist()):
        if end > acc[-1][1]:
            continue
        v = end - f - 4
        head = f >= 3 and b[f - 2] == 1 and b[f - 3] == 0               # [00 01 tag size]: an outer / single chunk
        inner = b[f - 2] == 0 and f >= 8 and b[f - 6] in (1, 2, 3) and _u32(b, f - 5) == v + 5    # [.. tag size+5][tag size]
        if inner:
            ok = True
        elif head:
            ok = (f + 9 <= len(b) and b[f + 4] in (1, 2, 3) and _u32(b, f + 5) == v - 5) or end == acc[-1][1] or _chain(b, end, acc[-1][1])
        else:
            ok = False
        if ok:
            acc.append((f, end))
    return [f for f, _ in acc[1:]]

def _replace(b, o, old_fs, new_fs):
    return _replace_all(b, old_fs, new_fs, [o])[0]

def _replace_all(b, old_fs, new_fs, offs=None):
    """Every occurrence (or the given offsets). The fields are found on the untouched blob, then all edits
    are applied last first so earlier offsets stay put; a size grows by d for each name it holds."""
    if offs is None:
        offs = []
        o = b.find(old_fs)
        while o >= 0:
            offs.append(o); o = b.find(old_fs, o + 1)
    if not offs:
        return b, 0
    cands = _candidates(b)
    d = len(new_fs) - len(old_fs)
    grow = {}
    for o in offs:
        for f in chunk_fields(b, o, len(old_fs), cands):
            grow[f] = grow.get(f, 0) + d
    out = bytearray(b)
    for f, g in grow.items():
        struct.pack_into("<I", out, f, _u32(b, f) + g)
    for o in sorted(offs, reverse=True):
        out[o:o + len(old_fs)] = new_fs
    return bytes(out), len(offs)

_HUNTER_BEFORE = re.compile(rb"(GameDifficulty\.Overall\.\w+\x00|[\x04-\x0b]\x00\x00\x00(?:Map\d\d|Hub|Tutorial\d\d)\x00....)$", re.S)

def _hunter_offsets(b, old_fs):
    """Only where a record keeps the hunter (after the map name + 4 bytes, or after the difficulty tag):
    a short old name could also turn up elsewhere by chance."""
    offs = []
    o = b.find(old_fs)
    while o >= 0:
        if _HUNTER_BEFORE.search(b[max(0, o - 48):o]):
            offs.append(o)
        o = b.find(old_fs, o + 1)
    return offs

def _check(name):
    name = (name or "").strip()
    if not name:
        raise ValueError("The name can't be empty.")
    if len(name) > MAX_LEN:
        raise ValueError(f"Keep the name to {MAX_LEN} letters or fewer.")
    try:
        name.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError("Use plain letters, numbers and symbols (no accents or emoji).")
    return name

def _sections(sf, part):
    seed, secs = nrgs.split_sections(sf.part(part).data)
    return seed, [list(s) for s in secs]

def _world_parts(sf):
    return [e[1] for e in sf.entries if e[2] == "v2" and e[1].startswith("Game_0/World_0/")]

def read_names(sf):
    """-> {"hunters": {name: count}, "dog": name or None}"""
    hunters, dog = {}, None
    _seed, secs = _sections(sf, "Game_0/GameData")
    for h, _v, b in secs:
        if h == HUNTINGLOG_SECTION:
            import stats
            try:
                for r in stats.parse_hunting_log(b)[0]:
                    hunters[r.hunter] = hunters.get(r.hunter, 0) + 1
            except Exception:
                pass
        elif h == DOG_SECTION:
            i = b.find(DOG_PROFILE)
            if i >= 0:
                p = i + len(DOG_PROFILE)
                _prof, p = nrgs.read_fstring(b, p)
                dog, _p = nrgs.read_fstring(b, p)
    return {"hunters": hunters, "dog": dog}

def rename_dog(sf, new):
    """-> notes. Changes the parsed SaveFile in memory."""
    new = _check(new)
    seed, secs = _sections(sf, "Game_0/GameData")
    for s in secs:
        if s[0] != DOG_SECTION:
            continue
        b = s[2]
        i = b.find(DOG_PROFILE)
        if i < 0:
            break
        p = i + len(DOG_PROFILE)
        _prof, p = nrgs.read_fstring(b, p)
        old, end = nrgs.read_fstring(b, p)
        if old == new:
            return [f"the dog is already called {new}"]
        s[2] = _replace(b, p, b[p:end], nrgs.fstring(new))
        sf.part("Game_0/GameData").data = nrgs.build_sections(seed, [tuple(x) for x in secs])
        return [f"dog renamed: {old} -> {new}"]
    raise ValueError("No dog found in this save yet.")

def rename_hunter(sf, old, new):
    """Rename the hunter on every harvest + trophy record. -> notes"""
    new = _check(new)
    if old == new:
        return ["nothing to change"]
    old_fs, new_fs = nrgs.fstring(old), nrgs.fstring(new)
    total = 0
    for part, wanted in [("Game_0/GameData", HUNTINGLOG_SECTION)] + [(w, TROPHY_SECTION) for w in _world_parts(sf)]:
        seed, secs = _sections(sf, part)
        n_part = 0
        for s in secs:
            if s[0] == wanted and old_fs in s[2]:
                s[2], n = _replace_all(s[2], old_fs, new_fs, _hunter_offsets(s[2], old_fs)); n_part += n
        if n_part:
            sf.part(part).data = nrgs.build_sections(seed, [tuple(x) for x in secs])
            total += n_part
    if not total:
        raise ValueError(f"No harvests by {old} in this save.")
    return [f"hunter renamed on {total} harvest / trophy records: {old} -> {new}",
            "new harvests will still get your Steam name (the game takes it from Steam)"]
