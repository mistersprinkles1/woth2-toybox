"""Hunter + dog names in the save (free: no code needed).

The hunter's name is the Steam name the game stamped on every harvest (hunting log, GameData 0x49672E80) and on
every trophy / carcass record (World_0/<map> 0x197E791F) - the game keeps no separate "player name" setting, so
new harvests get the Steam name again. The dog's name is a field of the dog profile (GameData 0x3EEC2FCD).

Names are FStrings inside nested size-prefixed chunks ([u8 tag 1|2|3][u32 size], often in outer/inner pairs
where outer = inner + 5), so changing a name's length means fixing every chunk size around it. chunk_fields()
finds them: a u32 after [00 01 tag] whose span holds the name and pairs with an inner [tag size-5], ends exactly
where its parent ends, or is followed by sibling chunks that land on the parent's end (+ the inner of a pair).
"""
import re
import struct
import nrgs
import i18n

HUNTINGLOG_SECTION = 0x49672E80
DOG_SECTION = 0x3EEC2FCD
TROPHY_SECTION = 0x197E791F
DOG_PROFILE = b"DogProfileConfigDataAsset\0"
MAX_LEN = 32

def _u32(b, o):
    return struct.unpack_from("<I", b, o)[0]

def _chain(b, q, end, hops=64):
    """True when sibling chunks starting at q ([u32 1] [u8 1][u8 tag][u32 size]) land exactly on end."""
    for _ in range(hops):
        if q == end:
            return True
        if q + 6 > end:
            return False
        if _u32(b, q) == 1 and q + 10 <= end:
            q += 4
        if b[q] == 1 and b[q + 1] in (1, 2, 3):
            q = q + 6 + _u32(b, q + 2)
            continue
        return False
    return False

def _candidates(b):
    """(offset, end) of every u32 right after a tag byte 1|2|3 whose span fits in b (numpy, once per blob)."""
    import numpy as np
    a = np.frombuffer(b, dtype=np.uint8)
    if len(a) < 6:
        return np.zeros(0, np.int64), np.zeros(0, np.int64)
    f = np.arange(2, len(a) - 3, dtype=np.int64)
    f = f[(a[f - 1] >= 1) & (a[f - 1] <= 3)]
    v = a[f].astype(np.int64) | a[f + 1].astype(np.int64) << 8 | a[f + 2].astype(np.int64) << 16 | a[f + 3].astype(np.int64) << 24
    end = f + 4 + v
    keep = end <= len(a)
    return f[keep], end[keep]

def chunk_fields(b, o, n, cands=None):
    """Offsets of the chunk-size u32s whose chunks hold b[o:o+n], outermost first."""
    import numpy as np
    cf, ce = cands if cands is not None else _candidates(b)
    sel = (cf < o - 3) & (ce >= o + n)
    acc = [(None, len(b))]
    for f, end in zip(cf[sel].tolist(), ce[sel].tolist()):
        if end > acc[-1][1]:
            continue
        v = end - f - 4
        head = f >= 3 and b[f - 2] == 1 and b[f - 3] == 0               # [00 01 tag size]: an outer / single chunk
        inner = b[f - 2] == 0 and f >= 8 and b[f - 6] in (1, 2, 3) and _u32(b, f - 5) == v + 5    # [.. tag size+5][tag size]
        if inner:
            ok = True
        elif head:
            ok = (f + 9 <= len(b) and b[f + 4] in (1, 2, 3) and _u32(b, f + 5) == v - 5) or end == acc[-1][1] or _chain(b, end, acc[-1][1])
        else:
            ok = False
        if ok:
            acc.append((f, end))
    return [f for f, _ in acc[1:]]

def _replace(b, o, old_fs, new_fs):
    return _replace_all(b, old_fs, new_fs, [o])[0]

def _replace_all(b, old_fs, new_fs, offs=None):
    """Every occurrence (or the given offsets). The fields are found on the untouched blob, then all edits
    are applied last first so earlier offsets stay put; a size grows by d for each name it holds."""
    if offs is None:
        offs = []
        o = b.find(old_fs)
        while o >= 0:
            offs.append(o); o = b.find(old_fs, o + 1)
    if not offs:
        return b, 0
    cands = _candidates(b)
    d = len(new_fs) - len(old_fs)
    grow = {}
    for o in offs:
        for f in chunk_fields(b, o, len(old_fs), cands):
            grow[f] = grow.get(f, 0) + d
    out = bytearray(b)
    for f, g in grow.items():
        struct.pack_into("<I", out, f, _u32(b, f) + g)
    for o in sorted(offs, reverse=True):
        out[o:o + len(old_fs)] = new_fs
    return bytes(out), len(offs)

_HUNTER_BEFORE = re.compile(rb"(GameDifficulty\.Overall\.\w+\x00|[\x04-\x0b]\x00\x00\x00(?:Map\d\d|Hub|Tutorial\d\d)\x00....)$", re.S)

def _hunter_offsets(b, old_fs):
    """Only where a record keeps the hunter (after the map name + 4 bytes, or after the difficulty tag):
    a short old name could also turn up elsewhere by chance."""
    offs = []
    o = b.find(old_fs)
    while o >= 0:
        if _HUNTER_BEFORE.search(b[max(0, o - 48):o]):
            offs.append(o)
        o = b.find(old_fs, o + 1)
    return offs

def _check(name):
    name = (name or "").strip()
    if not name:
        raise ValueError(i18n.t("The name can't be empty."))
    if len(name) > MAX_LEN:
        raise ValueError(i18n.t("Keep the name to {n} letters or fewer.").format(n=MAX_LEN))
    try:
        name.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError(i18n.t("Use plain letters, numbers and symbols (no accents or emoji)."))
    return name

def _sections(sf, part):
    seed, secs = nrgs.split_sections(sf.part(part).data)
    return seed, [list(s) for s in secs]

def _world_parts(sf):
    return [e[1] for e in sf.entries if e[2] == "v2" and e[1].startswith("Game_0/World_0/")]

def read_names(sf):
    """-> {"hunters": {name: count}, "dog": name or None}"""
    hunters, dog, levels = {}, None, None
    _seed, secs = _sections(sf, "Game_0/GameData")
    for h, _v, b in secs:
        if h == HUNTINGLOG_SECTION:
            import stats
            try:
                for r in stats.parse_hunting_log(b)[0]:
                    hunters[r.hunter] = hunters.get(r.hunter, 0) + 1
            except Exception:
                pass
        elif h == DOG_SECTION:
            i = b.find(DOG_PROFILE)
            if i >= 0:
                p = i + len(DOG_PROFILE)
                _prof, p = nrgs.read_fstring(b, p)
                dog, _p = nrgs.read_fstring(b, p)
                try:
                    levels = dog_levels(dog_fields(b))
                except Exception:
                    levels = None
    return {"hunters": hunters, "dog": dog, "dog_levels": levels}

# The dog's levels (GameData 0x3EEC2FCD, FDogProfileSerialized): after the profile + name FStrings come 3 bools
# (u32 each), focus ratio (f32), bonding XP (i32), the trait count (u32) and one chunk [01 01 u32 size] per trait:
# tag FString, isHidden (u32 bool), potential level (u8), XP (i32). The game keeps no level: it counts the
# thresholds of the story dog profile (DA_DogProfile_FoxhoundAmerican_Story) the XP has reached (DogProfile
# GetBondingLevel / GetTraitLevel), and stops the XP at the top one (a fully raised dog reads 1200 / 600).
DOG_BONDING_XP = (100, 250, 400, 650, 900, 1200)
DOG_SKILL_XP = (100, 200, 300, 400, 500, 600)
DOG_SKILLS = {"Dog.Traits.Hunting.Scent.SearchAndQuartering": "Search and quartering",
              "Dog.Traits.Hunting.Scent.BloodTrailing": "Blood tracking",
              "Dog.Traits.Hunting.Obedience.FollowingAllTheCommands": "Obedience"}

def _level(xp, steps):
    return sum(1 for s in steps if xp >= s)

def dog_fields(b):
    """-> {"profile", "name", "bonding_off", "bonding_xp", "traits": [{"tag", "hidden", "potential", "xp", "xp_off"}]}
    for the dog section bytes, or None when the save has no dog yet."""
    i = b.find(DOG_PROFILE)
    if i < 0:
        return None
    p = i + len(DOG_PROFILE)
    prof, p = nrgs.read_fstring(b, p)
    name, p = nrgs.read_fstring(b, p)
    bond_off = p + 16
    bond = struct.unpack_from("<i", b, bond_off)[0]
    n = _u32(b, p + 20)
    p += 24
    traits = []
    for _ in range(n):
        if b[p] != 1 or b[p + 1] not in (1, 2, 3):
            raise ValueError("dog trait list is laid out in an unknown way")
        end = p + 6 + _u32(b, p + 2)
        tag, q = nrgs.read_fstring(b, p + 6)
        if end - q != 9:
            raise ValueError("dog trait is laid out in an unknown way")
        hidden, pot, xp = struct.unpack_from("<IBi", b, q)
        traits.append({"tag": tag, "hidden": hidden, "potential": pot, "xp": xp, "xp_off": q + 5})
        p = end
    if p != len(b):
        raise ValueError("dog section is laid out in an unknown way")
    return {"profile": prof, "name": name, "bonding_off": bond_off, "bonding_xp": bond, "traits": traits}

def dog_levels(f):
    """Plain view of dog_fields(): bonding + the hunting skills shown in the game's dog screen."""
    if not f:
        return None
    skills = [{"name": DOG_SKILLS[t["tag"]], "level": _level(t["xp"], DOG_SKILL_XP), "xp": t["xp"]}
              for t in f["traits"] if t["tag"] in DOG_SKILLS]
    order = list(DOG_SKILLS.values())
    skills.sort(key=lambda s: order.index(s["name"]))
    lv = _level(f["bonding_xp"], DOG_BONDING_XP)
    return {"bonding": lv, "bonding_xp": f["bonding_xp"], "skills": skills, "top": len(DOG_BONDING_XP),
            "maxed": lv == len(DOG_BONDING_XP) and len(skills) == len(DOG_SKILLS)
                     and all(s["level"] == len(DOG_SKILL_XP) for s in skills)}

def rename_dog(sf, new):
    """-> notes. Changes the parsed SaveFile in memory."""
    new = _check(new)
    seed, secs = _sections(sf, "Game_0/GameData")
    for s in secs:
        if s[0] != DOG_SECTION:
            continue
        b = s[2]
        i = b.find(DOG_PROFILE)
        if i < 0:
            break
        p = i + len(DOG_PROFILE)
        _prof, p = nrgs.read_fstring(b, p)
        old, end = nrgs.read_fstring(b, p)
        if old == new:
            return [i18n.t("the dog is already called {name}").format(name=new)]
        s[2] = _replace(b, p, b[p:end], nrgs.fstring(new))
        sf.part("Game_0/GameData").data = nrgs.build_sections(seed, [tuple(x) for x in secs])
        return [i18n.t("dog renamed: {old} -> {new}").format(old=old, new=new)]
    raise ValueError(i18n.t("No dog found in this save yet."))

def rename_hunter(sf, old, new):
    """Rename the hunter on every harvest + trophy record. -> notes"""
    new = _check(new)
    if old == new:
        return [i18n.t("nothing to change")]
    old_fs, new_fs = nrgs.fstring(old), nrgs.fstring(new)
    total = 0
    for part, wanted in [("Game_0/GameData", HUNTINGLOG_SECTION)] + [(w, TROPHY_SECTION) for w in _world_parts(sf)]:
        seed, secs = _sections(sf, part)
        n_part = 0
        for s in secs:
            if s[0] == wanted and old_fs in s[2]:
                s[2], n = _replace_all(s[2], old_fs, new_fs, _hunter_offsets(s[2], old_fs)); n_part += n
        if n_part:
            sf.part(part).data = nrgs.build_sections(seed, [tuple(x) for x in secs])
            total += n_part
    if not total:
        raise ValueError(i18n.t("No harvests by {name} in this save.").format(name=old))
    return [i18n.t("hunter renamed on {n} harvest / trophy records: {old} -> {new}").format(n=total, old=old, new=new),
            i18n.t("new harvests will still get your Steam name (the game takes it from Steam)")]
