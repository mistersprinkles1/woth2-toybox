"""Energy of every load at range, flown the way the game flies its projectiles (patch 1.3 exe: SimulateBulletDrop /
the in-flight step / GetEnergy):
- velocity Verlet with lagged drag: p += v dt + a dt^2 / 2; a' = drag(old v) + gravity; v += (a + a') dt / 2; the first
  step starts with a = 0; dt = 1/60 s (a real shot);
- drag = 1/2 x air density x v^2 x area x coefficient of form x Cd, where Cd = table[int(Mach x 40)] (no blending)
  from the game's own 8 drag tables (ballistics_drag.json; CurveType picks the table: 0 = G1, 7 = round shot);
- air: 20 C, dry, sea level (density 1.2041 kg/m3, speed of sound 343.42 m/s), the game's fixed setting; only wind
  and the height of the ground change it in game;
- energy = 1/2 m v^2, with the speed blended inside the step where the range is crossed.
Area and coefficient of form are stored in each DA_Ballistics_*."""
import bisect, json, math, os, struct

# the game's drag tables (204 values each, Mach 0 to 5.075 in steps of 0.025); the textbook G1/GS below only if missing
try:
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "ballistics_drag.json"), encoding="utf-8") as _f:
        GAME_TABLES = {int(k): v for k, v in json.load(_f).items()}
except (OSError, ValueError):
    GAME_TABLES = {}

G1 = [(0.00, 0.2629), (0.05, 0.2558), (0.10, 0.2487), (0.15, 0.2413), (0.20, 0.2344), (0.25, 0.2278), (0.30, 0.2214),
      (0.35, 0.2155), (0.40, 0.2104), (0.45, 0.2061), (0.50, 0.2032), (0.55, 0.2020), (0.60, 0.2034), (0.70, 0.2165),
      (0.725, 0.2230), (0.75, 0.2313), (0.775, 0.2417), (0.80, 0.2546), (0.825, 0.2706), (0.85, 0.2901), (0.875, 0.3136),
      (0.90, 0.3415), (0.925, 0.3734), (0.95, 0.4084), (0.975, 0.4448), (1.0, 0.4805), (1.025, 0.5136), (1.05, 0.5427),
      (1.075, 0.5677), (1.10, 0.5883), (1.125, 0.6053), (1.15, 0.6191), (1.20, 0.6393), (1.25, 0.6518), (1.30, 0.6589),
      (1.35, 0.6621), (1.40, 0.6625), (1.45, 0.6607), (1.50, 0.6573), (1.55, 0.6528), (1.60, 0.6474), (1.65, 0.6413),
      (1.70, 0.6347), (1.75, 0.6280), (1.80, 0.6210), (1.85, 0.6141), (1.90, 0.6072), (1.95, 0.6003), (2.00, 0.5934),
      (2.05, 0.5867), (2.10, 0.5804), (2.15, 0.5743), (2.20, 0.5685), (2.25, 0.5630), (2.30, 0.5577), (2.35, 0.5527),
      (2.40, 0.5481), (2.45, 0.5438), (2.50, 0.5397), (2.60, 0.5325), (2.70, 0.5264), (2.80, 0.5211), (2.90, 0.5168),
      (3.00, 0.5133), (3.10, 0.5105), (3.20, 0.5084), (3.30, 0.5067), (3.40, 0.5054), (3.50, 0.5040), (3.60, 0.5030),
      (3.70, 0.5022), (3.80, 0.5016), (3.90, 0.5010), (4.00, 0.5006), (4.20, 0.4998), (4.40, 0.4995), (4.60, 0.4992),
      (4.80, 0.4990), (5.00, 0.4988)]
# GS: round shot (shotgun pellets: CurveType 7 in their files)
GS = [(0.00, 0.4662), (0.05, 0.4689), (0.10, 0.4717), (0.15, 0.4745), (0.20, 0.4772), (0.25, 0.4800), (0.30, 0.4827),
      (0.35, 0.4852), (0.40, 0.4882), (0.45, 0.4920), (0.50, 0.4970), (0.55, 0.5044), (0.60, 0.5153), (0.65, 0.5299),
      (0.70, 0.5507), (0.75, 0.5797), (0.80, 0.6174), (0.85, 0.6662), (0.90, 0.7253), (0.95, 0.7881), (1.00, 0.8460),
      (1.05, 0.8933), (1.10, 0.9268), (1.15, 0.9502), (1.20, 0.9684), (1.25, 0.9822), (1.30, 0.9930), (1.35, 1.0010),
      (1.40, 1.0071), (1.50, 1.0148), (1.60, 1.0189), (1.70, 1.0206), (1.80, 1.0206), (1.90, 1.0197), (2.00, 1.0183),
      (2.50, 1.0110), (3.00, 1.0044), (4.00, 0.9930), (5.00, 0.9850)]
TABLES = {0: G1, 7: GS}
# 20 C dry air at sea level, as the game sets it (UNRGBallistics atmosphere, h = 0)
RHO, SOUND, G = 1.2041180328059726, 343.42, 9.80665
DT = 1 / 60                                  # BP_BallisticsSubsystem SimulationDelta


def cd(mach, curve=0):
    G_ = GAME_TABLES.get(curve) or GAME_TABLES.get(0)
    if G_:
        return G_[min(max(int(mach * 40.0), 0), len(G_) - 1)]
    T = TABLES.get(curve, G1)
    i = bisect.bisect_right([m for m, _ in T], mach)
    if i <= 0: return T[0][1]
    if i >= len(T): return T[-1][1]
    (m0, c0), (m1, c1) = T[i - 1], T[i]
    return c0 + (c1 - c0) * (mach - m0) / (m1 - m0)

def drag_values(dat, diameter_cm, speed_cms):
    """(area m2, coefficient of form, curve type) from a DA_Ballistics_* export. After the speed double come (each
    only when set): UseFormFactor u8, FormFactor f64, BallisticCoefficient f64, CurveType u8; then
    CrossSectionalArea (3 x f64), SectionalDensity f64, CoefficientOfForm f64."""
    p = dat.find(struct.pack("<d", speed_cms))
    if p < 0: return None
    p += 8
    want = math.pi * (diameter_cm / 100.0) ** 2 / 4
    for q in range(p, min(p + 40, len(dat) - 48)):
        area, = struct.unpack_from("<d", dat, q)
        if abs(area - want) <= want * 0.02:
            gap = q - p
            curve = dat[q - 1] if gap % 8 == 2 or (gap % 8 == 1 and gap == 1 and dat[p] > 1) else 0
            cof, = struct.unpack_from("<d", dat, q + 32)
            if 0.05 < cof < 100: return area, cof, curve
    return None

def energies(kg, v0, area, cof, ranges, curve=0, dt=DT):
    """{range m: (energy J, speed m/s)} for a shot fired level from the muzzle; range is along the bore."""
    out = {}; todo = sorted(ranges); k = 0
    while k < len(todo) and todo[k] <= 0:
        out[todo[k]] = (0.5 * kg * v0 * v0, v0); k += 1
    x = z = 0.0; vx, vz = float(v0), 0.0; ax = az = 0.0; t = 0.0
    while k < len(todo) and t < 30.0:
        nx = x + vx * dt + 0.5 * ax * dt * dt; nz = z + vz * dt + 0.5 * az * dt * dt
        sp = math.hypot(vx, vz)
        if sp <= 0: break
        a = 0.5 * RHO * sp * sp * area * cof * cd(sp / SOUND, curve) / kg
        nax = -a * vx / sp; naz = -a * vz / sp - G
        nvx = vx + 0.5 * (ax + nax) * dt; nvz = vz + 0.5 * (az + naz) * dt
        while k < len(todo) and nx >= todo[k]:
            f = (todo[k] - x) / (nx - x) if nx > x else 1.0
            ux = vx + (nvx - vx) * f; uz = vz + (nvz - vz) * f
            v2 = ux * ux + uz * uz
            out[todo[k]] = (0.5 * kg * v2, math.sqrt(v2)); k += 1
        x, z, vx, vz, ax, az = nx, nz, nvx, nvz, nax, naz; t += dt
    return out

AMMO_TYPES = ("Bullet", "Slug", "Shot", "Arrow", "Bolt")

def hit_energy_maps(paks_dir):
    """The game's hit-energy window per animal weight class and ammo type: {class: {type: (low J, high J)}} from
    DA_HealthObjectEnergyMap_<class> (u32 count, then FName EAmmunitionType + two f64). Below the window the hit
    shows as low energy, inside it as optimal. Plus {subspecies: class} from each DA_AnimalSubspecies_*."""
    import re, woth2_paks as paks, zenpkg
    maps = {}; animals = {}
    for t in paks.all_tocs(paks_dir):
        for f, i in t.files.items():
            b = f.rsplit("/", 1)[-1]
            m = re.match(r"DA_HealthObjectEnergyMap_([\w+-]+)\.uasset$", b)
            if m and "Tutorial" not in b and "Player" not in b and "Vehicle" not in b:
                z = zenpkg.ZenPackage(t.read(i)); dat = z.export_data[0]
                n, = struct.unpack_from("<I", dat, 6); p = 10; out = {}
                for _ in range(n):
                    k, _num, lo, hi = struct.unpack_from("<IIdd", dat, p); p += 24
                    nm = z.name(k)
                    if nm.startswith("EAmmunitionType::"): out[nm.split("::")[1]] = (lo, hi)
                maps[m.group(1)] = out
            m = re.match(r"DA_AnimalSubspecies_(\w+)\.uasset$", b)
            if m:
                c = re.findall(rb"DA_HealthObjectEnergyMap_([\w+-]+)", t.read(i))
                if c: animals[m.group(1)] = c[0].decode()
    return maps, animals
