"""Trophy score and 1-5 stars the way the game rates an animal.

The game measures a trophy (BP_TrophyMeasurement_*: antler/horn lengths, spreads, circumferences, skull
size, body length or weight) and the score is the SUM of those measurements. Stars come from the 4
thresholds in DA_TrophyRequirements_<species>[_<sex>] (two are misspelled in the game files:
BP_TrophyRequiurements_Antilocapra..., DA_TrophyRequierements_Syncerus...): below the first = 1 star,
at/above the 4th = 5 stars.

How the game computes it (decompiled from WOTH2-Win64-Shipping.exe, see re/):
* growth  t = clamp((age x fitness - 0.1 x initialAge) / (maxAge - 0.1 x initialAge), 0, 1)   (FUN_1456d9f50;
  initialAge 1, the 0.1 is a float constant in the exe)
* weight  = clamp(min + (max - min) x t) with the range from BP_BodyConfig_<species>_<M|F> (m_weightRange)
* WeightGrams score = int(kg x 1000 / m_scoreMultiplier); Weight = int(kg x m_scoreMultiplier);
  SkullLength / SkullWidth / BodyLength = int(lerp(range, t) x m_scoreMultiplier), ranges and multipliers from
  BP_TrophyMeasurement_<species>_<kind>[_M|_F]. These are EXACT (checked against every measured kill).
* antlers / horns / tusks are measured on the posed 3D trophy skeleton (sum of bone-to-bone distances along
  each chain, FUN_1456dba80), driven by the BS_* blend values: that needs the engine's animation system, so
  for those the score is predicted as below and shown with the range it can land in.

Live animals have no measurements yet, so the score is predicted from what drives it:
* weight-scored animals (birds, hares, wolverines, honey badgers: WeightGrams; zebra / ostrich: Weight):
  score = factor x weight, and weight = W0 + k x age x fitness per species and sex. Both are exact; they
  are learnt from the save's own harvest log and kill records (every record keeps age, fitness, weight).
  Example: turkey hen 2.40 kg + 0.915 kg per age-fitness, x 20.
* everything else (racks, horns, tusks, skulls, body length): a per-species curve from the rack size
  (share of the species' biggest, the app's `size`) to points, fitted on the save's measured trophies;
  species with too few of them use one shared curve relative to their own thresholds.

Kill-record header (hunting log BP_HuntingLog_GS_C and the per-map kill list 0x197E791F), counted back
from the "AnimalConfigDataAsset" FString text: -26 u32 age, -22 f32 fitness, -17 f32 weight kg.
Measurement entry: 01 01 u32 len | u32 value | u32 value | u32 1 | FString Trophies.MeasurementTypes.<X>.
"""
import collections, json, os, re, struct

import nrgs

HERE = os.path.dirname(os.path.abspath(__file__))
CAL_FILE = os.path.join(HERE, "trophy_calibration.json")

# ---------------------------------------------------------------- grown racks / horns / tusks
# A grown trophy (live animal's trophy-section entry or a kill record) holds, per side
# (Trophies.Head.Left/Right, Trophies.Mouth.Lower.Left/Right for hippo tusks): 01 02 u32 len, FString mesh path,
# FString name, u32 0, FString anim BP path, FString class, u32 0, u32 nh + nh u8 HIDDEN tine bones, u32 nv +
# nv x (01 01 u32 len, FString BS_<segment>_Var, f32), ...  The hidden-tine count + the growth fraction predict
# the measured score far better than size alone (2026-10-05, 86 measured kills: whitetail bucks rmse 93 -> 21
# points, every star right; hippo tusks exact from growth alone).
_SIDE = re.compile(rb"Trophies\.(?!MeasurementTypes)[A-Za-z.]*?(Left|Right)\x00")

def _fs(b, p):
    n, = struct.unpack_from("<i", b, p); p += 4
    if n < 0:
        return b[p:p - 2 * n - 2].decode("utf-16-le"), p - 2 * n
    return b[p:p + n - 1].decode("latin-1"), p + n

def rack_sides(blob):
    """[{"side", "hidden", "bs": {name: value}}] for every trophy side in blob ([] when not grown)."""
    out = []
    for m in _SIDE.finditer(blob):
        p = m.end()
        try:
            if blob[p:p + 2] != b"\x01\x02":
                continue
            p += 6
            for _ in range(2):
                _s, p = _fs(blob, p)
                _s, p = _fs(blob, p); p += 4
            nh, = struct.unpack_from("<I", blob, p); p += 4 + nh
            nv, = struct.unpack_from("<I", blob, p); p += 4
            bs = {}
            for _ in range(nv):
                if blob[p:p + 2] != b"\x01\x01":
                    raise ValueError
                p += 6
                name, p = _fs(blob, p); v, = struct.unpack_from("<f", blob, p); p += 4
                bs[name] = v
            out.append({"side": m.group(1).decode(), "hidden": nh, "bs": bs})
        except (ValueError, struct.error, UnicodeDecodeError):
            continue
    return out

def rack_hidden(blob):
    """Hidden-tine count of a grown trophy (both sides), None when it has none."""
    sides = rack_sides(blob)
    return sum(x["hidden"] for x in sides) if sides else None

HUNTINGLOG_SECTION = 0x49672E80
KILLS_SECTION = 0x197E791F
WEIGHT_KINDS = {"WeightGrams", "Weight"}
_MT = re.compile(rb"\x01\x01(....)(....)(....)\x01\x00\x00\x00(....)Trophies\.MeasurementTypes\.([A-Za-z0-9]+)\x00", re.S)
_BS = re.compile(rb"\x01\x01(....)(....)(BS_[A-Za-z0-9_]+_Var)\x00(....)", re.S)
_CFG = re.compile(rb"DA_AnimalConfig_([A-Za-z0-9]+)_(M|F)(?:_[A-Za-z0-9_]+)?\x00")
_REQ = re.compile(r"^(?:DA|BP)_TrophyReq[a-z]*ments_([A-Za-z0-9]+?)(?:_(M|F))?$")

# ---------------------------------------------------------------- game data
def thresholds(paks_dir):
    """{(name, sex or ""): [4 ints]} from every DA_TrophyRequirements_* asset."""
    import woth2_paks as paks
    out = {}
    for t in paks.all_tocs(paks_dir):
        for p, i in t.files.items():
            b = p.rsplit("/", 1)[-1]
            if not b.endswith(".uasset"):
                continue
            m = _REQ.match(b[:-7])
            if not m:
                continue
            d = t.read(i); hdr, = struct.unpack_from("<I", d, 4); ex = d[hdr:]
            vals = list(struct.unpack_from("<4I", ex, len(ex) - 24))
            if vals == sorted(vals) and 0 < vals[0] < 100000:
                out[(m.group(1), m.group(2) or "")] = vals
    return out

def body_ranges(paks_dir):
    """{(species, sex): (min kg, max kg)} = m_weightRange of BP_BodyConfig_<species>_<sex>."""
    import woth2_paks as paks
    out = {}
    for t in paks.all_tocs(paks_dir):
        for p, i in t.files.items():
            m = re.match(r"BP_BodyConfig_?([A-Za-z]+)_(M|F)\.uasset$", p.rsplit("/", 1)[-1])   # the hare's has no "_"
            if not m:
                continue
            d = t.read(i); hdr, = struct.unpack_from("<I", d, 4); ex = d[hdr:]
            ms = list(re.finditer(rb"\x00\x05\x01\x03(....)\x01\x03(....)", ex, re.S))
            if ms:
                out[(m.group(1), m.group(2))] = struct.unpack("<ff", ms[-1].group(1) + ms[-1].group(2))
    return out

_KIND = re.compile(r"BP_TrophyMeasurement_(?:([A-Za-z]+?)_)?(WeightGrams|Weight|SkullLength|SkullWidth|BodyLength)(?:_(?!(?:M|F|U)\.)([A-Za-z]+?))?(?:_(M|F|U))?\.uasset$")
def measure_rules(paks_dir):
    """{(species, sex or ""): {kind: {"lo", "hi", "mult"}}} for the weight / skull / body-length measurements."""
    import woth2_paks as paks
    out = {}
    for t in paks.all_tocs(paks_dir):
        for p, i in t.files.items():
            m = _KIND.match(p.rsplit("/", 1)[-1])
            if not m or not (m.group(1) or m.group(3)):
                continue
            sp = m.group(1) or m.group(3); kind = m.group(2); sex = m.group(4) if m.group(4) in ("M", "F") else ""
            d = t.read(i); hdr, = struct.unpack_from("<I", d, 4); ex = d[hdr:-8]
            n = ex.rfind(b"BPTYPE_Normal\x00"); tail = ex[n + 14:] if n >= 0 else b""
            rec = {"lo": None, "hi": None, "mult": None}
            for k in range(len(tail) - 15):
                lo, hi = struct.unpack_from("<dd", tail, k)
                if 0.1 < lo < hi < 10000 and lo == round(lo, 3) and hi == round(hi, 3):
                    rec["lo"], rec["hi"] = lo, hi
                    if k + 20 <= len(tail):
                        rec["mult"] = struct.unpack_from("<i", tail, k + 16)[0]
                    break
            if rec["lo"] is None:
                mm = re.search(rb"\x03(.)\x00\x00\x00$", tail, re.S)
                if mm:
                    rec["mult"] = mm.group(1)[0]
            out.setdefault((sp, sex), {})[kind] = rec
    return out

def game_max_ages(paks_dir):
    """{subspecies: m_maxAge} from DA_AnimalSubspecies_* (the int right before m_developmentStageRanges)."""
    import woth2_paks as paks
    out = {}
    for t in paks.all_tocs(paks_dir):
        for p, i in t.files.items():
            b = p.rsplit("/", 1)[-1]
            if not (b.startswith("DA_AnimalSubspecies_") and b.endswith(".uasset")):
                continue
            d = t.read(i); hdr, = struct.unpack_from("<I", d, 4); ex = d[hdr:]
            ms = list(re.finditer(rb"(.)\x00\x00\x00\x00[\x01-\x09]\x00\x00\x00\x00\x03[\x03-\x05]\x00", ex, re.S))
            if ms and 0 < ms[0].group(1)[0] < 120:
                out[b[20:-7]] = ms[0].group(1)[0]
    return out

def growth(age, fitness, max_age, initial_age=1):
    """The game's growth fraction (FUN_1456d9f50)."""
    lo = 0.1 * initial_age
    if max_age <= lo:
        return 0.0
    return max(0.0, min(1.0, (age * fitness - lo) / (max_age - lo)))

def _match(table, species, sex):
    """Value for a subspecies id + sex from a table keyed by (asset name, sex): asset names are the
    subspecies or a shorter / slightly different spelling of it (OdocoileusHemionus, SusScrofa...)."""
    best = None
    for (name, s), v in table.items():
        if s and s != sex:
            continue
        n = min(len(name), len(species))
        common = next((k for k in range(n) if name[k] != species[k]), n)
        if common >= min(len(name), 12):
            rank = (common, s == sex)
            if best is None or rank > best[0]:
                best = (rank, v)
    return best[1] if best else None

# ---------------------------------------------------------------- save data
ARCHIVE_NAME = "kill_archive.json"

def _archive_path():
    try:
        import trainer_core
        return os.path.join(trainer_core.user_data_dir(), ARCHIVE_NAME)
    except Exception:
        return None

def kill_records(sf, archive=True):
    """Every killed animal with its measured trophy that the save holds - plus (archive=True) every one the app has
    ever seen in it: the game measures every kill, but only each map's recent kill list (~60) keeps the full record;
    older kills shrink to a ~380-byte hunting-log summary. The app keeps them in user_data_dir/kill_archive.json.
    [{"species", "sex", "age", "fit", "w", "kinds", "score", "shortlong", "hidden"}] (duplicates removed)."""
    out = _kill_records_in(sf)
    if not archive:
        return out
    path = _archive_path()
    if not path:
        return out
    key = lambda r: (r["species"], r["sex"], r["age"], round(r["fit"], 5), round(r["w"], 3))
    try:
        old = json.load(open(path))
    except (OSError, ValueError):
        old = []
    have = {key(r) for r in out}
    merged = out + [r for r in old if key(r) not in have]
    if len(merged) != len(old):
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path + ".tmp", "w") as f:
                json.dump(merged, f)
            os.replace(path + ".tmp", path)
        except OSError:
            pass
    return merged

def _kill_records_in(sf):
    out, seen = [], set()
    parts = [("Game_0/GameData", HUNTINGLOG_SECTION)] + [(f"Game_0/World_0/{m}", KILLS_SECTION) for m in ("Map01", "Map02", "Hub")]
    for part, sec in parts:
        try:
            secs = nrgs.split_sections(sf.part(part).data)[1]
        except (KeyError, ValueError, struct.error):
            continue
        for h, _v, blob in secs:
            if h != sec:
                continue
            ms = list(_CFG.finditer(blob))
            for k, m in enumerate(ms):
                seg = blob[m.end():ms[k + 1].start() if k + 1 < len(ms) else len(blob)]
                meas = [(mm.group(5).decode(), struct.unpack("<I", mm.group(2))[0]) for mm in _MT.finditer(seg)]
                if not meas or any(v >= 100000 for _n, v in meas):
                    continue
                st = blob.rfind(b"AnimalConfigDataAsset", 0, m.start())
                if st < 26:
                    continue
                age, fit = struct.unpack_from("<If", blob, st - 26); w, = struct.unpack_from("<f", blob, st - 17)
                if not (0 < age < 200 and 0 <= fit <= 1.0001 and 0 < w < 20000):
                    continue
                key = (m.group(1), m.group(2), age, round(fit, 5), round(w, 3))
                if key in seen:
                    continue
                seen.add(key)
                sl = next((struct.unpack("<f", b.group(4))[0] for b in _BS.finditer(seg) if b"ShortLong" in b.group(3)), None)
                out.append({"species": m.group(1).decode(), "sex": m.group(2).decode(), "age": age, "fit": fit, "w": w,
                            "kinds": sorted(set(n for n, _ in meas)), "score": sum(v for _n, v in meas), "shortlong": sl,
                            "hidden": rack_hidden(seg)})
    return out

def harvest_weights(sf):
    """[(species, sex, age, fitness, weight)] from every hunting-log record (measured or not)."""
    import stats
    out = []
    try:
        secs = nrgs.split_sections(sf.part("Game_0/GameData").data)[1]
    except (KeyError, ValueError):
        return out
    b = next((x for h, v, x in secs if h == HUNTINGLOG_SECTION), None)
    if not b:
        return out
    seen = set()
    for m in re.finditer(rb"\x01\x01(....)\x02(....)", b, re.S):
        try:
            r = stats.parse_record(b[m.start() + 6:])
        except Exception:
            continue
        if r.index in seen:
            continue
        seen.add(r.index)
        age, = struct.unpack_from("<I", b, m.start() + 15)
        if 0 < age < 200 and r.weight and r.weight > 0:
            out.append((r.subspecies, r.sex, age, r.rating, r.weight))
    return out

def _line(pts):
    """Least squares y = a + b x."""
    n = len(pts); sx = sum(x for x, _ in pts); sy = sum(y for _, y in pts)
    sxx = sum(x * x for x, _ in pts); sxy = sum(x * y for x, y in pts)
    d = n * sxx - sx * sx
    if n < 2 or abs(d) < 1e-12:
        return (sy / n if n else 0.0), 0.0
    b = (n * sxy - sx * sy) / d
    return (sy - b * sx) / n, b

def _robust_line(pts, tol=0.003):
    """y = a + b x on the points that agree (field dressing / wounds lower some harvest weights)."""
    a, b = _line(pts)
    for _ in range(3):
        keep = [(x, y) for x, y in pts if abs(y - (a + b * x)) <= max(tol * abs(y), 0.02)]
        if len(keep) < 3:
            break
        a, b = _line(keep)
    good = sum(1 for x, y in pts if abs(y - (a + b * x)) <= max(tol * abs(y), 0.02))
    return a, b, good

# ---------------------------------------------------------------- calibrated rack models
# Per species + sex the score is fitted from measured kills on the game's growth fraction t (and the hidden-tine
# count when that predicts better), the model picked by leave-one-out error. A calibration baked from a save with
# many kills ships with the app (trophy_calibration.json, `python3 trophy_score.py --calibrate SAVE`); a save's
# own kills replace a baked model once they are at least as many.
RACK_MODELS = {"t": lambda t, h, a, f: [1.0, t], "sqrt": lambda t, h, a, f: [1.0, t ** 0.5],
               "t+hid": lambda t, h, a, f: [1.0, t, float(h)],
               # horns that follow AGE rather than age x fitness (blesbok ewes 16.7 -> 1.5, warthog sows 42.6 -> 2.1,
               # buffalo bulls 35 -> 19 points, 2026-10-06); a = age / oldest age, f = fitness
               "age": lambda t, h, a, f: [1.0, a], "sqrt_age": lambda t, h, a, f: [1.0, a ** 0.5],
               "age+fit": lambda t, h, a, f: [1.0, a, f],
               # tines shown grow faster than linearly (kudu 29 -> 14, moose 15 -> 13 points)
               "t+hid+hid2": lambda t, h, a, f: [1.0, t, float(h), float(h) ** 2]}
HID_MAX = 80.0
RACK_MODELS["t+hid2"] = lambda t, h, a, f: [1.0, t, (HID_MAX - float(h)) ** 2]
RACK_MODELS["t+f+hid"] = lambda t, h, a, f: [1.0, t, f, float(h)]      # whitetail bucks 25 -> 24 (119 kills)
RACK_MODELS["t+a+hid"] = lambda t, h, a, f: [1.0, t, a, float(h)]
# horns / tusks that curve with age (2026-10-06, shaped line-ups): blesbok rams 5 -> 0.8, warthog sows 2.6 -> 1.2,
# warthog boars 7.9 -> 6.8 points
RACK_MODELS["age+age2"] = lambda t, h, a, f: [1.0, a, a * a]
RACK_MODELS["age+age2+af"] = lambda t, h, a, f: [1.0, a, a * a, a * f]
# warthog boars: tusks either grow their extra hidden parts (hidden > 0: scores ~96-104) or not (smooth age curve
# 36 -> 76) - a step, not a slope (6.9 -> 2.5 points, 32 kills, 2026-10-06)
RACK_MODELS["age+age2+af+step"] = lambda t, h, a, f: [1.0, a, a * a, a * f, 1.0 if (h or 0) > 0 else 0.0]
# Racks with extra (non-typical) tines also get "LengthOfAllPoints", worth hundreds of points; they are exactly the
# ones with FEWER hidden tines (elk: 23-24 hidden vs 26-28, 2026-10-06). "t+ap" adds that step: ap = hidden <= hcut.
def _ap_model(hcut, kind="t"):
    ap = lambda h: 1.0 if h is not None and h <= hcut else 0.0
    if kind == "sqrt":
        return lambda t, h, a, f: [1.0, t ** 0.5, ap(h)]
    if kind == "hid":
        return lambda t, h, a, f: [1.0, t, float(h or 0), ap(h)]
    return lambda t, h, a, f: [1.0, t, ap(h)]
AP_KINDS = {"t+ap": "t", "sqrt+ap": "sqrt", "t+hid+ap": "hid"}

def _lstsq(rows, ys):
    import numpy as np
    return [float(v) for v in np.linalg.lstsq(np.array(rows, dtype=float), np.array(ys, dtype=float), rcond=None)[0]]

def fit_rack_models(kills, max_age_of):
    """kills: kill_records(); max_age_of(species) -> oldest age. -> {"Sp|Sex": {"x", "coef", "rmse", "n"}}"""
    groups = collections.defaultdict(list)
    for r in kills:
        if set(r["kinds"]) <= WEIGHT_KINDS or r.get("hidden") is None:
            continue
        ma = max_age_of(r["species"])
        if ma:
            groups[(r["species"], r["sex"])].append((growth(r["age"], r["fit"], ma), r["hidden"], min(1.0, r["age"] / ma), r["fit"], r["score"]))
    ap = collections.defaultdict(list)
    for r in kills:
        if r.get("hidden") is not None and not set(r["kinds"]) <= WEIGHT_KINDS:
            ap[(r["species"], r["sex"])].append((r["hidden"], "LengthOfAllPoints" in r["kinds"]))
    out = {}
    for (sp, sex), pts in groups.items():
        best = None
        models = dict(RACK_MODELS)
        a = ap.get((sp, sex), [])
        yes = [h for h, f in a if f]; no = [h for h, f in a if not f]
        if len(yes) >= 2 and len(no) >= 2 and max(yes) < min(no):      # the hidden count separates them cleanly
            hcut = max(yes)
            for nm, kd in AP_KINDS.items():
                models[nm] = _ap_model(hcut, kd)
        for name, fx in models.items():
            k = len(fx(0.5, 0, 0.5, 0.5))
            if len(pts) < k + 2:
                continue
            if name in ("t+hid", "t+hid+hid2", "t+hid2", "t+f+hid", "t+a+hid") and len(set(p[1] for p in pts)) < 3:
                continue
            if name == "age+age2+af+step" and len({(p[1] or 0) > 0 for p in pts}) < 2:
                continue
            errs = []
            for i in range(len(pts)):
                tr = pts[:i] + pts[i + 1:]
                c = _lstsq([fx(t, h, a, f) for t, h, a, f, _s in tr], [p[4] for p in tr])
                t, h, a, f, y = pts[i]
                errs.append(sum(u * v for u, v in zip(c, fx(t, h, a, f))) - y)
            rmse = (sum(e * e for e in errs) / len(errs)) ** 0.5
            if best is None or rmse < best[0] - 1e-9:
                best = (rmse, name, _lstsq([fx(t, h, a, f) for t, h, a, f, _s in pts], [p[4] for p in pts]))
        if best:
            out[f"{sp}|{sex}"] = {"x": best[1], "coef": [round(v, 6) for v in best[2]], "rmse": round(best[0], 2), "n": len(pts)}
            if best[1] in AP_KINDS:
                out[f"{sp}|{sex}"]["hcut"] = max(yes)
    return out

def hidden_by_age(samples):
    """samples: [(species, sex, age, hidden)] -> {"Sp|Sex": {age: median hidden}}"""
    g = collections.defaultdict(lambda: collections.defaultdict(list))
    for sp, sex, age, h in samples:
        if h is not None:
            g[f"{sp}|{sex}"][int(age)].append(int(h))
    return {k: {str(a): sorted(v)[len(v) // 2] for a, v in sorted(d.items())} for k, d in g.items()}

def load_calibration():
    try:
        with open(CAL_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}

def live_hidden_samples(sf, terr_guids_by_map):
    """[(species, sex, age, hidden)] from every grown trophy of a living animal in the save."""
    import animals
    out = []
    for m, terr in terr_guids_by_map.items():
        try:
            part, seed, secs = animals._sections(sf, m)
            i, j = animals._find(secs, animals.ANIMAL_SECTION), animals._find(secs, animals.TROPHY_SECTION)
            if i < 0 or j < 0:
                continue
            ages = {a["id"]: a for a in animals.AnimalSection(secs[i][2], terr).animals()}
            for aid, bl in animals.TrophySection(secs[j][2]).entries:
                a = ages.get(aid)
                if a and len(bl) > 60:
                    out.append((a["species"], a["sex"], a["age"], rack_hidden(bl)))
        except (KeyError, ValueError, struct.error):
            continue
    return out

def build_calibration(save_path, out_path=CAL_FILE):
    """Bake the rack models + hidden-tine-by-age table from a save with many kills into trophy_calibration.json."""
    import woth2_paks as paks
    sf = nrgs.SaveFile(save_path)
    pd = paks.find_paks_dir(save_path)
    ma = game_max_ages(pd)
    max_age_of = lambda sp: next((v for s, v in ma.items() if s.startswith(sp) or sp.startswith(s)), None)
    kills = kill_records(sf)
    guids, _src = paks.all_map_guids(save_path, prefer_cache=True)
    samples = [(r["species"], r["sex"], r["age"], r["hidden"]) for r in kills if r.get("hidden") is not None]
    samples += live_hidden_samples(sf, {m: g[0] for m, g in guids.items()})
    cal = {"version": 1, "kills": len(kills), "models": fit_rack_models(kills, max_age_of), "hidden_by_age": hidden_by_age(samples)}
    with open(out_path, "w") as f:
        json.dump(cal, f, indent=1, sort_keys=True)
    return cal

# ---------------------------------------------------------------- the rater
class Rater:
    def __init__(self, paks_dir, sf, max_ages, shortlong_k=None):
        """max_ages: {species: oldest age}; shortlong_k: {(species, sex): ShortLong value per age-fitness}
        (to turn a measured rack into the app's size, same as animals.rack_sizes)."""
        self.req = thresholds(paks_dir)
        self.body = body_ranges(paks_dir)
        self.rules = measure_rules(paks_dir)
        self.kills = kill_records(sf)
        hw = harvest_weights(sf)
        # the game's max age: the save's oldest animal, unless 3+ harvest weights agree on an older one
        self.max_ages = dict(max_ages)
        votes = collections.defaultdict(collections.Counter)
        for sp, sex, age, fit, w in hw + [(r["species"], r["sex"], r["age"], r["fit"], r["w"]) for r in self.kills]:
            br = _match(self.body, sp, sex)
            if br and br[1] > br[0]:
                t = (w - br[0]) / (br[1] - br[0])
                if 0.02 < t < 0.98 and age * fit > 0.1:
                    votes[sp][round((age * fit - 0.1) / t + 0.1)] += 1
        for sp, c in votes.items():
            v, n = c.most_common(1)[0]
            key = next((s for s in self.max_ages if s.startswith(sp) or sp.startswith(s)), sp)
            if n >= 3 and v > self.max_ages.get(key, 0):
                self.max_ages[key] = v
        for sp, v in game_max_ages(paks_dir).items():           # the game's own value wins
            key = next((s for s in self.max_ages if s.startswith(sp) or sp.startswith(s)), sp)
            self.max_ages[key] = v
        k = {}
        ratios = collections.defaultdict(collections.Counter)          # ShortLong per age-fitness, as animals.rack_sizes
        for r in self.kills:
            if r["shortlong"] is not None and r["age"] > 0 and r["fit"] > 0.01:
                ratios[(r["species"], r["sex"])][round(r["shortlong"] / (r["age"] * r["fit"]), 3)] += 1
        for key, c in ratios.items():
            v, n = c.most_common(1)[0]
            if n >= 2:
                k[key] = v
        k.update(shortlong_k or {})
        # weight = W0 + k age fitness
        pts = collections.defaultdict(list)
        for sp, sex, age, fit, w in hw:
            pts[(sp, sex)].append((age * fit, w))
        for r in self.kills:
            pts[(r["species"], r["sex"])].append((r["age"] * r["fit"], r["w"]))
        self.weight = {}
        for key, p in pts.items():
            if len(p) >= 3:
                a, b, good = _robust_line(p)
                if good >= 3 and good >= 0.6 * len(p) and b >= 0:
                    self.weight[key] = (a, b)
        # score per kg for weight-scored animals
        f = collections.defaultdict(list)
        for r in self.kills:
            if set(r["kinds"]) <= WEIGHT_KINDS:
                f[(r["species"], r["sex"])].append(r["score"] / r["w"])
                f[(r["species"], "")].append(r["score"] / r["w"])
        self.factor = {key: float(f"{sorted(v)[len(v) // 2]:.2g}") for key, v in f.items()}   # 10, 20, 200 ...
        # size -> points for everything else
        self.curve_pts = collections.defaultdict(list)
        rel = []
        for r in self.kills:
            if set(r["kinds"]) <= WEIGHT_KINDS:
                continue
            sp = self._species(r["species"]); req = self.thresholds_for(sp or r["species"], r["sex"])
            size = None
            kk = _match({(s, x): v for (s, x), v in k.items()}, r["species"], r["sex"]) if k else None
            if r["shortlong"] is not None and kk and sp and self.max_ages.get(sp):
                size = min(1.0, r["shortlong"] / (kk * self.max_ages[sp]))
            elif sp and self.max_ages.get(sp):
                size = min(1.0, r["age"] * r["fit"] / self.max_ages[sp])
            if size is None:
                continue
            self.curve_pts[(sp, r["sex"])].append((size, r["score"]))
            if req:
                rel.append((size ** 0.5, r["score"] / req[3]))
        self.shared = _line(rel) if len(rel) >= 5 else (0.29, 0.62)
        self.shared_err = (sum((self.shared[0] + self.shared[1] * x - y) ** 2 for x, y in rel) / len(rel)) ** 0.5 if len(rel) >= 5 else 0.12
        cal = load_calibration()
        self.models = dict(cal.get("models", {}))
        mine = fit_rack_models(self.kills, lambda sp: self.max_ages.get(self._species(sp) or sp))
        for key, mdl in mine.items():                      # the save's own kills win once they are as many
            if key not in self.models or mdl["n"] >= self.models[key]["n"]:
                self.models[key] = mdl
        self.hidden_age = dict(cal.get("hidden_by_age", {}))
        own = hidden_by_age([(r["species"], r["sex"], r["age"], r.get("hidden")) for r in self.kills])
        for key, d in own.items():
            self.hidden_age.setdefault(key, {}).update(d)
        self.curves = {}
        for key, p in self.curve_pts.items():
            if len(p) >= 3 and max(x for x, _ in p) - min(x for x, _ in p) >= 0.15:
                best = None
                for pw in (0.5, 1.0):
                    a, b = _line([(x ** pw, y) for x, y in p])
                    err = sum((a + b * x ** pw - y) ** 2 for x, y in p)
                    if b > 0 and (best is None or err < best[0]):
                        best = (err, pw, a, b)
                if best:
                    self.curves[key] = best[1:] + ((best[0] / max(1, len(p) - 2)) ** 0.5,)

    def exact_score(self, species, sex, age, fitness):
        """The game's own score for weight / skull / body-length trophies, or None (racks, horns, tusks)."""
        rules = dict(_match({k: v for k, v in self.rules.items() if not k[1]}, species, "") or {})
        rules.update(_match({k: v for k, v in self.rules.items() if k[1] == sex}, species, sex) or {})
        if not rules:
            return None
        ma = self.max_ages.get(species) or next((v for s, v in self.max_ages.items() if s.startswith(species) or species.startswith(s)), None)
        if not ma:
            return None
        g = growth(age, fitness, ma)
        total = 0
        for kind, r in rules.items():
            if kind in WEIGHT_KINDS:
                br = _match(self.body, species, sex)
                if not br:
                    return None
                kg = br[0] + (br[1] - br[0]) * g
                total += int(kg * 1000 / (r["mult"] or 1) + 1e-4) if kind == "WeightGrams" else int(kg * (r["mult"] or 1) + 1e-4)
            else:
                if r["lo"] is None:
                    return None
                total += int((r["lo"] + (r["hi"] - r["lo"]) * g) * (r["mult"] or 1) + 1e-4)
        return total

    def _species(self, name):
        return next((s for s in self.max_ages if s.startswith(name) or name.startswith(s)), None)

    def thresholds_for(self, species, sex):
        return _match(self.req, species, sex)

    def _model(self, species, sex):
        key = f"{species}|{sex}"
        if key in self.models:
            return self.models[key]
        return next((v for k, v in self.models.items() if k.endswith("|" + sex) and (k.startswith(species) or species.startswith(k.split("|")[0]))), None)

    def _hidden_for(self, species, sex, age):
        d = self.hidden_age.get(f"{species}|{sex}")
        if not d:
            return None
        ages = sorted(int(a) for a in d)
        a = min(ages, key=lambda x: (abs(x - age), x))
        return d[str(a)]

    # Cows the game never measures (no antlers / horns), although DA_TrophyRequirements still has lines for the
    # species: bison 8 kills, moose 4, elk 2 recorded without a single measurement (2026-10-06); kudu cows are hornless.
    NO_TROPHY = {("BisonBisonAthabascae", "F"), ("AlcesAlcesAndersoni", "F"), ("CervusCanadensisNelsoni", "F"),
                 ("TragelaphusStrepsicerosStrepsiceros", "F")}

    def rate(self, species, sex, age, fitness, size, hidden=None, blob=None, weight=None, variant=""):
        """-> {"score": int, "stars": 1..5, "stars_lo", "stars_hi" (the range the game's own measurement can
        land in: the same for weight-scored animals), "req": [4], "how": "weight"|"curve"|"shared"} or None."""
        req = self.thresholds_for(species, sex)
        if not req or (species, sex) in self.NO_TROPHY:
            return None
        st = lambda v: 0 if v < 1 else 1 + sum(1 for t in req if v >= t)      # the game's rule (FUN_1456dbc20)
        exact = self.exact_score(species, sex, age, fitness)
        if exact is None and blob:
            try:
                import rackscore
                rs = rackscore.score(species, sex, age, fitness, blob, self.max_ages.get(self._species(species) or species), weight=weight, variant=variant)
            except Exception:
                rs = None
            if rs:
                return {"score": rs["score"], "stars": st(rs["score"]), "stars_lo": st(rs["score"]), "stars_hi": st(rs["score"]),
                        "req": req, "how": "rack3d"}
        if exact is not None:
            return {"score": exact, "stars": st(exact), "stars_lo": st(exact), "stars_hi": st(exact), "req": req, "how": "exact"}
        key = (species, sex)
        wm = self.weight.get(key) or _match({(s, x): v for (s, x), v in self.weight.items()}, species, sex)
        fac = self.factor.get(key) or _match(self.factor, species, sex) or _match(self.factor, species, "")
        if wm and fac:
            kg = wm[0] + wm[1] * min(age, self.max_ages.get(species, age)) * fitness
            score = int(fac * kg + 1e-6)
            how = "weight"; err = 0.0
        elif (mdl := self._model(species, sex)) and self.max_ages.get(self._species(species) or species) and \
                (mdl["x"] not in ("t+hid", "t+ap", "sqrt+ap", "t+hid+ap", "t+hid+hid2", "t+hid2", "t+f+hid", "t+a+hid", "age+age2+af+step") or hidden is not None or self._hidden_for(species, sex, age) is not None):
            ma_ = self.max_ages[self._species(species) or species]
            t = growth(age, fitness, ma_); a_ = min(1.0, age / ma_)
            h = hidden if hidden is not None else self._hidden_for(species, sex, age)
            ap = mdl["x"] in AP_KINDS
            fx = _ap_model(mdl["hcut"], AP_KINDS[mdl["x"]]) if ap else RACK_MODELS[mdl["x"]]
            score = int(round(sum(c * x for c, x in zip(mdl["coef"], fx(t, h if ap else (h or 0), a_, fitness)))))
            how = "calibrated"; err = mdl["rmse"]
        elif key in self.curves:
            pw, a, b, err = self.curves[key]
            score = int(round(a + b * max(0.0, size) ** pw)); how = "curve"
        else:
            a, b = self.shared
            score = int(round((a + b * max(0.0, size) ** 0.5) * req[3])); how = "shared"; err = self.shared_err * req[3]
        return {"score": score, "stars": st(score), "stars_lo": st(score - err), "stars_hi": st(score + err), "req": req, "how": how}

if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3 and sys.argv[1] == "--calibrate":
        cal = build_calibration(sys.argv[2])
        for k, v in sorted(cal["models"].items()):
            print(f"{k}: {v['x']} rmse {v['rmse']} from {v['n']} kills")
        print(f"{len(cal['hidden_by_age'])} hidden-tine tables -> {CAL_FILE}")
