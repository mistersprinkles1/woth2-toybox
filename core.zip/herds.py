"""Herd size, as the game does it (decoded 2026-10-11 from BP_AnimalTerritoryInfrastructure / BP_HerdEcosystem /
BP_HerdAnimalSubspecies and checked against two saves: every one of 1359 + 657 herds is a species its territory
allows and sits inside its size range).

  * Every herd territory has a size type: Big, Medium, Small or Solitary (the territory's
    DA_AnimalTerritoryInfrastructure_* asset, Size tag). Each animal has its own min-max per type
    (DA_AnimalSubspecies_* mGroupSizes).
  * When a map's animals are first made, a herd gets a random size inside that range.
  * Every game year, after the animals age, each herd is topped up to its target with young animals (born around
    the herd's fitness). A herd is never cut down by this; only hunting and old age make it smaller.
  * target = min + floor(t x (max - min + 1)), at most max, where t = herd fitness placed between the land's
    lowest starting fitness (t = 0) and the top (t = 1): 100 % on private lands (their cap can be raised with
    habitat enhancements), the land's base cap on public lands. (The game's fitness -> spawn quantity curve is a
    straight line for every animal.)
"""
import json, os, re, struct

VERSION = 1
SIZES = ("Big", "Medium", "Small", "Solitary")

def _uv_present(d):
    """Property indices present in an unversioned property block."""
    import mapdata
    return mapdata._uv_header(d, 0)[0]

def group_sizes(paks_dir):
    """{subspecies: {"Big": [min, max], ...}} from DA_AnimalSubspecies_* mGroupSizes."""
    import woth2_paks as paks, zenpkg
    out = {}
    for t in paks.all_tocs(paks_dir):
        for f, i in t.files.items():
            m = re.match(r"DA_AnimalSubspecies_(\w+)\.uasset$", f.rsplit("/", 1)[-1])
            if not m:
                continue
            z = zenpkg.ZenPackage(t.read(i)); dat = z.export_data[0]
            sizes = {}
            for k in range(len(z.names)):
                n = z.name(k)
                if not n.startswith("HerdManagement.AnimalSubspecies.Size."):
                    continue
                for mm in re.finditer(re.escape(bytes([3, k])) + rb"\x00\x00\x00\x00...", dat, re.S):
                    q = mm.end(); hdr = int.from_bytes(dat[q:q + 2], "little")
                    if hdr & 0xff7f != 0x0700:              # S_AnimalSubspeciesGroupSize: 3 properties
                        continue
                    q += 2; zm = 0
                    if hdr & 0x80: zm = dat[q]; q += 1
                    vals = []
                    for j in range(3):
                        if zm & (1 << j): vals.append(0)
                        else: vals.append(dat[q]); q += 1
                    if n.split(".")[-1] in SIZES and vals[1] > 0:
                        sizes[n.split(".")[-1]] = vals[:2]
            if sizes:
                out[m.group(1)] = sizes
    return out

def territory_sizes(paks_dir, mapname):
    """{territory id: size type} - each territory's DA_AnimalTerritoryInfrastructure_* (an import of its
    TerritoryData in the map's spawn data) and that asset's Size tag."""
    import woth2_paks as paks, zenpkg
    infra = {}
    for t in paks.all_tocs(paks_dir):
        for f, i in t.files.items():
            b = f.rsplit("/", 1)[-1]
            if b.startswith("DA_AnimalTerritoryInfrastructure_") and b.endswith(".uasset"):
                z = zenpkg.ZenPackage(t.read(i))
                tags = [z.name(k).split(".")[-1] for k in range(len(z.names)) if z.name(k).startswith("HerdManagement.AnimalSubspecies.Size.")]
                if tags: infra[b[:-7]] = tags[0]
    out = {}
    for t in paks.all_tocs(paks_dir):
        for path, i in t.files.items():
            nm = path.rsplit("/", 1)[-1]
            if not ((nm.startswith(f"SD_{mapname}_") or nm.startswith(f"{mapname}_SpawnData")) and nm.endswith(".uasset")) \
                    or "Signs" in nm or "plines" in nm or "SubAreas" in nm:
                continue
            try:
                z = zenpkg.ZenPackage(t.read(i))
            except Exception:
                continue
            names = [n[0] for n in z.names]
            pk = [n[0] if isinstance(n, tuple) else n for n in z.package_names]
            for e, dd in zip(z.exports, z.export_data):
                ci = e[2] & 0xffffffff
                if ci >= len(names) or names[ci] != "TerritoryData" or len(dd) < 28:
                    continue
                g = len(dd) - 20
                tid = "".join("%08X" % struct.unpack_from("<I", dd, g + j)[0] for j in range(0, 16, 4))
                for o in range(0, len(dd) - 3):
                    v, = struct.unpack_from("<i", dd, o)
                    if -len(z.imports) <= v < 0:
                        s = zenpkg.split_import(z.imports[-v - 1])
                        if s and s[0] < len(pk) and "DA_AnimalTerritoryInfrastructure_" in pk[s[0]]:
                            size = infra.get(pk[s[0]].rsplit("/", 1)[-1])
                            if size: out[tid] = size
                            break
    return out

def ecosystems(paks_dir, mapname):
    """{land key: {"raise": bool (cap can be raised: private lands), subspecies: [lowest start, base cap]}}
    from DA_HerdEcosystem_<Map>_<Land>."""
    import woth2_paks as paks, zenpkg
    out = {}
    for t in paks.all_tocs(paks_dir):
        for f, i in t.files.items():
            b = f.rsplit("/", 1)[-1]
            m = re.match(rf"DA_HerdEcosystem_{mapname}_(\w+)\.uasset$", b)
            if not m:
                continue
            z = zenpkg.ZenPackage(t.read(i)); dat = z.export_data[0]
            names = [z.name(k) for k in range(len(z.names))]
            land = {"raise": 2 in _uv_present(dat)}         # mSoftCapCanBeIncreased (only written when true)
            for mm in re.finditer(rb"\x00\x03(.)\x00{7}(.{1,4}?)((?:.{7}[\x3f\x3e\x3d\x3c]){5})", dat, re.S):
                k = mm.group(1)[0]
                vals = struct.unpack("<5d", mm.group(3))
                if k < len(names) and names[k].startswith("Animals.Subspecies.") and all(0 <= v <= 1 for v in vals):
                    land[names[k].split(".")[-1]] = [round(vals[0], 4), round(vals[4], 4)]
            out[m.group(1)] = land
    return out

def target(fitness, low, top, gmin, gmax):
    """The herd's refill target at this herd fitness (see the module notes)."""
    if top - low <= 1e-6:
        return 0
    tt = min(1.0, max(0.0, (fitness - low) / (top - low)))
    return min(gmax, max(gmin, gmin + int(tt * (gmax - gmin + 1))))

def herd_members(asv, terr_guids):
    """{territory id: [animal id, ...]} from the save's AnimalSaveSystem herd list. The list starts at the top of the
    section (u32 herd count); each herd record holds the herd's transform (scale 1, 1, 1), u32 n and its n member ids,
    and is closed by its territory GUID. A herd whose territory is not in terr_guids sits in the same stretch as the
    next known one, so the LAST transform before a GUID is that herd's own. Harvested and dead animals are not listed."""
    pos = sorted((asv.find(g), g) for g in terr_guids if asv.find(g) >= 0)
    one = struct.pack("<3d", 1.0, 1.0, 1.0)
    out = {}; prev = 0
    for p, g in pos:
        rec = asv[prev:p]; prev = p + 16
        j = rec.rfind(one)
        if j < 0 or j + 28 > len(rec):
            continue
        n, = struct.unpack_from("<I", rec, j + 24)
        if n <= 500 and j + 28 + 4 * n <= len(rec):
            a, b, c, d = struct.unpack("<IIII", g)
            out[f"{a:08X}{b:08X}{c:08X}{d:08X}"] = list(struct.unpack_from("<%dI" % n, rec, j + 28))
    return out

def herd_counts(asv, terr_guids):
    """{territory id: animals in the herd now} (the length of each herd's member list, herd_members)."""
    return {t: len(ids) for t, ids in herd_members(asv, terr_guids).items()}

def herd_fitness(hm, terr_guids=None):
    """{territory id: herd fitness} from the save's BP_HerdManagement_<Map>_WS_C section: one record per species per
    land (BP_HerdAnimalSubspecies Write Archive), framed by its Animals.Subspecies.<name> header: f64 fitness,
    u8 herd count, that many territory GUIDs. Read by the frame, so a record that also lists a herd the map does
    not draw still counts for all its herds (it dropped every mule deer / moose herd of some lands before)."""
    out = {}
    for m in re.finditer(rb"Animals\.Subspecies\.[A-Za-z]+\x00\x01\x00\x00\x00\x01\x02.{4}\x01(.{4})", hm, re.S):
        l2, = struct.unpack("<I", m.group(1)); pay = hm[m.end():m.end() + l2]
        if len(pay) < 9: continue
        f, = struct.unpack_from("<d", pay, 0); n = pay[8]
        if not (0.0 <= f <= 1.0) or 9 + 16 * n > len(pay): continue
        for k in range(n):
            a, b, c, d = struct.unpack_from("<IIII", pay, 9 + 16 * k)
            out[f"{a:08X}{b:08X}{c:08X}{d:08X}"] = f
    return out
